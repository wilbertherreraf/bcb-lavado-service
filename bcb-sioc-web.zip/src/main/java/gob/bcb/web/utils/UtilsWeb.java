package gob.bcb.web.utils;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

public class UtilsWeb {
	public static void log(FacesContext facesContext, String message) {
		facesContext.getExternalContext().log(message);
	}

	public static void log(FacesContext facesContext, String message, Exception exception) {
		facesContext.getExternalContext().log(message, exception);
	}

	public static void reportError(FacesContext facesContext, String message, String detail, Exception exception) {
		facesContext.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, message, detail));
		if (exception != null) {
			facesContext.getExternalContext().log(message, exception);
		}
	}

	public static void reportError(FacesContext facesContext, String messageId, Exception exception) {
		FacesMessage message = getMessage(messageId, null, FacesMessage.SEVERITY_ERROR);
		facesContext.addMessage(null, message);
		if (exception != null) {
			facesContext.getExternalContext().log(message.getSummary(), exception);
		}
	}

	public static void log(ServletContext servletContext, String message) {
		servletContext.log(message);
	}

	protected static void addInvalidStateChangeMessage(FacesContext context, boolean approve) {

		String message;
		if (approve) {
			message = "You cannot approve a project with this status.";
		} else {
			message = "You cannot reject a project with this status.";
		}
		context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, message, ""));
	}

	protected static ClassLoader getCurrentClassLoader(Object defaultObject) {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		if (loader == null) {
			loader = defaultObject.getClass().getClassLoader();
		}
		return loader;
	}

	public static String getDisplayString(String bundleName, String id, Object params[], Locale locale) {
		String text = null;
		ResourceBundle bundle = ResourceBundle.getBundle(bundleName, locale, getCurrentClassLoader(params));
		try {
			text = bundle.getString(id);
		} catch (MissingResourceException e) {
			text = "!! key " + id + " not found !!";
		}
		if (params != null) {
			MessageFormat mf = new MessageFormat(text, locale);
			text = mf.format(params, new StringBuffer(), null).toString();
		}
		return text;
	}

	public static FacesMessage getMessage(String messageId, Object params[], FacesMessage.Severity severity) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		String bundleName = facesContext.getApplication().getMessageBundle();
		if (bundleName != null) {
			String summary = null;
			String detail = null;
			Locale locale = facesContext.getViewRoot().getLocale();
			ResourceBundle bundle = ResourceBundle.getBundle(bundleName, locale, getCurrentClassLoader(params));
			try {
				summary = bundle.getString(messageId);
				detail = bundle.getString(messageId + ".detail");
			} catch (MissingResourceException e) {
			}
			if (summary != null) {
				MessageFormat mf = null;
				if (params != null) {
					mf = new MessageFormat(summary, locale);
					summary = mf.format(params, new StringBuffer(), null).toString();
				}
				if (detail != null && params != null) {
					mf.applyPattern(detail);
					detail = mf.format(params, new StringBuffer(), null).toString();
				}
				return (new FacesMessage(severity, summary, detail));
			}
		}
		return new FacesMessage(severity, "!! key " + messageId + " not found !!", null);
	}
	
	
	public static void limpiarCache(HttpSession session){
		
		System.out.println(" ---------------------- ingresando  a limpiar cache");
		session.removeAttribute("crudParametros");
		session.removeAttribute("listaOperacionesController");
		session.removeAttribute("listaOperacionesPController");
		session.removeAttribute("listaSolicitudesController");
		session.removeAttribute("principalController");
		session.removeAttribute("solicitudesASFController");
		session.removeAttribute("solicitudesASFAutController");
		session.removeAttribute("solicitudesAutController");
		session.removeAttribute("solicitudesLocalController");
		session.removeAttribute("solicitudesBolsinController");
		session.removeAttribute("ventaController");
		session.removeAttribute("solicitudesBolsinController");
		session.removeAttribute("solicitudB");
		session.removeAttribute("solicitante");
		session.removeAttribute("listaBolsinPController");
		session.removeAttribute("listaBolsinPVentaDirController");
		session.removeAttribute("listaBolsinVController");
		session.removeAttribute("listaBolsinVIntController");
		session.removeAttribute("operacionesDEEController");
		session.removeAttribute("operacionesDEMController");
		session.removeAttribute("operacionesDEPController");
		session.removeAttribute("reportesBolsinController");
		session.removeAttribute("reportesEst1Controller");
		session.removeAttribute("reportesEst2Controller");
		session.removeAttribute("reportesOPController");
		session.removeAttribute("solBolsinIntController");
		session.removeAttribute("solicitudesASFAController");
		session.removeAttribute("solicitudesASFAutController");
		session.removeAttribute("solicitudesASFController");
		session.removeAttribute("solicitudesASFIntController");
		session.removeAttribute("solicitudesASFModController");
		session.removeAttribute("solicitudesAutController");
		session.removeAttribute("solicitudesBCBAutController");
		session.removeAttribute("solicitudesBCBController");
		session.removeAttribute("solicitudesBCBIntController");
		session.removeAttribute("solicitudesBolsinController");
		session.removeAttribute("solicitudesDSFController");
		session.removeAttribute("solicitudesDSFOpeController");
		session.removeAttribute("solicitudesIntController");
		session.removeAttribute("solicitudesLocalController");
		session.removeAttribute("solicitudesLocalIntController");
		session.removeAttribute("solicitudesLocalYController");
		session.removeAttribute("solicitudesModController");
		session.removeAttribute("ventaController");
		session.removeAttribute("ventaIntController");
		session.removeAttribute("ventaIntOldController");
		session.removeAttribute("ventaLController");
		session.removeAttribute("ventaLIntController");
		session.removeAttribute("ventaOController");
		session.removeAttribute("ventaOIntController");
		session.removeAttribute("ventaPController");
		session.removeAttribute("venta");
		session.removeAttribute("solicitud");
		session.removeAttribute("listaOrdenPAController");		
		session.removeAttribute("opa");		
		session.removeAttribute("datos");
		session.removeAttribute("mens");
		session.removeAttribute("venta");
		session.removeAttribute("operacionS");
		session.removeAttribute("listaBolsinVVentaDirController");
		session.removeAttribute("solicitudBS");		
		session.removeAttribute("estadisticaController");
		session.removeAttribute("est");		
		session.removeAttribute("listaExportadoresController");
		session.removeAttribute("detalleExportadorController");
	}

}
