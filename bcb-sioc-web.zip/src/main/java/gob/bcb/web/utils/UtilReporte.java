package gob.bcb.web.utils;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;



import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;
import gob.bcb.bpm.pruebaCU.SocSolicitante;

import gob.bcb.web.utils.ConstructorReporteDinamico;

import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.controller.ReportesBolsinController;
import gob.bcb.service.servicioSioc.pojos.OperacionesCambiarias;
import gob.bcb.service.servicioTres.model.FeriadoDao;



public class UtilReporte extends BaseBeanController
{
	private Logger log = Logger.getLogger(UtilReporte.class);
	public String nombreReporte;
	public static final String REPORTE_FORMATO = "reportFormato";
	private List<BigDecimal> bolsin = new ArrayList<BigDecimal>();
	private FeriadoDao feriadoDao;
	
//	private final static Logger log = Logger.getLogger(reporte.class);

	/**
	 * Constructor de la clase.
	 */
	public UtilReporte()
	{
		// Método que recupera varaibles de sesión.
		recuperarVisit();
	}
	
	
	
	public void setFeriadoDao(FeriadoDao feriadoDao) {
		this.feriadoDao = feriadoDao;
	}



	/**
	 * Método que genera el encabezado del reporte.
	 * @param anho Año del reporte.
	 * @param mes Mes del reporte.
	 * @param pFechaFin Fecha fin de reporte.
	 * @param pConPorcentaje Verifica si incluye el encabezado porcentaje.
	 * @param pConTotalAnual Verifica si incluye el encabezado de total anual
	 * @param pConSemana Verifica si va a incluir semana al encabezado
	 * @param pConDias TODO
	 * @return Lista de resultado.
	 */
	public List<String> generarEncabezadoOpcional(int anho, int mes, Date pFechaFin, boolean pConPorcentaje, boolean pConTotalAnual, boolean pConSemana, boolean pConDias) 
	{
		
		List<String> headers = new ArrayList<String>();
		headers.add(" ");
		if(pConSemana){			
			headers.add(" ");
		}
		
		if(pConDias){			
			headers.add(" ");
		}
		
		headers.add(String.valueOf(anho - 1));
		if(pConSemana || pConDias){
			// Iteramos para obtener los meses
			for (int i = 0; i < mes; i++) {
				try 
				{
					if(pConSemana){
						if (i != mes) {
							String nomMes = getNombreMesCorto(0, i);
							headers.add(nomMes);

						}
					} else{
						String nomMes = getNombreMesCorto(0, i);
						headers.add(nomMes);
					}
					
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} else{
			// Iteramos para obtener los meses
			for (int i = 0; i <= mes; i++) {
				try 
				{
					if(pConSemana){
						if (i != mes) {
							String nomMes = getNombreMesCorto(0, i);
							headers.add(nomMes);

						}
					} else{
						String nomMes = getNombreMesCorto(0, i);
						headers.add(nomMes);
					}
					
					
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
			
		if(pConDias){
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calDia = Calendar.getInstance();
			// Obtenemos el número del dia en funcion a la fecha final
			calDia.setTime(pFechaFin);
			int nroDia = calDia.get(Calendar.DAY_OF_MONTH);
			for (int i = 1; i <= nroDia; i++) {
				calDia.set(Calendar.DAY_OF_MONTH, i);
	            int diaSemana = calDia.get(Calendar.DAY_OF_WEEK);

	            // Verificamos si es fin de semana
	            if( (diaSemana >= Calendar.MONDAY) && (diaSemana <= Calendar.FRIDAY)){
	            	// Verificamos que no existan feriados
	            	String fecha = format.format(calDia.getTime());
	            	boolean existeFeriado = feriadoDao.existeFeriado(fecha, fecha);
	            	if(!existeFeriado){
	            		headers.add(String.valueOf(i));	
	            	}
	            	
	            }				
				
			}
		}
		
		
		
		if(pConSemana){
			Calendar calSemana = Calendar.getInstance();			
			
			// Obtenemos el número de semana en función a la fecha final
			calSemana.setTime(pFechaFin);
			int nroSemana = calSemana.get(Calendar.WEEK_OF_MONTH);
			
			for (int i = 0; i < nroSemana; i++) {
				headers.add(String.valueOf(i+1));	
			}
		}
		
		headers.add("Total");
		if(pConTotalAnual){
			headers.add("Total " + anho);	
		}
		
		if(pConPorcentaje){
			headers.add(String.valueOf(anho) + " %");
		}
			
		
		// Retorna encabezado.
		return headers;
	}
	
	/**
	 * Método que genera informacion del cuerpo del reporte.
	 * @param anho Año del reporte.
	 * @param mes Mes del reporte.
	 * @param pFechaFin Fecha fin de reporte.
	 * @param pConSemana TODO
	 * @param pConDia TODO
	 * @return Lista de resultado.
	 */
	public List<List<String>> generarCuerpoReporte(int anho, int mes, Date pFechaFin, String pNombreReporte, boolean pConSemana, boolean pConDia) 
	{
		// Instancia tipo de formato.
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);

		// Instancia fecha de inicio y fecha fin.
		Date fecIniMes = null;
		Date fecFinMes = null;
		
		// Instancia objeto de tipo "Calendar".
		Calendar cal = Calendar.getInstance();
		
		// Almacena gestion anterior.
		cal.set(Calendar.YEAR, anho - 1);
		// Almacena primer dia y mes de la gestión anterior.
		cal.set(Calendar.DAY_OF_YEAR, 1);		
		// Obtiene primer dia y mes de la gestión anterior.
		Date fechaInicio = cal.getTime();
		
		// Obtiene el ultimo dia del año
		cal.set(Calendar.YEAR, anho - 1);
		// Almacena ultimo mes de la gestión.
		cal.set(Calendar.MONTH, 11); 
		// Almacena ultimo dia de la gestión.
		cal.set(Calendar.DAY_OF_MONTH, 31); 

		// Obtiene ultimo dia de la gestión.
		Date fechaFin = cal.getTime();
		
		// Instancia lista resultado de tipo cadena.
		List<List<String>> rows = new ArrayList<List<String>>();
		
		HashMap<BigDecimal, List<List<String>>> hashMap = new HashMap<BigDecimal, List<List<String>>>();
		
		
			
		// Obtiene lista de entidades bancarias de sistema financiero.
		List<OperacionesCambiarias> instituciones = this.obtenerListaEntidadBancaria(fechaInicio, pFechaFin, pNombreReporte);//getSolicitudBean().getSocSolicitudesDao().obtenerEntidadBancariaBolsinSistemaFinanciero(fechaInicio, fecha2);
			
		// Añadimos los valores a las columanas
		for (OperacionesCambiarias operacionesCambiarias : instituciones) 
		{
			
			// Instancia lista de tipo cadena.
			List<String> row = new ArrayList<String>();
			
//			if(pConDia){			
//				row.add(" ");
//			}
			
			
			// Inicializa variables para ralizar la suma.
			BigDecimal vSumaGestionAnterior =  BigDecimal.ZERO;
			BigDecimal vSumaGestionActual =   BigDecimal.ZERO;
			BigDecimal vSumaMes = BigDecimal.ZERO;
			BigDecimal vSumaSemana = BigDecimal.ZERO;			
			BigDecimal vSumaSemanaTotal =  BigDecimal.ZERO;
			
			// Obtiene y adiciona objeto institución.
			row.add(operacionesCambiarias.getInstitucion());
			
			// Adiciona a la lista resultante.
			rows.add(row);			
				
			// Adiciona campos en blanco.
			row.add(0, " ");			
			
			// Obtiene suma gestión anterior.
			vSumaGestionAnterior = this.obtenerMontoEntidadBancariaPorFechaIdInstitucionNombreReporte(operacionesCambiarias.getCodInstitucion(), fechaInicio, fechaFin,pNombreReporte);
					
			// Adiciona suma gestion anterior.
			row.add(decimalFormat.format(vSumaGestionAnterior));			

			// Añadimos los valores de las filas en funcion al tiemmpo
			for (int i = 0; i <= mes; i++) 
			{				
					// Adiciona año actual.
					cal.set(Calendar.YEAR, anho);
					// Adiciona mes correspondiene a la iteración.
					cal.set(Calendar.MONTH, i);
					// Adiciona dia inicial del mes.
					cal.set(Calendar.DATE,	cal.getActualMinimum(Calendar.DAY_OF_MONTH));					
					// Obtiene la fecha inicial. 
					fecIniMes = cal.getTime();
					// Adiciona dia final del mes.
					cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
					// Obtiene la fecha final.
					fecFinMes = cal.getTime();
					
					// Verifica si el mes es igual.
					if(i!= mes)
					{
						// Obtiene suma del mes correspondiente.
						vSumaMes = this.obtenerMontoEntidadBancariaPorFechaIdInstitucionNombreReporte(operacionesCambiarias.getCodInstitucion(), fecIniMes, fecFinMes,pNombreReporte);
						// Adiciona suma del mes.
						row.add(decimalFormat.format(vSumaMes));
						
						// Suma la gestión actual segun los meses.
						vSumaGestionActual = vSumaGestionActual.add(vSumaMes);						
					}
					else
					{
						if(pConSemana){
							// Instancia objeto de tipo calendario.
							Calendar calSemana = Calendar.getInstance();						
							// Obtiene el número de semana en función a la fecha final.
							calSemana.setTime(pFechaFin);
							// Instancia cantidad de semanas.
							int nroSemana = calSemana.get(Calendar.WEEK_OF_MONTH);
							// Obtiene las fechas de las semanas obtenidas en función a la fecha inicial
							calSemana.setTime(fecIniMes);
							
							// Recorre el numer de semanas.
							for (int j = 0; j < nroSemana; j++) 
							{
								// Instancia fecha correspondiente de la samana.
								calSemana.set(Calendar.WEEK_OF_MONTH, j);
								
								// Obtiene fecha de semana.
								List<Date> fechas = obtenerFechasInicioFin(fecIniMes, pFechaFin, j);
								
								if(fechas.size() > 0){
									// Obtener monto de entidad bancaria por fechas de semana.
									vSumaSemana = this.obtenerMontoEntidadBancariaPorFechaIdInstitucionNombreReporte(operacionesCambiarias.getCodInstitucion(), fechas.get(0), fechas.get(fechas.size()-1),pNombreReporte);
								}
									
								
								
								// Adiciona suma de la semana
								row.add(decimalFormat.format(vSumaSemana));
								
								// Suma monto de la semana.
								vSumaSemanaTotal = vSumaSemanaTotal.add(vSumaSemana);
								
								// Suma la gestión actual.
								vSumaGestionActual = vSumaGestionActual.add(vSumaSemana);
								
								
							}
						}
						
						if(pConDia){
							// Instancia objeto de tipo calendario.
							Calendar calDia = Calendar.getInstance();
							SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
							
							calDia.setTime(pFechaFin);
							int nroDia = calDia.get(Calendar.DAY_OF_MONTH);

					        for (int j = 1; j <= nroDia; j++) {
					        	calDia.set(Calendar.DAY_OF_MONTH, j);
					            int diaSemana = calDia.get(Calendar.DAY_OF_WEEK);

					            // Verificamos si es fin de semana
					            if( (diaSemana >= Calendar.MONDAY) && (diaSemana <= Calendar.FRIDAY)){
					            	
					            	// Verificamos feriados
					            	String fecha = format.format(calDia.getTime());
					            	boolean existeFeriado = feriadoDao.existeFeriado(fecha, fecha);
					            	if(!existeFeriado){
					            		vSumaSemana = this.obtenerMontoEntidadBancariaPorFechaIdInstitucionNombreReporte(operacionesCambiarias.getCodInstitucion(), calDia.getTime(), calDia.getTime(),pNombreReporte);
						            	// Adiciona suma de la semana
										row.add(decimalFormat.format(vSumaSemana));
										
										// Suma monto de la semana.
										vSumaSemanaTotal = vSumaSemanaTotal.add(vSumaSemana);
										
										// Suma la gestión actual.
										vSumaGestionActual = vSumaGestionActual.add(vSumaSemana);
					            	}
					            	
					            }					            
					         
					        }						
							
						}
						
						
						// Adiciona suma total de la semana.
						row.add(decimalFormat.format(vSumaSemanaTotal));
						// Adiciona suma total de la gestión.
						row.add(decimalFormat.format(vSumaGestionActual));
						
						List<List<String>> rowValues = null;
						
						if(hashMap.containsKey(vSumaGestionActual)){
							rowValues = hashMap.get(vSumaGestionActual);
							rowValues.add(row);
						}else{
							rowValues = new ArrayList<List<String>>();
							rowValues.add(row);
							hashMap.put(vSumaGestionActual, rowValues);
						}
						
					}																
			}
		}
		
		// Ordenamos las filas de acuerdo a los montos totales
		


		Map<BigDecimal, List<List<String>>> orderMap = new TreeMap<BigDecimal, List<List<String>>>(hashMap);
		
		// Obtenemos las filas ordenadas
		List<List<String>> sortRows = new ArrayList<List<String>>();
		
		Iterator it = orderMap.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        sortRows.addAll((List<List<String>>) pair.getValue());
	        
	    }
	    
	    
	    List<List<String>> sortDesRows = new ArrayList<List<String>>();
	    
	    for (int i = sortRows.size() - 1; i >= 0; i--) {
			sortDesRows.add(sortRows.get(i));
		}
	    
		
		// Retorna resultado.
		return sortDesRows;
	}
	
	/**
	 * Método que genera informacion del cuerpo del reporte.
	 * @param anho Año del reporte.
	 * @param mes Mes del reporte.
	 * @param pConSemana TODO
	 * @param pConDia TODO
	 * @return Lista de resultado.
	 */
	public List<List<String>> generarFilasReporteVentaDolares(int anho, int mes, Date pFechaInicio, Date pFechaFin, boolean pConSemana, boolean pConDia) 
	{

		
		// Instancia objeto de tipo "Calendar".
		Calendar cal = Calendar.getInstance();
		
		// Almacena gestion anterior.
		cal.set(Calendar.YEAR, anho - 1);
		// Almacena primer dia y mes de la gestión anterior.
		cal.set(Calendar.DAY_OF_YEAR, 1);
		
		// Obtiene primer dia y mes de la gestión anterior.
		Date fechaInicio = cal.getTime();
		// Obtiene el ultimo dia del año
		cal.set(Calendar.YEAR, anho - 1);
		// Almacena ultimo mes de la gestión.
		cal.set(Calendar.MONTH, 11); 
		// Almacena ultimo dia de la gestión.
		cal.set(Calendar.DAY_OF_MONTH, 31); 

		// Obtiene ultimo dia de la gestión.
		Date fechaFin = cal.getTime();
		
		// Obtiene nombres de las filas que contiene la columna.
		List<List<String>> rows = obtenerFilasReporteVentaDolares();
		
		// Obtiene tamaño de lista.
		int contador = rows.size() - 1;
		// Obtiene contador de etiquetas de fila.
		int vContadorNumero = 3;
		
		BigDecimal filaTotal = null;
		BigDecimal vSumaGestionAnterior = null;
		String vformatoSumaGestionAnterior = "";		
		BigDecimal vSumaMes = null;
		BigDecimal vSumaSemana = null;
		BigDecimal vSumaSemanaTotal =  BigDecimal.ZERO;
		BigDecimal vSumaGestionActual = null;
		BigDecimal vSumaTotal = null;
		BigDecimal vPorcentaje = BigDecimal.ZERO;
		BigDecimal vCien = new BigDecimal (100);
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		Date fecIniMes = null;
		Date fecFinMes = null;

		// Añadimos los valores a las columanas
		for (Iterator iterator = rows.iterator(); iterator.hasNext();) {
			
			filaTotal = new BigDecimal("0");
			vSumaGestionAnterior = new BigDecimal("0");
			vSumaMes = new BigDecimal("0");
			vSumaGestionActual = new BigDecimal("0");
			vSumaSemanaTotal =  new BigDecimal("0");
			// Obtiene suma gestión anterior.
			vSumaGestionAnterior = obtieneValorCuerpoReportePorFechas(contador, fechaInicio, fechaFin);
			// Convierte el formato de la suma.
			vformatoSumaGestionAnterior = decimalFormat.format(vSumaGestionAnterior);		

			// Almacena gestión anterior.
			filaTotal = filaTotal.add(vSumaGestionAnterior);

			// Instancia lista de tipo "String".
			List<String> list = (List<String>) iterator.next();
			
			// Verifica el contador.
			if (contador == 0 || contador == 4 || contador == 8) {
				// Adiciona etiqueta numero de fila.
				list.add(0, String.valueOf(vContadorNumero));
				vContadorNumero--;
			} else {
				// Adiciona campos en blanco.
				list.add(0, " ");
			}

			// Verifica contador de la fila.
			if (contador == 3 || contador == 7) {
				// Adiciona campos en blanco.
				list.add(" ");
			} else {
				// Adiciona suma gestion anterior.
				list.add(vformatoSumaGestionAnterior);
			}

			// Añadimos los valores de las filas en funcion al tiemmpo
			for (int i = 0; i <= mes; i++) {
				// Verifica contador de la fila.
				if (contador == 3 || contador == 7) {
					if (i != mes) {
						// Adiciona campos en blanco.
						list.add(" ");

					}

				} else {
					// Adiciona año actual.
					cal.set(Calendar.YEAR, anho);
					// Adiciona mes correspondiene a la iteración.
					cal.set(Calendar.MONTH, i);
					// Adiciona dia inicial del mes.
					cal.set(Calendar.DATE, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
					// Obtiene la fecha inicial.
					fecIniMes = cal.getTime();
					// Adiciona dia final del mes.
					cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
					// Obtiene la fecha final.
					fecFinMes = cal.getTime();

					// Verifica si el mes es igual.
					if (i != mes) {
						// Obtiene suma del mes correspondiente.
						vSumaMes = obtieneValorCuerpoReportePorFechas(contador,fecIniMes, fecFinMes);
						list.add(decimalFormat.format(vSumaMes));
						// Obtiene suma gestión actual.
						vSumaGestionActual = vSumaGestionActual.add(vSumaMes);

					} else {
						if (pConSemana) {
							Calendar calSemana = Calendar.getInstance();
							// Obtenemos el número de semana en función a la
							// fecha final
							calSemana.setTime(pFechaFin);
							int nroSemana = calSemana.get(Calendar.WEEK_OF_MONTH);
							// Obtenemos las fechas de las semanas obtenidas en
							// función a la fecha inicial
							calSemana.setTime(fecIniMes);
							vSumaSemana = BigDecimal.ZERO;

							for (int j = 0; j < nroSemana; j++) {
								calSemana.set(Calendar.WEEK_OF_MONTH, j);
								List<Date> fechas = obtenerFechasInicioFin(fecIniMes, pFechaFin, j);
								if (fechas.size() > 0) {
									vSumaSemana = obtieneValorCuerpoReportePorFechas(contador, fechas.get(0),fechas.get(fechas.size() - 1));
									vSumaSemanaTotal = vSumaSemanaTotal.add(vSumaSemana);

									// Obtiene suma gestión actual.
									vSumaGestionActual = vSumaGestionActual.add(vSumaSemana);

									list.add(decimalFormat.format(vSumaSemana));
								}
								
							}
							list.add(decimalFormat.format(vSumaSemanaTotal));
						}

						if (pConDia) {
							Calendar calDia = Calendar.getInstance();
							SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
							// Obtenemos el número de semana en función a la
							// fecha final
							calDia.setTime(pFechaFin);
							int nroDia = calDia.get(Calendar.DAY_OF_MONTH);
							// Obtenemos las fechas de las semanas obtenidas en
							// función a la fecha inicial
							calDia.setTime(fecIniMes);
							vSumaSemana = BigDecimal.ZERO;

							for (int j = 1; j <= nroDia; j++) {
								calDia.set(Calendar.DAY_OF_MONTH, j);
								int diaSemana = calDia.get(Calendar.DAY_OF_WEEK);
								// Verificamos si es fin de semana
								if ((diaSemana >= Calendar.MONDAY) && (diaSemana <= Calendar.FRIDAY)) {
									// Verificamos feriados
									String fecha = format.format(calDia.getTime());
					            	boolean existeFeriado = feriadoDao.existeFeriado(fecha, fecha);
									if(!existeFeriado){
										vSumaSemana = obtieneValorCuerpoReportePorFechas(contador, calDia.getTime(),calDia.getTime());
										vSumaSemanaTotal = vSumaSemanaTotal.add(vSumaSemana);
										// Obtiene suma gestión actual.
										vSumaGestionActual = vSumaGestionActual.add(vSumaSemana);
										list.add(decimalFormat.format(vSumaSemana));	
									}
								}
								
							}
							list.add(decimalFormat.format(vSumaSemanaTotal));
						}

						list.add(decimalFormat.format(vSumaGestionActual));
					}
				}
			}

			// Verifica contador de la fila.
			if (contador == 3 || contador == 7) {

				if (pConSemana) {
					// Adiciona campos en blanco.
					Calendar calSemana = Calendar.getInstance();
					// Obtenemos el número de semana en función a la fecha final
					calSemana.setTime(pFechaFin);
					int nroSemana = calSemana.get(Calendar.WEEK_OF_MONTH);

					for (int i = 0; i < nroSemana; i++) {
						list.add(" ");// list.add(String.valueOf(i+1));
					}
				}

				if (pConDia) {
					Calendar calDia = Calendar.getInstance();
					SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
					// Obtenemos el número de semana en función a la fecha final
					calDia.setTime(pFechaFin);
					int nroDia = calDia.get(Calendar.DAY_OF_MONTH);
					// Obtenemos las fechas de las semanas obtenidas en función
					// a la fecha inicial
					calDia.setTime(fecIniMes);

					for (int j = 1; j <= nroDia; j++) {
						calDia.set(Calendar.DAY_OF_MONTH, j);
						int diaSemana = calDia.get(Calendar.DAY_OF_WEEK);
						// Verificamos si es fin de semana
						if ((diaSemana >= Calendar.MONDAY) && (diaSemana <= Calendar.FRIDAY)) {
							// Verificamos feriados
							String fecha = format.format(calDia.getTime());
			            	boolean existeFeriado = feriadoDao.existeFeriado(fecha, fecha);
			            	if(!existeFeriado){
			            		list.add(" ");	
			            	}
							
						}
					}
				}

				list.add(" ");
				list.add(" ");
				list.add(" ");
			} else {
				// Verifica contador de la fila.
				if (contador == 8) {
					// Obtiene suma total de la gestión actual.
					vSumaTotal = vSumaGestionActual;
				}

				if(vSumaTotal.compareTo(BigDecimal.ZERO) > 0){
					// Obtiene porcentaje de la suma de la gestión actual.
					vPorcentaje = vSumaGestionActual.multiply(vCien).divide(vSumaTotal, 0, BigDecimal.ROUND_HALF_UP);	
				}
				
				// Adiciona porcentaje de la suma de la gestión actual.
				list.add(vPorcentaje + " %");
			}
			contador--;
		}
		// Método que invierte la lista.
		// vListaResultado = invertirLista(rows);
		Collections.reverse(rows);
		// Retorna reslutado.
		return rows;
	}
	
	/**
	 * Método que agrega el total de un reporte dinamico.
	 * @param pListaFilas Lista de filas del cuerpo del reporte a sumar.
	 */
	public void generarSumaFilasReporte(List<List<String>> pListaFilas) {
		List<String> row = new ArrayList<String>();
		BigDecimal monto = null;
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		row.add(" ");
		row.add("Total ");
		pListaFilas.add(row);
		
		// Obtenemos una fila para obtener la cantidad de columnas 
		List<String> fila = pListaFilas.get(0);
		int nroCol = fila.size();
		// Iteramos las columnas
		for (int j = 0; j < nroCol; j++) {
			monto = BigDecimal.ZERO;
			// Se excluye la fila de descripción
			if (j > 1) {
				// Se itera las filas
				for (int i = 0; i < pListaFilas.size(); i++) {
					// Obtenemos las filas
						fila = pListaFilas.get(i);
						// Verificamos la fila total
						if (i != pListaFilas.size() - 1) {
							// Modificamos el valor del formato para que acepte el
							// Valor el objeto BiDecimal
							String valor = fila.get(j).replace(".", "");
							valor = valor.replace(",", ".");
							monto = monto.add(new BigDecimal(valor));
							
						} else {
							fila.add(decimalFormat.format(monto));
						}				
				}
			}
		}	

	}
	
	/**
	 * Método que obtiene lista de entidades bancarias por fecha de inicio, fecha fin y nombre de reporte.
	 * @param pFechaInicio Fecha de inicio.
	 * @param pFechaFin Fecha fin.
	 * @return Lista de tipo "OperacionesCambiarias".
	 */
	private List<OperacionesCambiarias> obtenerListaEntidadBancaria(Date pFechaInicio, Date pFechaFin, String pNombreReporte)
	{
		// Instancia lista de tipo "OperacionesCambiarias".
		List<OperacionesCambiarias> vListaInstituciones = new ArrayList<OperacionesCambiarias>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fInicio = dateFormat.format(pFechaInicio);
		String fHasta = dateFormat.format(pFechaFin);
		
		
		// Verifica reporte de venta de dolares dia al sistema financiero.
		if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero))
		{			
			// Obtiene lista de entidades bancarias dia al sistema financiero.
			vListaInstituciones = getSolicitudBean().getSocSolicitudesDao().obtenerListaEntidadBancariaDiaSistemaFinanciero(fInicio, fHasta);
		}
		// Verifica reporte de venta de dolares a través de bolsin al sistema financiero.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero))
		{
			// Obtiene lista de entidades bancarias a través de bolsin al sistema financiero.
			vListaInstituciones = getSolicitudBean().getSocSolicitudesDao().obtenerEntidadBancariaBolsinSistemaFinanciero(fInicio, fHasta);
		}
		// Verifica reporte transferencias al exterior por gestión.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteTransferenciasExterior))
		{
			// Obtiene lista de entidades bancarias de tranferencias al exterior.
			vListaInstituciones = getSolicitudBean().getSocSolicitudesDao().obtenerInstitucionesTransExterior(fInicio, fHasta);
		}	
		// Verifica reporte de venta de dolares del bolsin a clientes del sistema financiero.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero))
		{
			// Obtiene lista de entidades bancarias de venta de dolares del bolsin a clientes del sistema financiero.
			vListaInstituciones = getSolicitudBean().getSocSolicitudesDao().obtenerInstitucionesBolCliSisFin(fInicio, fHasta);
		}
		// Verifica reporte de venta de dolares estadounidenses en el dia a clientes del sistema financiero.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero))
		{
			// Obtiene lista de entidades bancarias de venta de dolares estadounidenses en el dia a clientes del sistema financiero.
			vListaInstituciones = getSolicitudBean().getSocSolicitudesDao().obtenerInstitucionesDiaClientesSisFin(fInicio, fHasta);
		}
		// Retorna lista de instituciones.
		return vListaInstituciones;
	}
	
	/**
	 * Método que obtiene monto de entidad bancaria por fecha de inicio, fecha fin y nombre de reporte.
	 * @param pFechaInicio Fecha de inicio.
	 * @param pFechaFin Fecha fin.
	 * @return Lista de tipo "OperacionesCambiarias".
	 */
	private BigDecimal obtenerMontoEntidadBancariaPorFechaIdInstitucionNombreReporte(String pIdInstitucion, Date pFechaInicio, Date pFechaFin, String pNombreReporte)
	{	
		// Inicializa variables para ralizar la suma.
		BigDecimal vSumaMonto =  BigDecimal.ZERO;
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fInicio = dateFormat.format(pFechaInicio);
		String fHasta = dateFormat.format(pFechaFin);
		
		// Verifica reporte de venta de dolares dia al sistema financiero.
		if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero))
		{					
			// Obtiene monto calculado de venta de dolares dia al sistema financiero.
			vSumaMonto = getSolicitudBean().getSocSolicitudesDao().obtenerMontoVentaDolaresDiaSistemaFinancieroPorFechaIdInstitucion(pIdInstitucion, fInicio, fHasta);
		}
		// Verifica reporte de venta de dolares a través de bolsin al sistema financiero.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero))
		{
			// Obtiene monto calculado de venta de dolares a través de bolsin al sistema financiero.
			vSumaMonto = getSolicitudBean().getSocSolicitudesDao().obtenerMontoEntidadBancariaPorFechaIdInstitucion(pIdInstitucion, fInicio, fHasta);
		}	
		// Verifica reporte de venta de dolares a través de bolsin al sistema financiero.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteTransferenciasExterior))
		{
			// Obtiene monto calculado de tranferencias al exterior.
			vSumaMonto = getSolicitudBean().getSocSolicitudesDao().obtenerMontoInstitucionTransExteriorPorFecha(pIdInstitucion, fInicio, fHasta);
		}
		// Verifica reporte de venta de venta de dolares del bolsin a clientes del sistema financiero.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero))
		{
			// Obtiene monto calculado de venta de dolares del bolsin a clientes del sistema financiero.
			vSumaMonto = getSolicitudBean().getSocSolicitudesDao().obtenerMontoInstitucionBolCliSisFinPorFecha(pIdInstitucion, fInicio, fHasta);
		}
		// Verifica reporte de venta de dolares estadounidenses en el dia a clientes del sistema financiero.
		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero))
		{
			// Obtiene monto calculado de venta de dolares estadounidenses en el dia a clientes del sistema financiero.
			vSumaMonto = getSolicitudBean().getSocSolicitudesDao().obtenerMontoInstitucionDiaCliSisFinPorFecha(pIdInstitucion, fInicio, fHasta);
		}
		
		// Retorna resultado.
		return vSumaMonto.divide(new BigDecimal(String.valueOf(1000000)));
	}
	
	/**
	 * Método que obtiene sumatoria correspondiente a cada mes para el reporte de venta de dolares.
	 * @param row Fecha de inicio.
	 * @param pFechaInicio Fecha de inicio.
	 * @param pFechaFin Fecha fin.
	 * @return Sumatoria de tipo "BigDecimal".
	 */
	private BigDecimal obtieneValorCuerpoReportePorFechas(int row, Date fechaInicio,	Date fechaFin) 
	{
		BigDecimal resultado = new BigDecimal("0");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fInicio = dateFormat.format(fechaInicio);
		String fHasta = dateFormat.format(fechaFin);
		// Obtenmos el valor para el total anual en función a las filas
		switch (row) 
		{			
			case 0:
			// Total
				resultado = getSolicitudBean().getSocSolicitudesDao().obtenerTotalBolsinReporteVentaDolares(fInicio, fHasta);
				break;
			// >>>>>Bolsin
			case 1:
				// Sistema financiero
				resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoBolSisFin(fInicio, fHasta);
				break;
			case 2:
				// Clientes del sistema financiero
				resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoBolCliSisFin(fInicio, fHasta);
				break;
			case 4:
				// Total
				resultado = getSolicitudBean().getSocSolicitudesDao().obtenerTotalBolsinReporteVentaDolaresDia(fInicio, fHasta);
				break;
			case 5:
				// Sistema Financiero
				resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoVentDiaSisFin(fInicio, fHasta);
				break;
			case 6:
				// Clientes del sistema financiero
				resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoVentDiaCliSisFin(fInicio, fHasta);
				break;
			case 8:
				// Clientes del sistema financiero
				resultado = getSolicitudBean().getSocSolicitudesDao().obtenerTotalGeneralBolsinReporteVentaDolares(fInicio, fHasta);
				break;
		}
		// Retorna resultado.
		return resultado.divide(new BigDecimal(String.valueOf(1000000)));
	}
	
	/**
	 * Método que genera nombres de filas del reporte venta de dolares estadounidenses.
	 * @param row Fecha de inicio.
	 * @param pFechaInicio Fecha de inicio.
	 * @param pFechaFin Fecha fin.
	 * @return Sumatoria de tipo "BigDecimal".
	 */
	private List<List<String>> obtenerFilasReporteVentaDolares() 
	{
		// Instancia lista de lista de tipo "String".
		List<List<String>> vFilas = new ArrayList<List<String>>();
		
		// Instancia lista fila uno de tipo "String".
		List<String> vFilaUno = new ArrayList<String>();
		// Instancia lista fila dos de tipo "String".
		List<String> vFilaDos = new ArrayList<String>();
		// Instancia lista fila tres de tipo "String".
		List<String> vFilaTres = new ArrayList<String>();
		// Instancia lista fila cuatro de tipo "String".
		List<String> vFilaCuatro = new ArrayList<String>();
		// Instancia lista fila cinco de tipo "String".
		List<String> vFilaCinco = new ArrayList<String>();
		// Instancia lista fila seis de tipo "String".
		List<String> vFilaSeis = new ArrayList<String>();
		// Instancia lista fila siete de tipo "String".
		List<String> vFilaSiete = new ArrayList<String>();
		// Instancia lista fila ocho de tipo "String".
		List<String> vFilaOcho = new ArrayList<String>();
		// Instancia lista fila nueve de tipo "String".
		List<String> vFilaNueve = new ArrayList<String>();
		
		// Adiciona nombre de fila uno.
		vFilaUno.add("VENTA A TRAVES DEL BOLSIN");		
		// Adiciona nombre de fila dos.
		vFilaDos.add(generarNumeroEspacio(4) + "Sistema Financiero");	
		// Adiciona nombre de fila tres.
		vFilaTres.add(generarNumeroEspacio(4) + "Clientes Sistema Financiero");	
		// Adiciona nombre de fila cuatro.
		vFilaCuatro.add(" ");
		// Adiciona nombre de fila cinco.
		vFilaCinco.add("VENTA USD EN EL DIA");
		// Adiciona nombre de fila seis.
		vFilaSeis.add(generarNumeroEspacio(4) +"Sistema Financiero");
		// Adiciona nombre de fila siete.
		vFilaSiete.add(generarNumeroEspacio(4) +"Clientes Sistema Financiero");
		// Adiciona nombre de fila ocho.
		vFilaOcho.add(" ");
		// Adiciona nombre de fila nueve.
		vFilaNueve.add("TOTAL GENERAL ");
		
		// Añadimos las fila uno a la fila.
		vFilas.add(vFilaUno);
		// Añadimos las fila dos a la fila.
		vFilas.add(vFilaDos);
		// Añadimos las fila tres a la fila.
		vFilas.add(vFilaTres);
		// Añadimos las fila cuatro a la fila.
		vFilas.add(vFilaCuatro);
		// Añadimos las fila cinco a la fila.
		vFilas.add(vFilaCinco);
		// Añadimos las fila seis a la fila.
		vFilas.add(vFilaSeis);
		// Añadimos las fila siete a la fila.
		vFilas.add(vFilaSiete);
		// Añadimos las fila ocho a la fila.
		vFilas.add(vFilaOcho);
		// Añadimos las fila nueve a la fila.
		vFilas.add(vFilaNueve);
		
		// Método que invierte una lista.
		//vFilasResultado= invertirLista(vFilas);
		Collections.reverse(vFilas);
		// Retorna fila.
		return vFilas;
	}
	
	
	/**
	 * Método que retorna el nombre del mes actual del sistema
	 * 
	 * @param p_idioma
	 *            Entero que determina el idioma en que se retornara la
	 *            respuesta (0 -> español, 1-> ingles)
	 * @return Nombre del mes actual en el idioma determinado en el parametro
	 */
	private static String getNombreMesCorto(int p_idioma, int pMes)
			throws Exception {
		String[][] mesNombre = { { "Ene", "Jan" }, { "Feb", "Feb" },
				{ "Mar", "Mar" }, { "Abr", "Apr" }, { "May", "May" },
				{ "Jun", "Jun" }, { "Jul", "Jul" }, { "Ago", "Aug" },
				{ "Sep", "Sep" }, { "Oct", "Oct" }, { "Nov", "Nov" },
				{ "Dic", "Dec" }, };
		/** se verifica que el parametro idioma sea valido **/
		if (p_idioma > 1)
			throw new Exception(
					"Error al intentar obtener el nombre del mes con el código de idioma "
							+ p_idioma);
		/** se calcula el mes del sistema */
		String mes = mesNombre[pMes][p_idioma];
		/** se retorna el nombre del mes **/
		return mes;
	}

	/**
     * Metodo que obtiene la fecha de inicio y fecha fina de una semana
     * @param fechaInicio Fecha de Inicio del mes
     * @param fechaFin Fecha final 
      * @param nroSemana Número de semana
     * @return retorna una colección que obtiene las fecha de inicio y final de una semana
     */
     private List<Date> obtenerFechasInicioFin(Date fechaInicio, Date fechaFin, int nroSemana) {
	  List<Date> resultado = new ArrayList<Date>();
	  List<Date> fechas = new ArrayList<Date>();
	  System.out.println("Número de semana " + nroSemana);
      SimpleDateFormat sdf = new SimpleDateFormat("dd/M/yyyy");
      Calendar calendar = Calendar.getInstance();
      Calendar calendarSemana = Calendar.getInstance();
      calendarSemana.setTime(fechaInicio);
      calendar.setTime(fechaInicio);
      int mesFeIni = calendar.get(Calendar.MONTH);

      calendarSemana.set(Calendar.MONTH, mesFeIni);
      calendarSemana.set(Calendar.WEEK_OF_MONTH, nroSemana);
      calendarSemana.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
      for (int j = Calendar.SUNDAY; j <= Calendar.SATURDAY; j++) {
          if (fechaFin.after(calendarSemana.getTime()) || fechaFin.equals(calendarSemana.getTime())) {
        	  int mesSemana = calendarSemana.get(Calendar.MONTH);
        	  String test = sdf.format(calendarSemana.getTime());
              if (mesFeIni == mesSemana) {
                  fechas.add(calendarSemana.getTime());
                  System.out.println(sdf.format(calendarSemana.getTime()));
              }
          }

          calendarSemana.add(Calendar.DATE, 1);
      }
      
      System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Semana Nro: " + nroSemana + " >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
           
      if(fechas.size() > 0){
    	  resultado.add(fechas.get(0));
          resultado.add(fechas.get(fechas.size() -1 ));  
      }
      
      return resultado;
     }

     private String generarNumeroEspacio(int numero) {
 		String resultado = "";
 		StringBuilder espacios = new StringBuilder();
 		for (int i = 0; i <= numero; i++) {
 			espacios.append("&nbsp;");
 		}
 		resultado = espacios.toString();
 		return resultado;
 	}
     
     /**
      * Método que obtiene el titulo del reporte.
      * @param pNombreReporte Nombre de reporte.
      * @param pFechaFin Fecha fin del reporte.
      * @return Titulo del reporte.
     */
     public String obtenerTituloReporte(String pNombreReporte, Date pFechaFin)
     {    	 
    	 // Instancia variable para el titulo.
    	 String vSubTitulo = "";
    	 String vTitulo = "";
    	    	 
		// Instancia obejto de tipo "Calendar".
    	 Calendar vObjCalendario = Calendar.getInstance();
    	 
    	 // Adiciona fecha fin de reporte.
    	 vObjCalendario.setTime(pFechaFin);
    	 
    	 // Almacena año de la fecha fin.
    	 int vAnio = vObjCalendario.get(Calendar.YEAR);
    	 
    	// Verifica reporte de venta de dolares dia al sistema financiero.
 		if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero)) 							
 			// Almacena titulo de venta de dolares dia al sistema financiero.
 			vSubTitulo = "Venta de Dólares Estadounidenses en el día al Sistema Financiero"; 		
 		// Verifica reporte de venta de dolares a través de bolsin al sistema financiero.
 		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero)) 		
 			// Almacena titulo venta de dolares a través de bolsin al sistema financiero.
 			vSubTitulo = "Venta de Dólares Estadounidenses a través del Bolsín al Sistema Financiero"; 		
 		// Verifica reporte de venta de dolares a través de bolsin al sistema financiero.
 		else if(pNombreReporte.equals(ConstantesReportes.cReporteTransferenciasExterior)) 		
 			// Almacena titulo de tranferencias al exterior.
 			vSubTitulo = "Transferencias al Exterior"; 		
 		// Verifica reporte de venta de venta de dolares del bolsin a clientes del sistema financiero.
 		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero)) 		
 			// Almacena titulo venta de dolares del bolsin a clientes del sistema financiero.
 			vSubTitulo = "Venta de Dólares Estadounidenses a través del Bolsín a Clientes del Sistema Financiero"; 		
 		// Verifica reporte de venta de dolares estadounidenses en el dia a clientes del sistema financiero.
 		else if(pNombreReporte.equals(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero)) 		
 			// Almacena titulo venta de dolares estadounidenses en el dia a clientes del sistema financiero.
 			vSubTitulo = "Venta de Dólares Estadounidenses en el día a Clientes del Sistema Financiero";
 		else if(pNombreReporte.equalsIgnoreCase(ConstantesReportes.cReporteVentaDolaresEstadounidenses)){
 			vSubTitulo = "Venta de Dólares Estadounidenses";
 		}
 		
 		
 		
 		// Concatena titulo para el reporte
 		vTitulo = vSubTitulo + "\nGestion " + vAnio + "\n(En millones de USD)";    		 
    	  		
 		// Retorna titulo generado.
 		return vTitulo;
     }
     
    /**
     *  
     * @param anho Año de la fecha final seleccionada 
     * @param mes Mes de la fecha final seleccioanda
     * @return Una coleecion de datos 
     */
	public List<List<String>> generarFilasReporteOperacionesCambiarias(int anho, int mes) {

		// Obtenemos la fecha y el valor del año por fila
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, anho - 1);
		cal.set(Calendar.DAY_OF_YEAR, 1);
		Date fechaInicio = cal.getTime();
		// Obtiene el ultimo dia del año
		cal.set(Calendar.YEAR, anho - 1);
		cal.set(Calendar.MONTH, 11); // 11 = december
		cal.set(Calendar.DAY_OF_MONTH, 31); // new years eve

		Date fechaFin = cal.getTime();

		// Aramamos las filas del reporte con sus respectivos valores
		List<List<String>> rows = obtenerFilas();

		int contador = 0;
		BigDecimal filaTotal = null;
		BigDecimal anual = null;
		BigDecimal mensual = null;
		BigDecimal mensualTotal = null;
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		String filaTotalFormat = "";
		String montoAnualFormat = "";
		String montoMensualFormat = "";
		Date fecIniMes = null;
		Date fecFinMes = null;

		// Añadimos los valores a las columanas
		for (Iterator iterator = rows.iterator(); iterator.hasNext();) {

			filaTotal = new BigDecimal("0");
			anual = new BigDecimal("0");
			mensual = new BigDecimal("0");
			mensualTotal = new BigDecimal("0");
			anual = obtieneValorFilaPorFechas(contador, fechaInicio, fechaFin);

			montoAnualFormat = decimalFormat.format(anual);

//			filaTotal = filaTotal.add(anual);

			List<String> list = (List<String>) iterator.next();
			if (contador == 13) {
				list.add(" ");
			} else {
				list.add(montoAnualFormat);
			}

			// Añadimos los valores de las filas en funcion al tiemmpo

			for (int i = 0; i <= mes; i++) {
				if (contador < 13 || contador >= 16) {
					// Obtenemos la fecha inicial y final de los meses

					cal.set(Calendar.YEAR, anho);
					cal.set(Calendar.MONTH, i);
					cal.set(Calendar.DATE, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
					fecIniMes = cal.getTime();
					cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
					fecFinMes = cal.getTime();
					mensual = obtieneValorFilaPorFechas(contador, fecIniMes, fecFinMes);

					montoMensualFormat = decimalFormat.format(mensual);

					// Agregamos el valor mensual a la lista
					list.add(montoMensualFormat);
					mensualTotal = mensualTotal.add(mensual);
				} else if (contador == 13) {
					list.add(" ");
				} else if (contador == 14 || contador == 15) {
					mensual = new BigDecimal("0");
					montoMensualFormat = decimalFormat.format(mensual);
					list.add(montoMensualFormat);
				}

			}

			// Agregamos el valor a la utlima Fila que es el total
			filaTotal = filaTotal.add(mensualTotal);
			filaTotalFormat = decimalFormat.format(filaTotal);
			if (contador == 13) {
				list.add(" ");
			} else {				
				list.add(filaTotalFormat);				
			}

			//

			// Obtenemos los valores en funcion a las filas ejemplo del sistema
			// Financiero

			contador++;
		}

		// Completamos con la obtencion de las filas

		obtenerTotalTransAlExt(rows);

		obtenerTotalTrasnDelExt(rows);

		obtenerTotalTransNeta(rows);

		obtenerTotalCompraDivisas(rows);

		obtenerTotalVentaDia(rows);

		obtenerTotalBolsin(rows);

		obtenerTotalSisFin(rows);

		obtenerTotalVentaDivisas(rows);

		obtenerTotalVentaNeta(rows);				

		return rows;
	}
	
	/**
	 * Obtiene las filas del reporte de operaciones cambiarias
	 * @return Colección de datos
	 */
	public List<List<String>> obtenerFilas(){
    	List<List<String>> rows = new ArrayList<List<String>>();
    	//Definimos la cantidad de filas del reporte
    	List<String> row1 = new ArrayList<String>();
    	row1.add("Venta Neta");
    	List<String> row2 = new ArrayList<String>();
    	row2.add("Venta de divisas");
    	List<String> row3 = new ArrayList<String>();
    	row3.add(generarNumeroEspacio(4) + "Sistema Financiero");
    	List<String> row4 = new ArrayList<String>();
    	row4.add(generarNumeroEspacio(5) + "Bolsin");
    	List<String> row5 = new ArrayList<String>();
    	row5.add(generarNumeroEspacio(6) + "Sistema Financiero");
    	List<String> row6 = new ArrayList<String>();
    	row6.add(generarNumeroEspacio(6) + "Clientes Sistema Financiero");
    	List<String> row7 = new ArrayList<String>();
    	row7.add(generarNumeroEspacio(5) + "Venta en el día");
    	List<String> row8 = new ArrayList<String>();
    	row8.add(generarNumeroEspacio(6) + "Sistema Financiero");
    	List<String> row9 = new ArrayList<String>();
    	row9.add(generarNumeroEspacio(6) + "Clientes Sistema Financiero");
    	List<String> row10 = new ArrayList<String>();
    	row10.add(generarNumeroEspacio(4) + "Sector Público");
    	List<String> row11 = new ArrayList<String>();
    	row11.add("Compra de divisas");
    	List<String> row12 = new ArrayList<String>();
    	row12.add(generarNumeroEspacio(4) + "Sector Público");
    	List<String> row13 = new ArrayList<String>();
    	row13.add(generarNumeroEspacio(4) + "Sistema Financiero");
    	List<String> row14 = new ArrayList<String>();
    	row14.add( " ");
    	List<String> row15 = new ArrayList<String>();
    	row15.add("Transferencia Neta");
    	List<String> row16 = new ArrayList<String>();
    	row16.add("Transferencias del exterior");
    	List<String> row17 = new ArrayList<String>();
    	row17.add(generarNumeroEspacio(4) + "Sector Público");
    	List<String> row18 = new ArrayList<String>();
    	row18.add(generarNumeroEspacio(4) + "Sistema Financiero");
    	List<String> row19 = new ArrayList<String>();
    	row19.add(generarNumeroEspacio(4) + "Otros");
    	List<String> row20 = new ArrayList<String>();
    	row20.add("Transferencias al exterior");
    	List<String> row21 = new ArrayList<String>();
    	row21.add(generarNumeroEspacio(4) + "Sector Público");
    	List<String> row22 = new ArrayList<String>();
    	row22.add(generarNumeroEspacio(4) + "Sistema Financiero");
    	
    	// Añadimos las filas
    	rows.add(row1);
    	rows.add(row2);
    	rows.add(row3);
    	rows.add(row4);
    	rows.add(row5);
    	rows.add(row6);
    	rows.add(row7);
    	rows.add(row8);
    	rows.add(row9);
    	rows.add(row10);
    	rows.add(row11);
    	rows.add(row12);
    	rows.add(row13);
    	rows.add(row14);
    	rows.add(row15);
    	rows.add(row16);
    	rows.add(row17);
    	rows.add(row18);
    	rows.add(row19);
    	rows.add(row20);
    	rows.add(row21);
    	rows.add(row22);
    	
    	return rows;
    }

	/**
	 * Metodo que obtiene el valor total de la fila transferencias al exterior
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalTransAlExt(List<List<String>> rows) {
		BigDecimal monto = null;
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
    	//Trasferencias al exterior
    			List<String> transAlExt = rows.get(19);
    			//Sector Publico
    			List<String> taSecPub = rows.get(20);
    			// Sistema Financiero
    			List<String> taSisFin = rows.get(21);
    			//Obtenemos el numero de columnas
    			int nroCol = taSecPub.size();
    			    			    			
    			for (int j = 0; j < nroCol; j++) {
    				if (j != 0) {
    					monto = BigDecimal.ZERO;

    					String secPub = taSecPub.get(j).replace(".", "");
    					String sisFin = taSisFin.get(j).replace(".", "");
    					secPub = secPub.replace(",", ".");
    					sisFin = sisFin.replace(",", ".");
    					monto = monto.add(new BigDecimal(secPub));
    					monto = monto.add(new BigDecimal(sisFin));

    					transAlExt.set(j, decimalFormat.format(monto));
    				}
    			}
	}
    
	/**
	 * Metodo que obtiene el valor total de la fila transferencias del exterior
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalTrasnDelExt(List<List<String>> rows) {
		BigDecimal monto = null;
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Trasferencias del exterior
		List<String> transDelExt = rows.get(15);
		// Sector Publico
		List<String> tdSecPub = rows.get(16);
		// Sistema Financiero
		List<String> tdSisFin = rows.get(17);
		// Sistema Financiero
		List<String> tdOtros = rows.get(18);
		int nroCol = transDelExt.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String secPub = tdSecPub.get(j).replace(".", "");
				String sisFin = tdSisFin.get(j).replace(".", "");
				String otros = tdOtros.get(j).replace(".", "");
				secPub = secPub.replace(",", ".");
				sisFin = sisFin.replace(",", ".");
				otros = otros.replace(",", ".");
				monto = monto.add(new BigDecimal(secPub));
				monto = monto.add(new BigDecimal(sisFin));
				monto = monto.add(new BigDecimal(otros));

				transDelExt.set(j, decimalFormat.format(monto));
			}
		}
	}
	
	/**
	 * Metodo que obtiene el valor total de la fila transferencia neta
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalTransNeta(List<List<String>> rows) {
    	BigDecimal monto = null;
    	DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Trasferencia Neta
		List<String> transNeta = rows.get(14);
		// Trasferencias del exterior
		List<String> transDelExt = rows.get(15);
		// Trasferencias al exterior
		List<String> transAlExt = rows.get(19);
		
		int nroCol = transDelExt.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String delExt = transDelExt.get(j).replace(".", "");
				String alExt = transAlExt.get(j).replace(".", "");
				
				delExt = delExt.replace(",", ".");
				alExt = alExt.replace(",", ".");
				
				monto = monto.add(new BigDecimal(delExt));
				monto = monto.subtract(new BigDecimal(alExt));
				

				transNeta.set(j, decimalFormat.format(monto));
			}
		}
		
	}
	
	/**
	 * Metodo que obtiene el valor total de la fila Compra de divisas
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalCompraDivisas(List<List<String>> rows) {
		BigDecimal monto = null;
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Compra de divisas
		List<String> compraDiv = rows.get(10);
		// Sector Público
		List<String> cvSecPub = rows.get(11);
		// Sistema Financiero
		List<String> cvSisFin = rows.get(12);
		
		int nroCol = compraDiv.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String secPub = cvSecPub.get(j).replace(".", "");
				String sisFin = cvSisFin.get(j).replace(".", "");
				
				secPub = secPub.replace(",", ".");
				sisFin = sisFin.replace(",", ".");
				
				monto = monto.add(new BigDecimal(secPub));
				monto = monto.add(new BigDecimal(sisFin));
				

				compraDiv.set(j, decimalFormat.format(monto));
			}
		}
		
	}
	
	/**
	 * Metodo que obtiene el valor total de la fila Venta dia
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalVentaDia(List<List<String>> rows) {
    	BigDecimal monto = null;
    	DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Venta en el dia
		List<String> ventaDia = rows.get(6);
		// Sistema Financiero
		List<String> vdSisFin = rows.get(7);
		// Clientes Sistema Financiero
		List<String> vdCliSisFin = rows.get(8);
		
		int nroCol = ventaDia.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String sisFin = vdSisFin.get(j).replace(".", "");
				String cliSisFin = vdCliSisFin.get(j).replace(".", "");
				
				sisFin = sisFin.replace(",", ".");
				cliSisFin = cliSisFin.replace(",", ".");
				
				monto = monto.add(new BigDecimal(sisFin));
				monto = monto.add(new BigDecimal(cliSisFin));
				

				ventaDia.set(j, decimalFormat.format(monto));
			}
		}
	}

	/**
	 * Metodo que obtiene el valor total de la fila Bolsin
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalBolsin(List<List<String>> rows) {
    	BigDecimal monto = null;
    	DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Bolsin
		List<String> bolsin = rows.get(3);
		// Sistema Financiero
		List<String> vdSisFin = rows.get(4);
		// Clientes Sistema Financiero
		List<String> vdCliSisFin = rows.get(5);
		
		int nroCol = bolsin.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String sisFin = vdSisFin.get(j).replace(".", "");
				String cliSisFin = vdCliSisFin.get(j).replace(".", "");
				
				sisFin = sisFin.replace(",", ".");
				cliSisFin = cliSisFin.replace(",", ".");
				
				monto = monto.add(new BigDecimal(sisFin));
				monto = monto.add(new BigDecimal(cliSisFin));
				

				bolsin.set(j, decimalFormat.format(monto));
			}
		}
		
	}
	
	/**
	 * Metodo que obtiene el valor total de la fila Sistema financiero
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalSisFin(List<List<String>> rows) {
    	BigDecimal monto = null;
    	DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Sistema Financiero
		List<String> sisFin = rows.get(2);
		// Bolsin
		List<String> sfBolsin = rows.get(3);
		// Venta al dia
		List<String> sfVentaDia = rows.get(6);
		
		int nroCol = sisFin.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String bolsin = sfBolsin.get(j).replace(".", "");
				String ventaDia = sfVentaDia.get(j).replace(".", "");
				
				bolsin = bolsin.replace(",", ".");
				ventaDia = ventaDia.replace(",", ".");
				
				monto = monto.add(new BigDecimal(bolsin));
				monto = monto.add(new BigDecimal(ventaDia));
				

				sisFin.set(j, decimalFormat.format(monto));
			}
		}
		
	}
	
	/**
	 * Metodo que obtiene el valor total de la fila Venta de divisas
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalVentaDivisas(List<List<String>> rows) {
    	BigDecimal monto = null;
    	DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Venta divisas
		List<String> ventaDivisas = rows.get(1);
		// Sistema Financiero
		List<String> sisFin = rows.get(2);
		// Sector publico
		List<String> secPub = rows.get(9);
		
		int nroCol = ventaDivisas.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String vdSisFin = sisFin.get(j).replace(".", "");
				String vdSecPuc = secPub.get(j).replace(".", "");
				
				vdSisFin = vdSisFin.replace(",", ".");
				vdSecPuc = vdSecPuc.replace(",", ".");
				
				monto = monto.add(new BigDecimal(vdSisFin));
				monto = monto.add(new BigDecimal(vdSecPuc));
				

				ventaDivisas.set(j, decimalFormat.format(monto));
			}
		}
	}
	
	/**
	 * Metodo que obtiene el valor total de la fila Venta Neta
	 * @param rows Fila a retornar
	 */
	private void obtenerTotalVentaNeta(List<List<String>> rows) {
    	BigDecimal monto = null;
    	DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		// Venta divisas
		List<String> ventaNeta = rows.get(0);
		// Sistema Financiero
		List<String> ventaDivisas = rows.get(1);
		// Sector publico
		List<String> compraDivisas = rows.get(10);
		
		int nroCol = ventaNeta.size();
		for (int j = 0; j < nroCol; j++) {
			if (j != 0) {
				monto = BigDecimal.ZERO;

				String vnVentDiv = ventaDivisas.get(j).replace(".", "");
				String vnComDiv = compraDivisas.get(j).replace(".", "");
				
				vnVentDiv = vnVentDiv.replace(",", ".");
				vnComDiv = vnComDiv.replace(",", ".");
				
				monto = monto.add(new BigDecimal(vnVentDiv));
				monto = monto.subtract(new BigDecimal(vnComDiv));
				

				ventaNeta.set(j, decimalFormat.format(monto));
			}
		}
	}
	
	/**
	 * Obtiene el monto por de cada fila
	 * @param row Nro. de fila
	 * @param fechaInicio Fecha de Inicio
	 * @param fechaFin Fecha de Fin
	 * @return Monto de la fila
	 */
	public BigDecimal obtieneValorFilaPorFechas(int row, Date fechaInicio, Date fechaFin){
    	BigDecimal resultado = new BigDecimal("0");
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fInicio = dateFormat.format(fechaInicio);
		String fHasta = dateFormat.format(fechaFin);
    	
    	// Obtenmos el valor para el total anual en función a las filas
		switch (row) {
		// >>>>>Bolsin
		case 4:
			// Sistema financiero
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoBolSisFin(fInicio, fHasta);
			bolsin.add(resultado);					
			break;
		case 5:
			// Clientes del sistema financiero
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoBolCliSisFin(fInicio, fHasta);
			bolsin.add(resultado);
			break;
		// >>>>> Venta en el día
		case 7:
			// Sistema Financiero
			bolsin = new ArrayList<BigDecimal>();
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoVentDiaSisFin(fInicio, fHasta);
			break;
		case 8:
			// Clientes del sistema financiero
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoVentDiaCliSisFin(fInicio, fHasta);
			break;
		// >>>>> Sector publico
		case 9:
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoSecPublico(fInicio, fHasta);
			break;
		case 10:
			// Otros
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoOtros(fInicio, fHasta);
			break;
		case 11:
			//Compras sector publico
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoComprasSectorPublico(fInicio, fHasta);
			break;
		case 16:
			//Transferencias del exterior al sector publico
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoTransDelExteriorSecPub(fInicio, fHasta);
			break;
		case 17:
			//Transferencias del exterior al sistema financiero
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoTransDelExteriorSisFin(fInicio, fHasta);
			break;
		case 18:
			// Otros
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoOtros(fInicio, fHasta);
			break;
		case 20:
			//Transferencias al exterior al sector publico
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoTransAlExteriorSecPub(fInicio, fHasta);
			break;
			
		case 21:
			//Transferencias al exterior al sector publico
			resultado = getSolicitudBean().getSocSolicitudesDao().obtenerMontoTransAlExteriorSisFin(fInicio, fHasta);
			break;
			
			
		}
		return resultado.divide(new BigDecimal(String.valueOf(1000000)));
	}
	
	
	public void obtenerParametrosOperacionesCambiariasPorPeriodo(Date pFechaIni, Date pFechaFin, Map<String, Object> pParametros){
		pParametros.put("fechaInicio", pFechaIni);
		pParametros.put("fechaFin", pFechaFin);
		// Obtenemos el data source del reporte de dias de operaciones
		// cambiarias para el sector publico

		BigDecimal totalSecPubVentDia = new BigDecimal("0");
		BigDecimal totalSecPubVentBol = new BigDecimal("0");
		BigDecimal totalSecPubCompras = new BigDecimal("0");
		BigDecimal totalSecPubAlExt = new BigDecimal("0");
		BigDecimal totalSecPubDelExt = new BigDecimal("0");

		List<OperacionesCambiarias> dtSectorPublico = getSolicitudBean().getSocSolicitudesDao().obtenerInsitutcionOpeCambiariasSecPublico(pFechaIni, pFechaFin);
		log.info("Entidades para el sector publico " + dtSectorPublico.size());
			

		for (OperacionesCambiarias operacionesCambiarias : dtSectorPublico) {
			totalSecPubVentDia = totalSecPubVentDia.add(operacionesCambiarias.getVentasDia());
			totalSecPubVentBol = totalSecPubVentBol.add(operacionesCambiarias.getVentasBolsin());
			totalSecPubCompras = totalSecPubCompras.add(operacionesCambiarias.getCompras());
			totalSecPubAlExt = totalSecPubAlExt.add(operacionesCambiarias.getAlExterior());
			totalSecPubDelExt = totalSecPubDelExt.add(operacionesCambiarias.getDelExterior());
		}

		JRBeanCollectionDataSource beanDtSectorPublico = new JRBeanCollectionDataSource(
				dtSectorPublico, false);
		// Obtenemos el data source del reporte de dias de operaciones
		// cambiarias para el sistema financiero

		BigDecimal totalSisFinVentDia = new BigDecimal("0");
		BigDecimal totalSisFinVentBol = new BigDecimal("0");
		BigDecimal totalSisFinCompras = new BigDecimal("0");
		BigDecimal totalSisFinAlExt = new BigDecimal("0");
		BigDecimal totalSisFinDelExt = new BigDecimal("0");
		List<OperacionesCambiarias> dtSisFinanciero = getSolicitudBean()
				.getSocSolicitudesDao().obtenerInsitutcionOpeCambiariasSisFinanciero(pFechaIni,pFechaFin);
		// List<OperacionesCambiarias> dtSisFinanciero = new
		// ArrayList<OperacionesCambiarias>();
		log.info("Entidades para el sistema financiero "
				+ dtSisFinanciero.size());

		for (OperacionesCambiarias operacionesCambiarias : dtSisFinanciero) {
			totalSisFinVentDia = totalSisFinVentDia.add(operacionesCambiarias.getVentasDia());
			totalSisFinVentBol = totalSisFinVentBol.add(operacionesCambiarias.getVentasBolsin());
			totalSisFinCompras = totalSisFinCompras.add(operacionesCambiarias.getCompras());
			totalSisFinAlExt = totalSisFinAlExt.add(operacionesCambiarias.getAlExterior());
			totalSisFinDelExt = totalSisFinDelExt.add(operacionesCambiarias.getDelExterior());
		}

		JRBeanCollectionDataSource beanDtSisFinanciero = new JRBeanCollectionDataSource(dtSisFinanciero, false);

		// Obtenemos el data source del reporte de dias de operaciones
		// cambiarias para el sistema financiero
		BigDecimal totalCliSisFinVentDia = new BigDecimal("0");
		BigDecimal totalCliSisFinVentBol = new BigDecimal("0");
		BigDecimal totalCliSisFinCompras = new BigDecimal("0");
		BigDecimal totalCliSisFinAlExt = new BigDecimal("0");
		BigDecimal totalCliSisFinDelExt = new BigDecimal("0");
		List<OperacionesCambiarias> dtCliSisFinanciero = getSolicitudBean()
				.getSocSolicitudesDao().obtenerInsitutcionOpeCambiariasCliSisFinanciero(pFechaIni, pFechaFin);
		// List<OperacionesCambiarias> dtCliSisFinanciero = new
		// ArrayList<OperacionesCambiarias>();
		log.info("Entidades para clientes del sistema financiero " + dtCliSisFinanciero.size());

		for (OperacionesCambiarias operacionesCambiarias : dtCliSisFinanciero) {
			totalCliSisFinVentDia = totalCliSisFinVentDia.add(operacionesCambiarias.getVentasDia());
			totalCliSisFinVentBol = totalCliSisFinVentBol.add(operacionesCambiarias.getVentasBolsin());
			totalCliSisFinCompras = totalCliSisFinCompras.add(operacionesCambiarias.getCompras());
			totalCliSisFinAlExt = totalCliSisFinAlExt.add(operacionesCambiarias.getAlExterior());
			totalCliSisFinDelExt = totalCliSisFinDelExt.add(operacionesCambiarias.getDelExterior());
		}

		JRBeanCollectionDataSource beanDtCliSisFinanciero = new JRBeanCollectionDataSource(
				dtCliSisFinanciero, false);

		// Obtemos el valor del dia total para el sistema financiero
		totalSisFinVentDia = totalSisFinVentDia.add(totalCliSisFinVentDia);
		
		pParametros.put("totSisFinDia", totalSisFinVentDia);
		// Obtemos el valor de ventas bolsin total para el sistema
		// financiero
		totalSisFinVentBol = totalSisFinVentBol
				.add(totalCliSisFinVentBol);
		pParametros.put("totSisFinBol", totalSisFinVentBol);
		// Obtemos el valor de compras total para el sistema financiero
		totalSisFinCompras = totalSisFinCompras.add(totalCliSisFinCompras);
		pParametros.put("totSisFinCom", totalSisFinCompras);
		// Obtemos el valor de al exterior total para el sistema
		// financiero
		totalSisFinAlExt = totalSisFinAlExt.add(totalCliSisFinAlExt);
		pParametros.put("totSisFinAlE", totalSisFinAlExt);
		// Obtemos el valor del exterior total para el sistema
		// financiero
		totalSisFinDelExt = totalSisFinDelExt.add(totalCliSisFinDelExt);
		pParametros.put("totSisFinDEl", totalSisFinDelExt);

		// Obtenemos el data source de las otras isntituciones
		BigDecimal totalOtrosDelExt = new BigDecimal("0");
		BigDecimal totalOtrosCom = new BigDecimal("0");
		List<OperacionesCambiarias> dtOtros = getSolicitudBean()
				.getSocSolicitudesDao().obtenerInsitutcionOpeCambiariasOtros(pFechaIni, pFechaFin);
		log.info("Entidades para clientes del sistema financiero "
				+ dtOtros.size());

		for (OperacionesCambiarias operacionesCambiarias : dtOtros) {
			totalOtrosDelExt = totalOtrosDelExt.add(operacionesCambiarias.getDelExterior());
			totalOtrosCom = totalOtrosCom.add(operacionesCambiarias.getCompras());
			
		}

		JRBeanCollectionDataSource beanDtOtros = new JRBeanCollectionDataSource(
				dtOtros, false);

		// OBTENEMOS EL VALOR FINAL DEL DIA
		// Obtemos el valor del dia total para el sistema financiero
		totalSisFinVentDia = totalSisFinVentDia.add(totalSecPubVentDia);
		pParametros.put("totFinDia", totalSisFinVentDia);
		// Obtemos el valor de ventas bolsin total para el sistema
		// financiero
		totalSisFinVentBol = totalSisFinVentBol.add(totalSecPubVentBol);
		pParametros.put("totFinBol", totalSisFinVentBol);
		// Obtemos el valor de compras total para el sistema financiero
		totalSisFinCompras = totalSisFinCompras.add(totalSecPubCompras).add(totalOtrosCom);
		pParametros.put("totFinCom", totalSisFinCompras);
		// Obtemos el valor de al exterior total para el sistema
		// financiero
		totalSisFinAlExt = totalSisFinAlExt.add(totalSecPubAlExt);
		pParametros.put("totFinAlE", totalSisFinAlExt);
		// Obtemos el valor del exterior total para el sistema
		// financiero
		totalSisFinDelExt = totalSisFinDelExt.add(totalSecPubDelExt).add(totalOtrosDelExt);
		pParametros.put("totFinDEl", totalSisFinDelExt);

		pParametros.put("DS1", beanDtSectorPublico);
		pParametros.put("DS2", beanDtSisFinanciero);
		pParametros.put("DS3", beanDtCliSisFinanciero);
		pParametros.put("DS4", beanDtOtros);
		
		
	}
	
	
	public List<List<String>> obtenerFilasDiaSisFin(Date pFechaFin){
		
		int contador = 0;
		BigDecimal filaTotal = null;
		BigDecimal anual = null;
		BigDecimal mensual = null;
		BigDecimal mensualTotal = null;
		BigDecimal semanal = null;
		BigDecimal semanalTotal = null;
		
		DecimalFormatSymbols formatSymbols = new DecimalFormatSymbols(new Locale("es","BO"));
		formatSymbols.setDecimalSeparator(',');
		formatSymbols.setGroupingSeparator('.');
		DecimalFormat decimalFormat = new DecimalFormat("#,##0.0",formatSymbols);
		
		
		
		//Obtenemos el año de la fecha
		Calendar cal = Calendar.getInstance();
		cal.setTime(pFechaFin);
		int anho = cal.get(Calendar.YEAR);
					
		//Obtenemos el mes para el calculo de los meses anterirores
		int mes = cal.get(Calendar.MONTH);
		
		
		List<List<String>> rows = new ArrayList<List<String>>();
		//Obtenemos la fecha y el valor del año por fila
		
		cal.set(Calendar.YEAR, anho - 1);
		cal.set(Calendar.DAY_OF_YEAR, 1);    
		Date fechaInicio = cal.getTime();
		// Obtiene el ultimo dia del año
		cal.set(Calendar.YEAR, anho - 1);
		cal.set(Calendar.MONTH, 11); // 11 = december
		cal.set(Calendar.DAY_OF_MONTH, 31); // new years eve

		Date fechaFin = cal.getTime();
		
		Date fecIniMes = null;
		Date fecFinMes = null;
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fInicio = dateFormat.format(fechaInicio);
		String fHasta = dateFormat.format(pFechaFin);
		
		// Obtenemos las instituciones
		List<OperacionesCambiarias> instituciones = getSolicitudBean().getSocSolicitudesDao().obtenerListaEntidadBancariaDiaSistemaFinanciero(fInicio, fHasta);
		for (OperacionesCambiarias operacionesCambiarias : instituciones) {
			List<String> row = new ArrayList<String>();
			filaTotal = new BigDecimal("0");
	    	anual = new BigDecimal("0");
	    	mensual = new BigDecimal("0");
	    	mensualTotal = new BigDecimal("0");
	    	// Adiciona campos en blanco.
	    	row.add(0, " ");
			row.add(operacionesCambiarias.getInstitucion());
			rows.add(row);
			//Calculamos el total de la insitución de la gestion anterior
			anual = getSolicitudBean().getSocSolicitudesDao().obtenerMontoInstitucionDiaSisFinPorFecha(operacionesCambiarias.getCodInstitucion(), fechaInicio, fechaFin);
			row.add(decimalFormat.format(anual));
			
			// Calculamos el mes seleccionado y se obtentra el monto del mismo
			//Añadimos los valores de las filas en funcion al tiemmpo
			
			for (int i = 0; i <= mes; i++) {				
					//Obtenemos la fecha inicial y final de los meses
					 
					cal.set(Calendar.YEAR, anho);
					cal.set(Calendar.MONTH, i);
					cal.set(Calendar.DATE, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
					fecIniMes = cal.getTime();
					cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
					fecFinMes = cal.getTime();
					if(i!= mes){
						mensual = getSolicitudBean().getSocSolicitudesDao().obtenerMontoInstitucionDiaSisFinPorFecha(operacionesCambiarias.getCodInstitucion(), fecIniMes, fecFinMes);
						
						//Agregamos el valor mensual a la lista
						row.add(decimalFormat.format(mensual));
						mensualTotal = mensualTotal.add(mensual);
					} else {
						// Calculamos las semanas del ultimo mes
						int contadorSemana = 0;
						Calendar calSemana = Calendar.getInstance();
						semanal = BigDecimal.ZERO;
						semanalTotal = BigDecimal.ZERO;
						// Obtenemos el número de semana en función a la fecha final
						calSemana.setTime(pFechaFin);
						int nroSemana = calSemana.get(Calendar.WEEK_OF_MONTH);
						// Obtenemos las fechas de las semanas obtenidas en función a la fecha inicial
						calSemana.setTime(fecIniMes);						
						for (int j = 0; j < nroSemana; j++) {
							//Obtenemos la fecha de inicio y la fecha final en funcion al número de semana
							calSemana.set(Calendar.WEEK_OF_MONTH, j);
							List<Date> fechas = obtenerFechasInicioFin(fecIniMes, pFechaFin, j);
							if(fechas.size() > 0 ){
								fInicio = dateFormat.format(fechas.get(0));
								fHasta = dateFormat.format(fechas.size() - 1);
								
								semanal = getSolicitudBean().getSocSolicitudesDao().obtenerMontoInstitucionTransExteriorPorFecha(operacionesCambiarias.getCodInstitucion(), fInicio, fHasta);
							}
							
							semanalTotal = semanalTotal.add(semanal);
							row.add(decimalFormat.format(semanal));
						}
						mensualTotal = mensualTotal.add(semanalTotal);
								
						row.add(decimalFormat.format(semanalTotal));
					}
				
			}
			
			row.add(decimalFormat.format(mensualTotal));
		}
		
		
		
		return rows;
	}
	
	
	
	/**
	 * Método que retorna el nombre del dia actual del sistema
	 * 
	 * @param p_idioma
	 *            Entero que determina el idioma en que se retornara la
	 *            respuesta (0 -> español, 1-> ingles)
	 * @return Nombre del dia actual en el idioma determinado en el parametro
	 */
	public String getNombreDia(int p_idioma, int pDia) throws Exception {
		String[][] diaNombre = { {"Seleccione","Seleccione"},{ "Lunes", "Monday" },
				{ "Martes", "Tuesday" }, { "Miercoles", "Wednesday" },
				{ "Jueves", "Thursday" }, { "Viernes", "Friday" },
				{ "Sabado", "Saturday" }, { "Domingo", "Sunday" }, };
		/** se verifica que el parametro idioma sea valido **/
		if (p_idioma > 1)
			throw new Exception(
					"Error al intentar obtener el nombre del mes con el código de idioma "
							+ p_idioma);
		/** se calcula el mes del sistema */
		String mes = diaNombre[pDia - 1][p_idioma];
		/** se retorna el nombre del mes **/
		return mes;
	}
	
	/**
	 * Método que retorna el nombre del mes actual del sistema
	 * 
	 * @param p_idioma
	 *            Entero que determina el idioma en que se retornara la
	 *            respuesta (0 -> español, 1-> ingles)
	 * @return Nombre del mes actual en el idioma determinado en el parametro
	 */
	public String getNombreMes(int p_idioma, int pMes) throws Exception {
		String[][] mesNombre = { { "Enero", "January" },
				{ "Febrero", "Febrary" }, { "Marzo", "March" },
				{ "Abril", "April" }, { "Mayo", "May" }, { "Junio", "June" },
				{ "Julio", "July" }, { "Agosto", "August" },
				{ "Septiembre", "September" }, { "Octubre", "October" },
				{ "Noviembre", "November" }, { "Diciembre", "December" }, };
		/** se verifica que el parametro idioma sea valido **/
		if (p_idioma > 1)
			throw new Exception(
					"Error al intentar obtener el nombre del mes con el código de idioma "
							+ p_idioma);
		/** se calcula el mes del sistema */
		String mes = mesNombre[pMes][p_idioma];
		/** se retorna el nombre del mes **/
		return mes;
	}
	
}
