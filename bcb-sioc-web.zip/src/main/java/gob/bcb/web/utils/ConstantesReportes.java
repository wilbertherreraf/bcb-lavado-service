package gob.bcb.web.utils;

public class ConstantesReportes 
{
	// Constante para reporte de transferencias al exterior
	public static final String cReporteTransferenciasExterior = "vReporteTransferenciasExterior";
	
	// Constante para reporte de venta de dolares a traves de bolsin al sistema financiero.
	public static final String cReporteVentaDolaresBolsinSistemaFinanciero = "vReporteVentaDolaresBolsinSistemaFinanciero";
		
	// Constante para reporte de venta de Dólares Estadounidenses del Bolsin a Clientes del Sistema Financiero.
	public static final String cReporteVentaDolaresBolsinClientesSistemaFinanciero = "vReporteVentaDolaresBolsinClientesSistemaFinanciero";
	
	// Constante para reporte de venta de dolares en el dia al sistema financiero.
	public static final String cReporteVentaDolaresDiaSistemaFinanciero = "vReporteVentaDolaresDiaSistemaFinanciero";
	
	// Constante para reporte de venta de Dólares Estadounidenses en el dia al Clientes al Sistema Financiero.
	public static final String cReporteVentaDolaresDiaClientesSistemaFinanciero = "vReporteVentaDolaresDiaClientesSistemaFinanciero";

	// Constante para reporte de venta de Dólares Estadounidenses.
	public static final String cReporteVentaDolaresEstadounidenses = "vReporteVentaDolaresEstadounidenses";
	
	// Constante para reporte de Operaciones cambiarias en millonres de dólares estaounidenses.
	public static final String cReporteOperacionesCambiarias = "vReporteOperacionesCambiarias";	
	
	// Constante para para validar el periodo de un reporte.
	public static final String cPeriodoCero = "0";
	
	// Constante para para validar el periodo de un reporte.
	public static final String cPeriodoUno = "1";
		
	// Constante para para validar el periodo de un reporte.
	public static final String cPeriodoDos = "2";
	
	// Constante para para validar el periodo de un reporte.
	public static final String cPeriodoTres = "3";
	
	// Constante para para validar el periodo de un reporte.
	public static final String cPeriodoCuatro = "4";
	
}
