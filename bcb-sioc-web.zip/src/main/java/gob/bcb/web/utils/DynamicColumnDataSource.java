package gob.bcb.web.utils;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import net.sf.jasperreports.engine.data.JRAbstractBeanDataSource;
import net.sf.jasperreports.engine.design.JRDesignField;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.jfree.util.Log;

/**
 * Created by eborda on 01/11/2016.
 * Implementation of a Jasper Reports data source that can contain a dynamic number of columns
 */
public class DynamicColumnDataSource extends JRAbstractBeanDataSource {
    private List<String> columnHeaders;
    private List<List<String>> rows;
    private Iterator<List<String>> iterator;
    private List<String> currentRow;
    private int contadorColumnas;
    private int contadorfilas = 0;
    
    private String mes = "";
    private Logger log = Logger.getLogger(DynamicColumnDataSource.class);

    public DynamicColumnDataSource(List<String> columnHeaders, List<List<String>> rows, String pMes)
    {
        super(true);

        this.rows = rows;
        this.columnHeaders = columnHeaders;
        this.mes = pMes;

        if (this.rows != null && this.rows != null)
        {
            this.iterator = this.rows.iterator();
        }
    }

    
    public void moveFirst()
    {
        if (rows != null)
        {
            iterator = rows.iterator();
        }
    }

    
    public boolean next()
    {
        boolean hasNext = false;

        if (iterator != null)
        {
            hasNext = iterator.hasNext();

            if (hasNext)
            {
                this.currentRow = iterator.next();
            }
        }

        return hasNext;
    }

    
    public Object getFieldValue(JRField field) throws JRException
    {
        // The name of the field in dynamic columns that were created by DynamicReportBulder is also the index into the list of columns.
        // For example, if the field is named 'col1', this is the second (because it's zero-based) column in the currentRow.
    	                
    	String fieldName = field.getName();
            if (fieldName.startsWith(DynamicReportBuilder.COL_EXPR_PREFIX)) {
            String indexValue = fieldName.substring(DynamicReportBuilder.COL_EXPR_PREFIX.length());
            
            String column = currentRow.get(Integer.parseInt(indexValue));
            return column;
        }
        else if (fieldName.startsWith(DynamicReportBuilder.COL_HEADER_EXPR_PREFIX)) {
            int indexValue = Integer.parseInt(fieldName.substring(DynamicReportBuilder.COL_HEADER_EXPR_PREFIX.length()));
            String columnHeader = columnHeaders.get(indexValue);
            return columnHeader;
        }
        else if (fieldName.startsWith(DynamicReportBuilder.COL_EXPR_MES_FINAL)) {
            int indexValue = Integer.parseInt(fieldName.substring(DynamicReportBuilder.COL_EXPR_MES_FINAL.length()));
            String columnHeader = mes;
            return columnHeader;
        }
        else {
            throw new RuntimeException("The field name '" + fieldName + "' in the Jasper Report is not valid");
        }
    }
    
    
}
