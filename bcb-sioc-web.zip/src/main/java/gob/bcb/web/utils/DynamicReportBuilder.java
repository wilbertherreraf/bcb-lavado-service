package gob.bcb.web.utils;


import java.awt.Color;

import gob.bcb.portal.sioc.transferencias.controller.ReportesBolsinController;

import org.apache.log4j.Logger;
import org.apache.poi.xslf.usermodel.TextAlign;
import org.apache.poi.xwpf.usermodel.VerticalAlign;
import org.jfree.util.Log;

import com.informix.msg.csm_en_US;

import net.sf.jasperreports.engine.JRConditionalStyle;
import net.sf.jasperreports.engine.JRDefaultStyleProvider;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExpression;
import net.sf.jasperreports.engine.JRLineBox;
import net.sf.jasperreports.engine.JRParagraph;
import net.sf.jasperreports.engine.JRPen;
import net.sf.jasperreports.engine.JRStyle;
import net.sf.jasperreports.engine.design.*;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.type.FillEnum;
import net.sf.jasperreports.engine.type.HorizontalAlignEnum;
import net.sf.jasperreports.engine.type.HorizontalImageAlignEnum;
import net.sf.jasperreports.engine.type.HorizontalTextAlignEnum;
import net.sf.jasperreports.engine.type.LineSpacingEnum;
import net.sf.jasperreports.engine.type.ModeEnum;
import net.sf.jasperreports.engine.type.PositionTypeEnum;
import net.sf.jasperreports.engine.type.RotationEnum;
import net.sf.jasperreports.engine.type.ScaleImageEnum;
import net.sf.jasperreports.engine.type.VerticalAlignEnum;
import net.sf.jasperreports.engine.type.VerticalImageAlignEnum;
import net.sf.jasperreports.engine.type.VerticalTextAlignEnum;
import net.sf.jasperreports.engine.xml.JRConditionalStyleFactory;

/**
 * Created by eborda on 01/11/2016.
 * Uses the Jasper Report API to dynamically add columns to the Report
 */
public class DynamicReportBuilder {
    //The prefix used in defining the field name that is later used by the
    // JasperFillManager
    public static final String COL_EXPR_PREFIX = "col";

    // The prefix used in defining the column header name that is later
    // used by the JasperFillManager
    public static final String COL_HEADER_EXPR_PREFIX = "header";
    
    // Instancia prefijo utilizado para definir el nombre del encabezado de la columna que es posterior usado por el JasperFillManagerr.
    public static final String COL_EXPR_MES_FINAL = "mesFinal";

    // The page width for a page in portrait mode with 10 pixel margins
    private final static int TOTAL_PAGE_WIDTH = 725;

    // The whitespace between columns in pixels
    private final static int SPACE_BETWEEN_COLS = 0;

    // The height in pixels of an element in a row and column
    private final static int COLUMN_HEIGHT = 15;
    
 // The height in pixels of an element in a row and column
    private final static float LINE_WIDTH = 0.5f;

    // The total height of the column header or detail band
    private final static int BAND_HEIGHT = 15;

    // The left and right margin in pixels
    private final static int MARGIN = 15;

    // The JasperDesign object is the internal representation of a report
    private JasperDesign jasperDesign;

    // The number of columns that are to be displayed
    private int numColumns;
    
    private Logger log = Logger.getLogger(DynamicReportBuilder.class);
    

    public DynamicReportBuilder(JasperDesign jasperDesign, int numColumns) {
        this.jasperDesign = jasperDesign;
        this.numColumns = numColumns;
    }


    public void addDynamicColumns() throws JRException {

        JRDesignBand detailBand = new JRDesignBand();
        JRDesignBand headerBand = new JRDesignBand();

        JRDesignStyle normalStyle = getCustomlStyle();
        JRDesignStyle columnHeaderStyle = getColumnHeaderStyle();
        jasperDesign.addStyle(normalStyle);
        jasperDesign.addStyle(columnHeaderStyle);
        jasperDesign.setColumnSpacing(0);
        int xPos = MARGIN;
        
        int columnWidth = 0;
        columnWidth = (int) (((TOTAL_PAGE_WIDTH - 130 - (xPos * 2)) / (numColumns )) + (0.5));
//        if(numColumns <= 15 ){
//        	columnWidth = (int) ((TOTAL_PAGE_WIDTH - 130  - (xPos * 2) -  ((numColumns) * 0.5)) / (numColumns ));
//        } else {
//        	columnWidth = (int) ((TOTAL_PAGE_WIDTH - 130  - (xPos * 2) -  ((numColumns) * 0.5)) / (numColumns - 1));
//        }
               
        for (int i = 0; i < numColumns; i++) {

            // Create a Column Field
            JRDesignField field = new JRDesignField();
            field.setName(COL_EXPR_PREFIX + i);
            field.setValueClass(java.lang.String.class);
            jasperDesign.addField(field);

            // Create a Header Field
            JRDesignField headerField = new JRDesignField();
            headerField.setName(COL_HEADER_EXPR_PREFIX + i);
            headerField.setValueClass(java.lang.String.class);
            jasperDesign.addField(headerField);

            // Add a Header Field to the headerBand
            headerBand.setHeight(BAND_HEIGHT);
            
            JRDesignTextField colHeaderField = new JRDesignTextField();
            
            colHeaderField.setX(xPos);
            colHeaderField.setY(0);
            if(i == 0){
            	colHeaderField.setWidth(130);
            } else{
            	colHeaderField.setWidth(columnWidth);
            }

            colHeaderField.setHeight(COLUMN_HEIGHT);
            colHeaderField.setHorizontalAlignment(HorizontalAlignEnum.CENTER);
            colHeaderField.setStyle(columnHeaderStyle);
            // Dibujamos los bordes de la cabecera
            if(i != 0){
            	colHeaderField.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);	
            }
            
            colHeaderField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
            colHeaderField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
            
            JRDesignExpression headerExpression = new JRDesignExpression();
            headerExpression.setValueClass(java.lang.String.class);
            headerExpression.setText("$F{" + COL_HEADER_EXPR_PREFIX + i + "}");
            colHeaderField.setExpression(headerExpression);
            headerBand.addElement(colHeaderField);

            // Add text field to the detailBand
            detailBand.setHeight(BAND_HEIGHT);
            JRDesignTextField textField = new JRDesignTextField();
            
                        
            textField.setX(xPos);
            textField.setY(0);
        
            
            if(i == 0){
            	textField.setWidth(130);
            } else{
            	textField.setWidth(columnWidth);
            }
            
            textField.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);
            textField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
            textField.setHeight(COLUMN_HEIGHT);
        
            if(i == 0){
            	textField.setHorizontalAlignment(HorizontalAlignEnum.LEFT);	
            } else {
            	textField.setHorizontalAlignment(HorizontalAlignEnum.RIGHT);	
            }    
            if(i == 0){
            	textField.getParagraph().setLeftIndent(3);
            } else {
            	textField.getParagraph().setRightIndent(3);	
            }
            
            
            
            textField.setStyle(normalStyle);
            textField.setMarkup("html");
            
            JRDesignExpression expression = new JRDesignExpression();
            expression.setValueClass(java.lang.String.class);
            expression.setText("$F{" + COL_EXPR_PREFIX + i + "}");
            
            JRDesignExpression expressionVacia = new JRDesignExpression();
            expressionVacia.setValueClass(java.lang.String.class);
            
            
            
            textField.setExpression(expression);
            
            detailBand.addElement(textField);
            

            if(i == 0){
            	xPos = xPos + 130;
            } else{
            	xPos = xPos + columnWidth + SPACE_BETWEEN_COLS;	
            }
            
        }
        
        jasperDesign.setColumnHeader(headerBand);
        ((JRDesignSection)jasperDesign.getDetailSection()).addBand(detailBand);
    }
    
    
    public void addDynamicColumnsTransExt() throws JRException {

        JRDesignBand detailBand = new JRDesignBand();
        JRDesignBand headerBand = new JRDesignBand();

        JRDesignStyle normalStyle = getNormalStyle();
        JRDesignStyle columnHeaderStyle = getColumnHeaderStyle();
        jasperDesign.addStyle(normalStyle);
        jasperDesign.addStyle(columnHeaderStyle);
        jasperDesign.setColumnSpacing(0);
        int xPos = MARGIN;
        
//        int columnWidth = ((TOTAL_PAGE_WIDTH - ((numColumns - 1))) / numColumns);
        int columnWidth = ((TOTAL_PAGE_WIDTH - 130) / (numColumns - 1));
               
        for (int i = 0; i < numColumns; i++) {

            // Create a Column Field
            JRDesignField field = new JRDesignField();
            field.setName(COL_EXPR_PREFIX + i);
            field.setValueClass(java.lang.String.class);
            jasperDesign.addField(field);

            // Create a Header Field
            JRDesignField headerField = new JRDesignField();
            headerField.setName(COL_HEADER_EXPR_PREFIX + i);
            headerField.setValueClass(java.lang.String.class);
            jasperDesign.addField(headerField);

            // Add a Header Field to the headerBand
            headerBand.setHeight(BAND_HEIGHT);
            
            JRDesignTextField colHeaderField = new JRDesignTextField();
            
            colHeaderField.setX(xPos);
            colHeaderField.setY(0);
            if(i == 0){
            	colHeaderField.setWidth(130);
            } else{
            	colHeaderField.setWidth(columnWidth);
            }

            colHeaderField.setHeight(COLUMN_HEIGHT);
            colHeaderField.setHorizontalAlignment(HorizontalAlignEnum.CENTER);
            colHeaderField.setStyle(columnHeaderStyle);
            // Dibujamos los bordes de la cabecera
            if(i != 0){
            	colHeaderField.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);	
            }
            
            colHeaderField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
            colHeaderField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
            
            JRDesignExpression headerExpression = new JRDesignExpression();
            headerExpression.setValueClass(java.lang.String.class);
            headerExpression.setText("$F{" + COL_HEADER_EXPR_PREFIX + i + "}");
            colHeaderField.setExpression(headerExpression);
            headerBand.addElement(colHeaderField);

            // Add text field to the detailBand
            detailBand.setHeight(BAND_HEIGHT);
            JRDesignTextField textField = new JRDesignTextField();
            
                        
            textField.setX(xPos);
            textField.setY(0);
        
            
            if(i == 0){
            	textField.setWidth(130);
            } else{
            	textField.setWidth(columnWidth);
            }
            
            textField.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);
            textField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
            textField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
            textField.setHeight(COLUMN_HEIGHT);
        
            if(i == 0){
            	textField.setHorizontalAlignment(HorizontalAlignEnum.LEFT);	
            } else {
            	textField.setHorizontalAlignment(HorizontalAlignEnum.RIGHT);	
            }    
            if(i == 0){
            	textField.getParagraph().setLeftIndent(3);
            } else {
            	textField.getParagraph().setRightIndent(3);	
            }
            
            
            
            textField.setStyle(normalStyle);
            textField.setMarkup("html");
            
            JRDesignExpression expression = new JRDesignExpression();
            expression.setValueClass(java.lang.String.class);
            expression.setText("$F{" + COL_EXPR_PREFIX + i + "}");
            
            JRDesignExpression expressionVacia = new JRDesignExpression();
            expressionVacia.setValueClass(java.lang.String.class);
            
            
            
            textField.setExpression(expression);
            
            detailBand.addElement(textField);
            

            if(i == 0){
            	xPos = xPos + 130;
            } else{
            	xPos = xPos + columnWidth + SPACE_BETWEEN_COLS;	
            }
            
        }
        
        jasperDesign.setColumnHeader(headerBand);
        ((JRDesignSection)jasperDesign.getDetailSection()).addBand(detailBand);
    }

    private JRDesignStyle getNormalStyle() {
        JRDesignStyle normalStyle = new JRDesignStyle();
        normalStyle.setName("Sans_Normal");
        normalStyle.setDefault(true);
        normalStyle.setFontName("SansSerif");
        normalStyle.setFontSize(8);
        normalStyle.setPdfFontName("Helvetica");
        normalStyle.setPdfEncoding("Cp1252");
        normalStyle.setPdfEmbedded(false);
        return normalStyle;
    }


    private JRDesignStyle getCustomlStyle() {
        JRDesignStyle normalStyle = new JRDesignStyle();
        
        JRDesignConditionalStyle cSBoldUnderline = new JRDesignConditionalStyle();
        //Adicionamos las condiciones
        JRDesignExpression expressionBUnderline = new JRDesignExpression();
        // Añadimos las condiciones para el cambio de caja de linea
        String boldUnderlineExpression = "new Boolean($V{REPORT_COUNT} == 1 || $V{REPORT_COUNT} == 15)";
        expressionBUnderline.setText(boldUnderlineExpression);
        cSBoldUnderline.setConditionExpression(expressionBUnderline);
        cSBoldUnderline.setBold(true);
        cSBoldUnderline.setUnderline(true);
        normalStyle.addConditionalStyle(cSBoldUnderline);        
        
        JRDesignConditionalStyle cSBold = new JRDesignConditionalStyle();
        //Adicionamos las condiciones           
        JRDesignExpression expressionBold = new JRDesignExpression();
        // Añadimos las condiciones para el cambio de caja de linea
        String boldExpression = "new Boolean($V{REPORT_COUNT} == 2 || $V{REPORT_COUNT} == 3|| $V{REPORT_COUNT} == 4 || $V{REPORT_COUNT} == 7 || " +
        		"$V{REPORT_COUNT} == 10 || $V{REPORT_COUNT} == 11 || $V{REPORT_COUNT} == 16 || $V{REPORT_COUNT} == 20)";
        expressionBold.setText(boldExpression);
        cSBold.setConditionExpression(expressionBold);
        cSBold.setBold(true);
        normalStyle.addConditionalStyle(cSBold);
        
        
        JRDesignConditionalStyle cSBottomLine = new JRDesignConditionalStyle();
        //Adicionamos las condiciones
        JRDesignExpression expressionBottomLine = new JRDesignExpression();
        // Añadimos las condiciones para el cambio de caja de linea
        String bottomLineExpression = "new Boolean($V{REPORT_COUNT} == 13 || $V{REPORT_COUNT} == 22)";
        expressionBottomLine.setText(bottomLineExpression);
        cSBottomLine.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
        cSBottomLine.setConditionExpression(expressionBottomLine);
        normalStyle.addConditionalStyle(cSBottomLine);
        
        JRDesignConditionalStyle cSNoLine = new JRDesignConditionalStyle();
        //Adicionamos las condiciones
        JRDesignExpression expressionNoLine = new JRDesignExpression();
        // Añadimos las condiciones para el cambio de caja de linea
        String noLineExpression = "new Boolean($V{REPORT_COUNT} == 14)";
        expressionNoLine.setText(noLineExpression);
        cSNoLine.getLineBox().getLeftPen().setLineColor(Color.WHITE);
        cSNoLine.getLineBox().getRightPen().setLineColor(Color.WHITE);
                       
        cSNoLine.setConditionExpression(expressionNoLine);
        normalStyle.addConditionalStyle(cSNoLine);
        
        JRDesignConditionalStyle cSTopLine = new JRDesignConditionalStyle();
        //Adicionamos las condiciones
        JRDesignExpression expressionTopLine = new JRDesignExpression();
        // Añadimos las condiciones para el cambio de caja de linea
        String topLineExpression = "new Boolean($V{REPORT_COUNT} == 15)";
        expressionTopLine.setText(topLineExpression);
        cSTopLine.getLineBox().getTopPen().setLineWidth(LINE_WIDTH);
        cSTopLine.setConditionExpression(expressionTopLine);
        normalStyle.addConditionalStyle(cSTopLine);
                             
        normalStyle.setName("Sans_Normal");
        normalStyle.setDefault(true);
        normalStyle.setFontName("SansSerif");
        normalStyle.setFontSize(7);
        normalStyle.setPdfFontName("Helvetica");
        VerticalTextAlignEnum verticalTextAlign = VerticalTextAlignEnum.MIDDLE;
        normalStyle.setVerticalTextAlign(verticalTextAlign);
        normalStyle.setPdfEncoding("Cp1252");
        normalStyle.setPdfEmbedded(false);
        return normalStyle;
    }

    private JRDesignStyle getColumnHeaderStyle() {
        JRDesignStyle columnHeaderStyle = new JRDesignStyle();
        columnHeaderStyle.setName("Sans_Header");
        columnHeaderStyle.setDefault(false);
        columnHeaderStyle.setFontName("SansSerif");
        columnHeaderStyle.setFontSize(8);
        columnHeaderStyle.setBold(false);
        VerticalTextAlignEnum verticalTextAlign = VerticalTextAlignEnum.MIDDLE;
        HorizontalTextAlignEnum horizontalTextAlign = HorizontalTextAlignEnum.CENTER;        
        columnHeaderStyle.setVerticalTextAlign(verticalTextAlign);
        columnHeaderStyle.setHorizontalTextAlign(horizontalTextAlign);
        columnHeaderStyle.setPdfFontName("Helvetica");
        columnHeaderStyle.setPdfEncoding("Cp1252");
        columnHeaderStyle.setPdfEmbedded(false);
        return columnHeaderStyle;
    }

}

