package gob.bcb.web.utils;

public class FechaPojo 
{
	// Valor de gestión.
	private int gestionValor;
	// Literal de gestión.
	private String gestionLiteral;
	// Valor de mes.
	private int mesValor;
	// Literal de mes.
	private String mesLiteral;
	// Valor de semana.
	private int semanaValor;
	// Literal de semana.
	private String semanaLiteral;
	// Valor de dia.
	private int diaValor;
	// Literal de dia.
	private String diaLiteral;
	
	private int diasValidos;
	
	/**
	* Constructor de la clase.
	**/
	public FechaPojo()
	{
		
	}
	
	/**
	* Constructor de la clase con parametros de entrada.
	* @param pGestionValor Valor de gestión.
	* @param pGestionLiteral Valor literal de gestión.
	* @param pMesValor Valor de mes.
	* @param pMesLiteral Valor literal de mes.
	* @param pSemanaValor Valor de semana.
	* @param pSemanaLiteral Valor literal de semana.
	* @param pDiaValor Valor de dia.
	* @param pDiaLiteral Valor literal de dia.
	**/
	public FechaPojo(int pGestionValor, String pGestionLiteral, int pMesValor, String pMesLiteral, int pSemanaValor, String pSemanaLiteral, int pDiaValor, String pDiaLiteral, int pDiasValidos)
	{		
		// Almacena variables de entrada.
		this.gestionValor = pGestionValor;
		this.gestionLiteral = pGestionLiteral;
		this.mesValor = pMesValor;
		this.mesLiteral = pMesLiteral;
		this.semanaValor = pSemanaValor;
		this.semanaLiteral = pSemanaLiteral;
		this.diaValor = pDiaValor;
		this.diaLiteral = pDiaLiteral;
		this.diasValidos = pDiasValidos;				
	}
	
	// Método para obtener valor de la gestión.
	public int getGestionValor()
	{
		return gestionValor;
	}
	
	// Método para establecer valor de la gestión.
	public void setGestionValor(int pGestionValor)
	{
		gestionValor = pGestionValor;
	}
	
	// Método para obtener valor literal de la gestión.
	public String getGestionLiteral()
	{
		return gestionLiteral;
	}
	
	// Método para establecer valor literal de la gestión.
	public void setGestionLiteral(String pGestionLiteral)
	{
		gestionLiteral = pGestionLiteral;
	}
	
	// Método para obtener valor del mes.
	public int getMesValor() {
		return mesValor;
	}

	// Método para establecer valor del mes.
	public void setMesValor(int mesValor) {
		this.mesValor = mesValor;
	}

	// Método para obtener valor literal del mes.
	public String getMesLiteral() {
		return mesLiteral;
	}
	
	// Método para establecer valor literal del mes.
	public void setMesLiteral(String mesLiteral) {
		this.mesLiteral = mesLiteral;
	}
	
	// Método para obtener valor de la semana.
	public int getSemanaValor() {
		return semanaValor;
	}
	
	// Método para establecer valor de la semana.
	public void setSemanaValor(int semanaValor) {
		this.semanaValor = semanaValor;
	}
	
	// Método para obtener valor literal de la semana.
	public String getSemanaLiteral() {
		return semanaLiteral;
	}
	
	// Método para establecer valor literal de la semana.
	public void setSemanaLiteral(String semanaLiteral) {
		this.semanaLiteral = semanaLiteral;
	}
	
	// Método para obtener valor del dia.
	public int getDiaValor() {
		return diaValor;
	}
	
	// Método para establecer valor del dia.
	public void setDiaValor(int diaValor) {
		this.diaValor = diaValor;
	}
	
	// Método para obtener valor literal del dia.
	public String getDiaLiteral() {
		return diaLiteral;
	}
	
	// Método para establecer valor literal del dia.
	public void setDiaLiteral(String diaLiteral) {
		this.diaLiteral = diaLiteral;
	}
	
	
	public int getDiasValidos(){
		return diasValidos;
	}
	
	public void setDiasValidos(int pDiasValidos){
		this.diasValidos = pDiasValidos;
	}
	
	
}
