package gob.bcb.web.utils;

import gob.bcb.portal.sioc.transferencias.controller.ReportesBolsinController;

import java.awt.Color;

import net.sf.jasperreports.engine.JRElement;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.design.JRDesignBand;
import net.sf.jasperreports.engine.design.JRDesignConditionalStyle;
import net.sf.jasperreports.engine.design.JRDesignExpression;
import net.sf.jasperreports.engine.design.JRDesignField;
import net.sf.jasperreports.engine.design.JRDesignSection;
import net.sf.jasperreports.engine.design.JRDesignSortField;
import net.sf.jasperreports.engine.design.JRDesignStyle;
import net.sf.jasperreports.engine.design.JRDesignTextField;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.type.HorizontalAlignEnum;
import net.sf.jasperreports.engine.type.HorizontalTextAlignEnum;
import net.sf.jasperreports.engine.type.StretchTypeEnum;
import net.sf.jasperreports.engine.type.VerticalTextAlignEnum;

import org.apache.log4j.Logger;

public class ConstructorReporteDinamico {

	// Instancia prefijo utilizado en la definición del nombre del campo que más tarde.
    public static final String COL_EXPR_PREFIX = "col";


    // Instancia prefijo utilizado para definir el nombre del encabezado de la columna que es posterior usado por el JasperFillManagerr.
    public static final String COL_HEADER_EXPR_PREFIX = "header";
    
    // Instancia prefijo utilizado para definir el nombre del encabezado de la columna que es posterior usado por el JasperFillManagerr.
    public static final String COL_EXPR_MES_FINAL = "mesFinal";


    // Instancia ancho de página de una página en modo vertical con 10 márgenes de píxeles.
    private static int TOTAL_PAGE_WIDTH = 792;//725;

    // Instancia espacio en blanco entre columnas en píxeles.
    private final static int SPACE_BETWEEN_COLS = 0;

    // Instancia altura en píxeles de un elemento de una fila y una columna.
    private final static int COLUMN_HEIGHT = 30;
    
    // Instancia ancho de la linea del reporte de cada celda.
    private final static float LINE_WIDTH = 0.5f;

    // Instancia altura total del encabezado de columna o banda de cabecera.
    private final static int BAND_HEIGHT = 30;
    
    // Instancia altura total del cuerpo de columna o banda de detalle.
    private final static int BAND_DETALLE_ALTO = 15;
    
    // Instancia alto de las celdas del cuerpo del reporte.
    private final static int COLUMN_DETALLE_ALTO = 15;

    // Instancia margen izquierdo y derecho en píxeles.
    private final static int MARGIN = 5; //15
    
    // Instancia objeto JasperDesign es la representación interna de un informe.
    private JasperDesign jasperDesign;
    
    // Inicializa número de columnas que se van a mostrar.
    private int numColumns;
    
    // Inicializa número de columnas de semanas a mostrar.
    private int vNumeroColumnasSemana;
    
    // Inicializa número de columnas a restar para el pivote.
    private int vNumeroColumnaPivote;
    
 // Inicializa número de columnas a restar para el pivote.
    private int vEstiloReporte;
    
    /*
     * Constructor del reporte dinámico.
     * */
    public ConstructorReporteDinamico(JasperDesign jasperDesign, int numColumns, int pNumeroColumnasSemana, int pNumeroColumnaPivote, int pEstiloReporte) {
        this.jasperDesign = jasperDesign;
        this.numColumns = numColumns;
        this.vNumeroColumnasSemana = pNumeroColumnasSemana;
        this.vNumeroColumnaPivote = pNumeroColumnaPivote;
        this.vEstiloReporte = pEstiloReporte;
    }
    
    /*
     * Método que adicion a celdas dinamicamente.
     * */
	public void addDynamicColumns() throws JRException {

		int vNumeroColumna = this.numColumns - vNumeroColumnaPivote;
		int vCantidadColumnaSemana = vNumeroColumnasSemana;

		int vContadorColumnas = 1;
		int sw = 0;

		int vNumeroColumnaCabecera = this.numColumns - vNumeroColumnaPivote; 
		int vCantidadColumnaSemanaCabecera = vNumeroColumnasSemana;

		int vContadorColumnasCabecera = 1;

		// Instancia clase de tipo "JRDesignBand", seccion de detalle del
		// reporte.
		JRDesignBand detailBand = new JRDesignBand();
		// Instancia clase de tipo "JRDesignBand", seccion de titulo del
		// reporte.
		JRDesignBand headerBand = new JRDesignBand();

		// Instancia clase de tipo "JRDesignStyle" para el estilo del cuerpo del
		// reporte.
		// JRDesignStyle normalStyle = getNormalStyle();
		// Instancia clase de tipo "JRDesignStyle" para el estilo de las
		// cabeceras del reporte.
		JRDesignStyle columnHeaderStyle = getColumnHeaderStyle();

		// Obtiene tipo de estilo definido.
		JRDesignStyle normalStyle = obtenerTipoEstilo(vEstiloReporte);

		// Adiciona el estilo "normalStyle" al diseño del reporte.
		jasperDesign.addStyle(normalStyle);
		// Adiciona el estilo "columnHeaderStyle" al diseño del reporte.
		jasperDesign.addStyle(columnHeaderStyle);
		// Adiciona espaciado de columnas.
		jasperDesign.setColumnSpacing(0);
		
		// Obtiene el valor del margen.
		int xPos = MARGIN;
		int vPosCuerpo = MARGIN;

			
		int columnWidth = 34;
		
		int pageWidth = (numColumns * columnWidth) + 130;
		int diferencia = pageWidth - TOTAL_PAGE_WIDTH;
		

		
		if(pageWidth > TOTAL_PAGE_WIDTH){
			JRElement[] titleElements = jasperDesign.getTitle().getElements();
			for (JRElement jrElement : titleElements) {
				String key = jrElement.getKey();
				if(key != null){
					if("txtTitulo".equals(key)){
						int posX = jrElement.getX();
						int posCal = (diferencia * 45)/100;
						int nuevaPosX = posX + posCal;
						jrElement.setX(nuevaPosX);
					}else{
						int posX = jrElement.getX();
						int nuevaPosX = posX + diferencia - 100;
						jrElement.setX(nuevaPosX);
					}
											
				}
			}
			jasperDesign.setPageWidth(pageWidth);
		} else{
			// Recalculamos el ancho de las columnas
			columnWidth = ((TOTAL_PAGE_WIDTH - 130) / numColumns);
			jasperDesign.setPageWidth(TOTAL_PAGE_WIDTH);
		}
	
		
		// Calculamos el ancho de la semana tomando el 80% del ancho de la
		// columna
		int columnWeekWidth = (columnWidth * 80) / 100;
		
		
		int columnWeekTotalWidth = columnWeekWidth * vNumeroColumnasSemana;
		int vAnchoColumnaSemana = columnWeekTotalWidth / vNumeroColumnasSemana;

		// Recorre el numero de columnas.
		for (int i = 0; i <= numColumns; i++) {
			if (i == numColumns) {
				// Instancia clase de tipo celda "JRDesignField" para el cuerpo.
				JRDesignField fieldMes = new JRDesignField();
				// Adiciona el nombre de la columna.
				fieldMes.setName(COL_EXPR_MES_FINAL + 1);

				// Adiciona el tipo de la celda, tipo cadena.
				fieldMes.setValueClass(java.lang.String.class);
				// Adiciona la celda al diseño del reporte.
				jasperDesign.addField(fieldMes);
				break;
			}

			// Instancia clase de tipo celda "JRDesignField" para el cuerpo.
			JRDesignField field = new JRDesignField();
			// Adiciona el nombre de la columna.
			field.setName(COL_EXPR_PREFIX + i);

			// Adiciona el tipo de la celda, tipo cadena.
			field.setValueClass(java.lang.String.class);
			// Adiciona la celda al diseño del reporte.
			jasperDesign.addField(field);

			// Instancia clase de tipo celda "JRDesignField" para la cabecera.
			JRDesignField headerField = new JRDesignField();
			// Adiciona el nombre de la columna.
			headerField.setName(COL_HEADER_EXPR_PREFIX + i);
			// Adiciona el tipo de la celda, tipo cadena.
			headerField.setValueClass(java.lang.String.class);
			// Adiciona la celda al diseño del reporte.
			jasperDesign.addField(headerField);

			// Adiciona alto para la seccion de cabecera del reporte.
			headerBand.setHeight(BAND_HEIGHT);
			// Adiciona alto para la seccion de detalle del reporte.
			detailBand.setHeight(BAND_DETALLE_ALTO);

			// Instancia clase de tipo "JRDesignTextField" para la cabecera del
			// reporte.
			JRDesignTextField colHeaderField = new JRDesignTextField();
			// Adiciona posición x para la celda cabecera del reporte.
			colHeaderField.setX(xPos);
			// Adiciona posición y para la celda cabecera del reporte.
			colHeaderField.setY(0);

			// Verifica posicion.
			if (i == 0) {
				if (vEstiloReporte == 2) {
					// Ancho de la celda.
					colHeaderField.setWidth(10);
					// Dibuja alto para la celda.
					colHeaderField.setHeight(COLUMN_HEIGHT);
					// Obtiene formato de la celda de la cabecera.
					colHeaderField = this.obtenerFomatoCeldaCabecera(i, colHeaderField, columnHeaderStyle);
					// Adiciona celda a la seccion de cabecera del reporte.
					headerBand.addElement(colHeaderField);
				} else {
					// Ancho de la celda.
					colHeaderField.setWidth(10);
					// Dibuja linea inferior.
					colHeaderField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
					// Dibuja alto para la celda.
					colHeaderField.setHeight(COLUMN_HEIGHT);
					// Obtiene formato de la celda de la cabecera.
					colHeaderField = this.obtenerFomatoCeldaCabecera(i, colHeaderField, columnHeaderStyle);
					// Adiciona celda a la seccion de cabecera del reporte.
					headerBand.addElement(colHeaderField);
				}
				// Adiciona a la posicion segun el ancho de la celda.
				xPos = xPos + 10;
			} else if (i == 1) {
				// Ancho de la celda.
				colHeaderField.setWidth(130);
				// Dibuja linea derecha.
				colHeaderField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
				// Dibuja linea inferior.
				colHeaderField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
				// Dibuja alto para la celda.
				colHeaderField.setHeight(COLUMN_HEIGHT);
				// Obtiene formato de la celda de la cabecera.
				colHeaderField = this.obtenerFomatoCeldaCabecera(i, colHeaderField, columnHeaderStyle);
				// Adiciona celda a la seccion de cabecera del reporte.
				headerBand.addElement(colHeaderField);
				// Adiciona a la posicion segun el ancho de la celda.
				xPos = xPos + 130;
			} else if (vNumeroColumnaCabecera == i) {
				// Instancia posicion para la celda con mayor ancho.
				int vPosicionCeldaPivote = xPos;

				// Verifica que el contador de cabecera sea menor que la
				// cantidad de columnas de semanas.
				if (vContadorColumnasCabecera <= vCantidadColumnaSemanaCabecera) {
					// Instancia clase de tipo "JRDesignTextField" para la
					// cabecera del reporte.
					JRDesignTextField colHeaderFieldAux = new JRDesignTextField();
					// Obtiene formato de la celda de la cabecera.
					colHeaderFieldAux = obtenerCeldaCabeceraSemanaMes(xPos, i, columnHeaderStyle, vAnchoColumnaSemana);
					// Adiciona celda a la seccion de cabecera del reporte.
					headerBand.addElement(colHeaderFieldAux);
					// Incrementa en uno numero de columna.
					vNumeroColumnaCabecera++;
					// Incrementa en uno contador de columnas.
					vContadorColumnasCabecera++;
					// Adiciona a la posicion segun el ancho de la celda.
					xPos = xPos + vAnchoColumnaSemana;
				} else {
					// Ancho de la celda.
					colHeaderField.setWidth(columnWidth);
					// Dibuja linea izquierda.
					colHeaderField.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);
					// Dibuja linea superior.
					colHeaderField.getLineBox().getTopPen().setLineWidth(LINE_WIDTH);
					// Dibuja linea derecha.
					colHeaderField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
					// Dibuja linea inferior.
					colHeaderField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
					// Dibuja alto para la celda.
					colHeaderField.setHeight(COLUMN_HEIGHT);
					// Obtiene formato de la celda de la cabecera.
					colHeaderField = this.obtenerFomatoCeldaCabecera(i, colHeaderField, columnHeaderStyle);
					// Adiciona celda a la seccion de cabecera del reporte.
					headerBand.addElement(colHeaderField);
					// Adiciona a las demas posiciones.
					xPos = xPos + columnWidth + SPACE_BETWEEN_COLS;
				}

				// Verifica que solo cree una vez la celda.
				if (sw == 0) {
					// Instancia clase de tipo "JRDesignTextField" para la
					// cabecera del reporte.
					JRDesignTextField colHeaderFieldPivote = new JRDesignTextField();
					// Ancho de la celda.
					colHeaderFieldPivote.setWidth(columnWeekTotalWidth);
					// Dibuja linea derecha.
					colHeaderFieldPivote.getLineBox().getTopPen().setLineWidth(LINE_WIDTH);
					// Dibuja linea derecha.
					colHeaderFieldPivote.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
					// Dibuja linea inferior.
					colHeaderFieldPivote.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
					// Dibuja alto para la celda.
					colHeaderFieldPivote.setHeight(COLUMN_DETALLE_ALTO);

					// Alinea contenido al centro.
					colHeaderFieldPivote.setHorizontalAlignment(HorizontalAlignEnum.CENTER);
					// Adiciona estilo a la columna creada.
					colHeaderFieldPivote.setStyle(columnHeaderStyle);
					// Instancia clase de tipo "JRDesignExpression".
					JRDesignExpression headerExpression1 = new JRDesignExpression();
					// Adiciona tipo de expresion, tipo cadena.
					headerExpression1.setValueClass(java.lang.String.class);
					// Adiciona nombre de la expresion para la celda.
					headerExpression1.setText("$F{" + COL_EXPR_MES_FINAL + 1 + "}");
					// Adiciona la expresion a la celda cabecera.
					colHeaderFieldPivote.setExpression(headerExpression1);

					// Obtiene formato de la celda de la cabecera.
					// colHeaderFieldPivote = this.obtenerFomatoCeldaCabecera(i,
					// colHeaderFieldPivote, columnHeaderStyle);

					// Adiciona posicion para la celda pivote.
					colHeaderFieldPivote.setX(vPosicionCeldaPivote);
					// Adiciona celda a la seccion de cabecera del reporte.
					headerBand.addElement(colHeaderFieldPivote);
					// Cambia de estado.
					sw = 1;
				}
			} else {
				// Ancho de la celda.
				colHeaderField.setWidth(columnWidth);
				// Dibuja linea izquierda.
				colHeaderField.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);
				// Dibuja linea superior.
				colHeaderField.getLineBox().getTopPen().setLineWidth(LINE_WIDTH);
				// Dibuja linea derecha.
				colHeaderField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
				// Dibuja linea inferior.
				colHeaderField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
				// Dibuja alto para la celda.
				colHeaderField.setHeight(COLUMN_HEIGHT);
				// Obtiene formato de la celda de la cabecera.
				colHeaderField = this.obtenerFomatoCeldaCabecera(i, colHeaderField, columnHeaderStyle);
				// Adiciona celda a la seccion de cabecera del reporte.
				headerBand.addElement(colHeaderField);
				// Adiciona a la posicion segun el ancho de la celda.
				xPos = xPos + columnWidth + SPACE_BETWEEN_COLS;
			}

			// Instancia objeto de tipo "JRDesignTextField" para el cuerpo del
			// reporte.
			JRDesignTextField textField = new JRDesignTextField();

			// Genramos codigo para expancion de textos
			textField.setStretchType(StretchTypeEnum.RELATIVE_TO_TALLEST_OBJECT);
			textField.setStretchWithOverflow(true);

			// Adiciona posición x para la celda cuerpo del reporte.
			textField.setX(vPosCuerpo);
			// Adiciona posición y para la celda cuerpo del reporte.
			textField.setY(0);

			// Construye celda cuerpo reporte personalizado.
			if (i == 0) {
				if (vEstiloReporte == 2) {
					// Ancho de la celda.
					textField.setWidth(10);
					// Dibuja alto para la celda.
					textField.setHeight(BAND_DETALLE_ALTO);
					// Obtiene formato de la celda de la cabecera.
					textField = this.obtenerCeldaSinLineas(i, textField, normalStyle);
					// Adiciona celda a la seccion de cabecera del reporte.
					detailBand.addElement(textField);
				} else {
					// Adiciona ancho de la columna.
					textField.setWidth(10);
					// Adiciona alineamiento de la celda.
					textField.setHorizontalAlignment(HorizontalAlignEnum.CENTER);
					// Adiciona indentacion para la celda.
					textField.getParagraph().setRightIndent(3);
					// Obtiene formato de la celda del cuerpo.
					textField = this.obtenerFomatoCeldaCuerpo(i, textField, normalStyle);
					// Adiciona celda a la seccion de detalle del reporte.
					detailBand.addElement(textField);
				}
				// Adiciona a la posicion segun el ancho de la celda.
				vPosCuerpo = vPosCuerpo + 10;
			} else if (i == 1) {
				// Adiciona ancho de la columna.
				textField.setWidth(130);
				// Adiciona alineamiento de la celda.
				textField.setHorizontalAlignment(HorizontalAlignEnum.LEFT);
				// Adiciona indentacion para la celda.
				textField.getParagraph().setLeftIndent(3);
				if(vEstiloReporte == 2){
					textField.setFontSize(6);	
				}	
				
				
				// Obtiene formato de la celda del cuerpo.
				textField = this.obtenerFomatoCeldaCuerpo(i, textField, normalStyle);
				// Adiciona celda a la seccion de detalle del reporte.
				detailBand.addElement(textField);
				// Adiciona a la posicion segun el ancho de la celda.
				vPosCuerpo = vPosCuerpo + 130;
			} else if (vNumeroColumna == i) {
				// Verifica que el contador de columnas se menor que cantidad de
				// columnas de la semana.
				if (vContadorColumnas <= vCantidadColumnaSemana) {
					// Instancia objeto de tipo "JRDesignTextField" para el
					// cuerpo del reporte.
					JRDesignTextField textFieldCeldaSemana = new JRDesignTextField();

					// Generamos codigo para que se estire el texto
					textFieldCeldaSemana.setStretchType(StretchTypeEnum.RELATIVE_TO_TALLEST_OBJECT);
					textFieldCeldaSemana.setStretchWithOverflow(true);

					// Obtiene formato de la celda del cuerpo.
					textFieldCeldaSemana = obtenerCeldaSemanaMes(vPosCuerpo, i, normalStyle, vAnchoColumnaSemana);
					// Adiciona celda a la seccion de detalle del reporte.
					detailBand.addElement(textFieldCeldaSemana);
					// Incrementa numero de columnas.
					vNumeroColumna++;
					// Incremententa contador de columnas.
					vContadorColumnas++;
					// Adiciona a la posicion segun el ancho de la celda.
					vPosCuerpo = vPosCuerpo + vAnchoColumnaSemana;
				} else {
					// Adiciona ancho de la columna.
					textField.setWidth(columnWidth);
					// Adiciona alineamiento de la celda.
					textField.setHorizontalAlignment(HorizontalAlignEnum.RIGHT);
					// Adiciona indentacion para la celda.
					textField.getParagraph().setRightIndent(3);
					// Obtiene formato de la celda del cuerpo.
					textField = this.obtenerFomatoCeldaCuerpo(i, textField, normalStyle);
					// Adiciona celda a la seccion de detalle del reporte.
					detailBand.addElement(textField);
					// Adiciona a la posicion segun el ancho de la celda.
					vPosCuerpo = vPosCuerpo + columnWidth + SPACE_BETWEEN_COLS;
				}
			} else {
				// Adiciona ancho de la columna.
				textField.setWidth(columnWidth);
				
				// Adiciona alineamiento de la celda.
				textField.setHorizontalAlignment(HorizontalAlignEnum.RIGHT);
				// Adiciona indentacion para la celda.
				textField.getParagraph().setRightIndent(3);
				// Obtiene formato de la celda del cuerpo.
				textField = this.obtenerFomatoCeldaCuerpo(i, textField, normalStyle);
				// Adiciona celda a la seccion de detalle del reporte.
				detailBand.addElement(textField);
				// Adiciona a las demas posiciones.
				vPosCuerpo = vPosCuerpo + columnWidth + SPACE_BETWEEN_COLS;
			}
		}
		// Adiciona la sección de cabecera al reporte.
		jasperDesign.setColumnHeader(headerBand);
		// Adiciona la sección de detalle al reporte.
		((JRDesignSection) jasperDesign.getDetailSection()).addBand(detailBand);
	}

    /*
     * Método que obtiene la celda semana mes del cuerpo del reporte.
     * */
    public JRDesignTextField obtenerCeldaSemanaMes(int xPos, int i, JRDesignStyle normalStyle, int vAnchoColumnaSemana)
    {
    	JRDesignTextField txtSemanaMes = new JRDesignTextField();
    	// Generamos codigo para que se estire el texto
    	txtSemanaMes.setStretchType(StretchTypeEnum.RELATIVE_TO_TALLEST_OBJECT);
    	txtSemanaMes.setStretchWithOverflow(true);
    	txtSemanaMes.setX(xPos);
    	txtSemanaMes.setWidth(vAnchoColumnaSemana);
    	txtSemanaMes.setHorizontalAlignment(HorizontalAlignEnum.RIGHT);
    	txtSemanaMes.getParagraph().setRightIndent(3);
    	 // Dibuja linea izquierda.
    	txtSemanaMes.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);
        // Dibuja linea derecha.
    	txtSemanaMes.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
        // Dibuja linea inferior.
    	txtSemanaMes.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
        // Adiciona alto de la columna.
    	txtSemanaMes.setHeight(COLUMN_DETALLE_ALTO);
        // Adiciona estilo a la celda del cuerpo del reporte.
    	txtSemanaMes.setStyle(normalStyle);
    	txtSemanaMes.setMarkup("html");
        // Instancia clase de tipo "JRDesignExpression". 
        JRDesignExpression expSemanaMes = new JRDesignExpression();
        // Adiciona tipo de expresion, tipo cadena.
        expSemanaMes.setValueClass(java.lang.String.class);
        // Adiciona nombre de la expresion para la celda.
        expSemanaMes.setText("$F{" + COL_EXPR_PREFIX + i + "}");                                       
        // Adiciona la expresion a la celda cuerpo.
        txtSemanaMes.setExpression(expSemanaMes);
        // Retorna celda con formato.
        return txtSemanaMes;
    }
    
    /*
     * Método que obtiene la celda semana mes de la cabecera del reporte.
     * */
    public JRDesignTextField obtenerCeldaCabeceraSemanaMes(int xPos, int i, JRDesignStyle columnHeaderStyle, int vAnchoColumnaSemana)
    {
    	// Instancia clase de tipo "JRDesignTextField" para la cabecera del reporte.
    	JRDesignTextField colHeaderFieldAux = new JRDesignTextField();

    	colHeaderFieldAux.setX(xPos);
    	colHeaderFieldAux.setY(15);
        colHeaderFieldAux.setWidth(vAnchoColumnaSemana);
    	// Dibuja linea derecha.
        colHeaderFieldAux.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
    	// Dibuja linea inferior.
        colHeaderFieldAux.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
        // Dibuja alto para la celda.
        colHeaderFieldAux.setHeight(COLUMN_DETALLE_ALTO);
        
        // Alinea contenido al centro.
        colHeaderFieldAux.setHorizontalAlignment(HorizontalAlignEnum.CENTER);            
        // Adiciona estilo a la columna creada.
        colHeaderFieldAux.setStyle(columnHeaderStyle);                                      
        // Instancia clase de tipo "JRDesignExpression".
        JRDesignExpression headerExpression1 = new JRDesignExpression();
        // Adiciona tipo de expresion, tipo cadena.
        headerExpression1.setValueClass(java.lang.String.class);
        // Adiciona nombre de la expresion para la celda.
        headerExpression1.setText("$F{" + COL_HEADER_EXPR_PREFIX + i + "}");            
        // Adiciona la expresion a la celda cabecera.
        colHeaderFieldAux.setExpression(headerExpression1);            

        return colHeaderFieldAux;
    }
    
    /*
     * Método que obtiene formato de la celda del cuerpo del reporte.
     * */
	public JRDesignTextField obtenerFomatoCeldaCuerpo (int i, JRDesignTextField textField, JRDesignStyle normalStyle)
	{
		// Dibuja linea izquierda.
	    textField.getLineBox().getLeftPen().setLineWidth(LINE_WIDTH);
	    // Dibuja linea derecha.
	    textField.getLineBox().getRightPen().setLineWidth(LINE_WIDTH);
	    // Dibuja linea inferior.
	    textField.getLineBox().getBottomPen().setLineWidth(LINE_WIDTH);
	    
	    // Adiciona alto de la columna.
	    textField.setHeight(COLUMN_DETALLE_ALTO);
	               
	    // Adiciona estilo a la celda del cuerpo del reporte.
	    textField.setStyle(normalStyle);
	    textField.setMarkup("html");
	    
	    // Instancia clase de tipo "JRDesignExpression". 
	    JRDesignExpression expression = new JRDesignExpression();
	    // Adiciona tipo de expresion, tipo cadena.
	    expression.setValueClass(java.lang.String.class);
	    // Adiciona nombre de la expresion para la celda.
	    expression.setText("$F{" + COL_EXPR_PREFIX + i + "}");
	    
	    // Instancia clase de tipo "JRDesignExpression".
	    JRDesignExpression expressionVacia = new JRDesignExpression();
	    // Adiciona tipo de expresion, tipo cadena.
	    expressionVacia.setValueClass(java.lang.String.class);                     
	    // Adiciona la expresion a la celda cuerpo.
	    textField.setExpression(expression);   
	    
	    return textField;
	}
	
	public JRDesignTextField obtenerCeldaSinLineas(int i, JRDesignTextField textField, JRDesignStyle normalStyle) {

		// Adiciona alto de la columna.
		textField.setHeight(COLUMN_DETALLE_ALTO);

		// Adiciona estilo a la celda del cuerpo del reporte.
		textField.setStyle(normalStyle);
		textField.setMarkup("html");

		// Instancia clase de tipo "JRDesignExpression".
		JRDesignExpression expression = new JRDesignExpression();
		// Adiciona tipo de expresion, tipo cadena.
		expression.setValueClass(java.lang.String.class);
		// Adiciona nombre de la expresion para la celda.
		expression.setText("$F{" + COL_EXPR_PREFIX + i + "}");

		// Instancia clase de tipo "JRDesignExpression".
		JRDesignExpression expressionVacia = new JRDesignExpression();
		// Adiciona tipo de expresion, tipo cadena.
		expressionVacia.setValueClass(java.lang.String.class);
		// Adiciona la expresion a la celda cuerpo.
		textField.setExpression(expression);

		return textField;
	}
    
	/*
	 * Método que obtiene formato de la celda de la cabecera del reporte.
	 */
	public JRDesignTextField obtenerFomatoCeldaCabecera(int i, JRDesignTextField colHeaderField, JRDesignStyle columnHeaderStyle) {
		// Alinea contenido al centro.
		colHeaderField.setHorizontalAlignment(HorizontalAlignEnum.CENTER);
		// Adiciona estilo a la columna creada.
		colHeaderField.setStyle(columnHeaderStyle);
		// Instancia clase de tipo "JRDesignExpression".
		JRDesignExpression headerExpression = new JRDesignExpression();
		// Adiciona tipo de expresion, tipo cadena.
		headerExpression.setValueClass(java.lang.String.class);
		// Adiciona nombre de la expresion para la celda.
		headerExpression.setText("$F{" + COL_HEADER_EXPR_PREFIX + i + "}");
		// Adiciona la expresion a la celda cabecera.
		colHeaderField.setExpression(headerExpression);

		return colHeaderField;
	}

    /*
     * Método que genera el estilo de las celdas del cuerpo del reporte.
     * */
	private JRDesignStyle getNormalStyle() {
		// Instancia objeto para el estilo de la celda.
		JRDesignStyle normalStyle = new JRDesignStyle();

		// Instancia filas que contendran el estilo.
		String boldExpression = "new Boolean($V{REPORT_COUNT} == 1 || $V{REPORT_COUNT} == 5|| $V{REPORT_COUNT} == 9)";
		// Instancia objeto de tipo "JRDesignConditionalStyle".
		JRDesignConditionalStyle cSBold = new JRDesignConditionalStyle();
		// Instancia objeto de tipo "JRDesignExpression".
		JRDesignExpression expressionBold = new JRDesignExpression();

		// Adiciona la condición a la expresión.
		expressionBold.setText(boldExpression);
		// Adiciona la expresion al objeto de tipo estilo.
		cSBold.setConditionExpression(expressionBold);
		// Adiciona el estilo negrita para el contenido de la celda.
		cSBold.setBold(true);

		// Adiciona el estilo programado al objeto general.
		normalStyle.addConditionalStyle(cSBold);

		// Instancia filas que contendran el estilo.
		String noLineExpression = "new Boolean($V{REPORT_COUNT} == 4 || $V{REPORT_COUNT} == 8)";
		// Instancia objeto de tipo "JRDesignConditionalStyle".
		JRDesignConditionalStyle cSNoLine = new JRDesignConditionalStyle();
		// Instancia objeto de tipo "JRDesignExpression".
		JRDesignExpression expressionNoLine = new JRDesignExpression();

		// Adiciona la condición a la expresión.
		expressionNoLine.setText(noLineExpression);
		// Adiciona estilo de linea color blanco parte izquierda de la celda.
		cSNoLine.getLineBox().getLeftPen().setLineColor(Color.WHITE);
		// Adiciona estilo de linea color blanco parte derecha de la celda.
		cSNoLine.getLineBox().getRightPen().setLineColor(Color.WHITE);
		// Adiciona la expresion al objeto de tipo estilo.
		cSNoLine.setConditionExpression(expressionNoLine);

		// Adiciona el estilo programado al objeto general.
		normalStyle.addConditionalStyle(cSNoLine);

		// Adiciona estilo letra.
		normalStyle.setName("Sans_Normal");
		normalStyle.setDefault(true);
		// Adiciona el tipo de letra para la celda.
		normalStyle.setFontName("SansSerif");
		// Adiciona el tamaño de letra.
		normalStyle.setFontSize(7);
		// Adiciona el tipo de letra para el reporte pdf.
		normalStyle.setPdfFontName("Helvetica");

		// Instancia alineamiento vertical.
		VerticalTextAlignEnum verticalTextAlign = VerticalTextAlignEnum.MIDDLE;
		// Adiciona alineamiento vertical al objeto estilo general.
		normalStyle.setVerticalTextAlign(verticalTextAlign);
		// Adiciona la codificacion del reporte.
		normalStyle.setPdfEncoding("Cp1252");
		normalStyle.setPdfEmbedded(false);

		// Retorna el estilo programado.
		return normalStyle;
	}

	/*
	 * Método que genera el estilo para la celda.
	 */
	private JRDesignStyle obtenerEstiloGeneral() {
		JRDesignStyle normalStyle = new JRDesignStyle();
		normalStyle.setName("Sans_Normal");
		normalStyle.setDefault(true);
		normalStyle.setFontName("SansSerif");
		normalStyle.setFontSize(7);
		normalStyle.setPdfFontName("Helvetica");

		// Instancia alineamiento vertical.
		VerticalTextAlignEnum verticalTextAlign = VerticalTextAlignEnum.MIDDLE;
		// Adiciona alineamiento vertical al objeto estilo general.
		normalStyle.setVerticalTextAlign(verticalTextAlign);
		// Adiciona la codificacion del reporte.
		normalStyle.setPdfEncoding("Cp1252");
		normalStyle.setPdfEmbedded(false);
		return normalStyle;
	}
    
	private JRDesignStyle obtenerTipoEstilo(int pTipoEstilo) {
		// Instancia objeto para el estilo de la celda.
		JRDesignStyle vObjEstilo = new JRDesignStyle();

		switch (pTipoEstilo) {
		case 1:
			vObjEstilo = getNormalStyle();
			break;
		case 2:
			vObjEstilo = obtenerEstiloGeneral();
			break;
		}
		return vObjEstilo;
	}
    
	/*
	 * Método que genera el estilo de las celdas del cuerpo del reporte.
	 */
	private JRDesignStyle getColumnHeaderStyle() {
		// Instancia objeto para el estilo de la celda.
		JRDesignStyle columnHeaderStyle = new JRDesignStyle();
		// Adiciona estilo letra.
		columnHeaderStyle.setName("Sans_Header");
		columnHeaderStyle.setDefault(false);
		// Adiciona el tipo de letra para la celda.
		columnHeaderStyle.setFontName("SansSerif");
		// Adiciona el tamaño de letra.
		columnHeaderStyle.setFontSize(8);
		
		// Adiciona el estilo negrita.
		columnHeaderStyle.setBold(true);
		// Instancia alineamiento vertical medio.
		VerticalTextAlignEnum verticalTextAlign = VerticalTextAlignEnum.MIDDLE;
		// Instancia alineamiento horizontal centro..
		HorizontalTextAlignEnum horizontalTextAlign = HorizontalTextAlignEnum.CENTER;
		// Adiciona alineamiento vertical.
		columnHeaderStyle.setVerticalTextAlign(verticalTextAlign);
		// Adiciona alineamiento horizontal.
		columnHeaderStyle.setHorizontalTextAlign(horizontalTextAlign);
		// Adiciona el tipo de letra para el reporte pdf.
		columnHeaderStyle.setPdfFontName("Helvetica");
		columnHeaderStyle.setPdfEncoding("Cp1252");
		columnHeaderStyle.setPdfEmbedded(false);
		// Retorna el estilo programado.
		return columnHeaderStyle;
	}
}
