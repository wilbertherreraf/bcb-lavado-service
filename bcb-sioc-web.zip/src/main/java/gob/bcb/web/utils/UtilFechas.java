package gob.bcb.web.utils;

import gob.bcb.service.servicioSioc.pojos.Resultado;
import gob.bcb.service.servicioTres.model.FeriadoDao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.Days;
import org.joda.time.LocalDate;

public class UtilFechas {
	
	FeriadoDao feriadoDao;
	

	public void setFeriadoDao(FeriadoDao feriadoDao) {
		this.feriadoDao = feriadoDao;
	}

	/**
	 * Constructor de la clase.
	 */
	public UtilFechas()
	{
		
	}
	
	/**
	 * Método que obtiene fecha completa.
	 * @param pFecha Fecha de inserción.
	 * @param pIdioma Idioma de la descripción del mes.
	 * @return Objeto de tipo "FechaPojo".
	 */
	public FechaPojo obtenerFechaCompletaPorFecha(Date pFecha,int pIdioma) throws Exception{
		
		// Instancia valor literal mes.
		String vLiteralMes = "";
		// Instancia valor literal dia.
		String vLiteralDia = "";
		
		// Instancia objeto de tipo "FechaPojo". 
		FechaPojo vObjFecha = new FechaPojo();
		
		// Instancia objeto de tipo "Calendar".
		Calendar vObjCalendario = Calendar.getInstance();
		
		// Almacena la fecha final.
		vObjCalendario.setTime(pFecha);
		
		// Obtiene año del calendario.
		int vAnio = vObjCalendario.get(Calendar.YEAR);

		// Obtiene el mes para el calculo de los meses.
		int vMes = vObjCalendario.get(Calendar.MONTH);
		
		// Obtiene numero de semana.
		int vNumeroSemana = vObjCalendario.get(Calendar.WEEK_OF_MONTH);
		
		// Obtiene dia semana correspondiente a nombre del dia de la semana.
		int vDiaSemana= vObjCalendario.get(Calendar.DAY_OF_WEEK);
		
		// Obtiene dia semana correspondiente a nombre del dia de la semana.
		int vDia= vObjCalendario.get(Calendar.DAY_OF_MONTH);
		
		// Adiciona valor año.
		vObjFecha.setGestionValor(vAnio);
		// Adiciona valor mes.
		vObjFecha.setMesValor(vMes);
		// Adiciona valor numero semana.
		vObjFecha.setSemanaValor(vNumeroSemana);
		// Adiciona valor dia.
		vObjFecha.setDiaValor(vDia);
		
		// Verifica valor de mes.
		if(vMes > -1){
			
			// Obtiene valor literal del mes.
			vLiteralMes = this.obtenerNombreMesCorto(pIdioma, vMes);
			// Adiciona el valor literal del mes. 
			vObjFecha.setMesLiteral(vLiteralMes);
		}
		// Verifica valor del dia.
		if(vDiaSemana > 0){
			
			// Obtiene valor literal del dia.
			vLiteralDia = this.obtenerNombreDia(vDiaSemana);
			// Adiciona el valor literal del dia. 
			vObjFecha.setDiaLiteral(vLiteralDia);
		}
		
		// Verficamos los dias validos
		int diasFinDeSemana = 0;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		
		for (int i = 1; i <= vDia; i++) {
            vObjCalendario.set(Calendar.DAY_OF_MONTH, i);
            int diaSemana = vObjCalendario.get(Calendar.DAY_OF_WEEK);

            // Verificamos si es fin de semana
            if( (diaSemana >= Calendar.MONDAY) && (diaSemana <= Calendar.FRIDAY)){
            	String fecha = dateFormat.format(vObjCalendario.getTime());
                // Verificamos si existe feriados
            	boolean existeFeriado = feriadoDao.existeFeriado(fecha, fecha);
            	if(existeFeriado){
            		diasFinDeSemana++;
            	}
            	
            } else{
            	diasFinDeSemana++;
            }

        }
		
		
		
		vObjFecha.setDiasValidos(vDia - diasFinDeSemana);		
		
		// Retorna objeto fecha.
		return vObjFecha;
	}
	
	/**
	 * Método que retorna el nombre del mes actual del sistema.
	 * @param p_idioma Entero que determina el idioma en que se retornara la respuesta (0 -> español, 1-> ingles).
	 * @return Nombre del mes actual en el idioma determinado en el parametro.
	 */
	public  String obtenerNombreMesCorto(int pIdioma, int pMes)throws Exception {
		
		// Instancia nombre del mes.
		String[][] vMatrizNombreMes = {{ "Ene", "Jan", "Enero" },{ "Feb", "Feb", "Febrero" },{ "Mar", "Mar","Marzo" },{ "Abr", "Apr","Abril" },{ "May", "May", "Mayo" },{ "Jun", "Jun", "Junio" },{ "Jul", "Jul", "Julio" },{ "Ago", "Aug","Agosto" },{ "Sep", "Sep", "Septiembre" }, { "Oct", "Oct", "Octubre" }, { "Nov", "Nov", "Noviembre" },{ "Dic", "Dec", "Diciembre" },};
		// Verifica idioma.
		if (pIdioma > 2)
			throw new Exception("Error al intentar obtener el nombre del mes con el código de idioma " + pIdioma);
		// Calcula el mes del sistema.
		String vNombreMes = vMatrizNombreMes[pMes][pIdioma];
		// Retorna el nombre del mes.
		return vNombreMes;
	}
	
	/**
	 * Método que retorna el nombre del dia.
	 * @param pDia Entero que determina el dia de la semana.
	 * @return Nombre del dia de la semana.
	 */
	public  String obtenerNombreDia(int pDia)throws Exception{
		
		// Instancia nombre dia de la semna
		String[] vArrayDia = new String[]{"Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"};
		// Verifica idioma.
		if (pDia > 7)
				throw new Exception("Error al intentar obtener el nombre dia de la semana " + pDia);
		// Calcula el dia de la semana.
		String vNombreDia = vArrayDia[pDia-1];
		// Retorna el nombre del dia.
		return vNombreDia;
	}

	/**
	 * Método que retorna el nombre del dia.
	 * @param pDia Entero que determina el dia de la semana.
	 * @return Nombre del dia de la semana.
	 */
	public Resultado validarFechas(Date pFechaInicial, Date pFechaFinal, String pTipoPeriodoReporteValidacion, String pNombreReporte) throws Exception {
			
		// Instancia objeto de tipo "Resultado".
		Resultado vObjResultado = new Resultado();
		
		// Inicializa el propiedad es valido.
		vObjResultado.setEsValido(false);
		
		// Obtiene fecha completa inicial.
		FechaPojo vObjFechaInicial = this.obtenerFechaCompletaPorFecha(pFechaInicial, 2);
		
		// Obtiene fecha completa final.
		FechaPojo vObjFechaFinal = this.obtenerFechaCompletaPorFecha(pFechaFinal, 2);
			
		// Instancia dias permitidos.
		int vDiasPermitidos = 0;

		// Instacia descripcion de variable.
		String vDescripcionPeriodo = "años";

		// Instancia objetode tipo "LocalDate.
		LocalDate vObjDatoLocal = null;
				
		// Verifica periodo del reporte.
		if (ConstantesReportes.cPeriodoCero.equalsIgnoreCase(pTipoPeriodoReporteValidacion)) {
			
			// Instancia dias permitidos
			vDiasPermitidos = 1;
			vDescripcionPeriodo = "dia";

		} 
		else if (ConstantesReportes.cPeriodoUno.equalsIgnoreCase(pTipoPeriodoReporteValidacion)) {
			
			// Instancia dias permitidos.
			vDiasPermitidos = 5;
			vDescripcionPeriodo = "dias (Semana)";

		} 
		else if (ConstantesReportes.cPeriodoDos.equalsIgnoreCase(pTipoPeriodoReporteValidacion)) {
			
			// Instancia dias permitidos.
			vDiasPermitidos = 31;
			vDescripcionPeriodo = "dias (Mes)";

		}
		else if (ConstantesReportes.cPeriodoTres.equalsIgnoreCase(pTipoPeriodoReporteValidacion)) {
			
			// Instancia dias permitidos.
			vDiasPermitidos = 31;
			vDescripcionPeriodo = "dias (Mes)";
		}	
		else {
			
			// Instancia valor dato local.
			vDescripcionPeriodo = "dias";
			vObjDatoLocal = new LocalDate(vObjFechaInicial.getGestionValor(), 1, 1);
			vDiasPermitidos = Days.daysBetween(vObjDatoLocal, vObjDatoLocal.plusYears(1)).getDays();		
		}
		
		// Instancia objeto de tipo "Calendar".
		Calendar calFechaVal = Calendar.getInstance();
		// Almacena fecha inicial.
		calFechaVal.setTime(pFechaInicial);
		// Adiciona dia permitido.
		calFechaVal.add(Calendar.DATE, vDiasPermitidos);
		// Instancia fecha valida.
		Date fechaValida = calFechaVal.getTime();
		
    	// Valida si la fechaInicio no es mayor a la fecha Fin.    	
    	if(pFechaInicial.compareTo(pFechaFinal)> 0 && !ConstantesReportes.cPeriodoCuatro.equalsIgnoreCase(pTipoPeriodoReporteValidacion)){
    		// Adiciaona mensaje de validación.
    		vObjResultado.setMensaje("La fecha inicial no debe ser mayor a la fecha final, para el " + pNombreReporte);
    	} 
    	else if(pFechaFinal.compareTo(fechaValida)>0 && !ConstantesReportes.cPeriodoCuatro.equalsIgnoreCase(pTipoPeriodoReporteValidacion)){    		
    		// Verifica tipo de periodo.
    		if(ConstantesReportes.cPeriodoTres.equalsIgnoreCase(pTipoPeriodoReporteValidacion)){
        		// Verifica que el periodo de gestines sea solo 1 y 2.
        		if((vObjFechaFinal.getGestionValor() - vObjFechaInicial.getGestionValor() )>2){
        			
        			// Adiciaona mensaje de validación.
        			vObjResultado.setMensaje( "El periodo valido de fechas debe ser de uno o dos años ");
        		}
        		else
        			// Adiciona valor valido.
        			vObjResultado.setEsValido(true);
        	}
    		else
    			// Adiciaona mensaje de validación.
    			vObjResultado.setMensaje( "El periodo valido de fechas debe tener un valor máximo de " + vDiasPermitidos + " " + vDescripcionPeriodo + ", para el " + pNombreReporte);
    	}    	
    	else if(ConstantesReportes.cPeriodoCuatro.equalsIgnoreCase(pTipoPeriodoReporteValidacion)){  		

    		// Verificamos si las fechas se encuentran en el mismo año
    		if(vObjFechaInicial.getGestionValor() != vObjFechaFinal.getGestionValor()){
    			// Adiciaona mensaje de validación.
    			vObjResultado.setMensaje( "El periodo valido de fechas debe tener el mismo año. Fecha Desde (Año): " + vObjFechaInicial.getGestionValor() + ", Fecha Hasta (Año): " + vObjFechaFinal.getGestionValor());
    		} 
    		else
    			// Adiciona valor valido.
    			vObjResultado.setEsValido(true);	    		
    	} 
    	else 
    		// Adiciona valor valido.
    		vObjResultado.setEsValido(true);
	    	
    	// Retorna objeto resultado.
    	return vObjResultado;
	 }
}
