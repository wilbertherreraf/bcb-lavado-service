package gob.bcb.swift.test;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.portal.sioc.view.SwfMensajeController;
import gob.bcb.service.servicioSioc.ServiceDao;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.service.ReporteSwift;

import java.io.InputStream;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import org.apache.log4j.Logger;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class ReporteSwiftTest {
	private static Logger log = Logger.getLogger(ReporteSwiftTest.class);
	private FileSystemXmlApplicationContext factory;
	private ServiceDao serviceDao ;
	private ReporteSwift reporteSwift = new ReporteSwift();
	public static String FILE_REPORT_SWIFT = "reposwiftsend.docx";
	
	public void initContext() {
		factory = new FileSystemXmlApplicationContext("WebContent/WEB-INF/applicationContext.xml");
		serviceDao = (ServiceDao) factory.getBean("siocFactoryDao");

	}
	public void initReport(){
		// inicialiar reporte swift
		InputStream in = SwfMensajeController.class.getClassLoader().getResourceAsStream(FILE_REPORT_SWIFT);
		
		reporteSwift.initArchivoTemplate(in, FILE_REPORT_SWIFT);
		reporteSwift.inicializar();		
	}
	
	public void verReporte(Integer mencod) {
		try {
//			SwfMensaje swfMensaje = serviceDao.getSwfMensajeLocal().findByCodigo(mencod);
//
//			SwiftDatos swiftDatos = serviceDao.getSwfMensajeLocal().swiftDatosFromSwfMensaje(swfMensaje);
//
//			ArchivoSinple archivoSinplePDF = generarReporte(swfMensaje.getMenPlano(), swiftDatos);
//
//			archivoSinplePDF.setDirectory("e:/tmp");
//			archivoSinplePDF.setName(archivoSinplePDF.getHash() + "." + ArchivoUtil.obtenerExtension(archivoSinplePDF.getNameOriginal()));
//			archivoSinplePDF.putPathFile();			
//
//			String p = UtilsFile.grabaEnArchivo(archivoSinplePDF.getStream(), archivoSinplePDF.getPathFile());
			
//			log.info("archivo salvado " + p);			
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error :" + e.getMessage(), e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}
	}

	private ArchivoSinple generarReporte(String swiftPlano, SwiftDatos mensajesDatos) {

		try {
			reporteSwift.populateReport(swiftPlano, mensajesDatos);

			reporteSwift.render();
			String nameFile = "reportSwf_" + mensajesDatos.getSwfMensaje().getMenCodmt() + "_" + mensajesDatos.getSwfMensaje().getMenCodmen()
					+ ".pdf";
			ArchivoSinple archivoSinple = reporteSwift.convertToPDF(reporteSwift.getArchivoSinple(), nameFile);
			log.info("reporte PDF generado " + archivoSinple.getNameOriginal());
			return archivoSinple;
		} catch (Exception e) {
			log.error("Error al renderizar reporte swift!!!!!! " + e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		} catch (Throwable e) {
			log.error("Throwable: Error al renderizar reporte swift!!!!!! " + e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		}
	}
	
	public static void main(String args[]) {
		ReporteSwiftTest reporteSwiftTest = new ReporteSwiftTest();
		try {
			reporteSwiftTest.initContext();
			reporteSwiftTest.initReport();
			reporteSwiftTest.verReporte(37);
		} catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		}

	}
}
