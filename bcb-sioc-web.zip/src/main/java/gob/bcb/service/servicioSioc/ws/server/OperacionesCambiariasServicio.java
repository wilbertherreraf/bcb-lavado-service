package gob.bcb.service.servicioSioc.ws.server;

import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.Utils;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.sioc.config.Constants;
import gob.bcb.portal.sioc.config.InitializerListener;
import gob.bcb.portal.sioc.transferencias.commons.BeanContextFactory;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.commons.ConfigurationServ;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

@WebService()
public class OperacionesCambiariasServicio {
	private static Logger log = Logger.getLogger(OperacionesCambiariasServicio.class);
	// private String brokerUrl = "tcp://10.2.11.91:61616";
	// private String brokerUrl = "tcp://localhost:61616";
	public static final String CONNECTION_FACTORY_ATTRIBUTE = "CONNECTION_FACTORY_ATTRIBUTEWS";
	//private 
	private static transient ConnectionFactory connectionFactory;

	@Resource
	WebServiceContext wsContext;

	@WebMethod()
	public String mensajeSioc(String mensajeXML) {
		MessageContext mc = wsContext.getMessageContext();
		HttpServletRequest req = (HttpServletRequest) mc.get(MessageContext.SERVLET_REQUEST);
		
		log.info("=======ooooOO00inicio WS servicio00OOooo======= " + UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd HH:mm:ss:SSS"));		
		log.info(mensajeXML);
		log.info("WWWWWWWWWWWWWWWW FIN : XML RECIBIDO(IP = " + req.getRemoteAddr() + ") WWWWWWWWWWWW");

		log.info("Parametrizacion inicializada? " + ConfigurationServ.isConfigured());

		ServletContext servletContext = (ServletContext) mc.get(MessageContext.SERVLET_CONTEXT);

		if (!ConfigurationServ.isConfigured()) {
			InitializerListener initializerListener = new InitializerListener();
			initializerListener.inicializar(servletContext);
		}
		log.info("UrlBroker = " + gob.bcb.portal.sioc.config.Constants.getUrlBroker());
		// brokerUrl = gob.bcb.portal.sioc.config.Constants.getUrlBroker();

		Map<String, Object> parametrosMsg = new HashMap<String, Object>();
		parametrosMsg.put("opcion", "REG_SOLWS");
		parametrosMsg.put(gob.bcb.service.servicioSioc.common.Constants.COD_IFA_REQUEST, gob.bcb.service.servicioSioc.common.Constants.COD_IFA_MEFP);		
		parametrosMsg.put("mensajeXML", mensajeXML);

		// Metodo estatico que se encarga de manejar las consultas al servicio

		StatusResponse statusResponse = null;
		Map<String, Object> parametros = new HashMap<String, Object>();
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();

		log.info("Estado connectionFactory nulo?:=> " + (connectionFactory == null));
		if (connectionFactory == null) 
			connectionFactory = initConnectionFactory();
		
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(connectionFactory);
		String usuarioTask = Servicios.getParam(gob.bcb.service.servicioSioc.common.Constants.PARAM_USUARIO_TASK);
		try {
			log.info("Llamando al servicio ...: " + parametrosMsg.get("opcion"));
			jMSConnectionHandler.before();
			parametros.put("BCBAddress", req.getRemoteAddr());
			parametros.put("BCBIdemisor", "SIOCWS");
			parametros.put("BCBIddestinatario", gob.bcb.portal.sioc.config.Constants.getParamsSystem().get("sioc"));
			parametros.put("BCBIdusuario", usuarioTask);
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOCWS");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));

			String uuid = Utils.generateUUID().replace("-", "");
			log.info("=>> ID: " + uuid);
			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					uuid, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));

			MessageObjectBean messageObjectBean = new MessageObjectBean();
			messageObjectBean.setTransformedMessage(parametrosMsg);

			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();

			if (statusResponse != null) {
				log.info("Respuesta : " + statusResponse.getCodResponse() + " - " + statusResponse.getDescrip());

				if (statusResponse.getResponse() instanceof MessageObjectBean) {

					MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
					mapaRespuesta = (Map<String, Object>) messageObjectBean1.getTransformedMessage();

				} else {
					mapaRespuesta.put("resp_msgerror", statusResponse.getDescrip());

				}

				mensajeXML = "Error??? Lo siento no se que paso comuniquese con el adm del sistema";

				if (mapaRespuesta.containsKey("mensajeXML")) {
					mensajeXML = (String) mapaRespuesta.get("mensajeXML");
				}
			} else {
				throw new RuntimeException("Error objeto statusResponse nulo, comunique al administrador");
			}
		} catch (Exception e) {
			log.error("Error en mensaje " + e.getMessage(), e);
			// throw new RuntimeException(e);
			mensajeXML = "Errorzango!!! comunique al adm. del sistema " + e.getMessage();
		} finally {
			try {
				if (jMSConnectionHandler != null){
					jMSConnectionHandler.close();
					jMSConnectionHandler.after();		
				}
			} catch (Exception e) {
				log.error("Error al cerrar JMS " + e.getMessage(), e);
			}
		}
		log.info("&&&&&&&&&&&&&&&&& RESPUESTA WS &&&&&&&&&&&&&&&&");
		log.info(mensajeXML);
		log.info("=======ooooOO00Fin WS servicio00OOooo======= " + UtilsDate.stringFromDate(new Date(), "yyyy-MM-dd HH:mm:ss:SSS"));

		return mensajeXML;
	}

	@Autowired
	private static synchronized ConnectionFactory initConnectionFactory() {
		// configuracion e inicializacion para colas
			try {
				Properties props = new Properties();
				// para el pool
				props.setProperty("maxConnections", "10");
				props.setProperty("maximumActive", "80");
				props.setProperty("brokerURL", Constants.getUrlBroker());
//				props.setProperty("dispatchAsync", "false");
//				props.setProperty("prefetchPolicy.durableTopicPrefetch", "2");
//				props.setProperty("prefetchPolicy.optimizeDurableTopicPrefetch", "2");
//				props.setProperty("prefetchPolicy.queuePrefetch", "10");
//				props.setProperty("prefetchPolicy.topicPrefetch", "100");
//				props.setProperty("useAsyncSend", "false");
//				props.setProperty("useCompression", "false");
//				props.setProperty("copyMessageOnSend", "false");
//				props.setProperty("closeTimeout", "10000");
//				props.setProperty("alwaysSessionAsync", "false");
//				props.setProperty("optimizeAcknowledge", "false");
//				props.setProperty("alwaysSyncSend", "false");
//				props.setProperty("sendAcksAsync", "false");
				// props.setProperty("statsEnabled",
				// Boolean.toString(isStatsEnabled()));
				// props.setProperty("producerWindowSize",
				// Integer.toString(getProducerWindowSize()));
				// props.setProperty("sendTimeout", "60000");
				// props.setProperty("auditDepth",
				// Integer.toString(getAuditDepth()));
				// props.setProperty("auditMaximumProducerNumber",
				// Integer.toString(getAuditMaximumProducerNumber()));
				// props.setProperty("checkForDuplicates",
				// Boolean.toString(isCheckForDuplicates()));
				// props.setProperty("messagePrioritySupported",
				// Boolean.toString(isMessagePrioritySupported()));

				ConnectionFactory connectionFactory = JMSConnectionHandler.initFromPropertiesContext(props);
				
				if (connectionFactory == null) {
					log.info("ERROR!!! al crear connectionFactory nulo");
					throw new RuntimeException("no se pudo recuperar coneccion JMS. comunique a sistemas");
				}

				log.info("ConnectionFactory creado por propiedades::=> \n" + connectionFactory);
				log.info("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
				return connectionFactory;				
			} catch (Exception e) {
				log.error("Error al crear ConnectionFactory mediante propiedades " + e.getMessage(), e);
				throw new RuntimeException(e);
			}
	}

}
