package gob.bcb.service.servicioSioc.jdbc;

import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Solicitante;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioSioc.common.Constants;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import dk.itst.oiosaml.sp.util.UtilsQNatives;

public class QNativesBolsin {
	private static Logger log = Logger.getLogger(QNativesBolsin.class);

	public Object getXXX(String codApp, String codRecu) {
		Connection con = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
		Set<Map<String, Object>> result = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement("");

			ps.setString(1, codApp);
			ps.setString(2, codRecu);

			rs = ps.executeQuery();
			result = (Set<Map<String, Object>>) UtilsQNatives.convertResultSetToMap(rs);
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("==>DESCRIPCION EXCEPCION: SQLException " + e.getMessage(), e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					log.error("==>DESCRIPCION EXCEPCION: SQLException " + e.getMessage(), e);
				}
			}
			try {
				if (con != null && !con.isClosed()) {
					con.close();
				}
			} catch (SQLException e) {
				log.error("EXCEPCION BASE DE DATOS: " + e.getMessage(), e);
			}

		}
		return result;
	}

	public void insertSolicitante(Solicitante solicitante) {
		Connection con = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
		final String INSERT_AXS_RECURSO = "INSERT INTO soc_solicitante(sol_codigo,sol_persona,cla_entidad,sol_direccion,"
				+ "sol_plaza,sol_bic,cla_vigente,usr_codigo,fecha_hora,estacion,sigla,login,sol_nit,sol_factura,sol_telefono,sol_fax)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, current, ?, ?, ?, ?, ?, ?, ?)";
		final String UPDATE_AXS_RECURSO = "update soc_solicitante set sol_persona= ?,cla_entidad= ?,sol_direccion= ?,sol_plaza= ?,"
				+ "sol_bic= ?,cla_vigente= ?,fecha_hora = current,sigla= ?,sol_nit= ?,sol_factura= ?,sol_telefono= ?,sol_fax= ? where sol_codigo = ?";
		PreparedStatement ps = null;
		try {
			Solicitante solic = Servicios.getSocSolicitante(solicitante.getSolCodigo());
			con.setAutoCommit(false);
			if (solic == null) {
				ps = con.prepareStatement(INSERT_AXS_RECURSO);
				ps.setString(1, solicitante.getSolCodigo());
				ps.setString(2, solicitante.getSolPersona()!= null ? solicitante.getSolPersona().toUpperCase() : solicitante.getSolPersona());
				ps.setString(3, solicitante.getClaEntidad());

				ps.setString(4, solicitante.getSolDireccion());
				ps.setString(5, solicitante.getSolPlaza());
				ps.setString(6, solicitante.getSolBic());
				ps.setInt(7, solicitante.getClaVigente());

				ps.setString(8, solicitante.getUsrCodigo());
				ps.setString(9, solicitante.getEstacion());
				ps.setString(10, solicitante.getSigla());
				ps.setString(11, "ADM"); // login
				ps.setString(12, solicitante.getSolNit()!= null ? solicitante.getSolNit().toUpperCase() : solicitante.getSolNit());
				ps.setString(13, solicitante.getSolFactura()!= null ? solicitante.getSolFactura().toUpperCase() : solicitante.getSolFactura());
				ps.setString(14, solicitante.getSolTelefono()!= null ? solicitante.getSolTelefono().toUpperCase() : solicitante.getSolTelefono());
				ps.setString(15, solicitante.getSolFax()!= null ? solicitante.getSolFax().toUpperCase() : solicitante.getSolFax());				
				ps.executeUpdate();
			} else {
				ps = con.prepareStatement(UPDATE_AXS_RECURSO);
				ps.setString(1, solicitante.getSolPersona()!= null ? solicitante.getSolPersona().toUpperCase() : solicitante.getSolPersona());				
				ps.setString(2, solicitante.getClaEntidad());

				ps.setString(3, solicitante.getSolDireccion());
				ps.setString(4, solicitante.getSolPlaza());
				ps.setString(5, solicitante.getSolBic());
				ps.setInt(6, solicitante.getClaVigente());
				ps.setString(7, solicitante.getSigla());
				ps.setString(8, solicitante.getSolNit()!= null ? solicitante.getSolNit().toUpperCase() : solicitante.getSolNit());				
				ps.setString(9, solicitante.getSolFactura()!= null ? solicitante.getSolFactura().toUpperCase() : solicitante.getSolFactura());
				ps.setString(10, solicitante.getSolTelefono()!= null ? solicitante.getSolTelefono().toUpperCase() : solicitante.getSolTelefono());				
				ps.setString(11, solicitante.getSolFax()!= null ? solicitante.getSolFax().toUpperCase() : solicitante.getSolFax());				
			
				ps.setString(12, solicitante.getSolCodigo());
				
				ps.executeUpdate();
			}
			con.commit();
		} catch (SQLException e) {
			log.error("Excepcion de BDD Seguridad: " + e.getMessage(), e);
			try {
				con.rollback();
			} catch (SQLException e1) {
				log.error("Error al revertir cambios en BdD: " + e1.getMessage(), e1);
			}
			throw new RuntimeException(e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					log.error("==>DESCRIPCION EXCEPCION: SQLException " + e.getMessage(), e);
				}
			}
			try {
				if (con != null && !con.isClosed()) {
					con.close();
				}
			} catch (SQLException e) {
				log.error("EXCEPCION BASE DE DATOS: " + e.getMessage(), e);
			}

		}
	}
}
