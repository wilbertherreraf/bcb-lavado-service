package gob.bcb.service.qnatives;

import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class UtilsQNatives {
	private static Logger log = Logger.getLogger(UtilsQNatives.class);
	public static Map<String, Object> ejecutarDML(String tipoSentencia, String sentencia) {
		Map<String, Object> respuesta = new HashMap<String, Object>();
		try {
			DataSource dataSource = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getDataSource();
			SentenciasDmlDao dml = new SentenciasDmlDao(dataSource);
			log.info("SQL ejecutado: " + sentencia);
			if ("SELECT".equals(tipoSentencia)) {
				List<Object> datos = (List<Object>) dml.select(sentencia);
				respuesta.put("datos", datos);
				respuesta.put("nroRegistros", Integer.toString(datos.size()));
			} else {
				respuesta.put("nroRegistros", Integer.toString(dml.update(sentencia)));
			}
		} catch (Exception e) {
			log.error("error al ejecutar dml " + e.getMessage(), e);
			respuesta.put("error", e.toString());
		}

		return respuesta;
	}

}
