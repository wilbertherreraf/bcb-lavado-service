package gob.bcb.service.qnatives;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class SentenciasDmlDao {
	private DataSource dataSource;

	public SentenciasDmlDao(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public Object select(String sentencia) {
		return ejecutarSentencia("SELECT", sentencia);
	}

	public int update(String sentencia) {
		return (Integer) ejecutarSentencia("", sentencia);
	}

	private Object ejecutarSentencia(String tipoSentencia, String sentencia) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		Object respuesta;

		if ("SELECT".equals(tipoSentencia)) {
			respuesta = jdbcTemplate.queryForList(sentencia);
		} else {
			// insert, update y delete
			respuesta = jdbcTemplate.update(sentencia);
		}

		return respuesta;
	}
}
