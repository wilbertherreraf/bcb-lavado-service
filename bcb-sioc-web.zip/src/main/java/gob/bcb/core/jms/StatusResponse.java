package gob.bcb.core.jms;


import gob.bcb.core.jms.model.Msgsistemaresp;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

public class StatusResponse {
	private String codTipoOperacion;
	private String statusCode;
	private String descrip;
	private String codResponse;
	private Map<String, String> descripTasksAdic = new HashMap<String, String>();
	private Object response;
	private Map<String, Object> contenido;
	
	public StatusResponse() {
	}
	public StatusResponse(Msgsistemaresp msgSistemaResponse) {
		this.statusCode = msgSistemaResponse.getCodestadoresp();
		if (this.statusCode != null && this.statusCode.equals("0000"))
			this.statusCode = "Success";
		if (msgSistemaResponse.getDescripcion() != null)
			this.descrip = msgSistemaResponse.getDescripcion().replaceAll("\"", "\\\\\"");
		if (!StringUtils.isEmpty(msgSistemaResponse.getMsgsadicionales())) {
			this.descripTasksAdic = new HashMap<String, String>();
			this.descripTasksAdic.put(" ", msgSistemaResponse.getMsgsadicionales().replaceAll("\"", "\\\\\""));
		}
	}
	
	public StatusResponse(String descrip) {
		this.descrip = descrip;
	}

	public void setCodTipoOperacion(String codTipoOperacion) {
		this.codTipoOperacion = codTipoOperacion;
	}

	public String getCodTipoOperacion() {
		return codTipoOperacion;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setCodResponse(String codResponse) {
		this.codResponse = codResponse;
	}

	public String getCodResponse() {
		return codResponse;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getDescrip() {
		return descrip;
	}

	public void setDescripTasksAdic(Map<String, String> descripTasks) {
		this.descripTasksAdic = descripTasks;
	}

	public Map<String, String> getDescripTasksAdic() {
		return

		descripTasksAdic;
	}

	public Object getResponse() {
		return response;
	}

	public void setResponse(Object response) {
		this.response = response;
	}

	public Map<String, Object> getContenido() {
		if (this.contenido == null)
			this.contenido = new HashMap<String, Object>();
		return this.contenido;
	}

	public void setContenido(Map<String, Object> contenido) {
		this.contenido = contenido;
	}
	public static void main(String[] args) {
		StatusResponse statusResponse = new StatusResponse("");		
	}
}
