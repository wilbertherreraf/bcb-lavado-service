package gob.bcb.core.jms;

import gob.bcb.core.jms.model.Msgbcb;
import gob.bcb.core.jms.model.Msgcabecera;
import gob.bcb.core.jms.model.Msgsistema;

import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class BcbRequestImpl extends BcbMsgAbstract implements BcbRequest {
	private static Logger log = Logger.getLogger(BcbRequestImpl.class);

	public BcbRequestImpl() {
		Msgcabecera msgcabecera = new Msgcabecera();
		Msgbcb msgbcb = new Msgbcb();
		msgbcb.setMsgcabecera(msgcabecera);
		Msgsistema msgsistema = new Msgsistema();
		msgbcb.setMsgsistema(msgsistema);
		setMensajeBCBJAXB(msgbcb);

	}

	public BcbRequestImpl(Message message) {
		this();
		setJmsMessage(message);
	}

	/**
	 * Crea una nueva instancia de bcbRequest desde paramatros basse
	 * 
	 * @param ipOrigen
	 *            IP de la pc que realiza la consulta
	 * @param requesterName
	 *            nombre del sistema que consulta
	 * @param idDestinatario
	 *            nombre de la institucion que recepciona el mensaje, gralmente
	 *            ser� BCB pero puede existir ocaciones donde sea el TGN por
	 *            ejmplo
	 * @param serviceDestination
	 *            id del servicio / aplicacion que consume el mensaje
	 * @param idTipoOperacion
	 *            codigo de tipo de operacion que realiza la operacion
	 * @param requestId
	 *            no se usa actualmente
	 * @param idUsuario
	 *            id del usuario que ejecuta el servicio
	 * @param password
	 *            password en MD5
	 * @param nroOperacion
	 *            codigo interno del emisor del mensaje
	 * @param tipoJAXBEleASubtituir
	 *            objeto que contiene los parametros del mensaje
	 * @return un objeto bcbrequest que contiene el objeto JAXB
	 */
	public static BcbRequest newInstance(String ipOrigen, String idemisor, String idDestinatario, String idSistema,
			String idTipoOperacion, String requestId, String idUsuario, String password, String nroOperacion, Object tipoJAXBEleASubtituir) {

		BcbRequestImpl bcbRequestImpl = new BcbRequestImpl();
		bcbRequestImpl.createMsgbcb(ipOrigen, idemisor, idDestinatario, idSistema, idTipoOperacion, requestId, idUsuario, password,
				nroOperacion, tipoJAXBEleASubtituir);

		return bcbRequestImpl;
	}

	public void createMsgbcb(String ipOrigen, String idemisor, String idDestinatario, String idSistema, String idTipoOperacion, String requestId,
			String idUsuario, String password, String nroOperacion, Object tipoJAXBEleASubtituir) {

		getMsgbcb().getMsgcabecera().setIdemisor(ipOrigen);
		getMsgbcb().getMsgcabecera().setIdusuario(idUsuario);
		getMsgbcb().getMsgcabecera().setPasswmd5(password);
		getMsgbcb().getMsgcabecera().setIdsistema(idSistema);
		getMsgbcb().getMsgcabecera().setIddestinatario(idDestinatario);
		getMsgbcb().getMsgcabecera().setNrooperacion(nroOperacion);

		getMsgbcb().getMsgsistema().setIdoperacion(idTipoOperacion);
	}

	public void setMsgBcbFromPropiedades() {
		getMsgbcb().getMsgcabecera().setIdemisor((String) getPropiedades().get("BCBIdemisor"));
		getMsgbcb().getMsgcabecera().setIddestinatario((String) getPropiedades().get("BCBIddestinatario"));
		getMsgbcb().getMsgcabecera().setIdusuario((String) getPropiedades().get("BCBIdusuario"));
		getMsgbcb().getMsgcabecera().setPasswmd5((String) getPropiedades().get("BCBPasswmd5"));
		getMsgbcb().getMsgcabecera().setIdsistema((String) getPropiedades().get("BCBIdsistema"));
		getMsgbcb().getMsgcabecera().setNrooperacion((String) getPropiedades().get("BCBNrooperacion"));
		getMsgbcb().getMsgsistema().setIdoperacion((String) getPropiedades().get("BCBIdoperacion"));
	}

	public void setPropiedadesFromMsgBcb() {
		getPropiedades().put("BCBIdemisor", getMsgbcb().getMsgcabecera().getIdemisor());
		getPropiedades().put("BCBIddestinatario", getMsgbcb().getMsgcabecera().getIddestinatario());
		getPropiedades().put("BCBIdusuario", getMsgbcb().getMsgcabecera().getIdusuario());
		getPropiedades().put("BCBPasswmd5", getMsgbcb().getMsgcabecera().getPasswmd5());
		getPropiedades().put("BCBIdsistema", getMsgbcb().getMsgcabecera().getIdsistema());
		getPropiedades().put("BCBNrooperacion", getMsgbcb().getMsgcabecera().getNrooperacion());
		getPropiedades().put("BCBIdoperacion", getMsgbcb().getMsgsistema().getIdoperacion());
	}

	public Msgbcb getMsgbcb() {
		return (Msgbcb) getMensajeBCBJAXB();
	}

	public StatusResponse procesarResponseMsgIn() {
		StatusResponse statusResponse = null;
		try {
			log.info("Esperando ZZzzZzzZZ!!! respuesta JMS ... ");			
			boolean esping = false;
			Message messageIn = getReplyConsumer().receive();// (50000);
			if (messageIn != null){
				if (messageIn instanceof TextMessage){
					String textMessage = ((TextMessage) messageIn).getText();
					if (!StringUtils.isBlank(textMessage) && textMessage.equals("PING")){
						esping = true;
					}
				}
			}
			
			if (messageIn == null){
				log.error("Sin Respuesta de Servicio");
				throw new RuntimeException("Sin Respuesta de Servicio");				
			}
			
			if (esping){
				messageIn = getReplyConsumer().receive();// (50000);
			}
			
			if (messageIn == null){
				log.error("Sin Respuesta de Servicio");
				throw new RuntimeException("Sin Respuesta de Servicio");				
			}
			
			BcbResponseImpl bcbResponseImpl = new BcbResponseImpl(messageIn);
			bcbResponseImpl.procesarMsgIn(); 
			
			log.info("$$$$$$$$$$$$$$$$ MENSAJE RECIBIDO $$$$$$$$$");			
			log.info(bcbResponseImpl.printMessage());

			statusResponse = new StatusResponse(bcbResponseImpl.getMsgBcbresp().getMsgsistemaresp());
			statusResponse.setContenido(bcbResponseImpl.getRequestElements());
			statusResponse.setResponse(bcbResponseImpl.getBody());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		} 
		return statusResponse;
	}

	
	public void updateMsgsistemaresp(String statusCode, String statusDescription, Object tipoJAXBEleASubtituir) {

	}

	
	public void setBodyMsgBcb() {
		// TODO Auto-generated method stub

	}
}
