package gob.bcb.core.jms.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.MessageAvailableConsumer;
import org.apache.activemq.pool.AmqJNDIPooledConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.log4j.Logger;

public class JMSConnectionHandler {
	// private static final Log log =
	// LogFactory.getLog(JMSConnectionHandler.class);
	private static Logger log = Logger.getLogger(JMSConnectionHandler.class);

	private transient Session session;
	private transient MessageProducer producer;
	private MessageConsumer consumer = null;
	private transient Connection connection;
	private int deliveryMode = DeliveryMode.NON_PERSISTENT;
	private transient ConnectionFactory connectionFactory;
	// private Properties propiedades;

	public JMSConnectionHandler() {
		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory();
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public JMSConnectionHandler(String brokerURL) {
		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory(brokerURL);
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public JMSConnectionHandler(ConnectionFactory cf) {
		log.info("Creando objeto JMSConnectionHandler ");
		if (cf == null) {
			throw new IllegalStateException("ConnectionFactory nulo, inicialice el objeto de conexion JMS");
		}
		connectionFactory = cf;
		// propiedades = activeMQConnectionFactory.getProperties();
		getPropertiesToString();
	}

	public JMSConnectionHandler(Properties prop) {
		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory();
		amqJNDIPooledConnectionFactory.setProperties(prop);
		// propiedades = amqJNDIPooledConnectionFactory.getProperties();
		connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		getPropertiesToString();
	}

	public static synchronized ConnectionFactory initFromPropertiesContext(Properties prop) {
		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = null;
		try {
			amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory();
			amqJNDIPooledConnectionFactory.setProperties(prop);
			log.info("PooledConnectionFactory creado con propiedades " + amqJNDIPooledConnectionFactory.getProperties().toString());

			return (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
		} catch (Exception e) {
			log.error("Error al iniciar ConnectionFactory " + e.getMessage(), e);
			throw new RuntimeException("Error al iniciar ConnectionFactory " + e.getMessage(), e);
		}
	}

	public String getPropertiesToString() {
		log.info("$$$Pool creado con parametros$$$$$");
		return getPropiedades().toString();
	}

	public void reConnect() throws JMSException {
		log.info("Intento de reconexion JMS ");
		close();
		log.info("XXX: connectionFactoryconnectionFactory " + connectionFactory == null);
		// PooledConnectionFactory pooledConnectionFactory =
		// (PooledConnectionFactory) connectionFactory;
		// pooledConnectionFactory.stop();
		//
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	}

	public Connection getConnection() throws JMSException {
		if (connection == null) {
			connection = connectionFactory.createConnection();
			log.info("XXX: connection connection " + (connection == null));
			connection.start();

			log.info("Nueva conexion JMS creada " + connection.getClientID() + "\nMetadata: " + connection);
		}

		return connection;
	}

	public Connection getJmsConnection() {
		return connection;
	}

	public void send(Destination destination, Message message, boolean persistent, int priority, long timeToLive) throws JMSException {
		producer = session.createProducer(destination);
		producer.send(message, deliveryMode, priority, timeToLive);
		log.info("Sent! to destination: " + destination + " message: " + message);
	}

	public Session getSession() throws JMSException {
		if (session == null) {
			log.info("Solicitud de Nueva session JMS.");
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		}
		return session;
	}

	public synchronized MessageConsumer createConsumer(Destination destination, boolean create) throws JMSException {
		consumer = session.createConsumer(destination);
		log.info("Consumer message creado: " + consumer);

		return consumer;
	}

	public synchronized void closeConsumer() throws JMSException {
			if (consumer != null) {
				consumer.setMessageListener(null);
				if (consumer instanceof MessageAvailableConsumer) {
					((MessageAvailableConsumer) consumer).setAvailableListener(null);
				}
				consumer.close();
				log.warn("Consumer cerrado...");
			}
	}

	public synchronized void close() {
		try {
			closeConsumer();
			if (producer != null) {
				try {
					producer.close();
					log.warn("Producer JMS cerrado...");
				} catch (JMSException e) {
					log.error("Exception al cerrar producer ", e);
				}
			}
			if (session != null) {
				try {
					log.warn("Cerrando Session JMS...");
					session.close();
					log.warn("Session JMS cerrado...");
				} catch (JMSException e) {
					log.error("Exception al cerrar session ", e);
				}
			}
			
			log.info("connexion jms cerrado ");
		} catch (Exception e) {
			log.error("caught exception closing consumer", e);
		} finally {
			producer = null;
			session = null;
		}
	}

	// public int getDeliveryMode() {
	// return deliveryMode;
	// }
	//
	// public void setDeliveryMode(int deliveryMode) {
	// this.deliveryMode = deliveryMode;
	// }

	public void setPropiedades(Properties prop) {
		PooledConnectionFactory pooledConnectionFactory = (PooledConnectionFactory) connectionFactory;
		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory(
				(ActiveMQConnectionFactory) pooledConnectionFactory.getConnectionFactory());
		amqJNDIPooledConnectionFactory.setProperties(prop);
		// this.propiedades = amqJNDIPooledConnectionFactory.getProperties();
		connectionFactory = (PooledConnectionFactory) amqJNDIPooledConnectionFactory;
	}

	public Properties getPropiedades() {
		log.info("XXX:PROPERties ");
		Properties prop = new Properties();

		PooledConnectionFactory pooledConnectionFactory = (PooledConnectionFactory) connectionFactory;
		AmqJNDIPooledConnectionFactory amqJNDIPooledConnectionFactory = new AmqJNDIPooledConnectionFactory(
				(ActiveMQConnectionFactory) pooledConnectionFactory.getConnectionFactory());
		log.info("XXX:PROPER " + amqJNDIPooledConnectionFactory.getProperties().toString());
		amqJNDIPooledConnectionFactory.setProperties(prop);
		return prop;
	}

	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}

	public ConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

	public void before() throws Exception {
		log.info("Before Nueva conexion JMS antes");		
		connection = connectionFactory.createConnection();
		connection.start();
		log.info("Before Nueva conexion JMS creada " + connection.getClientID() + "\nMetadata: " + connection);
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	}

	public void after() throws Exception {
		log.info("Despues de ejecutar jms cerrando.....");
		if (connection != null) {
			connection.close();
		}
	}

	public static void main(String[] args) {
		AtomicBoolean ai = new AtomicBoolean(false);
		System.out.println(ai);
		ai.get();
		System.out.println(ai);
	}

}
