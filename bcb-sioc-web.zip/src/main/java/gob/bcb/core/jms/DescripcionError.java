package gob.bcb.core.jms;

import java.util.Date;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class DescripcionError {
	  private final String code;
	  private final String codeDescription;
	  private final String errorDescription;
	  private final String errorTechnicalDescription;
	  private final Date errorDate;

	  /**
	   * @param code
	   * @param codeDescription
	   * @param errorDescription
	   * @param errorTechnicalDescription
	   * @param errorDate
	   */
	  public DescripcionError(String code, String codeDescription,
	      String errorDescription, String errorTechnicalDescription, Date errorDate)
	  {
	    super();
	    this.code = code;
	    this.codeDescription = codeDescription;
	    this.errorDescription = errorDescription;
	    this.errorTechnicalDescription = errorTechnicalDescription;
	    this.errorDate = errorDate;
	  }

	  /**
	   * @return the code
	   */
	  public final String getCode()
	  {
	    return code;
	  }

	  /**
	   * @return the codeDescription
	   */
	  public final String getCodeDescription()
	  {
	    return codeDescription;
	  }

	  /**
	   * @return the errorDescription
	   */
	  public final String getErrorDescription()
	  {
	    return errorDescription;
	  }

	  /**
	   * @return the errorDate
	   */
	  public final Date getErrorDate()
	  {
	    return errorDate;
	  }

	  /**
	   * @return the errorTechnicalDescription
	   */
	  public final String getErrorTechnicalDescription()
	  {
	    return errorTechnicalDescription;
	  }

	  /*
	   * (non-Javadoc)
	   * 
	   * @see java.lang.Object#toString()
	   */
	  
	  public String toString()
	  {
	    StringBuilder builder = new StringBuilder();
	    builder.append("DescripcionError [code=");
	    builder.append(code);
	    builder.append(", codeDescription=");
	    builder.append(codeDescription);
	    builder.append(", errorDescription=");
	    builder.append(errorDescription);
	    builder.append(", errorTechnicalDescription=");
	    builder.append(errorTechnicalDescription);
	    builder.append(", errorDate=");
	    builder.append(errorDate);
	    builder.append("]");
	    return builder.toString();
	  }

	  /*
	   * (non-Javadoc)
	   * 
	   * @see java.lang.Object#hashCode()
	   */
	  
	  public int hashCode()
	  {
	    final int prime = 31;
	    int result = 1;
	    result = prime * result + ((code == null) ? 0 : code.hashCode());
	    result = prime * result + ((errorDate == null) ? 0 : errorDate.hashCode());
	    result = prime * result + ((errorTechnicalDescription == null) ? 0
	        : errorTechnicalDescription.hashCode());
	    return result;
	  }

	  /*
	   * (non-Javadoc)
	   * 
	   * @see java.lang.Object#equals(java.lang.Object)
	   */
	  
	  public boolean equals(Object obj)
	  {
	    if (this == obj)
	      return true;
	    if (obj == null)
	      return false;
	    if (getClass() != obj.getClass())
	      return false;
	    DescripcionError other = (DescripcionError) obj;
	    if (code == null)
	    {
	      if (other.code != null)
	        return false;
	    }
	    else if (!code.equals(other.code))
	      return false;
	    if (errorDate == null)
	    {
	      if (other.errorDate != null)
	        return false;
	    }
	    else if (!errorDate.equals(other.errorDate))
	      return false;
	    if (errorTechnicalDescription == null)
	    {
	      if (other.errorTechnicalDescription != null)
	        return false;
	    }
	    else if (!errorTechnicalDescription.equals(other.errorTechnicalDescription))
	      return false;
	    return true;
	  }
}
