package gob.bcb.portal.menu.reporte;

import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.web.utils.ConstantesReportes;
import gob.bcb.web.utils.DynamicColumnDataSource;
import gob.bcb.web.utils.DynamicReportBuilder;

import gob.bcb.web.utils.ConstructorReporteDinamico;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JRRuntimeException;
import net.sf.jasperreports.engine.JRSortField;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.design.JRDesignSortField;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporterParameter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.engine.type.SortFieldTypeEnum;
import net.sf.jasperreports.engine.type.SortOrderEnum;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

import org.apache.log4j.Logger;

import com.lowagie.text.pdf.codec.Base64.InputStream;

/**
 * Servlet implementation class reporte
 */
public class reporte extends HttpServlet {
	private final static Logger log = Logger.getLogger(reporte.class);
	private static final long serialVersionUID = 1L;
	public static final String REPORTE_FORMATO = "reportFormato";

	/**
	 * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
	 * methods.
	 * 
	 * @param request
	 *            servlet request
	 * @param response
	 *            servlet response
	 * @throws ServletException
	 *             if a servlet-specific error occurs
	 * @throws IOException
	 *             if an I/O error occurs
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.info("-->Entrando processRequest a servlet Reportes");
		HttpSession session = null;
		Map<String, Object> parametros = null;
		// recuperacion de variables guardadas en sesion.
		session = request.getSession();
		String tipopar = null;
		int cont = 0;
		
		do 
		{
			// si el reporte no recibe parametros en los 10 seg
			parametros = (Map<String, Object>) session.getAttribute("parametros");

			try 
			{
				Thread.sleep(500);
			} catch (InterruptedException e) 
			{
				log.error(e);
			}
			tipopar = request.getParameter("tipo");
			cont++;
			log.info("REcuperannndo processRequest: " + cont);
		} 
		while ((parametros == null && tipopar == null) && cont <= 18);

		if (parametros == null)
			parametros = new HashMap<String, Object>();

		
		try {
			// //parametros leidos de la session

			// Creando objeto que permite la salida del archivo binario pdf
			// Para pasarle parametros al reporte

			if (request.getParameter("cod") != null)
				parametros.put("codigo", request.getParameter("cod"));

			String tipo = request.getParameter("tipo");
			if (parametros.containsKey("tipo"))
				tipo = (String) parametros.get("tipo");

			log.info("tipo: " + tipo);

			String nombreReporte = null;
			boolean banderaReporte = true;
			boolean banderaSubReporte = true;

			if (tipo == null) {
				throw new RuntimeException("Valor de tipo de reporte NULO, pruebe nuevamente la operación o avise a sistemas");
			}
			if (tipo.equals("SW")) {
				nombreReporte = "swift.jasper";
			} else if (tipo.equals("TE")) {
				nombreReporte = "solicitud.jasper";
			} else if (tipo.equals("TED")) {
				nombreReporte = "solicitudD.jasper";
			} else if (tipo.equals("TC") || tipo.equals("TCID") || tipo.equals("TCRG")) {
				// se agrega a operaciones de idhy regalias
				nombreReporte = "solicitudTC.jasper";
			} else if (tipo.equals("TD")) {
				nombreReporte = "solicitudDSF.jasper";
			} else if (tipo.equals("VE")) {
				nombreReporte = "solicitudVE.jasper";
			} else if (tipo.equals("VED")) {
				nombreReporte = "solicitudVE-cc.jasper";
			} else if (tipo.equals("VEL")) {
				nombreReporte = "solicitudVETC.jasper";
			} else if (tipo.equals("VEO")) {
				nombreReporte = "solicitudVEOP.jasper";
			} else if (tipo.equals("SF")) {
				nombreReporte = "solicitudSF.jasper";
			} else if (tipo.equals("BB")) {
				nombreReporte = "bolsin.jasper";
			} else if (tipo.equals("VD")) {
				nombreReporte = "bolsinVentaDir.jasper";
			} else if (tipo.equals("BE")) {
				nombreReporte = "beneficiarioExt.jasper";
			} else if (tipo.equals("OP")) {
				String literal = request.getParameter("lit");
				nombreReporte = "ordenPago.jasper";
				parametros.put("literal", literal);
			} else if (tipo.equals("LS")) { // Listado Solicitudes
				String f1 = request.getParameter("f1");
				String f2 = request.getParameter("f2");
				String codSolicitante = (String) parametros.get("codigo");

				nombreReporte = "listadoSol.jasper";
				parametros.put("soli", codSolicitante);
				parametros.put("f1", f1);
				parametros.put("f2", f2);
			} else if (tipo.equals("ROP")) {
				log.info("Entre a  la opcion  ROP reporte .................");
				String f1 = request.getParameter("f1");
				String f2 = request.getParameter("f2");
				String ee = request.getParameter("ee");
				nombreReporte = "listaOP.jasper";
				parametros.put("f1", f1);
				parametros.put("f2", f2);
				parametros.put("ee", ee);
			} else if (tipo.equals("RBO")) {
				String f1 = request.getParameter("f1");
				String f2 = request.getParameter("f2");
				String rr = request.getParameter("rr");
				if (rr.equals("R"))
					nombreReporte = "resumenBolsin.jasper";
				if (rr.equals("D"))
					nombreReporte = "detalleBolsin.jasper";
				if (rr.equals("C"))
					nombreReporte = "consultaBolsin.jasper";

				parametros.put("f1", f1);
				parametros.put("f2", f2);
			} else if (tipo.equals("DI")) {
				String f1 = request.getParameter("f1");
				nombreReporte = "diario.jasper";
				parametros.put("fecha", UtilsDate.dateFromString(f1, "dd/MM/yyyy"));
			} else if (tipo.equals("SE")) {
				Date fecha_desde = (Date) parametros.get("FECHA_DESDE");
				Date fecha_hasta = (Date) parametros.get("FECHA_HASTA");
				nombreReporte = "semanal.jasper";
				parametros.put("fecha", fecha_desde);
				parametros.put("fecha2", fecha_hasta);
			} else if (tipo.equals("SB")) {
				String f1 = request.getParameter("fecha");
				log.info("fecha:" + f1);
				Date fd = new Date();
				log.info("fechad:" + fd);
				nombreReporte = "sesion.jasper";
				parametros.put("fecha", f1);
				parametros.put("fechad", fd);
			} else if (tipo.equals("bolsinDetCompra")) {
				nombreReporte = "bolsinDetCompra.jasper";
			} else if (tipo.equals("transfExtSF")) {
				nombreReporte = "transexterior_sfin.jasper";
			} else if (tipo.equals("ordendepago")) {
				nombreReporte = "ordenDePago.jasper";
			} else if (tipo.equals("extractoCtas")) {
				nombreReporte = "extracto_movctascont.jasper";
			} else if (tipo.equals("soldetalle")) {
				nombreReporte = "solicitudresu.jasper";
			} else if (tipo.equals("bolSF")) {
				nombreReporte = "Sioc/rptVentaUsdBolsinSisFinan.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
			} else if (tipo.equals("bolCSF")) {
				nombreReporte = "Sioc/rptVentaUsdClienteBolsinFinanciero.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
			} else if (tipo.equals("bolDSF")) {
				nombreReporte = "Sioc/rptVentaUsdDiaSisFinanciero.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
			} else if (tipo.equals("bolDCSF")) {
				nombreReporte = "Sioc/rptVentaUsdDiaClienteFinanciero.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
			} else if (tipo.equals("vDol")) {
				nombreReporte = "Sioc/rptVentaDolaresEEUU.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
				banderaSubReporte = false;
			} else if (tipo.equals("gVeDiSisFin")) {
				nombreReporte = "Sioc/rptVentaDolares.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
				banderaSubReporte = false;
			} else if (tipo.equals("gVeMensualSisFin")) {
				nombreReporte = "Sioc/rptGraficoVentaMensualSistemaFinanciero.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
				banderaSubReporte = false;
			} else if(tipo.equals("gTransMenAlExt")){
				nombreReporte = "Sioc/rptGraficoMensualAlExterior.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
				banderaSubReporte = false;
			} else if(tipo.equals("vDOpCam")){
				nombreReporte = "Sioc/rptOperacionesCambiarias.jasper";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
				banderaSubReporte = false;
			}
			else if(ConstantesReportes.cReporteOperacionesCambiarias.equalsIgnoreCase(tipo)){
				nombreReporte = "Sioc/rptOpCambiariasMillones.jrxml";
				log.info("Obteniendo reporte " + nombreReporte);
				banderaReporte = false;
				banderaSubReporte = false;
			}
			else if(tipo.equals(ConstantesReportes.cReporteVentaDolaresEstadounidenses))
			{
				nombreReporte = "Sioc/reporteDinamico.jrxml";
			}			
			else if(tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero))
			{
				nombreReporte = "Sioc/reporteDinamico.jrxml";				
			}
			else if(tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero))
			{
				nombreReporte = "Sioc/reporteDinamico.jrxml";				
			}
			else if(tipo.equals(ConstantesReportes.cReporteTransferenciasExterior))
			{
				nombreReporte = "Sioc/reporteDinamico.jrxml";				
			}
			else if(tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero))
			{
				nombreReporte = "Sioc/reporteDinamico.jrxml";			
			}
			else if(tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero))
			{
				nombreReporte = "Sioc/reporteDinamico.jrxml";			
			}
				
			parametros.put("REPORT_LOCALE", new Locale("es","BO"));
			if (nombreReporte != null) 
			{
				String URL_SUBREPORT = getServletContext().getRealPath("/jasper/");
				parametros.put("SUBREPORT_DIR", URL_SUBREPORT + "/");
				
				if(!banderaSubReporte)
				{
					String subReportDir = URL_SUBREPORT + "/Sioc/subReporteVentaDolares/";
					log.info("Sub report dir " + subReportDir);
					parametros.put("SUBREPORT_DIR", subReportDir);
				}

				log.debug("OOO==) Reporte seleccionado tipo:" + tipo + " reporte : " + nombreReporte + " con  parametros: " + parametros.toString());
				// // cargando el query

				ServletContext context = this.getServletConfig().getServletContext();

				String reportFileName = context.getRealPath("/jasper/" + nombreReporte);
				log.info("reportFileName " + reportFileName);
				java.io.File reportFile = new java.io.File(reportFileName);

				if (!reportFile.exists())
					throw new JRRuntimeException("Archivo " + nombreReporte	+ " no encontrado. El reporte no puede ser visualizado, comunique al administrador del sistema.");

				parametros.put("BaseDir", reportFile.getParentFile());
				if (!parametros.containsKey("TITULO"))
					parametros.put("TITULO", "Operacion");
				if (!parametros.containsKey("USUARIO"))
					parametros.put("USUARIO", "usuario");

				String reportFormato = "pdf";
				if (parametros.containsKey(REPORTE_FORMATO)) {
					reportFormato = (String) parametros.get(REPORTE_FORMATO);
				}
				reportFormato = reportFormato.trim().toLowerCase();
				parametros.put(REPORTE_FORMATO, reportFormato);
				String nameFileOut = (tipo.concat(UtilsDate.stringFromDate(new Date(), "yyyyMMddHHss"))).concat(".").concat(reportFormato);
				parametros.put("nameFileOut", nameFileOut);
				/* ##### GENERANDO REPORTITO ############## */
				// whf 201609 se agrega opcion de imprimir en xls
				byte[] reportePDF = null;
				// Agregamos la region
				
				if(!parametros.containsKey("esDinamico"))
				{
					if (!parametros.containsKey("propioDt"))
					{
						reportePDF = obtenerReporte(reportFileName, parametros);	
					} else{
						log.info("Entro Data Source Report");
						reportePDF = obtenerReporteDataSource(reportFileName, parametros);
					}
				} else 
				{
					String vMes = "";
					int  nroSemana = 0;
					
					if((String)parametros.get("mes")!= null)
					{
						vMes = (String)parametros.get("mes");
					}
					if(parametros.containsKey("nroSemana"))
					{
						if((Integer) parametros.get("nroSemana") > 0)
						  nroSemana = (Integer) parametros.get("nroSemana");
					}
					
					// Verifica venta de dolares estadounidenses.
					if (tipo.equals(ConstantesReportes.cReporteVentaDolaresEstadounidenses)) {
						// Genera reporte de venta de dolares estadounidenses.
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 3, 1, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero)){
						// Genera reporte de venta de dolares a traves de bolsin al sistema financiero.
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero)){
						// Genera reporte de venta de dolares al dia al sistema financiero.
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteTransferenciasExterior)){
						// Genera reporte de transferencias al exterior.
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero)){
						// Genera reporte de venta de dolares del bolsin a clientes del sistema financiero.
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if (tipo.equals(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero)){
						// Genera reporte de venta de dolares del dia a clientes del sistema financiero.
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					} else if(ConstantesReportes.cReporteOperacionesCambiarias.equalsIgnoreCase(tipo)){
						// Genera reporte dinamico para operaciones cambiarias en millones de dólares
						reportePDF = obtenerReporteDinamico(reportFileName, parametros);
					} else 
					{
						// TODO: diseñamos los reportes dinamicos
						log.info(">>>>>>>>>>>>>> Entro Reporte Dinamico Data Source Report >>>>>>>>>>>>>>");
						reportePDF = generaReporteDinamico(reportFileName, parametros, nroSemana, nroSemana + 2, 2, vMes);
					}
				}	
					
				
				log.info("Formato " + nameFileOut);
				response.setHeader("Cache-Control", "no-cache");
				response.setHeader("Pragma", "no-cache");
				response.setDateHeader("Expires", 0);
				ServletOutputStream ouputStream = response.getOutputStream();
				response.setContentType(ArchivoUtil.getMimeFromExt(ArchivoUtil.obtenerExtension(nameFileOut)));
				response.setContentLength(reportePDF.length);
				response.setHeader("content-disposition", "inline; filename=\"" + nameFileOut + "\"");
				ouputStream.write(reportePDF, 0, reportePDF.length);
				ouputStream.flush();
				ouputStream.close();
			} else {
				throw new RuntimeException("No existe parametro de reporte, intente nuevamente");
			}

		} catch (Exception e) {
			log.error("Error al generar reporte " + e.getMessage(), e);
			try {
				StringWriter stringWriter = new StringWriter();
				PrintWriter out = new PrintWriter(stringWriter);
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Error al generar reporte</title>");
				out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"/resources/css/theme.css\" title=\"Style\">");
				out.println("</head>");
				out.println("<body bgcolor=\"white\">");
				out.println("<span>Ocurrió un error al generar el reporte :</span>");
				out.println("<pre>");
				e.printStackTrace(out);
				out.println("</pre>");
				out.println("</body>");
				out.println("</html>");
				response.setContentType("text/html");
				response.getOutputStream().print(stringWriter.toString());
				out.flush();
				out.close();
			} catch (Exception e1) {
				log.error("Error al generar pagina de error de reporte " + e1.getMessage(), e1);
			}
		} finally {
			if (session != null) {
				log.info("Removiendo valores sesion reporte processRequest");
				session.removeAttribute("RPTSwift");
				session.removeAttribute("nombreReporte");
				session.removeAttribute("archivoSinple");
				session.removeAttribute("parametros");
			}
		}
	}

	
	
	private void desplegarReporte(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = null;
		try {
			log.info("Inicio archivo simple ....");

			ArchivoSinple archivo = null;
			int cont = 0;
			session = request.getSession();
			do {
				// si el reporte no recibe parametros en los 10 seg
				archivo = (ArchivoSinple) session.getAttribute("archivoSinple");
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					log.error(e);
				}
				cont++;
				log.info("Recuperando archivo simple pdf ciclo" + cont);
			} while (archivo == null && cont <= 20);

			if (archivo != null) {
				Integer menCodmen = (Integer) session.getAttribute("RPTSwift");
				log.info("Archivo simple recuperado: " + menCodmen + " : " + archivo.getName());

				ServletOutputStream ouputStream = response.getOutputStream();
				response.setContentType(archivo.getContentType());
				response.setContentLength(archivo.getData().length);
				response.setHeader("Content-Disposition", "inline; filename=\"" + archivo.getName() + "\"");
				ouputStream.write(archivo.getData(), 0, archivo.getData().length);
				ouputStream.flush();
				ouputStream.close();
			}

		} catch (Exception e) {
			log.error("Error al generar reporte " + e.getMessage(), e);
			try {
				StringWriter stringWriter = new StringWriter();
				PrintWriter out = new PrintWriter(stringWriter);
				out.println("<html>");
				out.println("<head>");
				out.println("<title>Error al generar reporte</title>");
				out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"/resources/css/theme.css\" title=\"Style\">");
				out.println("</head>");
				out.println("<body bgcolor=\"white\">");
				out.println("<span>Ocurrió un error al generar el reporte :</span>");
				out.println("<pre>");
				e.printStackTrace(out);
				out.println("</pre>");
				out.println("</body>");
				out.println("</html>");
				response.setContentType("text/html");
				response.getOutputStream().print(stringWriter.toString());
				out.flush();
				out.close();
			} catch (Exception e1) {
				log.error("Error al generar pagina de error de reporte " + e1.getMessage(), e1);
			}
		} finally {
			if (session != null) {
				log.info("Removiendo valores sesion reporte");
				session.removeAttribute("RPTSwift");
				session.removeAttribute("archivoSinple");
				session.removeAttribute("nombreReporte");
				session.removeAttribute("parametros");
			}
		}

	}

	/**
	 * Handles the HTTP <code>GET</code> method.
	 * 
	 * @param request servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.info("doGet Reporte...");
		HttpSession session = request.getSession();

		// String nombreReporte = (String)
		// session.getAttribute("nombreReporte");
		String nombreReporte = request.getParameter("nombreReporte");
		if (nombreReporte != null && nombreReporte.equals("reporteSwiftPdf")) {
			Map<String, Object> parametros = null;
			int cont = 0;
			do {
				// si el reporte no recibe parametros en los 10 seg
				parametros = (Map<String, Object>) session.getAttribute("parametros");
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					log.error(e);
				}
				cont++;
				log.info("espeando parametroe de reporte ... " + cont);
			} while (parametros == null && cont <= 5);

			desplegarReporte(request, response);
		} else {
			processRequest(request, response);
		}
	}

	/**
	 * Handles the HTTP <code>POST</code> method.
	 * 
	 * @param request servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException if an I/O error occurs
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.info("doPost Reporte...");
		HttpSession session = request.getSession();
		String nombreReporte = (String) session.getAttribute("nombreReporte");

		if (nombreReporte != null && nombreReporte.equals("reporteSwiftPdf")) {
			Map<String, Object> parametros = null;
			int cont = 0;
			do {
				// report exists in 10 segs ?
				parametros = (Map<String, Object>) session.getAttribute("parametros");
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					log.error(e);
				}
				cont++;
				log.info("espeando parametroe de reporte ... " + cont);
			} while (parametros == null && cont <= 30);

			desplegarReporte(request, response);
		} else {

			processRequest(request, response);
		}
	}

	/**
	 * Returns a short description of the servlet.
	 * 
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}

	private static byte[] obtenerReporte(String pathReporteJasper, Map<String, Object> parametros) throws Exception {
		Connection connection = null;
		byte[] reportePdf = null;

		// FileOutputStream fos = null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			// String fileName = "D:/Coffee.jrxml";
			long startTime = System.currentTimeMillis();

			String formatReport = (String) parametros.get(REPORTE_FORMATO);
			connection = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
			connection.setTransactionIsolation(Connection.TRANSACTION_READ_UNCOMMITTED);
			JasperPrint jrprintFile = JasperFillManager.fillReport(pathReporteJasper, parametros, connection);
			log.info("jrprintFile==" + jrprintFile);

			if (formatReport.trim().equalsIgnoreCase("xlsx") || formatReport.trim().equalsIgnoreCase("xls")) {
				JRXlsxExporter exporter = new JRXlsxExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);// Set configuration as
														// you
														// like it!!
				exporter.setConfiguration(configuration);
				exporter.exportReport();
			} else {
				reportePdf = JasperRunManager.runReportToPdf(pathReporteJasper, parametros, connection);
				out.write(reportePdf);
			}

			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " s");
			log.info("================== " + out.size());
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		} finally {
			try {
				if (connection != null)
					connection.close();
			} catch (Exception e1) {
				throw new Exception(e1);
			}
		}
		// return reportePdf;
	}
	
	/**
	 * Genera reporte que soporta otros data source
	 * @param pathReporteJasper Directorio del reporte
	 * @param parametros entradas para generar el reporte
	 * @return Archivi generado en Byte Array
	 * @throws Exception
	 */
	private static byte[] obtenerReporteDataSource(String pathReporteJasper, Map<String, Object> parametros) throws Exception {
		
		byte[] reportePdf = null;

		// FileOutputStream fos = null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			// String fileName = "D:/Coffee.jrxml";
			long startTime = System.currentTimeMillis();

			String formatReport = (String) parametros.get(REPORTE_FORMATO);
			
			JasperPrint jrprintFile = JasperFillManager.fillReport(pathReporteJasper, parametros, new JREmptyDataSource());
			log.info("jrprintFile==" + jrprintFile);

			if (formatReport.trim().equalsIgnoreCase("xlsx") || formatReport.trim().equalsIgnoreCase("xls")) {
				JRXlsxExporter exporter = new JRXlsxExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);// Set configuration as
														// you
														// like it!!
				Map<String, String> numberFormats = new HashMap<String, String>();
				configuration.setDetectCellType(true);
//				configuration.setAutoFitPageHeight(isAutoFitPageHeight)
				
				exporter.setConfiguration(configuration);				
				exporter.exportReport();
			} else {
				log.info(">>>>>>>>>>>>>> Exportando en PDF >>>>>>>>>>>>>>");
//				reportePdf = JasperRunManager.runReportToPdf(pathReporteJasper, parametros, new JREmptyDataSource());
				JRPdfExporter exporter = new JRPdfExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				
				exporter.exportReport();
//				out.write(reportePdf);
			}

			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " s");
			log.info("================== " + out.size());
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		}
		// return reportePdf;
	}	
	
	private static byte[] obtenerReporteDinamico(String pathReporteJasper, Map<String, Object> parametros) throws Exception {
		byte[] reportePdf = null;
		log.info(">>>>>>>>>>>>> GENERANDO REPORTE DINAMICO >>>>>>>>>>>>>");
		// FileOutputStream fos = null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			
			long startTime = System.currentTimeMillis();
			// Cargamos el reporte vacio
			java.io.InputStream is = new FileInputStream(pathReporteJasper);
			List<String> columnHeaders = (List<String>) parametros.get("headers");
													
			List<List<String>> rows =  (List<List<String>>) parametros.get("rows");
			
			JasperDesign jasperReportDesign = JRXmlLoader.load(is);
			DynamicReportBuilder reportBuilder = new DynamicReportBuilder(jasperReportDesign, columnHeaders.size());
	        
			// Generamos el tipo de reporte
			if(parametros.containsKey("tipoReporteDinamico")){
				String tipoReporteDinamico = parametros.get("tipoReporteDinamico").toString();
				if("opCambiarias".equalsIgnoreCase(tipoReporteDinamico)){
					reportBuilder.addDynamicColumns();
				} else if("transAlExterior".equalsIgnoreCase(tipoReporteDinamico)){
					reportBuilder.addDynamicColumnsTransExt();
				}
			}
			
	        
	        // Se compila el reporte dinamico
	        JasperReport jasperReport = JasperCompileManager.compileReport(jasperReportDesign);
	        

			String formatReport = (String) parametros.get(REPORTE_FORMATO);
			parametros.put("REPORT_TITLE", "Sample Dynamic Columns Report");
			//Generamos la informacion
			DynamicColumnDataSource pdfDataSource = new DynamicColumnDataSource(columnHeaders, rows, "");
			
						
			JasperPrint jrprintFile = JasperFillManager.fillReport(jasperReport, parametros, pdfDataSource);
			log.info("jrprintFile==" + jrprintFile);

			if (formatReport.trim().equalsIgnoreCase("xlsx") || formatReport.trim().equalsIgnoreCase("xls")) {
				JRXlsxExporter exporter = new JRXlsxExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));

				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);// Set configuration as
														// you
														// like it!!
				Map<String, String> numberFormats = new HashMap<String, String>();
				configuration.setDetectCellType(true);
//				configuration.setAutoFitPageHeight(isAutoFitPageHeight)
				
				exporter.setConfiguration(configuration);				
				exporter.exportReport();
			} else {
				log.info(">>>>>>>>>>>>>> Exportando en PDF >>>>>>>>>>>>>>");
//				reportePdf = JasperRunManager.runReportToPdf(pathReporteJasper, parametros, new JREmptyDataSource());
				JRPdfExporter exporter = new JRPdfExporter();
				exporter.setExporterInput(new SimpleExporterInput(jrprintFile));
				exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				
				exporter.exportReport();
//				out.write(reportePdf);
			}

			long endTime = System.currentTimeMillis();
			long time = (endTime - startTime) / 1;

			log.info("success with " + time + " s");
			log.info("================== " + out.size());
			log.info(">>>>>>>>>>>>> REPORTE DINAMICO GENERADO >>>>>>>>>>>>>");
			return out.toByteArray();
		} catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		}
		// return reportePdf;
	}	
	
	/**
	 * Genera reporte dinamico. 
	 * @pathReporteJasper Directorio del reporte.
	 * @parametros Parametros de entrada para generar el reporte.
	 * @pCantidadColumnas Cantidad de columnas por semana.
	 * @pNroColumnaPivote Numero de columna pivote para el reporte.
	 * @pEstiloReporte Tipo de estilo de reporte.
	 * @pMes Descripcion del mes pivote para el reporte.
	 * @return Archivo generado en Byte Array.
	 * @throws Exception
	 */
	private static byte[] generaReporteDinamico(String pathReporteJasper, Map<String, Object> parametros, int pCantidadColumnas, int pNroColumnaPivote, int pEstiloReporte, String pMes)throws Exception 
	{
		// Instancia objeto de tipo "ByteArrayOutputStream".
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		
		try 
		{
			// Obtiene formato de reporte.
			String vFormatoReporte = (String) parametros.get(REPORTE_FORMATO);
			
			// Instancia tiempo en milisegundos.
			long startTime = System.currentTimeMillis();
			
			// Instancia ruta del reporte
			java.io.InputStream vRutaReporte = new FileInputStream(pathReporteJasper);
			
			// Adiciona ruta del reporte.
			JasperDesign jasperReportDesign = JRXmlLoader.load(vRutaReporte);
			
			// Obtiene cabecera del reporte.
			List<String> vListaCabeceraReporte = (List<String>) parametros.get("headers");

			// Obtiene cuerpo del repore.
			List<List<String>> vListaCuerpoReporte = (List<List<String>>) parametros.get("rows");
									
			// Obtiene reporte construido dinamicamente.
			ConstructorReporteDinamico vObjReporte = new ConstructorReporteDinamico(jasperReportDesign, vListaCabeceraReporte.size(),	pCantidadColumnas, pNroColumnaPivote, pEstiloReporte);

			// Adiciona columnas del reporte.
			vObjReporte.addDynamicColumns();

			// Compila reporte dinamico.
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperReportDesign);

			// Adiciona titulo del reporte
			parametros.put("REPORT_TITLE", "Reporte dinamico.");
			
			// Genera reporte, adiciona información de la cabecera y cuerpo para el reporte.
			DynamicColumnDataSource pdfDataSource = new DynamicColumnDataSource(vListaCabeceraReporte, vListaCuerpoReporte, pMes);
			
//			List<JRSortField> sortList = new ArrayList<JRSortField>();
//			JRDesignSortField sortField = new JRDesignSortField();
//			String test = ConstructorReporteDinamico.COL_EXPR_PREFIX + (vListaCabeceraReporte.size());
//			sortField.setName(test);
//			sortField.setOrder(SortOrderEnum.ASCENDING);
//			sortField.setType(SortFieldTypeEnum.FIELD);
//			sortList.add(sortField);
//			
//			//add other sortfields here
//			parametros.put(JRParameter.SORT_FIELDS, sortList);

			// Llena el reporte.
			JasperPrint jrprintFile = JasperFillManager.fillReport(jasperReport, parametros, pdfDataSource);
			
			// Escribe en el log del sistema.
			log.info("jrprintFile==" + jrprintFile);

			// Verifica tipo de exportacion.
			if (vFormatoReporte.trim().equalsIgnoreCase("xlsx") || vFormatoReporte.trim().equalsIgnoreCase("xls")) 
			{
				// Instancia tipo de objeto para exportar a excel.
				JRXlsxExporter vObjExcel = new JRXlsxExporter();
				vObjExcel.setExporterInput(new SimpleExporterInput(jrprintFile));
				vObjExcel.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
				configuration.setOnePagePerSheet(false);
				configuration.setDetectCellType(true);
				Map<String, String> numberFormats = new HashMap<String, String>();
				configuration.setDetectCellType(true);
				vObjExcel.setConfiguration(configuration);
				vObjExcel.exportReport();
			} 
			else 
			{		
				// Instancia tipo de objeto para exportar a pdf.
				JRPdfExporter vObjPdf = new JRPdfExporter();
				vObjPdf.setExporterInput(new SimpleExporterInput(jrprintFile));
				vObjPdf.setExporterOutput(new SimpleOutputStreamExporterOutput(out));
				vObjPdf.exportReport();
			}
			// Tiempo de finalizacion para la generacion del reporte.
			long endTime = System.currentTimeMillis();
			// Obtiene tiempo.
			long time = (endTime - startTime) / 1;
			
			// Escribe en el log del sistema.
			log.info("success with " + time + " s");
			log.info("================== " + out.size());
			log.info(">>>>>>>>>>>>> REPORTE DINAMICO GENERADO >>>>>>>>>>>>>");
			return out.toByteArray();
		} 
		catch (Exception e) {
			log.error("Error al exportar a XCEL " + e.getMessage(), e);
			throw new Exception(e);
		}
	}

}