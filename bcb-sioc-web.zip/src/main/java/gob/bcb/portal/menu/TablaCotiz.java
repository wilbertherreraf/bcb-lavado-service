/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-web-sioc
 * gob.bcb.portal.menu.TablaCotiz
 * 27/09/2012 - 14:44:57
 * Creado por faflores
 */
package gob.bcb.portal.menu;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 *
 *
 * @author faflores
 *
 */
public class TablaCotiz
{

}
