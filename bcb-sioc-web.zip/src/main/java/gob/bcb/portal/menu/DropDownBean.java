package gob.bcb.portal.menu;

import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosol;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosolPK;
import gob.bcb.core.seguridad.web.AuthnHandler;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.BeanContextFactory;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.SiocFactoryDao;
import gob.bcb.portal.sioc.transferencias.commons.UsuarioSession;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Solicitante;
import gob.bcb.portal.sioc.view.SolicitudBean;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.util.CollectionUtils;

import dk.itst.oiosaml.sp.UserAssertion;
import dk.itst.oiosaml.sp.service.util.Constants;

public class DropDownBean extends BaseBeanController {
	private static Logger log = Logger.getLogger(DropDownBean.class);
	private String pagina = "";
	private String usuario = "";
	private String linkDesconectar = "";
	private Boolean mostrarBCB = true;
	private Boolean mostrarVenta = true;
	private String fechaLiteral;

	private String[][] menu;

	private Map<String, Boolean> menuAutorizado = new HashMap<String, Boolean>();
	private SolicitudBean solicitudBean = new SolicitudBean();

	@PostConstruct
	public void init() {
		log.info("***** creando DropDownBean *****");
		
		this.pagina = "/index.xhtml";
		
		this.fechaLiteral = UtilsDate.stringFromDate(new Date(), "dd/MM/yyyy");
		FacesContext facesContext = FacesContext.getCurrentInstance();
		HttpServletRequest request = (HttpServletRequest) facesContext.getExternalContext().getRequest();
		UserAssertion ua = (UserAssertion) request.getSession().getAttribute(Constants.SESSION_USER_ASSERTION);
		setRecursos(CollectionUtils.arrayToList(AuthnHandler.getRecursosUser().toArray()));

		Object objeto = FacesContext.getCurrentInstance().getExternalContext().getRequest();
		HttpServletRequest request1 = (HttpServletRequest) objeto;

		// link para desconectarse de sistema
		linkDesconectar = request1.getContextPath() + "/saml/Logout";

		log.info("PostConstruct DropDownBean ***** INCIANDO SESSION APPLICACION *****" + AuthnHandler.getCodParticipante());
		// ///////////////////
		this.usuario = ua.getUserId();

		try {
			String codparticipante = AuthnHandler.getCodParticipante();
			if (StringUtils.isBlank(codparticipante)){
				throw new RuntimeException("Parametro participante nulo , avise a seg. informatica: usuario " + ua.getUserId()
						+ " NO TIENE REGISTRADO CODIGO DE PARTICIPANTE.");				
			}
			codparticipante = codparticipante.trim();
			SiocFactoryDao siocFactoryDao = BeanContextFactory.getInstance().getSiocFactoryDao();
			SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
			socUsuariosolDao.setSessionFactory(siocFactoryDao.getHibernateTemplate().getSessionFactory());

			SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
			socSolicitanteDao.setSessionFactory(siocFactoryDao.getHibernateTemplate().getSessionFactory());

			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(codparticipante);
			
			if (socSolicitante == null) {
				throw new RuntimeException("Solicitante  " + codparticipante
						+ " NO REGISTRADO EN SOLICITANTES, avise al administrador.");
			}
			
			SocUsuariosol socUsuariosol = socUsuariosolDao.getUsuario(ua.getUserId());

			if (socUsuariosol == null) {
				// el usuario no esta registrado en sioc registramos en la tabla
				// siocusuarios
				socUsuariosol = new SocUsuariosol();
				SocUsuariosolPK socUsuariosolPK = new SocUsuariosolPK();
				socUsuariosolPK.setLogin(ua.getUserId());
				socUsuariosolPK.setSolCodigo(codparticipante);

				socUsuariosol = new SocUsuariosol();
				socUsuariosol.setSocUsuariosolPK(socUsuariosolPK);
				socUsuariosol.setUsrNombre(ua.getUserId());
				socUsuariosol.setClaVigente(Short.valueOf("1"));
				socUsuariosol.setUsrCodigo(ua.getUserId());
				socUsuariosol.setEstacion(AuthnHandler.getAddress());
				socUsuariosol.setFechaHora(new Date());

				socUsuariosolDao.saveOrUpdate(socUsuariosol);
				log.info("Ususario nuevo registrado en sioc " + socUsuariosol.getSocUsuariosolPK().getLogin() + " - "
						+ socUsuariosol.getSocUsuariosolPK().getSolCodigo());
			}
			socUsuariosol.getSocUsuariosolPK().setSolCodigo(socUsuariosol.getSocUsuariosolPK().getSolCodigo().trim());
			
			mostrarBCB = socUsuariosol.getSocUsuariosolPK().getSolCodigo().trim().equals(gob.bcb.service.servicioSioc.common.Constants.COD_BCB);

			setMostrarVenta(isVisibleSOC004() || isVisibleSOC005() || isVisibleSOC006() || isVisibleSOC007() || isVisibleSOC008());
			UsuarioSession usuarioSession = new UsuarioSession(ua.getUserId().trim());

			Solicitante solicitante = new Solicitante();  
			solicitante.setSolCodigo(socSolicitante.getSolCodigo().trim());
			solicitante.setSolPersona(socSolicitante.getSolPersona());
			solicitante.setClaEntidad(socSolicitante.getClaEntidad());
			solicitante.setSigla(socSolicitante.getSigla());
			
			usuarioSession.setSolicitante(solicitante);
			usuarioSession.setRecAutorizadosMapa(menuAutorizado);

//			ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
//			Visit.initConnectionFactory(servletContext);
			Visit visit = new Visit();
			visit.setUsuarioSession(usuarioSession);
			// visit.getUsuarioSession().setRecAutorizadosMapa(menuAutorizado);
			visit.setMainController(this);
			visit.setAddress(AuthnHandler.getAddress());

			setVisit(visit);
			solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
			setAutorizado(visit.getUsuarioSession().getRecAutorizadosMapa());
			getApplication().createValueBinding("#{" + gob.bcb.portal.sioc.config.Constants.SESSION_KEY_USER + "}").setValue(facesContext, visit);
			request.getSession().setAttribute(gob.bcb.portal.sioc.config.Constants.SESSION_KEY_USER, visit);
			
			log.info("FIN PostConstruct DropDownBean ***** INCIANDO SESSION APPLICACION *****");
			
			log.info("===> Sesion iniciada, usuario[" + visit.getUsuarioSession().getLogin() + "], participante["
					+ visit.getUsuarioSession().getSolicitante().getSolCodigo() + "], perfil" + ArrayUtils.toString(AuthnHandler.getUserRoles())
					+ ", estacion[" + visit.getAddress() + "] CodEmpleado: " + AuthnHandler.getCodEmpleado());
			log.info("RR: " + ArrayUtils.toString(AuthnHandler.getRecursosUser().toArray()));

			// //////////////////
		} catch (NullPointerException e) {
			log.error("NullPointerException " + e.getMessage(), e);
			addMessageError("NullPointerException:", "Valor nulo: " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "NullPointerException: " + e.getMessage(), null));
			
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrio un error: " + e.getMessage(), null));
		}

	}

	public String getPagina() {
		return pagina;
	}

	public void setPagina(String pagina) {
		this.pagina = pagina;
	}

	public String getLinkDesconectar() {
		return linkDesconectar;
	}

	public void setLinkDesconectar(String linkDesconectar) {
		this.linkDesconectar = linkDesconectar;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getUsuario() {
		return usuario;
	}

	public Boolean getMostrarBCB() {
		return mostrarBCB;
	}

	public void setMostrarBCB(Boolean mostrarBCB) {
		this.mostrarBCB = mostrarBCB;
	}

	public void setMostrarVenta(Boolean mostrarVenta) {
		this.mostrarVenta = mostrarVenta;
	}

	public Boolean getMostrarVenta() {
		return mostrarVenta;
	}

	public void listenerMenu(ActionEvent event) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		HttpSession session = (HttpSession) facesContext.getExternalContext().getSession(false);
		session.removeAttribute("solicitudesBolsinController");
		Map<String, String> map = facesContext.getExternalContext().getRequestParameterMap();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		removerSesiones(sesiones);
		getVisit().removeParametro("SIOCWEB_SOCCODIGO");
		getVisit().removeParametro("SIOCWEB_ACTION");
		
		String tipooperacion = map.get("SIOCWEB_TIPOPERACION");
		String SIOCWEB_CODBENEF = map.get("SIOCWEB_CODBENEF");
		String SIOCWEB_CODOPERACION = map.get("SIOCWEB_CODOPERACION");
		String SIOCWEB_TIPO_OPER = map.get("SIOCWEB_TIPO_OPER");
		String SIOCWEB_SUBTIPO_OPER = map.get("SIOCWEB_SUBTIPO_OPER");
		String SIOCWEB_TSOLIC = map.get("SIOCWEB_TSOLIC");

		log.info("XXX:SIOCWEB_CODBENEF " + SIOCWEB_CODBENEF + " tipooperacion " + tipooperacion);
		getVisit().setParametro("SIOCWEB_CODBENEF", SIOCWEB_CODBENEF);
		getVisit().setParametro("SIOCWEB_CODOPERACION", SIOCWEB_CODOPERACION);
		getVisit().setParametro("SIOCWEB_TIPOPERACION", tipooperacion);
		getVisit().setParametro("SIOCWEB_TIPO_OPER", SIOCWEB_TIPO_OPER);
		getVisit().setParametro("SIOCWEB_SUBTIPO_OPER", SIOCWEB_SUBTIPO_OPER);
		getVisit().setParametro("SIOCWEB_TSOLIC", SIOCWEB_TSOLIC);

		getVisit().setParametro("DropDownBean", this);

		// whf rq02
		// parche: si existe el parametro SIOCWEB_TIPOPERACION es venta directa
		// y el horario se valida en el servicio
		boolean enHorario = solicitudBean.getSocHorarioDao().operacionEstaEnHorario2(tipooperacion, new Date(),
				getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		if (!enHorario) {
			irA("/noAutorizado.xhtml");
		} else {
			this.pagina = map.get("pagina");
		}

		DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
		log.info("XXX: this.pagina" + dd.getPagina());
//		try {
//			FacesContext.getCurrentInstance().getExternalContext().redirect(getRaiz());
//		} catch (IOException e) {
//			log.error(e.getMessage(), e);
//		}
		
	}

	public void removerSesiones() {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		removerSesiones(sesiones);
	}

	public static void removerSesiones(Map<String, Object> sesiones) {
		log.info("removiendo sesiones beans ...");
		sesiones.remove("listaOperacionesController");
		sesiones.remove("listaOperacionesPController");
		sesiones.remove("listaSolicitudesController");
		sesiones.remove("principalController");
		sesiones.remove("solicitudesASFController");
		sesiones.remove("solicitudesASFAutController");
		sesiones.remove("solicitudesAutController");
		sesiones.remove("solicitudesLocalController");
		sesiones.remove("solicitudesBolsinController");
		sesiones.remove("ventaController");
		sesiones.remove("solicitudesBolsinController");
		sesiones.remove("solicitudB");
		sesiones.remove("solicitante");
		sesiones.remove("beneficiariosController");
		sesiones.remove("cobranzaEnvioController");
		sesiones.remove("consulta1Controller");
		// sesiones.remove("estadisticaController");
		sesiones.remove("listaAcreeController");
		sesiones.remove("listaBancosController");
		sesiones.remove("listaBeneficiariosController");
		sesiones.remove("listaBolsinController");
		sesiones.remove("listaBolsinPController");
		// whf vd2
		sesiones.remove("listaBolsinPVentaDirController");
		sesiones.remove("listaBolsinVController");
		sesiones.remove("listaBolsinVIntController");
		sesiones.remove("listaCobranzaController");
		sesiones.remove("usuariosController");
		sesiones.remove("clavesController");
		sesiones.remove("listaSolicitantesController");
		sesiones.remove("listaSolicitudesBCBController");
		sesiones.remove("listaSolicitudesController");
		sesiones.remove("listaSolicitudesIntController");
		sesiones.remove("listaSolicitudesPController");
		sesiones.remove("listaSolicitudesSController");
		sesiones.remove("operacionesDEEController");
		sesiones.remove("operacionesDEMController");
		sesiones.remove("operacionesDEPController");
		sesiones.remove("operacionesModController");
		sesiones.remove("parametrosSistController");
		sesiones.remove("reportesBolsinController");
		sesiones.remove("reportesEst1Controller");
		sesiones.remove("reportesEst2Controller");
		sesiones.remove("reportesOPController");
		sesiones.remove("solBolsinIntController");
		sesiones.remove("solicitanteDetailListController");
		sesiones.remove("solicitudesASFAController");
		sesiones.remove("solicitudesASFAutController");
		sesiones.remove("solicitudesASFController");
		sesiones.remove("solicitudesASFIntController");
		sesiones.remove("solicitudesASFModController");
		sesiones.remove("solicitudesAutController");
		sesiones.remove("solicitudesBCBAutController");
		sesiones.remove("solicitudesBCBController");
		sesiones.remove("solicitudesBCBIntController");
		sesiones.remove("solicitudesBolsinController");
		sesiones.remove("solicitudesDSFController");
		sesiones.remove("solicitudesDSFOpeController");
		sesiones.remove("solicitudesIntController");
		sesiones.remove("solicitudesLocalController");
		sesiones.remove("solicitudesLocalIntController");
		sesiones.remove("solicitudesLocalYController");
		sesiones.remove("solicitudesModController");
		sesiones.remove("cuentasSolController");
		sesiones.remove("venta");
		sesiones.remove("solicitud");
		sesiones.remove("detalle");
		sesiones.remove("listaOrdenPAController");
		sesiones.remove("opa");
		sesiones.remove("listaBolsinVVentaDirController");
		sesiones.remove("operacionesDEController");
		sesiones.remove("detalleO");
		sesiones.remove("listaBolsinAController");
		sesiones.remove("solicitudBS");
		sesiones.remove("solicitudController");
		sesiones.remove("solicitudTDController");
		sesiones.remove("solicitudTDCCController");		
		sesiones.remove("solicitudSearchPanel");
		sesiones.remove("detalleSolicitudController");
		sesiones.remove("mensajesController");
		sesiones.remove("horaSolicitudesController");
		sesiones.remove("feriadoController");
		sesiones.remove("socSolicitudesController");
		sesiones.remove("swfMensajeController");
		sesiones.remove("socBenefslocController");
		sesiones.remove("socBenefsController");
		sesiones.remove("socBenefsListController");		
	}

	public static void irA(String paginaDestino) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		removerSesiones(sesiones);
		DropDownBean menu = (DropDownBean) sesiones.get("dropDownBean");
		menu.setPagina(paginaDestino);
	}

	public boolean isVisibleSOC001() {
		return AuthnHandler.isUserAuthorizated("SOC001");
	}

	public boolean isVisibleSOC002() {
		return AuthnHandler.isUserAuthorizated("SOC002");
	}

	public boolean isVisibleSOC003() {
		return AuthnHandler.isUserAuthorizated("SOC003");
	}

	public boolean isVisibleSOC004() {
		return AuthnHandler.isUserAuthorizated("SOC004");
	}

	public boolean isVisibleSOC005() {
		return AuthnHandler.isUserAuthorizated("SOC005");
	}

	public boolean isVisibleSOC006() {
		return AuthnHandler.isUserAuthorizated("SOC006");
	}

	public boolean isVisibleSOC007() {
		return AuthnHandler.isUserAuthorizated("SOC007");
	}

	public boolean isVisibleSOC008() {
		return AuthnHandler.isUserAuthorizated("SOC008");
	}

	public boolean isVisibleSOC009() {
		return AuthnHandler.isUserAuthorizated("SOC009");
	}

	public boolean isVisibleSOC010() {
		return AuthnHandler.isUserAuthorizated("SOC010");
	}

	public boolean isVisibleSOC011() {
		return AuthnHandler.isUserAuthorizated("SOC011");
	}

	public boolean isVisibleSOC012() {
		return AuthnHandler.isUserAuthorizated("SOC012");
	}

	public boolean isVisibleSOC013() {
		return AuthnHandler.isUserAuthorizated("SOC013");
	}

	public boolean isVisibleSOC014() {
		return AuthnHandler.isUserAuthorizated("SOC014");
	}

	public boolean isVisibleSOC015() {
		return AuthnHandler.isUserAuthorizated("SOC015");
	}

	public boolean isVisibleSOC016() {
		return AuthnHandler.isUserAuthorizated("SOC016");
	}

	public boolean isVisibleSOC017() {
		return AuthnHandler.isUserAuthorizated("SOC017");
	}

	public boolean isVisibleSOC018() {
		return AuthnHandler.isUserAuthorizated("SOC018");
	}

	public boolean isVisibleSOC019() {
		return AuthnHandler.isUserAuthorizated("SOC019");
	}

	public boolean isVisibleSOC020() {
		return AuthnHandler.isUserAuthorizated("SOC020");
	}

	public boolean isVisibleSOC021() {
		return AuthnHandler.isUserAuthorizated("SOC021");
	}

	public boolean isVisibleSOC022() {
		return AuthnHandler.isUserAuthorizated("SOC022");
	}

	public boolean isVisibleSOC023() {
		return AuthnHandler.isUserAuthorizated("SOC023");
	}

	public boolean isVisibleSOC024() {
		return AuthnHandler.isUserAuthorizated("SOC024");
	}

	public boolean isVisibleSOC025() {
		return AuthnHandler.isUserAuthorizated("SOC025");
	}

	public boolean isVisibleSOC034() {
		return AuthnHandler.isUserAuthorizated("SOC034");
	}

	public boolean isVentaDir() {
		return AuthnHandler.isUserAuthorizated("VENTADIR");
	}

	// whf rq02
	public boolean isAutoVentaDir() {
		return AuthnHandler.isUserAuthorizated("AUTOVENTADIR");
	}

	public boolean isOpersVentaDir() {
		return AuthnHandler.isUserAuthorizated("OPERSVENTADIR");
	}

	public boolean isReportesHistoricos() {
		return AuthnHandler.isUserAuthorizated("REPOHISTO");
	}

	public Map<String, Boolean> getMenuAutorizado() {
		return menuAutorizado;
	}

	public void setRecursos(List<String> recursos) {
		if (menuAutorizado != null) {
			menuAutorizado.clear();
		} else {
			menuAutorizado = new HashMap<String, Boolean>();
		}
		for (String recurso : recursos) {
			menuAutorizado.put(recurso, true);
		}
	}

	public String getCodPersona() {
		return AuthnHandler.getCodParticipante();
	}

	public String getFechaLiteral() {
		return fechaLiteral;
	}

	public void setFechaLiteral(String fechaLiteral) {
		this.fechaLiteral = fechaLiteral;
	}
}
