/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import gob.bcb.bpm.pruebaCU.SocBolsin;

import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.SocBolsinS;

/**
 * BackingBean de la vista de solicitudes recibidas.
 *
 * @author Cecilia Uriona
 *
 */
public class ListaBolsinPVentaDirController extends BaseBeanController {

  private SocBolsin solicitudB = new SocBolsin();
  private SocBolsinS solicitudBS = new SocBolsinS();
  private List<SocBolsinS> solicitudes;
  private List<SocBolsin> listaSoli;
  private String f1 = "";
  private Boolean generada = true;
  private String idSoli = "-1";
  private String usuario = "";
  private String urlReporte;
  private String urlReporteS;

  private Logger log = Logger.getLogger(ListaBolsinPController.class);

  public ListaBolsinPVentaDirController() {
		
recuperarVisit();
		usuario = 
getVisit().getUsuarioSession().getLogin();
		// usuario = "rotaboada@bnb.com.bo";
		
idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
		// idSoli = "902";


    this.recuperarSolicitudes();
  }
  @SuppressWarnings("unchecked")
  private void recuperarSolicitudes() {
    this.solicitudes = new ArrayList<SocBolsinS>();
    this.listaSoli = new ArrayList<SocBolsin>();

    String query = " select s.*, ss.sol_persona "
      + " from soc_bolsin s, soc_solicitante ss "
      + " where s.sol_codigo = ss.sol_codigo"
      + " and s.cla_estado = '0'";

	solicitudes = Servicios.getSocBolsinSList("'9','5'", new Date(), idSoli, "'GD', 'ED'");
	listaSoli = Servicios.getSocBolsinList("'9','5'", new Date(), idSoli, "'GD', 'ED'");
  }

  public SocBolsin getSolicitudB() {
    return solicitudB;
  }

  public void setSolicitudB(SocBolsin solicitudB) {
    this.solicitudB = solicitudB;
  }

  public SocBolsinS getSolicitudBS() {
    return solicitudBS;
  }

  public void setSolicitudBS(SocBolsinS solicitudBS) {
    this.solicitudBS = solicitudBS;
  }

  public List<SocBolsinS> getSolicitudes() {
    return solicitudes;
  }

  public void setSolicitudes(List<SocBolsinS> solicitudes) {
    this.solicitudes = solicitudes;
  }

  public List<SocBolsin> getListaSoli() {
    return listaSoli;
  }

  public void setListaSoli(List<SocBolsin> listaSoli) {
    this.listaSoli = listaSoli;
  }

  public Boolean getGenerada() {
    return generada;
  }

  public void setGenerada(Boolean generada) {
    this.generada = generada;
  }

  public String getUrlReporte() {
    urlReporte = getRaiz() + "reporte?cod=0&tipo=BB";
    return urlReporte;
  }

  public void setUrlReporte(String urlReporte) {
    this.urlReporte = urlReporte;
  }

  public void setUrlReporteS(String urlReporteS) {
    this.urlReporteS = urlReporteS;
  }

  public String getUrlReporteS() {
    DateTime fecha = new DateTime();
    Integer i1, i2, i3;

    i1 = fecha.getDayOfMonth();
    i2 = fecha.getMonthOfYear();
    i3 = fecha.getYear();
    f1 = i3.toString() + "-" + i2.toString() + "-" + i1.toString();
    urlReporteS = getRaiz() + "reporte?cod=0&tipo=SB" + "&fecha=" + f1;
    log.info("rr:" + "SB" + ",fecha:" + f1);
    return urlReporteS;
  }
  // whf vd2
  public String getUrlReporteVentaDir() {
	    urlReporte = getRaiz() + "reporte?cod=0&tipo=VD";
	    return urlReporte;
	  }
}
