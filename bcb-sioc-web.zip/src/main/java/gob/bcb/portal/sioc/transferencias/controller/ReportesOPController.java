package gob.bcb.portal.sioc.transferencias.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;

public class ReportesOPController {

  private List<SelectItem> estados = new ArrayList<SelectItem>();
  private List<SelectItem> sorts = new ArrayList<SelectItem>();
  private String idEstado = "";
  private String idSort = "";
  private String f1 = "";
  private String f2 = "";
  private Date fecha1;
  private Date fecha2;
  
  
  private String urlReporte;
  
  private Logger log = Logger.getLogger(ReportesOPController.class);

  public ReportesOPController() 
  {
    estados.add(new SelectItem("P", "AUTORIZADA PARA PAGO"));
    estados.add(new SelectItem("I", "EFECTIVIZADA"));
    estados.add(new SelectItem("A", "ANULADA"));
    
    sorts.add(new SelectItem("N", "N�MERO DE ORDEN"));
    sorts.add(new SelectItem("B", "BENEFICIARIO"));
    sorts.add(new SelectItem("F", "FECHA DE EMISI�N"));
    sorts.add(new SelectItem("V", "FECHA DE VENCIMIENTO"));
  }
  
  public void seleccionChanged(ValueChangeEvent event)
  {
    String sel = (String) event.getNewValue();
    idEstado = sel;
    getUrlReporte();
    log.info("Valor seleccionado: " + idEstado);
  }
  
  public List<SelectItem> getEstados()
  {
    return estados;
  }
  
  public void setEstados(List<SelectItem> estados)
  {
    this.estados = estados;
  }

  public void setSorts(List<SelectItem> sorts) {
    this.sorts = sorts;
  }

  public List<SelectItem> getSorts() {
    return sorts;
  }

  public void setIdEstado(String idEstado) {
    this.idEstado = idEstado;
  }

  public String getIdEstado() {
    return idEstado;
  }

  public void setIdSort(String idSort) {
    this.idSort = idSort;
  }

  public String getIdSort() {
    return idSort;
  }

  public void setFecha1(Date fecha1) {	  
    this.fecha1 = fecha1;
  }

  public Date getFecha1() {	  
	  fecha1 = new Date();
    return fecha1;
  }

  public void setFecha2(Date fecha2) {	  
    this.fecha2 = fecha2;
  }

  public Date getFecha2() {
	  fecha2 = new Date();
    return fecha2;
  }

  private static String getRaiz() {
    HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    String url = request.getRequestURL().toString();
    String direccionRaiz = null;
    if (url.indexOf("/faces") > 0)
      direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
    else
      direccionRaiz = url;
    return direccionRaiz;
  }
  
  public String getUrlReporte() {
    if (fecha1 != null && fecha2 != null)
    {
      DateTime ff1 = new DateTime(fecha1);
      DateTime ff2 = new DateTime(fecha2);
      f1 = ff1.getYear() + "-" + ff1.getMonthOfYear() + "-" + ff1.getDayOfMonth();
      f2 = ff2.getYear() + "-" + ff2.getMonthOfYear() + "-" + ff2.getDayOfMonth();
    }
    log.info("ee:" + idEstado + ",f1:" + f1 + ",f2:" + f2);
    urlReporte = getRaiz() + "reporte?cod=0&tipo=ROP&ee=" + idEstado + "&f1=" + f1 + "&f2=" + f2;
    System.out.println("Datos de envio  para  el  reporte:");
    System.out.println("Estado" + idEstado );
    System.out.println("Fecha1 = " + f1 );
    System.out.println("Fecha2 = " + f2);    
    System.out.println("URL Reporte = " + urlReporte);
    
    return urlReporte;
  }
  
  public String eventoLink(){
	  System.out.println("Fecha1 = " + fecha1 );
	  System.out.println("Fecha2 = " + fecha2);	  
	  return "";
  }

  public void setUrlReporte(String urlReporte) {
    this.urlReporte = urlReporte;
  }


  

}
