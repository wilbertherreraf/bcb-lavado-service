package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.Opecomi;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class SolicitudesASFController extends BaseBeanController {

	private SocSolicitudes solicitud = new SocSolicitudes();
	private SocDetallessol detalle = new SocDetallessol();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
	private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
	private Opecomi comision = new Opecomi();
	private List<Opecomi> comisiones = new ArrayList<Opecomi>();
	private String nroSolicitud = "";
	private String idSoli = "-1";
	private String idBenef = "-1";
	private String idCuenta = "-1";
	private String idCuentaC = "-1";
	private String benef = "";
	private String concepto = "";
	private String banco = "";
	private String plaza = "";
	private String info = "";
	private String mensaje = "";
	private BigDecimal total = BigDecimal.valueOf(0);
	private Boolean botonHab = true;
	private Boolean comiVer = false;

	private String urlReporte;

	private Logger log = Logger.getLogger(SolicitudesASFController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	public SolicitudesASFController() {

		recuperarVisit();
		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		String query = "";

		if (!idSoli.equals("900")) {

			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SF' "
					+ " and cla_vigente = 1" + " and trim(sol_codigo) = '" + idSoli + "'";
		} else {
			idSoli = "-1";
			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SF' "
					+ " and cla_vigente = 1" + " order by sol_persona";
		}

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {

				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		}
	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		if (!idSoli.equals("-1")) {
			cuentasD.clear();

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") != 69)
						cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")));

					if ((Integer) res.get("moneda") == 34)
						// solo por ahora la cuenta de comisiones será en
						// dolares
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")));
				}
			}

			query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '" + idSoli + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {

					idBenef = (String) res.get("ben_codigo");
					benef = (String) res.get("ben_nombre");
				}
			}
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public List<SelectItem> getCuentasB() {
		cuentasB.clear();
		banco = "";
		info = "";
		String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
				+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta " + " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
				+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
				+ " AND pp.bco_codigo = bb.bco_codigo AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res1 : resultado) {
				log.info("resultado" + res1.toString());
				cuentasB.add(new SelectItem(res1.get("cta_codigo"), res1.get("cta_nrocuenta") + "-" + res1.get("moneda")));
				listaCuentasB.add(new CuentasBen((Integer) res1.get("cta_codigo"), (String) res1.get("cta_nrocuenta"), (String) res1.get("cta_info"),
						(Integer) res1.get("moneda"), (String) res1.get("bco_nombre"), (String) res1.get("pla_nombre"), (String) res1.get("pla_bic"),
						(String) res1.get("pla_intermediario"), (String) res1.get("pla_nrocuenta")));
			}
		}

		return cuentasB;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		log.info("Valor seleccionado: " + sel);

		if (sel != -1) {
			for (CuentasBen cuentaB : listaCuentasB) {
				if (cuentaB.getCtaCodigo().compareTo(sel) == 0) {
					banco = cuentaB.getBcoNombre() + " - " + cuentaB.getPlaNombre();
					info = cuentaB.getCtaInfo();
				}
			}
		} else {
			banco = "";
			info = "";
		}
	}

	public void montoChanged(ValueChangeEvent event) {
		log.info("enter changed");
		Long montoL = (Long) event.getNewValue();
		Double montoD = montoL.doubleValue();
		setComiVer(true);
		calcularComisiones(BigDecimal.valueOf(montoD));
	}

	private void calcularComisiones(BigDecimal monto) {
		Date fecha = new Date();
		int monUS = 34;
		BigDecimal tc1 = BigDecimal.valueOf(0.00);
		comisiones.clear();
		total = BigDecimal.valueOf(0);

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("fecha", fecha);
		mapaParametros1.put("moneda", monUS);
		mapaParametros1.put("consulta", "tc");

		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: factor_conv_mn");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros1, iid1);
			tc1 = (BigDecimal) mapaResultado1.get("tc");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BigDecimal comi = monto.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRF"))).divide(BigDecimal.valueOf(100))).divide(
				BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		comision = new Opecomi();
		comision.setOcoMonto(comi.multiply(tc1).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
		comision.setDescripcion("TRANSFERENCIA AL EXTERIOR");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))));
		comision.setDescripcion("GASTOS DE COMUNICACIÓN");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL"))));
		comision.setDescripcion("EMISIÓN DE COMPROBANTES");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitudTest) {
		this.solicitud = solicitudTest;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public List<SelectItem> getCuentasC() {
		return cuentasC;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	/*
	 * public List<SelectItem> getCuentasB() { return cuentasB; }
	 */

	public void setCuentasB(List<SelectItem> cuentasB) {
		this.cuentasB = cuentasB;
	}

	public List<CuentasBen> getListaCuentasB() {
		return listaCuentasB;
	}

	public void setListaCuentasB(List<CuentasBen> listaCuentasB) {
		this.listaCuentasB = listaCuentasB;
	}

	public void setComision(Opecomi comision) {
		this.comision = comision;
	}

	public Opecomi getComision() {
		return comision;
	}

	public void setComisiones(List<Opecomi> comisiones) {
		this.comisiones = comisiones;
	}

	public List<Opecomi> getComisiones() {
		return comisiones;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public String getBenef() {
		return benef;
	}

	public void setBenef(String benef) {
		this.benef = benef;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public String getIdCuentaC() {
		return idCuentaC;
	}

	public void setIdCuentaC(String idCuentaC) {
		this.idCuentaC = idCuentaC;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getPlaza() {
		return plaza;
	}

	public void setPlaza(String plaza) {
		this.plaza = plaza;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public void setComiVer(Boolean comiVer) {
		this.comiVer = comiVer;
	}

	public Boolean getComiVer() {
		return comiVer;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + nroSolicitud + "&tipo=SF";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		String corrs = Servicios.getCorrelativo(idSoli);

		String sigla = Servicios.getSigla(idSoli);

		solicitud.setSolCodigo(idSoli + "   ");
		solicitud.setClaTipo("TE");
		solicitud.setClaEstado('B');
		solicitud.setSocCuentad(Integer.parseInt(idCuenta));
		solicitud.setSocCuentac(Integer.parseInt(idCuentaC));
		solicitud.setMoneda("USD");
		solicitud.setMonedaT("USD");
		solicitud.setSocCorrelativo(sigla + "-" + corrs + "-" + Servicios.obtGestion());
		solicitud.setSocMontoord(BigDecimal.valueOf(0));
		detalle.setBenCodigo(idBenef);
		detalle.setDetMonto(solicitud.getSocMontome());
		detalle.setDetMontoord(solicitud.getSocMontoord());
		detalle.setMoneda(solicitud.getMoneda());

		detalle.setDetConcepto(concepto.toUpperCase());
		detalle.setDetInfo(info);

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "nueva");
		mapaParametros.put("solicitud", solicitud);
		mapaParametros.put("detalle", detalle);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
		log.info("Numero de Solicitud: " + nroSolicitud);

		if (!nroSolicitud.equals("-1")) {
			this.mensaje = "La solicitud se registró correctamente con el número " + solicitud.getSocCorrelativo() + ".";
			this.botonHab = true;
		} else {
			this.mensaje = "Se produjo un error al registrar la solicitud.";
			this.botonHab = true;
		}
	}

}
