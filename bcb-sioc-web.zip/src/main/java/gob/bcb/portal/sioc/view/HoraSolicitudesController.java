package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.SocHorario;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Cuenta;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;

import org.apache.commons.lang.SerializationUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

public class HoraSolicitudesController  extends BaseBeanController {
	private Logger log = Logger.getLogger(HoraSolicitudesController.class);	
	private SocHorario socHorarioSelected = new SocHorario();
	private List<SocHorario> listaHorarios = new ArrayList<SocHorario>();
	private SolicitudBean solicitudBean = new SolicitudBean();
	
	@PostConstruct
	public void init() {
		log.info("postcontructor en: " + this.getClass().getName());
		recuperarVisit();
		solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
		recuperarDatos();
	}
	
	private void recuperarDatos() {
		listaHorarios =solicitudBean.getSocHorarioDao().getSocHorarioList(); 
	}
	public void editar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocHorario cta0 = (SocHorario) SerializationUtils.clone(listaHorarios.get(fila));
		socHorarioSelected = solicitudBean.getSocHorarioDao().findByTOper(cta0.getCodOperacion());
	}
	public void guardar(ActionEvent event) {
		Visit visit = Visit.getVisit();
		try {
			log.info("modificar socHorarioSelected " + socHorarioSelected.getCodOperacion());
			log.info("modificar socHorarioSelected " + socHorarioSelected.toString());			
			socHorarioSelected.setEstacion(visit.getAddress());
			socHorarioSelected.setCodUsuario(visit.getUsuarioSession().getLogin());
			socHorarioSelected.setFechaHora(new Date());

			solicitudBean.getSocHorarioDao().saveOrUpdate(socHorarioSelected);
			log.info("Se modific� el registro correctamente.");

			recuperarDatos();
		} catch (Exception e) {
			log.info("No se pudo realizar la operacion solicitada.");
			e.printStackTrace();
		}
		
	}
	
	public List<SocHorario> getListaHorarios() {
		return listaHorarios;
	}

	public void setListaHorarios(List<SocHorario> listaHorarios) {
		this.listaHorarios = listaHorarios;
	}

	public SocHorario getSocHorarioSelected() {
		return socHorarioSelected;
	}

	public void setSocHorarioSelected(SocHorario socHorarioSelected) {
		this.socHorarioSelected = socHorarioSelected;
	}

}
