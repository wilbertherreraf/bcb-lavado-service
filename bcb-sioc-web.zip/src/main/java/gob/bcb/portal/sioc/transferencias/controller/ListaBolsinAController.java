/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.SocBolsinS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaBolsinAController {

	private SocBolsin solicitudB = new SocBolsin();
	private SocBolsinS solicitudBS = new SocBolsinS();
	private List<SocBolsinS> solicitudes;
	private List<SocBolsin> listaSoli;

	private Boolean generada = true;
	private String mensaje = "";

	private Logger log = Logger.getLogger(ListaBolsinAController.class);

	public ListaBolsinAController() {
		this.recuperarSolicitudes();
	}

	@SuppressWarnings("unchecked")
	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SocBolsinS>();
		this.listaSoli = new ArrayList<SocBolsin>();

		String query = " select s.*, ss.sol_persona " + " from soc_bolsin s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
				+ " and s.cla_estado in ('1', '2')";

		solicitudes = Servicios.getSocBolsinSList("'1', '2'", null, null);
		listaSoli = Servicios.getSocBolsinList("'1', '2'", null, null);
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Generando la operaci�n: ");
		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "adjudicacion");

		// enviando objeto del formulario
		mapaParametros.put("solicitudes", listaSoli);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);if (mapaRespuesta.containsKey("resp_msgerror")){mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");return;}

		String resp_codmsg = (String) mapaRespuesta.get("resp_codmsg");
		String resp_descripmsg = (String) mapaRespuesta.get("resp_descripmsg");
		if (resp_codmsg != null) {
			log.info("Estado devuelto: " + resp_descripmsg);
			mensaje = resp_descripmsg;
		} else {
			mensaje = "Se produjo un error al adjudicar las divisas. Avise a sistemas";
		}
		/*
		 * if (!nroOperacion.equals("0000")) {
		 * log.info("Numero de Operaci�n asignada desde el BPM: " +
		 * nroOperacion); generada = true; String ln =
		 * System.getProperty("line.separator"); this.recuperarSolicitudes(); }
		 * else { log.info("No se pudo generar la operaci�n."); mensaje =
		 * "No se pudo generar la operaci�n. No existe tipo de cambio para la fecha especificada."
		 * ; generada = false; }
		 */
	}

	public SocBolsin getSolicitudB() {
		return solicitudB;
	}

	public void setSolicitudB(SocBolsin solicitudB) {
		this.solicitudB = solicitudB;
	}

	public SocBolsinS getSolicitudBS() {
		return solicitudBS;
	}

	public void setSolicitudBS(SocBolsinS solicitudBS) {
		this.solicitudBS = solicitudBS;
	}

	public List<SocBolsinS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SocBolsinS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<SocBolsin> getListaSoli() {
		return listaSoli;
	}

	public void setListaSoli(List<SocBolsin> listaSoli) {
		this.listaSoli = listaSoli;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
