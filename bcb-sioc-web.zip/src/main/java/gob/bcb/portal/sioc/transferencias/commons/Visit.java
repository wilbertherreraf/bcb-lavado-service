package gob.bcb.portal.sioc.transferencias.commons;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.faces.context.FacesContext;
import javax.jms.ConnectionFactory;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.config.Constants;

public class Visit {
	public static final String CONNECTION_FACTORY_ATTRIBUTE = "CONNECTION_FACTORY_ATTRIBUTE";
	private static Logger log = Logger.getLogger(Visit.class);
	private UsuarioSession usuarioSession;
	private DropDownBean mainController;
	private Map<String, Object> parametro = new HashMap<String, Object>();
	private String Address;
//	private JMSConnectionHandler jMSConnectionHandler0;
//	private static transient ConnectionFactory connectionFactory0;

	public Visit() {
//        if (connectionFactory == null) {
//            throw new IllegalStateException("initConnectionFactory(ServletContext) no fue ejecutado");
//        }
//        jMSConnectionHandler = new JMSConnectionHandler(connectionFactory);
        log.info("Objeto Visit sesion usuario creado");
	}

	public void setUsuarioSession(UsuarioSession usuarioSession) {
		this.usuarioSession = usuarioSession;
	}

	public UsuarioSession getUsuarioSession() {
		return usuarioSession;
	}

	public void setParametro(String key, Object valor) {
		if (this.parametro == null) {
			parametro = new HashMap<String, Object>();
		}
		if (valor == null) {
			if (parametro.containsKey(key))
				parametro.remove(key);
		} else {
			if (key != null) {
				parametro.put(key, valor);
			}
		}
	}

	public Object getParametro(String key) {
		return parametro.get(key);
	}

	public void removeParametro(String key) {
		try {
			parametro.remove(key);
		} catch (Exception e) {
		}
	}

	public void limpiarParametros() {
		parametro.clear();
	}

	public void setParametro(Map<String, Object> parametro) {
		this.parametro = parametro;
	}

	public Map<String, Object> getParametro() {
		return parametro;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getAddress() {
		return Address;
	}

//	public static JMSConnectionHandler getJMSConnectionHandler(HttpServletRequest request) {
//		Visit visit = getVisit(request);
//		JMSConnectionHandler jMSConnectionHandler = visit.getjMSConnectionHandler();
//
//		return jMSConnectionHandler;
//	}

	public static Visit getVisit() {
		HttpServletRequest request = null;
		return getVisit(request);
	}
	public static Visit getVisit(HttpServletRequest request) {
		Map<String, String> sesiones = new HashMap<String, String>();		
		if (request == null) {
			try{
				request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
				sesiones = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
			}catch (Exception e) {
				log.error("Error al recuperar reques de Facescontext " + e.getMessage(), e);
			}
		}
		
        HttpSession session = request.getSession(false);
        if (session == null){
        	throw new IllegalStateException("session usuario no fue inicializado. cierre la sesion e intente nuevamente");        	
        }
        
		Visit visit = getVisit(session);
		if (visit == null ){
			throw new IllegalStateException("Objeto de session Visit no fue inicializado. cierre la sesion e intente nuevamente");			
		}
		//log.info("XXX: sesiones prams " + ArrayUtils.toString(sesiones));
		visit.getParametro().putAll(sesiones);		
		return visit;
	}
	
    public static Visit getVisit(HttpSession session) {
        return (Visit)session.getAttribute(Constants.SESSION_KEY_USER);
    }
    
//	public static synchronized ConnectionFactory initConnectionFactory0(ServletContext servletContext) {
//        if (connectionFactory == null) {
//        	connectionFactory = (ConnectionFactory)servletContext.getAttribute(CONNECTION_FACTORY_ATTRIBUTE);
//        }
//        
//		// configuracion e inicializacion para colas
//		if (connectionFactory == null) {
//			connectionFactory = BeanContextFactory.getInstance().getPooledConnectionFactory();
//			if (connectionFactory == null) {
//				try {
//					Properties props = new Properties();
//					// para el pool
//					props.setProperty("maxConnections", "25");
//					props.setProperty("maximumActive", "12");
//
//					props.setProperty("brokerURL", Constants.getUrlBroker());
//					props.setProperty("dispatchAsync", "false");
//					props.setProperty("prefetchPolicy.durableTopicPrefetch", "2");
//					props.setProperty("prefetchPolicy.optimizeDurableTopicPrefetch", "2");
//					props.setProperty("prefetchPolicy.queuePrefetch", "10");
//					props.setProperty("prefetchPolicy.topicPrefetch", "100");
//					props.setProperty("useAsyncSend", "false");
//					props.setProperty("useCompression", "false");
//					props.setProperty("copyMessageOnSend", "false");
//					props.setProperty("closeTimeout", "50000");
//					props.setProperty("alwaysSessionAsync", "false");
//					props.setProperty("optimizeAcknowledge", "false");
//					// props.setProperty("statsEnabled",
//					// Boolean.toString(isStatsEnabled()));
//					props.setProperty("alwaysSyncSend", "false");
//					// props.setProperty("producerWindowSize",
//					// Integer.toString(getProducerWindowSize()));
//					// props.setProperty("sendTimeout", "60000");
//					props.setProperty("sendAcksAsync", "false");
//					// props.setProperty("auditDepth",
//					// Integer.toString(getAuditDepth()));
//					// props.setProperty("auditMaximumProducerNumber",
//					// Integer.toString(getAuditMaximumProducerNumber()));
//					// props.setProperty("checkForDuplicates",
//					// Boolean.toString(isCheckForDuplicates()));
//					// props.setProperty("messagePrioritySupported",
//					// Boolean.toString(isMessagePrioritySupported()));
//
//					// PooledConnectionFactory pooledConnectionFactory =
//					// DaoFactory.getInstance().getPooledConnectionFactory();
//					// connectionFactory = pooledConnectionFactory;
//					connectionFactory = JMSConnectionHandler.initFromPropertiesContext(props);
//					log.info("ConnectionFactory creado mediante propiedades: " + props.toString());
//
//				} catch (Exception e) {
//					log.error("Error al crear ConnectionFactory mediante propiedades " + e.getMessage(), e);
//					throw new RuntimeException(e);
//				}
//			}
//			
//			if (connectionFactory == null) {
//				throw new RuntimeException("no se pudo recuperar coneccion JMS. comunique a sistemas");
//			}
//			
//			servletContext.setAttribute(CONNECTION_FACTORY_ATTRIBUTE, connectionFactory);
//			log.info("CONNECTION_FACTORY_ATTRIBUTE seteado en servletContext " + connectionFactory);			
//		}
//
//		return connectionFactory;
//	}

//	public void setjMSConnectionHandler(JMSConnectionHandler jMSConnectionHandler) {
//		this.jMSConnectionHandler = jMSConnectionHandler;
//	}
//
//	public JMSConnectionHandler getjMSConnectionHandler() {
//		if (jMSConnectionHandler == null) {
////			jMSConnectionHandler = new JMSConnectionHandler(connectionFactory);
//			log.info("jMSConnectionHandler nuloooo");
//		}
//		return jMSConnectionHandler;
//	}

	public void setMainController(DropDownBean mainController) {
		this.mainController = mainController;
	}

	public DropDownBean getMainController() {
		return mainController;
	}

}
