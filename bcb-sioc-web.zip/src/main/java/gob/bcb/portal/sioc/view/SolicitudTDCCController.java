package gob.bcb.portal.sioc.view;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolcuentas;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasPK;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CalcularVariables;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSioc.pojos.ComprobanteDet;
import gob.bcb.service.servicioSioc.pojos.Detallesol;
import gob.bcb.service.servicioTres.model.RengConcilia;
import gob.bcb.service.servicioTres.model.SaldoConcilia;

public class SolicitudTDCCController extends BaseBeanController {
	private Logger log = Logger.getLogger(SolicitudTDCCController.class);

	private List<SelectItem> monedaItems = new ArrayList<SelectItem>();
	private List<SelectItem> monedaTransferItems = new ArrayList<SelectItem>();
	private List<SelectItem> monedasItemsSigla = null;
	private List<SelectItem> motivosTransferencia = null;
	
	private String sIOCWEB_TIPOPERACION;
	private SocSolicitudes socSolicitudes = new SocSolicitudes();
	private List<SocDetallessol> socDetallessolLista = new ArrayList<SocDetallessol>();
	private List<Detallesol> detallesolLista = new ArrayList<Detallesol>();
	private List<SocFacturas> socFacturasLista = new ArrayList<SocFacturas>();
	private Detallesol detallesolSelected = new Detallesol();
	private SocEsquemas socEsquemasSelected = new SocEsquemas();
	private SocSolicitante socSolicitante = new SocSolicitante();
	private RengConcilia rengConciliaSelected = new RengConcilia();
	// ////////////////
	private SocSolicitudctas socSolicitudctasMovProv = new SocSolicitudctas();
	private SocSolicitudctas socSolicitudctasComGAdm = new SocSolicitudctas();
	private SocCuentassol socCuentassolDestino = new SocCuentassol();
	private SocCuentassol socCuentassolMovProv = new SocCuentassol();
	private SocCuentassol socCuentassolComGAdm = new SocCuentassol();
	private SocCuentassol socCuentassolComCTra = new SocCuentassol();
	private SocDetallessol socDetallessolSelected = new SocDetallessol();

	private List<SelectItem> socSolicitanteItems = new ArrayList<SelectItem>();
	private List<SelectItem> socSolcuentasItems = new ArrayList<SelectItem>();
	private List<SelectItem> socSolcuentasComisItems = new ArrayList<SelectItem>();
	private List<SelectItem> socCuentassolItems = new ArrayList<SelectItem>();
	private List<SelectItem> socCuentassolFVItems;
	private List<SelectItem> socCuentassolComisItems = new ArrayList<SelectItem>();
	private List<SelectItem> socBenefsItemsExt = new ArrayList<SelectItem>();
	private List<SelectItem> socBenefsItemsLoc = new ArrayList<SelectItem>();
	private List<SelectItem> rengConciliaItems = new ArrayList<SelectItem>();
	private Beneficiario beneficiarioSelected = new Beneficiario();

	private List<SelectItem> socBenefsItems = new ArrayList<SelectItem>();
	private List<SelectItem> nroCuentabcoItems = new ArrayList<SelectItem>();
	private List<SelectItem> nroCtasCtasComisBenefItems = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasContabsItems = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasContabsNroAfectItems = new ArrayList<SelectItem>();

	private List<ComprobanteDet> comprobanteLista = new ArrayList<ComprobanteDet>();
	private List<ComprobanteDet> comprobanteRenglonesLista = new ArrayList<ComprobanteDet>();
	private SocComprobante socComprobanteSelected = new SocComprobante();
	private BigDecimal debeSuma = BigDecimal.valueOf(0.00);
	private BigDecimal haberSuma = BigDecimal.valueOf(0.00);

	private SocOpecomi socOpecomiTOTTRANS;
	private SocOpecomi socOpecomiTOTDETMT;
	private SocOpecomi socOpecomiVENTAUSD;
	private SocOpecomi socOpecomiDIFERTC;
	private SocOpecomi socOpecomiCOMCTRA;
	private SocOpecomi socOpecomiTOTCOMISION;
	private SocOpecomi socOpecomiTOTDEBITO;

	@PostConstruct
	public void inicio() {
		log.info("=============ooo00OOO00ooo===================");
		log.info("PostConstruct SolicitudController - " + getClass().getName());
		try {
			recuperarVisit();

			String sIOCWEB_SUBTIPOPER = (String) getVisit().getParametro("SIOCWEB_SUBTIPOPER");
			String sIOCWEB_CODTIPOOPER = (String) getVisit().getParametro("SIOCWEB_CODTIPOOPER");
			String socCodigo = (String) getVisit().getParametro("SIOCWEB_SOCCODIGO");
			String sIOCWEB_ACTION = (String) getVisit().getParametro("SIOCWEB_ACTION");

			if (!StringUtils.isBlank(socCodigo)) {
				if (!StringUtils.isBlank(sIOCWEB_ACTION)) {
					sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
					if (sIOCWEB_ACTION.equals("SOL_EDIT")) {
						actualizarSolicitud(socCodigo);
						actualizar();
						monedasListas();
					} else {
						actualizarSolicitud(socCodigo);
					}
				} else {
					actualizarSolicitud(socCodigo);
				}
			} else {
				if (sIOCWEB_CODTIPOOPER != null) {
					String sIOCWEB_ESQREF = (String) getVisit().getParametro("SIOCWEB_ESQREF");
					String sIOCWEB_CTAPROV = (String) getVisit().getParametro("SIOCWEB_CTAPROV");
					String sIOCWEB_CLAENTIDAD = (String) getVisit().getParametro("SIOCWEB_CLAENTIDAD");
					String sIOCWEB_TIPOTRANSFER = (String) getVisit().getParametro("SIOCWEB_TIPOTRANSFER");
					String sIOCWEB_CODESQ = (String) getVisit().getParametro("SIOCWEB_CODESQ");
					String sIOCWEB_TIPOCONCEPTO = (String) getVisit().getParametro("SIOCWEB_TIPOCONCEPTO");

					socEsquemasSelected.setCodTipooper(sIOCWEB_CODTIPOOPER);
					socEsquemasSelected.setCveSubtipooper(sIOCWEB_SUBTIPOPER);
					if (NumberUtils.isNumber(sIOCWEB_ESQREF))
						socEsquemasSelected.setCodEsqref((sIOCWEB_ESQREF != null ? Integer.valueOf(sIOCWEB_ESQREF) : null));
					if (NumberUtils.isNumber(sIOCWEB_CODESQ))
						socEsquemasSelected.setEsqCodigo((sIOCWEB_CODESQ != null ? Integer.valueOf(sIOCWEB_CODESQ) : null));
					socEsquemasSelected.setProvisiona(sIOCWEB_CTAPROV);
					socEsquemasSelected.setTipoTransfer(sIOCWEB_TIPOTRANSFER);
					// retencion de comisiones sin descuento
					socEsquemasSelected.setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);
					socSolicitante.setClaEntidad(sIOCWEB_CLAENTIDAD);
					nuevaSolicitud(sIOCWEB_TIPOCONCEPTO);
					inicializarSolicitud(socSolicitudes);
					monedasListas();
				}
			}
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		} finally {
			getVisit().removeParametro("SIOCWEB_SOCCODIGO");
			getVisit().removeParametro("SOL_ACTION");
			getVisit().removeParametro("SOL_ESTADO");
			getVisit().removeParametro("SIOCWEB_CODTIPOOPER");
			getVisit().removeParametro("SIOCWEB_CLAOPERACION");
			getVisit().removeParametro("SIOCWEB_SUBTIPOPER");
			getVisit().removeParametro("SIOCWEB_ESQREF");
			getVisit().removeParametro("SIOCWEB_CTAPROV");
			getVisit().removeParametro("SIOCWEB_CLAENTIDAD");
			getVisit().removeParametro("SIOCWEB_TIPOTRANSFER");
			getVisit().removeParametro("SIOCWEB_CODESQ");
			getVisit().removeParametro("SIOCWEB_ACTION");
			getVisit().removeParametro("SIOCWEB_TIPOCONCEPTO");

			// la desesperada!! esto no deberÃ­a estar aqui
			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
			sesiones.remove("solicitudSearchPanel");
		}

	}

	private void nuevaSolicitud(String sIOCWEB_TIPOCONCEPTO) {
		log.info("nuevaSolicitud: Creando por defecto sIOCWEB_TIPOCONCEPTO " + sIOCWEB_TIPOCONCEPTO);
		socSolicitudes = new SocSolicitudes();

		socSolicitudes.setTipoConcepto(sIOCWEB_TIPOCONCEPTO);
		socSolicitudes.setSolEntsolic(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());

		socEsquemasSelected = getSolicitudBean().getSocEsquemasDao().esquemaByCod(socEsquemasSelected.getEsqCodigo());

		socSolicitudes.setEsqCodigo(socEsquemasSelected.getEsqCodigo());
		socSolicitudes.setClaTipo(socEsquemasSelected.getCodTipooper());
		socSolicitudes.setCveSubtipooper(socEsquemasSelected.getCveSubtipooper());
		socSolicitudes.setSocMontome(BigDecimal.ZERO);
		socSolicitudes.setSocMontomn(BigDecimal.ZERO);
		socSolicitudes.setSocMontoord(BigDecimal.ZERO);
		socSolicitudes.setCodMoneda(Constants.COD_MONEDA_USD);
		socSolicitudes.setCodMonedat(Constants.COD_MONEDA_USD);
		socSolicitudes.setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);
		socSolicitudes.setSocTipnegociacion(Constants.CLAVE_TIPNEGOCIA_NORMAL);
		socSolicitudes.setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
		socSolicitudes.setFecha(new Date());

		if (!getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitudes.setSolCodigo(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		} else {
			if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)) {
			} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
			} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ORDPAGO)) {
				socSolicitudes.setSolCodigo(Constants.COD_BCB);
			} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ACREEDORES)) {
				socSolicitudes.setSolCodigo(Constants.COD_BCB);
			} else {
				socSolicitudes.setSolCodigo(Constants.COD_BCB);
			}
		}

		if (!StringUtils.isBlank(socSolicitudes.getSolCodigo()))
			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socSolicitudes.getSolCodigo());
	}

	private void inicializarSolicitud(SocSolicitudes socSolicitudes) {
		socCuentassolItems = new ArrayList<SelectItem>();
		socSolcuentasItems = new ArrayList<SelectItem>();

		SocCuentassol socCuentassol = getSolicitudBean().getSocCuentassolDao().getByClaveCuenta(Constants.COD_CLAVE_FONDOSVISTA,
				socSolicitudes.getCodMoneda());

		socSolicitudctasMovProv = newSocSolicitudctas(Constants.COD_CLAVE_MOVPROVISION, Constants.CLAVE_TIPOCOMIS_SOLIC,
				socSolicitudes.getCodMoneda());
		socSolicitudctasMovProv.setCtaAfectable(socCuentassol.getCtaAfectable());

		if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT_REGACREE)) {
			// si es operacion de reg de acreedores
			SocCuentassol socCuentassolAcr = getSolicitudBean().getSocCuentassolDao().getByClaveCuenta(Constants.COD_CLAVE_CTAACREEDORES,
					Constants.COD_MONEDA_USD);
			socSolicitudctasMovProv.setCtaAfectable(socCuentassolAcr.getCtaAfectable());

		}

		if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT_DEVFONDOSVISTA)) {
			SocCuentassol socCuentassolAcr = getSolicitudBean().getSocCuentassolDao().getByClaveCuenta(Constants.COD_CLAVE_CTAACREEDORES,
					Constants.COD_MONEDA_USD);
			socSolicitudctasMovProv.setCtaAfectable(socCuentassolAcr.getCtaAfectable());
		}

		if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)
				|| socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
			socSolicitudctasComGAdm = newSocSolicitudctas(Constants.COD_CLAVE_COMGADM, Constants.CLAVE_TIPOCOMIS_SOLIC, null);
		} else {
			socSolicitudctasComGAdm = newSocSolicitudctas(Constants.COD_CLAVE_COMGADM, Constants.CLAVE_TIPOCOMIS_BENEF, null);
		}

		actualizarListaBeneficiarios(socSolicitudes, socDetallessolSelected);
		inicializarNuevoBeneficiario(socSolicitudes, socDetallessolSelected);
		cuentasContabsItems = actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected, socSolicitudes.getCodMonedat());
		cuentasContabsNroAfectItems = actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected, null);
		rengConciliaItems = recuperarListaRengConcilia(socSolicitudes);

		ctaProvisionChanged(null);
	}

	private SocSolicitudctas newSocSolicitudctas(String socTipoCuenta, String cveTipocomis, Integer codMoneda) {
		SocSolicitudctasPK socSolicitudctasPK = new SocSolicitudctasPK();
		SocSolicitudctas socSolicitudctas = new SocSolicitudctas();
		socSolicitudctas.setId(socSolicitudctasPK);
		socSolicitudctas.getId().setTipoCuenta(socTipoCuenta);
		socSolicitudctas.setCveTipocomis(cveTipocomis);
		socSolicitudctas.setCodMoneda(codMoneda);

		return socSolicitudctas;
	}

	private void monedasListas() {
		monedaItems = new ArrayList<SelectItem>();
		monedaTransferItems = new ArrayList<SelectItem>();

		List<GenMoneda> genMonedaLista = new ArrayList<GenMoneda>();
		List<GenMoneda> genMonedaTransferLista = new ArrayList<GenMoneda>();

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			// si es trx locales la moneda de la solicitud es usd
			List<Integer> monedaList = new ArrayList<Integer>();
			monedaList.add(Constants.COD_MONEDA_BS);
			monedaList.add(Constants.COD_MONEDA_USD);

			genMonedaTransferLista = getSolicitudBean().getGenMonedaDao().getMonedasLista(monedaList, true);
			genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedas(socSolicitudctasMovProv.getCodMoneda());
		}

		for (GenMoneda genMoneda : genMonedaLista) {
			monedaItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}

		for (GenMoneda genMoneda : genMonedaTransferLista) {
			monedaTransferItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}
		log.info("XXX: monedaTransferItems " + monedaTransferItems.size());
	}

	private void actualizarSolicitud(String socCodigo) {
		log.info("actualizando solicitud : '" + socCodigo + "'");

		Solicitud solicitudTO = getSolicitudBean().getProcesosSolicitud().recuperarSolicitudSimple(socCodigo);
		socSolicitudes = solicitudTO.getSolicitud();

		socDetallessolLista = solicitudTO.getSocDetallessolLista();
		if (socDetallessolLista.size() > 0)
			socDetallessolSelected = socDetallessolLista.get(0);
		recuperarDatosDetalle(socSolicitudes, socDetallessolLista);

		socSolicitante = solicitudTO.getSocSolicitante();
		if (solicitudTO.getSocEsquemas() != null) {
			socEsquemasSelected = solicitudTO.getSocEsquemas();
		}

		comprobanteLista = new ArrayList<ComprobanteDet>();
		if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			comprobanteLista = getSolicitudBean().getSocComprobanteDao().comprobantesGenerados(socCodigo);
		}

		socOpecomiTOTTRANS = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "TOTTRANSMT");
		socOpecomiVENTAUSD = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "VENTAUSD");
		socOpecomiDIFERTC = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "DIFERTC");
		socOpecomiTOTCOMISION = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "TOTCOMISION");
		socOpecomiCOMCTRA = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0,
				Constants.COD_VAR_COMTRANSF);
		socOpecomiTOTDEBITO = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "TOTDEBITO");

		socSolicitudctasMovProv = getSolicitudBean().getSocSolicitudctasDao().getCuenta(socSolicitudes.getSocCodigo(),
				Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
		socSolicitudctasComGAdm = getSolicitudBean().getSocSolicitudctasDao().getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMGADM,
				null, null, null, null);

		if (socSolicitudctasMovProv != null) {
			socCuentassolMovProv = getSolicitudBean().getSocCuentassolDao().getByAfectable(socSolicitudctasMovProv.getCtaAfectable());
			if (socCuentassolMovProv == null)
				socCuentassolMovProv = new SocCuentassol();
		}

		if (socSolicitudctasComGAdm != null) {
			socCuentassolComGAdm = getSolicitudBean().getSocCuentassolDao().getByAfectable(socSolicitudctasComGAdm.getCtaAfectable());
			if (socCuentassolComGAdm == null)
				socCuentassolComGAdm = new SocCuentassol();
		}
	}

	/**
	 * actualiza los datos para un registro existente en base de datos
	 */
	private void actualizar() {
		if (!StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
			log.info("socSolicitudes.getSolCodigo() " + socSolicitudes.getSolCodigo());
			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socSolicitudes.getSolCodigo());
		}

		actualizarListaBeneficiarios(socSolicitudes, socDetallessolSelected);
		cuentasContabsItems = actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected, socSolicitudes.getCodMonedat());
		cuentasContabsNroAfectItems = actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected, socSolicitudes.getCodMonedat());
		rengConciliaItems = recuperarListaRengConcilia(socSolicitudes);
	}

	private List<SelectItem> actualizarCuentasDestino() {
		// actualiza listas segun valores en la solicitud
		List<SelectItem> socCuentassolFVItems = new ArrayList<SelectItem>();
		// lista de cuentas de la entidad solicitante
		Map<String, SocCuentassol> mapaCrtl = new HashMap<String, SocCuentassol>();
		List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().findByClaveCuenta(Constants.COD_CLAVE_FONDOSVISTA);

		for (SocCuentassol socCuentassol : socCuentassolLista) {
			if (!StringUtils.isBlank(socCuentassol.getCtaAfectable())) {
				if (!mapaCrtl.containsKey(socCuentassol.getCtaAfectable())) {
					socCuentassolFVItems.add(new SelectItem(StringUtils.trim(socCuentassol.getCtaAfectable()),
							socCuentassol.getCtaMovimiento() + " - " + socCuentassol.getCtaNommovimiento() + " " + socCuentassol.getMoneda()));
					mapaCrtl.put(socCuentassol.getCtaAfectable(), socCuentassol);
				}
			}
		}
		return socCuentassolFVItems;
	}

	/**
	 * recupera la lista de registros conciliables pendientes, es decir con
	 * saldo
	 * 
	 * @param socSolicitudes
	 * @return
	 */
	private List<SelectItem> recuperarListaRengConcilia(SocSolicitudes socSolicitudes) {
		List<SelectItem> rengConciliaItems = new ArrayList<SelectItem>();
		if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT_REGACREE)
				|| socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT_DEVFONDOSVISTA)) {
			SocCuentassol socCuentassol = getSolicitudBean().getSocCuentassolDao().getByClaveCuenta(Constants.COD_CLAVE_CTAACREEDORES,
					socSolicitudes.getCodMoneda());

			List<RengConcilia> rengConciliaLista = getServicioCoinDao().getRengConciliaDao()
					.findRengConciliaByAfecNroComprob(socCuentassol.getCtaAfectable(), null, null);
			for (RengConcilia rengConcilia : rengConciliaLista) {
				SocComprobante socComprobante = getSolicitudBean().getSocComprobanteDao().getComprobanteByNroComprob(rengConcilia.getNroComprob(),
						rengConcilia.getId().getGestion());
				if (socComprobante != null) {
					// el registro fue generado por SIOC
					rengConciliaItems.add(new SelectItem(
							rengConcilia.getId().getNroConcilia() + "-" + rengConcilia.getId().getGestion() + "-"
									+ rengConcilia.getId().getSecRengConcilia() + "-" + socComprobante.getCpbNrocpbte(),
							rengConcilia.getId().getNroConcilia() + "-" + rengConcilia.getId().getGestion() + " : " + rengConcilia.getImporte()
									+ " (USD) [Cpbte: " + socComprobante.getCpbNrocpbte() + "]"));
				}
			}
		}
		return rengConciliaItems;
	}

	public void ctaProvisionChanged(ActionEvent event) {
		log.info("En ctaProvisionChanged " + socSolicitudctasMovProv.getCtaAfectable());
		monedaItems = new ArrayList<SelectItem>();

		socSolicitudes.setCodMoneda(null);
		socDetallessolSelected.setCodMoneda(null);
		try {
			if (!StringUtils.isBlank(socSolicitudctasMovProv.getCtaAfectable())) {
				List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasUnicas(null,
						socSolicitudctasMovProv.getCtaAfectable(), null, true);
				if (socCuentassolLista.size() > 0) {
					socSolicitudctasMovProv.setCodMoneda(socCuentassolLista.get(0).getMoneda());
					socSolicitudctasMovProv.setNroCuenta(socCuentassolLista.get(0).getCtaMovimiento());
					// moneda del monto origen de la transferencia
					socSolicitudes.setCodMoneda(socSolicitudctasMovProv.getCodMoneda());
					socDetallessolSelected.setCodMoneda(socSolicitudctasMovProv.getCodMoneda());

					GenMoneda genMoneda = getSolicitudBean().getGenMonedaDao().findByCodMoneda(socSolicitudctasMovProv.getCodMoneda());
					monedaItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
				}
			}
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void ctaFondosVistaChanged(ActionEvent event) {
		log.info("En ctaFondosVistaChanged " + socDetallessolSelected.getNroCuentabcointer());
		socDetallessolSelected.setCodMoneda(null);
		try {
			if (!StringUtils.isBlank(socDetallessolSelected.getNroCuentabcointer())) {
				List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasUnicas(null,
						socDetallessolSelected.getNroCuentabcointer(), null, true);
				if (socCuentassolLista.size() > 0) {
					// moneda del monto origen de la transferencia
					socSolicitudes.setCodMonedat(socCuentassolLista.get(0).getMoneda());
					//socDetallessolSelected.setCodMoneda(socCuentassolLista.get(0).getMoneda());					
				}
			}
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void rengSaldoConciliaChanged(ActionEvent event) {
		log.info("En rengSaldoConciliaChanged " + socSolicitudctasMovProv.getNroCuentabco());
		try {
			if (!StringUtils.isBlank(socSolicitudctasMovProv.getNroCuentabco())) {
				String[] nroLibreta = socSolicitudctasMovProv.getNroCuentabco().split("-");
				if (nroLibreta.length >= 3) {
					rengConciliaSelected = getServicioCoinDao().getRengConciliaDao().findRengConciliaById(Integer.valueOf(nroLibreta[0]),
							Integer.valueOf(nroLibreta[1]), Integer.valueOf(nroLibreta[2]), nroLibreta[3]);
					if (rengConciliaSelected != null) {
						socSolicitudes.setSocMontome(rengConciliaSelected.getImporte());
					}
				}
			} else {
				rengConciliaSelected = new RengConcilia();
			}

			if (rengConciliaSelected == null)
				rengConciliaSelected = new RengConcilia();

		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void monedaMontoChanged(ActionEvent event) {
		log.info("monedaMontoChanged " + socSolicitudes.getCodMoneda() + " " + socSolicitudes.getCodMonedat());
		try {
			calcularMontos();
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	/**
	 * al cambiar la moneda de la transferencia se actualiza los beneficiarios
	 * 
	 * @param event
	 */
	public void codMonedatChanged(ActionEvent event) {
		socDetallessolSelected.setBenCodigo(null);
		try {
			actualizarListaBeneficiarios(socSolicitudes, socDetallessolSelected);
			beneficiarioChanged(null);
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	private void inicializarNuevoBeneficiario(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {
		log.info("inicializarNuevoBeneficiario " + socSolicitudes.getSolCodigo());
		socDetallessol.setCodBanco(null);
		socDetallessol.setNroCuentabco(null);
		socDetallessol.setDetInfo(null);
		socDetallessol.setCtaCodigo(null);
		socDetallessol.setDetFacturas(null);
		socDetallessol.setBeneficiario(null);
		socDetallessol.setCodBancointer(null);
		socDetallessol.setNroCuentabcointer(null);
		socDetallessol.setDetCodttransfer(null);
		socDetallessol.setDetMonto(BigDecimal.ZERO);

		// actualizamos el solicitante en solicitud
		if (!getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitudes.setSolCodigo(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		} else {
			if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)) {
				socSolicitudes.setSolCodigo(socDetallessol.getBenCodigo());
				socDetallessol.setTipoConcepto(Constants.CLAVE_DELEXT_MOTIVO_TRANS_REMESAS);
			} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
				socSolicitudes.setSolCodigo(socDetallessol.getBenCodigo());
			} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ORDPAGO)) {
				socSolicitudes.setSolCodigo(Constants.COD_BCB);
			} else {
				socSolicitudes.setSolCodigo(Constants.COD_BCB);
				socDetallessol.setBenCodigo(Constants.COD_BCB);
			}
		}
	}

	/**
	 * recupera los datos de un detalle
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private void actualizarListaBeneficiarios(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel) {
		socBenefsItemsExt = new ArrayList<SelectItem>();
		if (socSolicitudes.getCodMonedat() == null)
			return;

		log.info("actualizarListaBeneficiarios moneda " + socSolicitudes.getCodMonedat() + " " + socDetallessolSel.getBenCodigo());

		List<Beneficiario> beneficiarios = getSolicitudBean().getSocBenefsDao().recuperarBeneficiariosSolicitante(socSolicitudes,
				socDetallessolSel.getBenCodigo(), socSolicitudes.getCodMonedat(), null, true);

		for (Beneficiario beneficiario : beneficiarios) {
			socBenefsItemsExt
					.add(new SelectItem(beneficiario.getBenCodigo().trim(), beneficiario.getBenNombre() + " [" + beneficiario.getBenCodigo() + "]"));
		}
	}

	/**
	 * Actualiza los datos del beneficiario dado un registro detalle del
	 * beneficiario
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private List<SelectItem> actualizarListaCtasBenef(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel, Integer codMoneda) {
		log.info("recuperando lista actualizarDatosBeneficiario " + socDetallessolSel.getBenCodigo());

		Map<String, BancoPlaza> bancoPlazaMapaCrtl = new HashMap<String, BancoPlaza>();
		List<SelectItem> cuentasContabsItems = new ArrayList<SelectItem>();
		beneficiarioSelected = new Beneficiario();

		if (StringUtils.isBlank(socDetallessolSel.getBenCodigo()))
			return cuentasContabsItems;

		beneficiarioSelected = getSolicitudBean().getSocBenefsDao().recuperarBeneficiario(socSolicitudes, socDetallessolSel);
		if (beneficiarioSelected == null) {
			beneficiarioSelected = new Beneficiario();
			return cuentasContabsItems;
		}

		if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)
				|| socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
			List<CuentasBen> listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(), codMoneda,
					null, null, null, null);

			for (CuentasBen cuentasBen : listaCuentasB) {
				if (!bancoPlazaMapaCrtl.containsKey(cuentasBen.getCtaAfectable())) {
					cuentasContabsItems.add(new SelectItem(StringUtils.trimToEmpty(cuentasBen.getCtaAfectable()),
							cuentasBen.getCtaMovimiento() + " [" + cuentasBen.getMonedaLit() + "]" + " " +  cuentasBen.getCtaNombre() ));

					bancoPlazaMapaCrtl.put(cuentasBen.getCtaAfectable(), null);
				}
			}			
		} else {
			List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
			if (socDetallessolSel.getId() != null && socDetallessolSel.getId().getDetCodigo() != null) {
				listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(),
						socSolicitudes.getCodMonedat(), null, null, null, socDetallessolSel.getNroCuentabcointer());
			} else {
				listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(), codMoneda,
						null, null, null, null);
			}

			for (CuentasBen cuentasBen : listaCuentasB) {
				if (!bancoPlazaMapaCrtl.containsKey(cuentasBen.getCtaAfectable())) {
					cuentasContabsItems.add(new SelectItem(StringUtils.trimToEmpty(cuentasBen.getCtaAfectable()),
							cuentasBen.getCtaNombre() + " [" + cuentasBen.getCtaMovimiento() + "-" + cuentasBen.getMoneda() + "]"));

					bancoPlazaMapaCrtl.put(cuentasBen.getCtaAfectable(), null);
				}
			}
		}
		return cuentasContabsItems;
	}

	/**
	 * recupera los nros de cuenta del beneficiario dado
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private List<SelectItem> actualizarListaNroCtasBenef(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel, Integer codMonedat,
			String ctaAfectable) {
		log.info("recuperando lista actualizarListaNroCtasBenef " + socDetallessolSel.getBenCodigo());

		List<SelectItem> nroCuentabcoItems = new ArrayList<SelectItem>();
		Map<String, BancoPlaza> bancoPlazaMapaCrtl = new HashMap<String, BancoPlaza>();

		if (StringUtils.isBlank(socDetallessolSel.getBenCodigo()) || StringUtils.isBlank(ctaAfectable))
			return nroCuentabcoItems;

		if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)
				|| socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
			List<SocSolcuentas> socSolcuentasLista = getSolicitudBean().getSocSolcuentasDao()
					.cuentasEnCuentaSolicitante(socDetallessolSel.getBenCodigo(), null, ctaAfectable, codMonedat, null, null);

			for (SocSolcuentas socSolcuentas : socSolcuentasLista) {
				if (!StringUtils.isBlank(socSolcuentas.getCtaNumero())) {
					nroCuentabcoItems.add(
							new SelectItem(socSolcuentas.getCtaNumero().trim(), socSolcuentas.getCtaNumero() + ": " + socSolcuentas.getCtaNombre()));
				}
			}
		} else {
			List<CuentasBen> listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(),
					codMonedat, null, null, null, ctaAfectable);
			for (CuentasBen cuentasBen : listaCuentasB) {
				if (!StringUtils.isBlank(cuentasBen.getCtaNroCuenta()))
					if (!bancoPlazaMapaCrtl.containsKey(cuentasBen.getCtaNroCuenta())) {
						nroCuentabcoItems.add(new SelectItem(cuentasBen.getCtaNroCuenta().trim(),
								cuentasBen.getCtaNroCuenta().trim() + " [" + cuentasBen.getMoneda() + "]"));
						bancoPlazaMapaCrtl.put(cuentasBen.getCtaNroCuenta(), null);
					}
			}
		}
		return nroCuentabcoItems;
	}

	public void beneficiarioChanged(ActionEvent event) {
		log.info("En beneficiarioChanged " + socDetallessolSelected.getBenCodigo());
		try {
			inicializarNuevoBeneficiario(socSolicitudes, socDetallessolSelected);
			cuentasContabsItems = actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected, socSolicitudes.getCodMonedat());
			cuentasContabsNroAfectItems = actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected, null);

			beneficiarioCtaCodigoChanged(null);
			beneficiarioBancoComisChanged(null);
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void beneficiarioCtaCodigoChanged(ActionEvent event) {
		log.info("En beneficiarioBancoChanged " + socDetallessolSelected.getNroCuentabcointer());
		try {
			socDetallessolSelected.setNroCuentabco(null);
			nroCuentabcoItems = actualizarListaNroCtasBenef(socSolicitudes, socDetallessolSelected, socSolicitudes.getCodMonedat(),
					socDetallessolSelected.getNroCuentabcointer());
			if (!StringUtils.isBlank(socDetallessolSelected.getNroCuentabcointer()))
				getSolicitudBean().getSocDetallessolDao().completarDatosDetalle(socSolicitudes, socDetallessolSelected);
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void beneficiarioBancoComisChanged(ActionEvent event) {
		log.info("En beneficiarioBancoComisChanged " + socSolicitudctasComGAdm.getCtaAfectable());
		try {
			socSolicitudctasComGAdm.setNroLibreta(null);
			socSolicitudctasComGAdm.setCodMoneda(null);
			socSolicitudctasComGAdm.setNroCuenta(null);
			if (!StringUtils.isBlank(socSolicitudctasComGAdm.getCtaAfectable())) {
				List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasUnicas(null,
						socSolicitudctasComGAdm.getCtaAfectable(), null, true);

				if (socCuentassolLista.size() == 1) {
					socSolicitudctasComGAdm.setCodMoneda(socCuentassolLista.get(0).getMoneda());
					socSolicitudctasComGAdm.setNroCuenta(socCuentassolLista.get(0).getCtaMovimiento());
				}
			}
			nroCtasCtasComisBenefItems = actualizarListaNroCtasBenef(socSolicitudes, socDetallessolSelected, null,
					socSolicitudctasComGAdm.getCtaAfectable());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	private void completarCtaCTra() {
		socDetallessolLista = new ArrayList<SocDetallessol>();
		SocDetallessolId socDetallessolId = new SocDetallessolId();
		socDetallessolId.setDetCodigo(1);

		socDetallessolSelected.setId(socDetallessolId);
		//socDetallessolSelected.setCodBanco(null);
		socDetallessolSelected.setDetInfo(null);
		socDetallessolSelected.setCtaCodigo(null);
		socDetallessolSelected.setDetFacturas(null);
		socDetallessolSelected.setBeneficiario(null);
		socDetallessolSelected.setCodBancointer(null);
		socDetallessolSelected.setDetCodttransfer(null);
		socDetallessolSelected.setDetMonto(socSolicitudes.getSocMontome());
		socDetallessolSelected.setCodMoneda(socSolicitudes.getCodMoneda());
		socDetallessolLista.add(socDetallessolSelected);
	}

	private Solicitud populateSolicitudTO() {
		Solicitud solicitudTO = new Solicitud();
		solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);
		solicitudTO.setSolicitud(socSolicitudes);
		solicitudTO.setSocDetallessolLista(socDetallessolLista);

		List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();
		socSolicitudctasLista.add(socSolicitudctasMovProv);
		socSolicitudctasLista.add(socSolicitudctasComGAdm);
		solicitudTO.setSocSolicitudctasLista(socSolicitudctasLista);

		return solicitudTO;
	}

	private void recuperarDatosDetalle(SocSolicitudes socSolicitudes, List<SocDetallessol> socDetallessolLista) {
		log.info("recuperarDatosDetalle : '" + socDetallessolLista.size() + "'");
		detallesolLista = getSolicitudBean().getSocDetallessolDao().recuperarListaDetallessol(socSolicitudes, socDetallessolLista);
	}

	public void verDetalleComprobante(ComprobanteDet comprobanteDetSel) {
		try {
			log.info("verDetalleComprobante : '" + comprobanteDetSel.getCpbCodigo() + "'");
			socComprobanteSelected = getSolicitudBean().getSocComprobanteDao().getComprobante(comprobanteDetSel.getCpbCodigo());
			if (socComprobanteSelected == null) {
				throw new BusinessException("Detalle comprobante " + comprobanteDetSel.getCpbCodigo() + " inexistente");
			}
			comprobanteRenglonesLista = getSolicitudBean().getSocComprobanteDao().recuperarComprobReng(socComprobanteSelected.getCpbCodigo());
			debeSuma = BigDecimal.ZERO;
			haberSuma = BigDecimal.ZERO;
			for (ComprobanteDet comprobanteDet : comprobanteRenglonesLista) {
				debeSuma = debeSuma.add(comprobanteDet.getDebe());
				haberSuma = haberSuma.add(comprobanteDet.getHaber());
			}

		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verDetalleFacturasComprob(ComprobanteDet comprobanteDetSel) {
		try {
			log.info("verDetalleFacturasComprob : '" + comprobanteDetSel.getCpbCodigo() + "'");
			socComprobanteSelected = getSolicitudBean().getSocComprobanteDao().getComprobante(comprobanteDetSel.getCpbCodigo());
			if (socComprobanteSelected == null) {
				throw new BusinessException("Detalle comprobante " + comprobanteDetSel.getCpbCodigo() + " inexistente");
			}
			socFacturasLista = getSolicitudBean().getSocFacturasDao().getFacturas(socComprobanteSelected.getCpbCodigo());

		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	/***********************************/
	public void guardarSolicitud() {
		log.info("Guardando Solicitud TD");
		Date fecha = socSolicitudes.getFechaCont();

		completarCtaCTra();

		Solicitud solicitudTO = populateSolicitudTO();
		try {
			solicitudTO = getSolicitudBean().procesar(solicitudTO, "REG_SOLICITUD");

			if (StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
				throw new BusinessException("El servicio no retorna el codigo de la solicitud");
			}
			solicitudTO.getSolicitud().setFechaCont(fecha);
			solicitudTO = getSolicitudBean().procesar(solicitudTO, "PREAUT");

			addMessageInfo("Aviso", "La operaciÃ³n se proceso satisfactoriamente " + solicitudTO.getSolicitud().getSocCodigo());

			// si es usuario del bcb se va al proceso de autorizar
			irAPagina("/view/Solicitud/solicitud_view.xhtml");
			getVisit().setParametro("pagretorno0", "/view/Solicitud/solicitudes_list_pend.xhtml");
			// se va con
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
			getVisit().setParametro("SIOCWEB_SOCCODIGO", solicitudTO.getSolicitud().getSocCodigo());
			actualizarSolicitud(solicitudTO.getSolicitud().getSocCodigo());

			return;
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

		try {
			actualizarSolicitud(solicitudTO.getSolicitud().getSocCodigo());
			actualizar();
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonPreAutorizar() {
		try {
			log.info("en botonPreAutorizar " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();
			getSolicitudBean().procesar(solicitudTO, "PREAUT");

			String mensajeError = "La operacion se genero exitosamente para solicitud " + socSolicitudes.getSocCodigo() + " a fecha valor "
					+ UtilsDate.stringFromDate(socSolicitudes.getFechaCont(), "dd/MM/yyyy");

			actualizarSolicitud(socSolicitudes.getSocCodigo());

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina((String) getVisit().getParametro("pagretorno0"));
			getVisit().removeParametro("pagretorno");
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonRechazar() {
		try {
			log.info("en botonRechazar " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();

			getSolicitudBean().procesar(solicitudTO, "RECHAZARSOL");

			String mensajeError = "La operacion se proceso exitosamente para solicitud " + socSolicitudes.getSocCodigo();

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina((String) getVisit().getParametro("pagretorno0"));
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonAnular() {
		try {
			log.info("en botonAnular " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();

			getSolicitudBean().procesar(solicitudTO, "ANULARSOL");

			String mensajeError = "La operacion se proceso exitosamente para solicitud " + socSolicitudes.getSocCodigo();

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina((String) getVisit().getParametro("pagretorno0"));
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAutorizarSwifts(ActionEvent actionEvent) {
		try {
			log.info("en botonAutorizarSwift " + socSolicitudes.toString());
			getSolicitudBean().autorizarSwifts(socSolicitudes);
			actualizarSolicitud(socSolicitudes.getSocCodigo());
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
			// return "";
		}
	}

	public void retornarDeSolicituesHa() {
		irAPagina("/view/Solicitud/solicitudes_list_ha.xhtml");
	}

	private void calcularMontos() {
		try {
			log.info("en calcularMontos " + socSolicitudes.toString());
			if (socSolicitudctasMovProv.getCodMoneda() == null) {
				return;
			}

			completarCtaCTra();
			Solicitud solicitudTO = populateSolicitudTO();

			CalcularVariables calcularVariables = getSolicitudBean().getProcesosSolicitud().calculoMontosSolicitud(solicitudTO);

			socOpecomiTOTTRANS = calcularVariables.buscarClaComision("TOTTRANSMT", 0);
			socOpecomiTOTDEBITO = calcularVariables.buscarClaComision("TOTALPROV", 0);
			socOpecomiVENTAUSD = calcularVariables.buscarClaComision("VENTAUSD", 0);
			socOpecomiTOTCOMISION = calcularVariables.buscarClaComision("TOTCOMISION", 0);
			socOpecomiCOMCTRA = calcularVariables.buscarClaComision(Constants.COD_VAR_COMTRANSF, 0);

		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public String botonRetornar() {
		log.info("en botonRetornar ");

		DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
		log.info("XXX: botonRetornar this.pagina= " + dd.getPagina());

		String pagretorno = (String) getVisit().getParametro("pagretorno");
		log.info("pagretorno " + pagretorno);

		dd.setPagina(pagretorno);
		getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);

		return "";
	}

	public void mostrarReporte(ActionEvent event) {
		log.info("Antes de reporte " + socSolicitudes.getSocCodigo());
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codigo", socSolicitudes.getSocCodigo());
		parametros.put("tipo", "soldetalle");
		parametros.put("TITULO", "DETALLE DE OPERACION");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "solicitudresu.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public String getUrlReporte() {
		String urlReporte = getRaiz() + "reporte";
		return urlReporte;
	}

	public SocSolicitudes getSocSolicitudes() {
		return socSolicitudes;
	}

	public void setSocSolicitudes(SocSolicitudes socSolicitudes) {
		this.socSolicitudes = socSolicitudes;
	}

	public List<SocDetallessol> getSocDetallessolLista() {
		return socDetallessolLista;
	}

	public List<SelectItem> getSocSolicitanteItems() {
		return socSolicitanteItems;
	}

	public List<SelectItem> getSocSolcuentasItems() {
		return socSolcuentasItems;
	}

	public List<SelectItem> getSocCuentassolItems() {
		return socCuentassolItems;
	}

	public List<SelectItem> getMonedasItemsSigla() {
		if (monedasItemsSigla == null) {
			monedasItemsSigla = new ArrayList<SelectItem>();
			List<GenMoneda> genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedas();

			for (GenMoneda genMoneda : genMonedaLista) {
				monedasItemsSigla.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonSigla()));
			}
		}
		return monedasItemsSigla;
	}

	public SocSolicitudctas getSocSolicitudctasMovProv() {
		return socSolicitudctasMovProv;
	}

	public SocSolicitudctas getSocSolicitudctasComGAdm() {
		return socSolicitudctasComGAdm;
	}

	public List<SelectItem> getSocCuentassolComisItems() {
		return socCuentassolComisItems;
	}

	public List<SelectItem> getSocSolcuentasComisItems() {
		return socSolcuentasComisItems;
	}

	public SocDetallessol getSocDetallessolSelected() {
		return socDetallessolSelected;
	}

	public void setSocDetallessolSelected(SocDetallessol socDetallessolSelected) {
		this.socDetallessolSelected = socDetallessolSelected;
	}

	public List<SelectItem> getSocBenefsItemsExt() {
		return socBenefsItemsExt;
	}

	public List<SelectItem> getSocBenefsItemsLoc() {
		return socBenefsItemsLoc;
	}

	public List<SelectItem> getSocBenefsItems() {
		return socBenefsItems;
	}

	public List<SelectItem> getMonedaItems() {
		return monedaItems;
	}

	public SocEsquemas getSocEsquemasSelected() {
		return socEsquemasSelected;
	}

	public void setSocEsquemasSelected(SocEsquemas socEsquemasSelected) {
		this.socEsquemasSelected = socEsquemasSelected;
	}

	public SocSolicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setSocSolicitante(SocSolicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public List<SelectItem> getMonedaTransferItems() {
		return monedaTransferItems;
	}

	public Beneficiario getBeneficiarioSelected() {
		return beneficiarioSelected;
	}

	public void setBeneficiarioSelected(Beneficiario beneficiarioSelected) {
		this.beneficiarioSelected = beneficiarioSelected;
	}

	public List<SelectItem> getCuentasContabsItems() {
		return cuentasContabsItems;
	}

	public List<SelectItem> getCuentasContabsNroAfectItems() {
		return cuentasContabsNroAfectItems;
	}

	public List<SelectItem> getNroCtasCtasComisBenefItems() {
		return nroCtasCtasComisBenefItems;
	}

	public List<SelectItem> getNroCuentabcoItems() {
		return nroCuentabcoItems;
	}

	public List<Detallesol> getDetallesolLista() {
		return detallesolLista;
	}

	public Detallesol getDetallesolSelected() {
		return detallesolSelected;
	}

	public void setDetallesolSelected(Detallesol detallesolSelected) {
		this.detallesolSelected = detallesolSelected;
	}

	public List<ComprobanteDet> getComprobanteLista() {
		return comprobanteLista;
	}

	public SocComprobante getSocComprobanteSelected() {
		return socComprobanteSelected;
	}

	public void setSocComprobanteSelected(SocComprobante socComprobanteSelected) {
		this.socComprobanteSelected = socComprobanteSelected;
	}

	public BigDecimal getDebeSuma() {
		return debeSuma;
	}

	public BigDecimal getHaberSuma() {
		return haberSuma;
	}

	public List<ComprobanteDet> getComprobanteRenglonesLista() {
		return comprobanteRenglonesLista;
	}

	public SocCuentassol getSocCuentassolMovProv() {
		return socCuentassolMovProv;
	}

	public void setSocCuentassolMovProv(SocCuentassol socCuentassolMovProv) {
		this.socCuentassolMovProv = socCuentassolMovProv;
	}

	public SocCuentassol getSocCuentassolComGAdm() {
		return socCuentassolComGAdm;
	}

	public void setSocCuentassolComGAdm(SocCuentassol socCuentassolComGAdm) {
		this.socCuentassolComGAdm = socCuentassolComGAdm;
	}

	public SocOpecomi getSocOpecomiTOTTRANS() {
		return socOpecomiTOTTRANS;
	}

	public void setSocOpecomiTOTTRANS(SocOpecomi socOpecomiTOTTRANS) {
		this.socOpecomiTOTTRANS = socOpecomiTOTTRANS;
	}

	public SocOpecomi getSocOpecomiTOTDETMT() {
		return socOpecomiTOTDETMT;
	}

	public void setSocOpecomiTOTDETMT(SocOpecomi socOpecomiTOTDETMT) {
		this.socOpecomiTOTDETMT = socOpecomiTOTDETMT;
	}

	public SocOpecomi getSocOpecomiVENTAUSD() {
		return socOpecomiVENTAUSD;
	}

	public void setSocOpecomiVENTAUSD(SocOpecomi socOpecomiVENTAUSD) {
		this.socOpecomiVENTAUSD = socOpecomiVENTAUSD;
	}

	public SocOpecomi getSocOpecomiDIFERTC() {
		return socOpecomiDIFERTC;
	}

	public void setSocOpecomiDIFERTC(SocOpecomi socOpecomiDIFERTC) {
		this.socOpecomiDIFERTC = socOpecomiDIFERTC;
	}

	public SocOpecomi getSocOpecomiCOMCTRA() {
		return socOpecomiCOMCTRA;
	}

	public void setSocOpecomiCOMCTRA(SocOpecomi socOpecomiCOMCTRA) {
		this.socOpecomiCOMCTRA = socOpecomiCOMCTRA;
	}

	public SocOpecomi getSocOpecomiTOTCOMISION() {
		return socOpecomiTOTCOMISION;
	}

	public void setSocOpecomiTOTCOMISION(SocOpecomi socOpecomiTOTCOMISION) {
		this.socOpecomiTOTCOMISION = socOpecomiTOTCOMISION;
	}

	public SocOpecomi getSocOpecomiTOTDEBITO() {
		return socOpecomiTOTDEBITO;
	}

	public void setSocOpecomiTOTDEBITO(SocOpecomi socOpecomiTOTDEBITO) {
		this.socOpecomiTOTDEBITO = socOpecomiTOTDEBITO;
	}

	public List<SocFacturas> getSocFacturasLista() {
		return socFacturasLista;
	}

	public SocCuentassol getSocCuentassolComCTra() {
		return socCuentassolComCTra;
	}

	public void setSocCuentassolComCTra(SocCuentassol socCuentassolComCTra) {
		this.socCuentassolComCTra = socCuentassolComCTra;
	}

	public List<SelectItem> getSocCuentassolFVItems() {
		if (socCuentassolFVItems == null)
			socCuentassolFVItems = actualizarCuentasDestino();
		return socCuentassolFVItems;
	}

	public SocCuentassol getSocCuentassolDestino() {
		return socCuentassolDestino;
	}

	public void setSocCuentassolDestino(SocCuentassol socCuentassolDestino) {
		this.socCuentassolDestino = socCuentassolDestino;
	}

	public List<SelectItem> getRengConciliaItems() {
		return rengConciliaItems;
	}

	public RengConcilia getRengConciliaSelected() {
		return rengConciliaSelected;
	}

	public List<SelectItem> getMotivosTransferencia() {
		if (motivosTransferencia == null){
			motivosTransferencia = new ArrayList<SelectItem>();			
			motivosTransferencia.add(new SelectItem(Constants.CLAVE_DELEXT_MOTIVO_TRANS_REMESAS, "REMESAS DEL EXTERIOR"));
			motivosTransferencia.add(new SelectItem(Constants.CLAVE_DELEXT_MOTIVO_TRANS_GIROS, "GIROS"));
			motivosTransferencia.add(new SelectItem(Constants.CLAVE_DELEXT_MOTIVO_TRANS_OPERBANCO, "OPERACIONES PROPIAS DEL BANCO"));			
		}
		return motivosTransferencia;
	}
}
