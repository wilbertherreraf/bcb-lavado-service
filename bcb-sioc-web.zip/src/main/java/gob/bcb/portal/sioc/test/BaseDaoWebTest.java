package gob.bcb.portal.sioc.test;

import gob.bcb.portal.sioc.transferencias.commons.SiocFactoryDao;

import org.apache.log4j.Logger;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class BaseDaoWebTest {
	private static Logger log = Logger.getLogger(BaseDaoWebTest.class);
	protected FileSystemXmlApplicationContext applicationContext;
	protected SiocFactoryDao siocFactoryDao;
	public void initContext() {
		applicationContext = new FileSystemXmlApplicationContext("WebContent/WEB-INF/applicationContext.xml");
		siocFactoryDao = (SiocFactoryDao) applicationContext.getBean("serviceSwiftDao");
	}

}
