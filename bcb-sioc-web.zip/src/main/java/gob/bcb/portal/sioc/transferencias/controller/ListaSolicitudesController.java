/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBenefslocal;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;
import gob.bcb.portal.sioc.transferencias.model.Solicitante;
import gob.bcb.portal.sioc.transferencias.model.Venta;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaSolicitudesController extends BaseBeanController {
	private SocSolicitudes solicitud = new SocSolicitudes();
	private SolicitudesS solicitudS = new SolicitudesS();
	private SocDetallessol detalle = new SocDetallessol();
	private SocBenefslocal benef = new SocBenefslocal();
	private CuentasBen cuentaBen = new CuentasBen();
	private Venta venta = new Venta();
	private List<SolicitudesS> solicitudes;
	private List<SocSolicitudes> listaSoli;
	private List<Datosmen> listaCampos;
	private List<Venta> ventas;

	private String prioridad = "NO";
	private String descuento = "NO";
	private BigDecimal montoOrd;
	private Boolean montoVer = false;
	private Boolean cuentaVer = true;
	private Boolean cuentaCVer = true;
	private Boolean nroVer = false;
	private Boolean interVer = false;
	private Boolean extVer = true;
	private Boolean localVer = false;
	private Boolean priVer = true;
	private Boolean swiftVer = false;
	private Boolean sigma = true;
	private Boolean opVer = true;
	private Boolean ccVer = false;
	private Date fechaValor;
	private String cuentaD = "";
	private String cuentaC = "";
	private String nombre = "";
	private String nroOperacion;
	private String codIns;
	private String usuario = "";
	private Boolean generada = true;
	private String mensaje = "";
	private String label1 = "BIC:";
	private String bic = "";
	private String subtipo = "";

	private String urlReporte;

	private Logger log = Logger.getLogger(ListaSolicitudesController.class);

	public ListaSolicitudesController() {

		recuperarVisit();
		usuario = getVisit().getUsuarioSession().getLogin();

		this.recuperarSolicitudes();
	}

	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SolicitudesS>();
		this.listaSoli = new ArrayList<SocSolicitudes>();

		String query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
				+ " and s.cla_estado = 'R' and (s.esq_codigo is null or s.esq_codigo < 100) ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'R', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");
				if (solicitudS.getClaTipo().equals("TE")) {
					solicitudS.setPanel1(true);
					solicitudS.setPanel2(false);
					solicitudS.setPanel3(false);
					solicitudS.setTipo("TRANSFERENCIA AL EXTERIOR");
				} else if (solicitudS.getClaTipo().equals("TC")) {
					solicitudS.setPanel1(false);
					solicitudS.setPanel2(true);
					solicitudS.setPanel3(false);
					solicitudS.setTipo("TRANSFERENCIA CUENTA A CUENTA");
				} 

				solicitudes.add(solicitudS);

				solicitud = new SocSolicitudes((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_tipo"),
						(Integer) res.get("soc_cuentad"), (String) res.get("soc_nrocuentad"), (String) res.get("moneda"), 'R',
						(Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (Integer) res.get("soc_cuentac"),
						(String) res.get("soc_nrocuentac"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"),
						(BigDecimal) res.get("soc_montomn"), (String) res.get("soc_nropago"), (String) res.get("monedat"));
				listaSoli.add(solicitud);
			}
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudS = this.solicitudes.get(fila);
		this.solicitud = this.listaSoli.get(fila);
		opVer = true;
		setCcVer(false);

		if (solicitud.getClaTipo().equals("VE")) {// venta de divisas
			nroVer = (solicitud.getSocNrocuentad() != null);

			if (solicitud.getSocCuentad() == 5) {
				prioridad = "SIGMA";
				cuentaVer = false;
				sigma = true;
			} else {
				prioridad = "CUENTA CORRIENTE FISCAL";
				cuentaVer = true;
				sigma = false;
			}

			String query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentad() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {

					cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentac() + "'";

			List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
			if (resultadoC.size() == 1) {
				for (Map<String, Object> res : resultadoC) {

					cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
				}
			}

			this.ventas = new ArrayList<Venta>();

			query = "select ben_codigo from soc_detallessol where soc_codigo = '" + solicitud.getSocCodigo() + "' and det_codigo = 1";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {

					subtipo = (String) res.get("ben_codigo");
				}
			}
			if (subtipo.equals("999998")) { // orden de pago
				subtipo = "OP";
				interVer = false;
				extVer = false;
				localVer = true;
				opVer = false;
				query = " select s.*, b.*" + " from soc_detallessol s, soc_benefslocal b" + " where s.soc_codigo = '" + solicitud.getSocCodigo()
						+ "'" + " and b.soc_codigo = s.soc_codigo " + " and b.det_codigo = s.det_codigo";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					for (Map<String, Object> res : resultado1) {

						venta = new Venta((String) res.get("beneficiario"), (String) res.get("cta_benef"), "", (BigDecimal) res.get("det_monto"),
								"999998", (String) res.get("moneda"), 0, "", (Integer) res.get("det_codigo"));
						ventas.add(venta);
					}
				}
			} else if (!subtipo.startsWith("0")) { // transf. sist. financ.
				subtipo = "TC";
				interVer = false;
				setExtVer(false);
				setLocalVer(true);
				query = " select d.*, b.ben_nombre, c.cta_nrocuenta, c.moneda, s.cta_nommovimiento "
						+ " from soc_detallessol d, soc_benefsloc b, soc_cuentasloc c, soc_cuentassol s " + " where d.soc_codigo = '"
						+ solicitud.getSocCodigo() + "'" + " and d.ben_codigo = b.ben_codigo " + " and d.det_ctabenef = c.cta_codigo "
						+ " and c.cta_ctacodigo = s.cta_codigo";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					for (Map<String, Object> res : resultado1) {
						Integer mon = (Integer) res.get("moneda");
						venta = new Venta((String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_nommovimiento"),
								(BigDecimal) res.get("det_monto"), "999999", mon.toString(), 0, "", (Integer) res.get("det_codigo"));
						ventas.add(venta);
					}
				}
			} else { // transf. al ext.
				subtipo = "TE";
				setExtVer(true);
				setLocalVer(false);
				query = "select s.*, b.ben_nombre, c.cta_nrocuenta, bb.bco_nombre, p.pla_nombre "
						+ "from soc_detallessol s, soc_benefs b, soc_plazas p, soc_bancos bb, soc_cuentas c "
						+ "where b.ben_codigo = s.ben_codigo and c.cta_codigo = s.det_ctabenef "
						+ "and c.bco_codigo = bb.bco_codigo and p.bco_codigo = bb.bco_codigo "
						+ "and c.pla_codigo = p.pla_codigo and s.soc_codigo = '" + solicitud.getSocCodigo() + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					for (Map<String, Object> res : resultado1) {

						venta = new Venta((String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"), (String) res.get("bco_nombre") + " - "
								+ (String) res.get("pla_nombre"), (BigDecimal) res.get("det_monto"), (String) res.get("ben_codigo"),
								(String) res.get("moneda"), (Integer) res.get("det_ctabenef"), (String) res.get("det_info"),
								(Integer) res.get("det_codigo"));
						ventas.add(venta);
					}
				}
			}

			if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
				descuento = "SI";
				priVer = true;
				montoVer = true;
				cuentaCVer = false;
			} else {
				descuento = "NO";
				priVer = true;
				montoVer = false;
				cuentaCVer = true;
			}

		} else {
			// TRANSFERENCIA AL EXTERIOR

			nroVer = (solicitud.getSocNrocuentad() != null);

			String query = " select s.* " + " from soc_detallessol s " + " where s.soc_codigo = '" + solicitud.getSocCodigo() + "'"
					+ " and s.det_codigo = 1";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {

					detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
							(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), (String) res.get("moneda"),
							(Integer) res.get("det_ctabenef"), (String) res.get("det_concepto"), (String) res.get("det_info"),
							(BigDecimal) res.get("det_montoord"), (String) res.get("monedat"), (String) res.get("det_facturas"));
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentad() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {

					cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentac() + "'";

			List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
			if (resultadoC.size() == 1) {
				for (Map<String, Object> res : resultadoC) {

					cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
				}
			}

			query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.ben_codigo) = '" + detalle.getBenCodigo() + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {

					nombre = (String) res.get("ben_nombre");
				}
			}

			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
					+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
					+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
					+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalle.getDetCtabenef() + "'";

			List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
			if (resultado2.size() == 1) {
				interVer = true;
				for (Map<String, Object> res : resultado2) {

					cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
							(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"),
							(String) res.get("pla_intermediario"), (String) res.get("pla_nrocuenta"), (String) res.get("bco1"),
							(String) res.get("pla1"));
				}
				label1 = "Cuenta:";
				bic = cuentaBen.getPlaNroCuenta();
			} else {
				query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
						+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
						+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
						+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalle.getDetCtabenef() + "'";

				List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
				if (resultado3.size() == 1) {
					interVer = false;
					for (Map<String, Object> res : resultado3) {

						cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
								(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"),
								(String) res.get("pla_bic"));
					}
					label1 = "BIC:";
					bic = cuentaBen.getPlaBic();
				} else {
					interVer = false;
				}
			}
			Solicitante solicitante = Servicios.getSocSolicitante(solicitud.getSolCodigo());

			if (solicitante != null && solicitante.getClaEntidad().equalsIgnoreCase("SF")) {
				prioridad = "NO";
				priVer = false;
				montoVer = false;
				cuentaVer = true;
			} else {
				if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
					prioridad = "SI";
					priVer = true;
					montoVer = true;
					cuentaVer = false;
				} else {
					prioridad = "NO";
					priVer = true;
					montoVer = false;
					cuentaVer = true;
				}
			}
		}
	}

	public void verBenef(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		venta = (Venta) SerializationUtils.clone(this.ventas.get(fila));

		String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
				+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
				+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
				+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
				+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
				+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			interVer = true;
			for (Map<String, Object> res : resultado) {

				cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
						(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"),
						(String) res.get("pla_intermediario"), (String) res.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1"));
			}
			label1 = "Cuenta:";
			bic = cuentaBen.getPlaNroCuenta();
		} else {
			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
					+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				interVer = false;
				for (Map<String, Object> res : resultado1) {

					cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
							(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"));
				}
				label1 = "BIC:";
				bic = cuentaBen.getPlaBic();
			} else {
				interVer = false;
			}
		}
	}

	public void verSwift(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		venta = (Venta) SerializationUtils.clone(this.ventas.get(fila));

		String query = "SELECT ins_codigo " + " FROM soc_detallesope " + " WHERE ope_codigo = '" + nroOperacion + "'" + " AND det_codigo = '"
				+ venta.getDetCodigo() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {

				codIns = (String) res.get("ins_codigo");
			}
			String ln = System.getProperty("line.separator");

			this.listaCampos = new ArrayList<Datosmen>();

			String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
					+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + codIns + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {

					String alto;
					String valor = "";
					String valor1 = (String) res.get("dam_valor");
					if (res.get("cam_codigo").equals(":32A")) {
						valor = valor1;
						valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
					}

					if (res.get("cam_codigo").equals(":33B")) {
						valor = valor1;
						valor1 = valor.substring(0, 3) + ln + valor.substring(3);
					}

					int i = StringUtils.countMatches(valor1, ln);
					i = (i + 1) * 16;
					alto = " height : " + i + "px;";

					listaCampos.add(new Datosmen((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto, (String) res
							.get("cam_nombre")));
				}
			}
		}

	}

	public void eventoGenerarBtn(ActionEvent action) {
		DateTime fecha = new DateTime();
		DateTime fechaV = new DateTime(fechaValor);
		log.info("fecha: " + fecha);
		log.info("valor: " + fechaV);

		mensaje = "";
		if ((fechaV.getDayOfMonth() >= fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear())
				|| (fechaV.getDayOfMonth() < fecha.getDayOfMonth() && fechaV.getMonthOfYear() > fecha.getMonthOfYear())) {
			log.info("Generando la operación: ");
			// parametros para request
			String id = new Long(new Date().getTime()).toString();

			// mapa de parametros a enviar a BPM
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "operacion");

			// enviando objeto del formulario
			mapaParametros.put("solicitud", solicitud);
			mapaParametros.put("detalle", detalle);
			mapaParametros.put("fecha", this.fechaValor);
			mapaParametros.put("usuario", usuario);

			// Metodo estatico que se encarga de manejar las consultas al BPM
			// parametros
			// nombre BPM, ipRequest, requester, feature, mapaParametros, id
			Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros,
					id);
			if (mapaRespuesta.containsKey("resp_msgerror")) {
				mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
				return;
			}
			nroOperacion = (String) mapaRespuesta.get("nroOperacion");
			codIns = (String) mapaRespuesta.get("nroInst");

			if (!nroOperacion.equals("0000")) {
				log.info("Numero de Operación asignada desde el BPM: " + nroOperacion);

				generada = true;

				String ln = System.getProperty("line.separator");

				this.listaCampos = new ArrayList<Datosmen>();

				String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
						+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + codIns + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
				if (resultado1 != null) {
					for (Map<String, Object> res : resultado1) {

						String alto;
						String valor = "";
						String valor1 = (String) res.get("dam_valor");
						if (res.get("cam_codigo").equals(":32A")) {
							valor = valor1;
							valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
						}

						if (res.get("cam_codigo").equals(":33B")) {
							valor = valor1;
							valor1 = valor.substring(0, 3) + ln + valor.substring(3);
						}

						int i = StringUtils.countMatches(valor1, ln);
						i = (i + 1) * 16;
						alto = " height : " + i + "px;";

						listaCampos.add(new Datosmen((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto, (String) res
								.get("cam_nombre")));
					}
				}

				this.recuperarSolicitudes();
			}

			else {
				log.info("No se pudo generar la operación.");
				mensaje = "No se pudo generar la operación. No existe tipo de cambio para la fecha especificada.";
				generada = false;
			}
		} else {
			log.info("No se puede generar la operación con fecha anterior.");
			mensaje = "No se puede generar la operación con fecha valor anterior a la fecha actual.";
			generada = false;
		}
	}

	public void eventoGenerarVBtn(ActionEvent action) {
		DateTime fecha = new DateTime();
		DateTime fechaV = new DateTime(fechaValor);
		log.info("fecha: " + fecha);
		log.info("valor: " + fechaV);

		mensaje = "";
		if ((fechaV.getDayOfMonth() >= fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear())
				|| (fechaV.getDayOfMonth() < fecha.getDayOfMonth() && fechaV.getMonthOfYear() > fecha.getMonthOfYear())) {
			log.info("Generando la operación: ");

			// parametros para request
			String id = new Long(new Date().getTime()).toString();

			// mapa de parametros a enviar a BPM
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			if (subtipo.equals("TE"))
				mapaParametros.put("opcion", "operacionV");
			else {
				if (subtipo.equals("TC"))
					mapaParametros.put("opcion", "operacionVTC");
				else {
					if (subtipo.equals("OP"))
						mapaParametros.put("opcion", "operacionVOP");
					else
						mapaParametros.put("opcion", "operacionVCC");
				}
			}

			// enviando objeto del formulario
			mapaParametros.put("solicitud", solicitud);
			mapaParametros.put("fecha", this.fechaValor);
			mapaParametros.put("usuario", usuario);

			// Metodo estatico que se encarga de manejar las consultas al BPM
			// parametros
			// nombre BPM, ipRequest, requester, feature, mapaParametros, id
			Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros,
					id);

			if (mapaRespuesta.containsKey("resp_msgerror")) {
				mensaje = "Se produjo un error: " + mapaRespuesta.get("resp_msgerror");
				return;
			}

			nroOperacion = (String) mapaRespuesta.get("nroOperacion");

			if (!nroOperacion.equals("0000")) {
				log.info("Numero de Operación asignada desde el BPM: " + nroOperacion);
				generada = true;

				if (subtipo.equals("TE")) {
					swiftVer = true;
					mensaje = "Se generó la operación y los mensajes de transferencia correspondientes.";
				} else {
					swiftVer = false;
					mensaje = "Se generó la operación correctamente.";
				}
				this.recuperarSolicitudes();
			} else {
				log.info("No se pudo generar la operación. No existe tipo de cambio para la fecha especificada.");
				mensaje = "No se pudo generar la operación. No existe tipo de cambio para la fecha especificada.";
				generada = false;
			}
		} else {
			log.info("No se puede generar la operación con fecha anterior.");
			mensaje = "No se puede generar la operación con fecha valor anterior a la fecha actual.";
			generada = false;
		}
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitud) {
		this.solicitud = solicitud;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public SolicitudesS getSolicitudS() {
		return solicitudS;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudS = solicitudS;
	}

	public Venta getVenta() {
		return venta;
	}

	public void setVenta(Venta venta) {
		this.venta = venta;
	}

	public SocBenefslocal getBenef() {
		return benef;
	}

	public void setBenef(SocBenefslocal benef) {
		this.benef = benef;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<SocSolicitudes> getListaSoli() {
		return listaSoli;
	}

	public void setListaSoli(List<SocSolicitudes> listaSoli) {
		this.listaSoli = listaSoli;
	}

	public List<Venta> getVentas() {
		return ventas;
	}

	public void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}

	public String getDescuento() {
		return descuento;
	}

	public void setDescuento(String descuento) {
		this.descuento = descuento;
	}

	public Date getFechaValor() {
		return fechaValor;
	}

	public void setFechaValor(Date fechaValor) {
		this.fechaValor = fechaValor;
	}

	public String getNroOperacion() {
		return nroOperacion;
	}

	public void setNroOperacion(String nroOperacion) {
		this.nroOperacion = nroOperacion;
	}

	public String getCodIns() {
		return codIns;
	}

	public void setCodIns(String codIns) {
		this.codIns = codIns;
	}

	public BigDecimal getMontoOrd() {
		return montoOrd;
	}

	public void setMontoOrd(BigDecimal montoOrd) {
		this.montoOrd = montoOrd;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getCuentaVer() {
		return cuentaVer;
	}

	public void setCuentaVer(Boolean cuentaVer) {
		this.cuentaVer = cuentaVer;
	}

	public Boolean getCuentaCVer() {
		return cuentaCVer;
	}

	public void setCuentaCVer(Boolean cuentaCVer) {
		this.cuentaCVer = cuentaCVer;
	}

	public void setNroVer(Boolean nroVer) {
		this.nroVer = nroVer;
	}

	public Boolean getNroVer() {
		return nroVer;
	}

	public void setExtVer(Boolean extVer) {
		this.extVer = extVer;
	}

	public void setOpVer(Boolean opVer) {
		this.opVer = opVer;
	}

	public Boolean getOpVer() {
		return opVer;
	}

	public Boolean getExtVer() {
		return extVer;
	}

	public void setLocalVer(Boolean localVer) {
		this.localVer = localVer;
	}

	public Boolean getLocalVer() {
		return localVer;
	}

	public Boolean getPriVer() {
		return priVer;
	}

	public void setPriVer(Boolean priVer) {
		this.priVer = priVer;
	}

	public Boolean getSwiftVer() {
		return swiftVer;
	}

	public void setSwiftVer(Boolean swiftVer) {
		this.swiftVer = swiftVer;
	}

	public Boolean getSigma() {
		return sigma;
	}

	public void setSigma(Boolean sigma) {
		this.sigma = sigma;
	}

	public List<Datosmen> getListaCampos() {
		return listaCampos;
	}

	public void setCcVer(Boolean ccVer) {
		this.ccVer = ccVer;
	}

	public Boolean getCcVer() {
		return ccVer;
	}

	public void setListaCampos(List<Datosmen> listaCampos) {
		this.listaCampos = listaCampos;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + codIns + "&tipo=SW";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

}
