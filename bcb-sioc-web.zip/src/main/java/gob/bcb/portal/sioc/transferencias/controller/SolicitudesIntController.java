package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.Opecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.view.SolicitudBean;
import gob.bcb.service.qnatives.coin.CalendarioComun;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.common.MensSwiftUtiles;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;

public class SolicitudesIntController extends BaseBeanController {

	private SocSolicitudes solicitud;
	private SocDetallessol detalle;
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> monedasT = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private List<SelectItem> benefs = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
	private List<SelectItem> conceptos = new ArrayList<SelectItem>();
	private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
	private CuentasBen cuentaBSelected = new CuentasBen();
	private List<Datosmen> listaCampos;
	private Opecomi comision;
	private List<Opecomi> comisiones = new ArrayList<Opecomi>();
	private String[][] comis = new String[3][2];
	private String idSoli = "-1";
	private String idBenef = "-1";
	private String idCuenta = "-1";
	private Integer idCuentaB = -1;
	private String idDescuento = "NO";
	private String idFijo = "F";
	private String idConcepto = "-1";
	private String concepto = "";
	private String conc = "-1";
	private String nroCuenta = "";
	private String cuenta = "";
	private String bic = "";
	private String bic1 = "";
	private String banco = "";
	private String plaza = "";
	private String informa = "";
	private String adicional = "";
	private String mensaje = "";
	private String label1 = "";
	private String label2 = "";
	private String labelM = "Monto a Transferir:";
	private String labelE = "Equivalente en USD:";
	private String usuario;
	private String nroOperacion;
	private String codIns;
	private String nit = "";
	private String fact = "";
	private BigDecimal montoOrd = BigDecimal.valueOf(0);
	private BigDecimal montoEquiv = BigDecimal.valueOf(0);
	private BigDecimal total = BigDecimal.valueOf(0);
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean comiVer = false;
	private Boolean botonHab = false;
	private Boolean interVer = false;
	private Boolean infoVer = false;
	private Boolean fijoVer = false;
	private Boolean fijo = true;
	private Boolean fijoT = false;
	private Boolean generada = true;
	private Boolean visible;
	private Date fechaValor;

	private String urlReporte;
	private SolicitudBean solicitudBean = new SolicitudBean();
	private Logger log = Logger.getLogger(SolicitudesIntController.class);

	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	@PostConstruct
	public void init() {

		recuperarVisit();
		solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
		usuario = getVisit().getUsuarioSession().getLogin();
		this.botonHab = false;
		String query = "";

		idSoli = "-1";
		query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SP' " + " and cla_vigente = 1"
				+ " order by sol_persona";

		solicitud = new SocSolicitudes();
		solicitud.setMonedaT("-1");
		solicitud.setSocMontome(BigDecimal.valueOf(0));

		monedas.add(new SelectItem("USD", "DOLARES ESTADOUNIDENSES"));
		monedas.add(new SelectItem("EUR", "EUROS"));
		monedas.add(new SelectItem("SEK", "CORONAS SUECAS"));
		monedas.add(new SelectItem("CHF", "FRANCOS SUIZOS"));// monedas.add(new
																// SelectItem("GBP",
																// "LIBRAS ESTERLINAS"));

		conceptos.add(new SelectItem("INV", "PAGO FACTURA"));
		conceptos.add(new SelectItem("OTR", "OTROS"));

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		}
		detalle = new SocDetallessol();
	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		cuentasD.clear();		
		if (!idSoli.equals("-1")) {

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());
					if ((Integer) res.get("moneda") != 69) {
						if (res.get("cta_numero") != null) {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD-" + res.get("cta_numero")));
						} else {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD"));
						}
					}
				}
			}
		} 

		return cuentasD;
	}

	public List<SelectItem> getBenefs() {
		log.debug("soli: " + idSoli);
		benefs.clear();		
		if (idSoli != "-1") {
			String query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '" + idSoli + "' " + "ORDER BY bb.ben_nombre ";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado != null) {
				for (Map<String, Object> res : resultado) {
					log.debug("resultado" + res.toString());
					benefs.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
				}
			}
		} 

		return benefs;
	}

	public List<SelectItem> getCuentasB() {
		cuentasB.clear();
		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";

		Integer codMon = null;
		if (!StringUtils.isBlank(solicitud.getMonedaT())) {
			if (solicitud.getMonedaT().equals("USD")) {
				codMon = 34;
			} else if (solicitud.getMonedaT().equals("EUR")) {
				codMon = 53;
			} else if (solicitud.getMonedaT().equals("CHF")) {
				codMon = 31;
			} else if (solicitud.getMonedaT().equals("SEK")) {
				codMon = 30;
			}
		}
		List<CuentasBen> listaCuentasB0 = solicitudBean.getSocBenefsDao().cuentasBenefExterior(null, idBenef, null, codMon, null, null, null, null,null,true);
		for (CuentasBen cuentasBen0 : listaCuentasB0) {
			String moneda = "";
			if (cuentasBen0.getMoneda().compareTo(34) == 0) {
				moneda = "USD";
			} else if (cuentasBen0.getMoneda().compareTo(53) == 0) {
				moneda = "EUR";
			} else if (cuentasBen0.getMoneda().compareTo(31) == 0) {
				moneda = "CHF";
			} else if (cuentasBen0.getMoneda().compareTo(30) == 0) {
				moneda = "SEK";
			} else {
				moneda = "";
			}
			cuentasB.add(new SelectItem(cuentasBen0.getCtaCodigo(), cuentasBen0.getCtaNroCuenta() + " - " + moneda));

			listaCuentasB.add(cuentasBen0);

		}

		return cuentasB;

	}

	public List<SelectItem> getCuentasC() {
		String idC;
		String moneda = "";

		if (idCuenta != "-1") {
			cuentasC.clear();

			if ("SI".equals(idDescuento)) {
				idC = Integer.toString(0);
			} else {
				idC = idCuenta;
			}

			log.debug("idc:" + idC);

			String query = " SELECT sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " FROM soc_solcuentas sc, soc_cuentassol cc "
					+ " WHERE sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());
					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					if (res.get("cta_numero") != null) {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda
								+ "-" + res.get("cta_numero")));
					} else {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda));
					}
				}
			}
		} else {
			cuentasC.clear();
		}

		return cuentasC;
	}

	public void benChanged(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idBenef = sel;
		log.debug("Valor seleccionado: " + idBenef);
		cuentaBSelected = new CuentasBen (); 
		this.getCuentasB();
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		idCuentaB = sel;
		log.debug("Valor seleccionado: " + sel);

		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";

		if (idCuentaB != -1) {
			for (CuentasBen cuentaB : listaCuentasB) {

				if (cuentaB.getCtaCodigo().compareTo(idCuentaB) == 0) {
					cuentaBSelected = cuentaB;					
					if (!interVer) {
						bic = cuentaB.getPlaBic();
						if (bic != null)
							label2 = "BIC:";
						else {
							bic = cuentaB.getPlaNroCuenta();
							label2 = "Cuenta:";
						}
					} else {
						bic = cuentaB.getPlaNroCuenta();
						if (bic != null)
							label2 = "Cuenta:";
						else {
							bic = cuentaB.getPlaBic();
							label2 = "BIC:";
						}
					}
					cuenta = cuentaB.getCtaNroCuenta();
					banco = cuentaB.getBcoNombre() + " - " + cuentaB.getPlaNombre();
					bic1 = cuentaB.getPlaIntermediario();
					plaza = cuentaB.getBcoNombreI() + " - " + cuentaB.getPlaNombreI();
					informa = cuentaB.getCtaInfo();

					setInfoVer(!StringUtils.isBlank(informa));

					if (montoVer) {
						String query = "SELECT ben_nit, ben_factura " + "FROM soc_benefs bb WHERE ben_codigo = '" + idBenef + "' "
								+ "AND cla_vigente = 1";

						List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
						if (resultado.size() == 1) {
							for (Map<String, Object> res : resultado) {
								log.debug("resultado" + res.toString());
								setNit((String) res.get("ben_nit"));
								setFact((String) res.get("ben_factura"));
							}
						}
					}
				}
			}
		}
	}

	public void seleccion1Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idConcepto = sel;
		log.debug("Valor seleccionado: " + sel);

		if ("INV".equals(sel)) {
			label1 = "Ingresar sólo el número de la factura";
		} else {
			label1 = "";
		}
	}

	public void seleccion2Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idDescuento = sel;
		log.debug("Valor seleccionado: " + idDescuento);

		if ("SI".equals(idDescuento)) {
			solicitud.setSocCuentac(Integer.parseInt(idCuenta));

			int monUS = 34;
			int mon = Servicios.getMoneda(solicitud.getMoneda());
			BigDecimal monto = BigDecimal.valueOf(0);
			BigDecimal tc = getTipoCambio(mon);
			BigDecimal tc1 = BigDecimal.valueOf(0);

			if (mon == monUS) {
				monto = solicitud.getSocMontome();
				tc1 = tc;
			} else {
				tc1 = getTipoCambio(monUS);
				monto = solicitud.getSocMontome().multiply(tc).divide(tc1, 2, RoundingMode.HALF_UP);
			}

			log.info("Monto: " + monto);
			BigDecimal swift = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))).divide(tc1, 11, RoundingMode.HALF_UP);
			BigDecimal util = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL"))).divide(tc1, 11, RoundingMode.HALF_UP);
			BigDecimal comi = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRA"))).divide(BigDecimal.valueOf(100));
			montoOrd = (monto.subtract(swift)).subtract(util).divide(comi.add(BigDecimal.valueOf(1)), 2, RoundingMode.HALF_UP);
			log.info("MontoOrd: " + montoOrd);

			BigDecimal montoC = ((montoOrd.multiply(comi).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP)).multiply(tc1)).divide(
					BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			BigDecimal totC = (montoC.add(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT")))).add(BigDecimal.valueOf(Double
					.valueOf(Servicios.getComision("UTIL"))))).divide(tc1, 2, RoundingMode.HALF_UP);
			BigDecimal tot = montoOrd.add(totC);
			BigDecimal diff = monto.subtract(tot);
			if (diff.abs().compareTo(BigDecimal.valueOf(0.01)) > 0) {

			} else {
				montoOrd = montoOrd.add(diff);
			}

			if (mon != monUS)
				montoOrd = montoOrd.multiply(tc1).divide(tc, 2, RoundingMode.HALF_UP);
			log.info("MontoOrd1: " + montoOrd);
			solicitud.setSocMontoord(solicitud.getSocMontome());
			cuentaHab = true;
			montoVer = true;

			calcularComisiones(montoOrd);
		} else {
			cuentaHab = false;
			montoVer = false;
			solicitud.setSocMontoord(BigDecimal.valueOf(0));
		}
	}

	private BigDecimal getTipoCambio(int mon) {
		BigDecimal tc = BigDecimal.valueOf(0);
		Date fecha = new Date();

		if (idFijo.equals("F"))
			fecha = new Date();
		else {
			CalendarioComun calendarioComun = new CalendarioComun();
			calendarioComun.setSessionFactory(getServicioCoinDao().getSessionFactory());
			
			Date sigFechaHabil = calendarioComun.fecHabilAntesDespuesDe(fecha, 1);
			fechaValor = sigFechaHabil;
		}

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("fecha", fecha);
		mapaParametros1.put("moneda", mon);
		mapaParametros1.put("consulta", "tc");

		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: factor_conv_mn");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros1, iid1);
			tc = (BigDecimal) mapaResultado1.get("tc");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return tc;
	}

	public void seleccion3Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		log.debug("Valor seleccionado: " + sel);

		if (!sel.equals("-1")) {
			solicitud.setMoneda(sel);
			if (sel.equals("USD"))
				fijoVer = false;
			else
				fijoVer = true;
		}
	}

	public void montoChanged(ValueChangeEvent event) {
		log.info("enter changed");
		String montoS = event.getNewValue().toString();
		log.info("montoS:" + montoS);
		Double montoD = Double.parseDouble(montoS);
		log.info("montoD:" + montoD);
		int monUS = 34;
		setComiVer(true);
		if (solicitud.getMonedaT().equals("USD"))
			calcularComisiones(BigDecimal.valueOf(montoD));
		else {
			BigDecimal tc = getTipoCambio(Servicios.getMoneda(solicitud.getMonedaT()));
			BigDecimal tcUS = getTipoCambio(monUS);
			if (idFijo.equals("F")) {
				calcularComisiones(BigDecimal.valueOf(montoD).multiply(tc).divide(tcUS, 2, RoundingMode.HALF_UP));
				montoEquiv = BigDecimal.valueOf(montoD).multiply(tc).divide(tcUS, 2, RoundingMode.HALF_UP);
			} else {
				montoEquiv = BigDecimal.valueOf(montoD).multiply(tcUS).divide(tc, 2, RoundingMode.HALF_UP);
				calcularComisiones(BigDecimal.valueOf(montoD));
			}
		}
	}

	public void seleccion5Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idFijo = sel;
		log.debug("Valor seleccionado: " + idFijo);
		montoEquiv = BigDecimal.valueOf(0);
		solicitud.setSocMontome(BigDecimal.valueOf(0));
		setComiVer(false);

		if (idFijo.equals("F")) {
			labelM = "Monto a Transferir:";
			labelE = "Equivalente en USD:";
			solicitud.setMoneda(solicitud.getMonedaT());
		} else {
			labelM = "Monto en USD:";
			labelE = "Equivalente en " + solicitud.getMonedaT() + ":";
			solicitud.setMoneda("USD");
		}
	}

	private void calcularComisiones(BigDecimal monto) {
		int monUS = 34;
		BigDecimal tc1 = BigDecimal.valueOf(0.00);
		comisiones.clear();
		total = BigDecimal.valueOf(0);

		tc1 = getTipoCambio(monUS);

		BigDecimal comi = monto.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRA"))).divide(BigDecimal.valueOf(100))).divide(
				BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		comision = new Opecomi();
		comision.setOcoMonto(comi.multiply(tc1).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
		comision.setDescripcion("TRANSFERENCIA AL EXTERIOR");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))));
		comision.setDescripcion("GASTOS DE COMUNICACIÓN");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL"))));
		comision.setDescripcion("EMISIÓN DE COMPROBANTES");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
	}

	private String cortarConcepto() {
		String concCortado = "";
		Boolean cortado = false;
		int i = 34;
		int j;
		String texto = "";
		String ln = "\r\n";

		if (concepto.length() > 35) {
			texto = concepto;
			do {
				if (concepto.charAt(i) == ' ' || concepto.charAt(i) == '.' || concepto.charAt(i) == ',') {
					texto = concepto.substring(0, i) + ln + concepto.substring(i + 1);
					cortado = true;
				}
				i--;
			} while (!cortado);

			concCortado = texto;
			log.debug("Cortado: " + concCortado);
			j = texto.indexOf(ln);
			texto = concCortado.substring(j + ln.length());
			log.debug("texto: " + texto);
			if (texto.length() > 35) {
				cortado = false;
				i = 34;
				do {
					if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
						texto = texto.substring(0, i) + ln + texto.substring(i + 1);
						cortado = true;
					}
					i--;
				} while (!cortado);
				concCortado = concCortado.substring(0, j + ln.length()) + texto;
				log.debug("Cortado: " + concCortado);
				j = texto.indexOf(ln);
				texto = texto.substring(j + ln.length());
				log.debug("texto: " + texto);
				if (texto.length() > 35) {
					cortado = false;
					i = 34;
					do {
						if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
							texto = texto.substring(0, i) + ln + texto.substring(i + 1);
							cortado = true;
						}
						i--;
					} while (!cortado);
					i = concCortado.indexOf(ln);
					j = concCortado.indexOf(ln, i + 1);
					concCortado = concCortado.substring(0, j + ln.length()) + texto;
					log.debug("Cortado: " + concCortado);
					j = texto.indexOf(ln);
					texto = texto.substring(j + ln.length());
					log.debug("texto: " + texto);
					if (texto.length() > 35) {
						concCortado = "-1";
					}
				}
			}
		} else {
			concCortado = concepto;
		}

		return concCortado;
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitudTest) {
		this.solicitud = solicitudTest;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setMonedasT(List<SelectItem> monedasT) {
		this.monedasT = monedasT;
	}

	public List<SelectItem> getMonedasT() {
		return monedasT;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	/*
	 * public List<SelectItem> getBenefs() { return benefs; }
	 */

	public void setBenefs(List<SelectItem> benefs) {
		this.benefs = benefs;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasB(List<SelectItem> cuentasB) {
		this.cuentasB = cuentasB;
	}

	public List<CuentasBen> getListaCuentasB() {
		return listaCuentasB;
	}

	public void setListaCuentasB(List<CuentasBen> listaCuentasB) {
		this.listaCuentasB = listaCuentasB;
	}

	public List<Datosmen> getListaCampos() {
		return listaCampos;
	}

	public void setListaCampos(List<Datosmen> listaCampos) {
		this.listaCampos = listaCampos;
	}

	public void setComision(Opecomi comision) {
		this.comision = comision;
	}

	public Opecomi getComision() {
		return comision;
	}

	public void setComisiones(List<Opecomi> comisiones) {
		this.comisiones = comisiones;
	}

	public List<Opecomi> getComisiones() {
		return comisiones;
	}

	public void setComis(String[][] comis) {
		this.comis = comis;
	}

	public String[][] getComis() {
		return comis;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public void setIdCuentaB(Integer idCuentaB) {
		this.idCuentaB = idCuentaB;
	}

	public Integer getIdCuentaB() {
		return idCuentaB;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getBic1() {
		return bic1;
	}

	public void setBic1(String bic1) {
		this.bic1 = bic1;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getPlaza() {
		return plaza;
	}

	public void setPlaza(String plaza) {
		this.plaza = plaza;
	}

	public List<SelectItem> getConceptos() {
		return conceptos;
	}

	public void setConceptos(List<SelectItem> conceptos) {
		this.conceptos = conceptos;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConc() {
		return conc;
	}

	public void setConc(String conc) {
		this.conc = conc;
	}

	public String getInforma() {
		return informa;
	}

	public void setInforma(String informa) {
		this.informa = informa;
	}

	public String getAdicional() {
		return adicional;
	}

	public void setAdicional(String adicional) {
		this.adicional = adicional;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getLabel2() {
		return label2;
	}

	public void setLabel2(String label2) {
		this.label2 = label2;
	}

	public void setLabelM(String labelM) {
		this.labelM = labelM;
	}

	public String getLabelM() {
		return labelM;
	}

	public void setLabelE(String labelE) {
		this.labelE = labelE;
	}

	public String getLabelE() {
		return labelE;
	}

	public BigDecimal getMontoOrd() {
		return montoOrd;
	}

	public void setMontoOrd(BigDecimal montoOrd) {
		this.montoOrd = montoOrd;
	}

	public void setMontoEquiv(BigDecimal montoEquiv) {
		this.montoEquiv = montoEquiv;
	}

	public BigDecimal getMontoEquiv() {
		return montoEquiv;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public String getIdDescuento() {
		return idDescuento;
	}

	public void setIdDescuento(String idDescuento) {
		this.idDescuento = idDescuento;
	}

	public void setIdFijo(String idFijo) {
		this.idFijo = idFijo;
	}

	public String getIdFijo() {
		return idFijo;
	}

	public String getIdConcepto() {
		return idConcepto;
	}

	public void setIdConcepto(String idConcepto) {
		this.idConcepto = idConcepto;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public void setFact(String fact) {
		this.fact = fact;
	}

	public String getFact() {
		return fact;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public void setComiVer(Boolean comiVer) {
		this.comiVer = comiVer;
	}

	public Boolean getComiVer() {
		return comiVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setInfoVer(Boolean infoVer) {
		this.infoVer = infoVer;
	}

	public Boolean getInfoVer() {
		return infoVer;
	}

	public Boolean getFijoVer() {
		return fijoVer;
	}

	public void setFijoVer(Boolean fijoVer) {
		this.fijoVer = fijoVer;
	}

	public Boolean getFijo() {
		return fijo;
	}

	public void setFijo(Boolean fijo) {
		this.fijo = fijo;
	}

	public Boolean getFijoT() {
		return fijoT;
	}

	public void setFijoT(Boolean fijoT) {
		this.fijoT = fijoT;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public Date getFechaValor() {
		fechaValor = new Date();
		return fechaValor;
	}

	public void setFechaValor(Date fechaValor) {
		this.fechaValor = fechaValor;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + codIns + "&tipo=SW";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");
		mensaje = "";
		visible = false;		
		// if (banco != "")
		// {
		if (idConcepto != "-1") {
			if (MensSwiftUtiles.validarConcepto(concepto) > 0) {
				if ("INV".equals(idConcepto))
					concepto = "/INV/" + concepto;

				concepto = this.cortarConcepto();
				if (concepto != "-1") {
					DateTime fecha = new DateTime();
					DateTime fechaV = new DateTime(fechaValor);
					log.debug("fecha: " + fecha);
					log.debug("valor: " + fechaV);

					if ((fechaV.getDayOfMonth() >= fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear())
							|| (fechaV.getDayOfMonth() < fecha.getDayOfMonth() && fechaV.getMonthOfYear() > fecha.getMonthOfYear()))
					// if (fechaV.getDayOfMonth() > fecha.getDayOfMonth() &&
					// fechaV.getMonthOfYear() == fecha.getMonthOfYear())
					{
						solicitud.setSocCuentad(Integer.parseInt(idCuenta));
						nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentad());
						solicitud.setSocNrocuentad(nroCuenta);
						nroCuenta = "";

						if ("NO".equals(idDescuento)) {
							nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentac());
							solicitud.setSocNrocuentac(nroCuenta);
							solicitud.setSocMontoord(BigDecimal.valueOf(0));
						} else {
							solicitud.setSocMontome(montoOrd);
						}
						solicitud.setSolCodigo(idSoli);
						solicitud.setClaTipo("TE");
						solicitud.setClaEstado('I');
						// solicitud.setSocCorrelativo(sigla + "-" + corrs +
						// "-2011");
						detalle.setBenCodigo(idBenef);
						detalle.setDetCtabenef(idCuentaB);
						detalle.setDetMonto(solicitud.getSocMontome());
						detalle.setDetMontoord(solicitud.getSocMontoord());
						detalle.setMoneda(solicitud.getMoneda());
						detalle.setMonedaT(solicitud.getMonedaT());
						detalle.setDetConcepto(concepto.toUpperCase());

						log.debug("informa1:" + informa);

						String info1 = "";
						if (!StringUtils.isBlank(informa))
							info1 = informa;
						if (!StringUtils.isBlank(info1) && !StringUtils.isBlank(adicional))
							info1 = info1 + " ";
						if (!StringUtils.isBlank(adicional))
							info1 = info1 + adicional;
						log.info("info1:" + info1);

						String ln = "\r\n";
						int j = info1.lastIndexOf(ln);
						String info2 = "";
						if (j > 0)
							info2 = info1.substring(j + ln.length());
						else
							info2 = info1;
						if (info2.length() > 35) {
							Boolean cortado = false;
							String texto = info2;
							int i = 34;
							do {
								if (info2.charAt(i) == ' ' || info2.charAt(i) == '.' || info2.charAt(i) == ',') {
									texto = info2.substring(0, i) + ln + "//" + info2.substring(i + 1);
									cortado = true;
								}
								i--;
							} while (!cortado);
							if (j > 0)
								info1 = info1.substring(0, j + ln.length()) + texto;
							else
								info1 = texto;
						}
						log.debug("informa2:" + info1);
						detalle.setDetInfo(info1);

						Date date = new Date();
						long time = date.getTime();
						log.info("Creando el objeto Request para enviar al BPM");

						// parametros para request
						String id = new Long(time).toString();

						// mapa de parametros a enviar a BPM
						Map<String, Object> mapaParametros = new HashMap<String, Object>();
						mapaParametros.put("opcion", "nuevaInt");
						mapaParametros.put("solicitud", solicitud);
						mapaParametros.put("detalle", detalle);
						mapaParametros.put("fecha", fechaValor);
						mapaParametros.put("usuario", usuario);

						Map<String, Object> mapaRespuesta = ManejadorServicioBPM
								.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
						if (mapaRespuesta.containsKey("resp_msgerror")) {
							mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
							visible = true;
							return;
						}

						nroOperacion = (String) mapaRespuesta.get("nroOperacion");
						codIns = (String) mapaRespuesta.get("nroInst");

						if (!nroOperacion.equals("0000")) {
							this.botonHab = true;
							log.info("Numero de Operación asignada desde el BPM: " + nroOperacion);

							generada = true;

							this.listaCampos = new ArrayList<Datosmen>();

							String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
									+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + codIns
									+ "'";

							List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
							if (resultado1 != null) {
								for (Map<String, Object> res : resultado1) {
									String alto;
									String valor = "";
									String valor1 = (String) res.get("dam_valor");
									if (res.get("cam_codigo").equals(":32A")) {
										valor = valor1;
										valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
									}

									if (res.get("cam_codigo").equals(":33B")) {
										valor = valor1;
										valor1 = valor.substring(0, 3) + ln + valor.substring(3);
									}

									int i = StringUtils.countMatches(valor1, ln);
									i = (i + 1) * 16;
									alto = " height : " + i + "px;";

									listaCampos.add(new Datosmen((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto,
											(String) res.get("cam_nombre")));
								}

								visible = false;

							} else {
								log.info("No se pudo generar datos del mensaje - Lista Nula");
								mensaje = "No se pudo generar datos del mensaje";
								visible = true;
							}
						} else {
							log.info("No se pudo generar la operación.");
							mensaje = "No se pudo generar la operación. No existe tipo de cambio para la fecha especificada.";
							generada = false;
							visible = true;
						}
					} else {
						log.info("No se puede generar la operación con fecha anterior.");
						mensaje = "No se puede generar la operación con fecha valor anterior a la fecha actual.";
						generada = false;
						visible = true;
					}
				} else {
					this.mensaje = "El concepto de la transferencia excede la longitud permitida para este campo.";
					this.botonHab = false;
					visible = true;
				}
			} else {
				this.mensaje = "Existen caracteres no válidos en el concepto de la transferencia.";
				this.botonHab = false;
				visible = true;
			}
		} else {
			this.mensaje = "Se debe seleccionar un concepto para la transferencia.";
			this.botonHab = false;
			visible = true;
		}
		/*
		 * } else { this.mensaje =
		 * "Los datos del beneficiario no son correctos. Comun�quese con el Depto. de Operacions Cambiarias del BCB."
		 * ; this.botonHab = false; }
		 */
	}

	public Boolean getVisible() {
		return visible;
	}

	public void setVisible(Boolean visible) {
		this.visible = visible;
	}

	public CuentasBen getCuentaBSelected() {
		return cuentaBSelected;
	}

	public void setCuentaBSelected(CuentasBen cuentaBSelected) {
		this.cuentaBSelected = cuentaBSelected;
	}

}
