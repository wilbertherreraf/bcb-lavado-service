/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;

import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.SocBolsinS;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaBolsinPController extends BaseBeanController {

	private SocBolsin solicitudB = new SocBolsin();
	private SocBolsinS solicitudBS = new SocBolsinS();
	private List<SocBolsinS> solicitudes;
	private List<SocBolsin> listaSoli;
	private String f1 = "";
	private Boolean generada = true;

	private String urlReporte;
	private String urlReporteS;

	private Logger log = Logger.getLogger(ListaBolsinPController.class);

	@PostConstruct
	public void init() {
		try {
			recuperarVisit();
			recuperarSolicitudes();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		}
	}

	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SocBolsinS>();
		this.listaSoli = new ArrayList<SocBolsin>();

		solicitudes = Servicios.getSocBolsinSList("'0'", null, null);
		listaSoli = Servicios.getSocBolsinList("'0'", null, null);
	}

	public SocBolsin getSolicitudB() {
		return solicitudB;
	}

	public void setSolicitudB(SocBolsin solicitudB) {
		this.solicitudB = solicitudB;
	}

	public SocBolsinS getSolicitudBS() {
		return solicitudBS;
	}

	public void setSolicitudBS(SocBolsinS solicitudBS) {
		this.solicitudBS = solicitudBS;
	}

	public List<SocBolsinS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SocBolsinS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<SocBolsin> getListaSoli() {
		return listaSoli;
	}

	public void setListaSoli(List<SocBolsin> listaSoli) {
		this.listaSoli = listaSoli;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=0&tipo=BB";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	public void setUrlReporteS(String urlReporteS) {
		this.urlReporteS = urlReporteS;
	}

	public String getUrlReporteS() {
		DateTime fecha = new DateTime();
		Integer i1, i2, i3;

		i1 = fecha.getDayOfMonth();
		i2 = fecha.getMonthOfYear();
		i3 = fecha.getYear();
		f1 = i3.toString() + "-" + i2.toString() + "-" + i1.toString();
		urlReporteS = getRaiz() + "reporte?cod=0&tipo=SB" + "&fecha=" + f1;
		log.info("rr:" + "SB" + ",fecha:" + f1);
		return urlReporteS;
	}

	// whf vd2
	public String getUrlReporteVentaDir() {
		urlReporte = getRaiz() + "reporte?cod=0&tipo=VD";
		return urlReporte;
	}
}
