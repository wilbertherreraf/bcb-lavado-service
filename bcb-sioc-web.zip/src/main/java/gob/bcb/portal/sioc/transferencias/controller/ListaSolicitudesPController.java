/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaSolicitudesPController {
  private SolicitudesS solicitudS = new SolicitudesS();
  
  private List<SolicitudesS> solicitudes;

  private String codSol = "";
  private String tipo = "";
  
  private String urlReporte;
  
  private Logger log = Logger.getLogger(ListaSolicitudesPController.class);

  public ListaSolicitudesPController() { 
    this.recuperarSolicitudes();
  }

  private void recuperarSolicitudes() {
    DateTime fecha = new DateTime();
    this.solicitudes = new ArrayList<SolicitudesS>();
    
    String query = " select s.*, ss.sol_persona, o.ope_fecha" 
        + " from soc_solicitudes s, soc_solicitante ss, soc_operaciones o"
        + " where s.sol_codigo = ss.sol_codigo"
        + " and s.soc_correlativo = o.soc_correlativo"
        + " and s.cla_tipo like 'TC%'"
        + " and s.cla_estado = 'O'";
    
    List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
    if (resultado.size() > 0)
    {
      for (Map<String, Object>res : resultado)
      {
        //
        solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"),
          (String) res.get("sol_persona"), (String) res.get("cla_tipo"), (String) res.get("moneda"),
          'R', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (String) res.get("soc_correlativo"), 
          (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");

            solicitudS.setTipo("TRANSFERENCIA CUENTA A CUENTA");

        DateTime fechaV = new DateTime(res.get("ope_fecha"));
        if (fechaV.getDayOfMonth() == fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear() && fechaV.getYear() == fecha.getYear())
        {
          solicitudes.add(solicitudS);
        }
      }
    }
    else
    {
      log.info("Lista Nula");
    }
  }

  public void verSolicitud(ActionEvent event) {
    HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent()
        .getParent();
    int fila = dataTable.getRowIndex();
    this.solicitudS = this.solicitudes.get(fila);
    codSol = solicitudS.getSocCodigo();
    tipo = solicitudS.getClaTipo();
    
    log.info("cod:" + codSol);
    log.info("tipo:" + tipo);
  }

  public SolicitudesS getSolicitudS() {
    return solicitudS;
  }

  public void setSolicitudS(SolicitudesS solicitudS) {
    this.solicitudS = solicitudS;
  }

  public List<SolicitudesS> getSolicitudes() {
    return solicitudes;
  }

  public void setSolicitudes(List<SolicitudesS> solicitudes) {
    this.solicitudes = solicitudes;
  }
  
  private static String getRaiz() {
    HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    String url = request.getRequestURL().toString();
    String direccionRaiz = null;
    if (url.indexOf("/faces") > 0)
      direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
    else
      direccionRaiz = url;
    return direccionRaiz;
  }
  
  public String getUrlReporte() {
    
    urlReporte = getRaiz() + "reporte?cod=" + codSol + "&tipo=" + tipo;
    return urlReporte;
  }

  public void setUrlReporte(String urlReporte) {
    this.urlReporte = urlReporte;
  }
  
}
