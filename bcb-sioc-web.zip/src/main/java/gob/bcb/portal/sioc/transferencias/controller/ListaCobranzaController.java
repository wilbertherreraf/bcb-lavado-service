/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaCobranzaController extends BaseBeanController {
	private List<SocOperaciones> cheques;
	private SocDetallesope detalleO;
	private SocOperaciones operacion;
	private String solicitante = "";
	private String cuentaD = "";
	private String cuentaC = "";
	private String concepto = "CONFIRMACION DE COBRANZA SEGUN REPORTE DEL CITIBANK DE LA FECHA A FAVOR DE ";
	private String mensaje = "";
	private String usuario;
	private Boolean botonHab = true;
	private Boolean cuentaHab = false;

	private Logger log = Logger.getLogger(ListaCobranzaController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	public ListaCobranzaController() {

		recuperarVisit();
		usuario = getVisit().getUsuarioSession().getLogin();

		this.recuperarCheques();
	}

	private void recuperarCheques() {
		this.cheques = new ArrayList<SocOperaciones>();

		String query = " select o.* " + " from soc_operaciones o " + " where o.cla_estado = 'A' " + " and o.cla_operacion = 'CE'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());

				operacion = new SocOperaciones((String) res.get("ope_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_operacion"),
						(Date) res.get("ope_fecha"), (BigDecimal) res.get("ope_montome"), (BigDecimal) res.get("ope_montomn"),
						(Integer) res.get("moneda"), (Integer) res.get("ope_ctaoperacion"), (Integer) res.get("ope_ctacomision"),
						(String) res.get("usr_codigo"), (Date) res.get("fecha_hora"), (String) res.get("estacion"), 'A',
						(String) res.get("ope_nrocuentac"), (String) res.get("soc_correlativo"), (String) res.get("ope_nrocuentad"));
				cheques.add(operacion);
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void verCobranza(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		operacion = this.cheques.get(fila);

		solicitante = Servicios.getSolicitante(operacion.getSolCodigo().trim());

		String query = " select * " + " from soc_detallesope " + " where ope_codigo = '" + operacion.getOpeCodigo() + "'" + " and det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());

				detalleO = new SocDetallesope(new SocDetallesopeId((String) res.get("ope_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ins_codigo"), (String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"),
						(Integer) res.get("moneda"), (String) res.get("det_ctabenef"), (String) res.get("det_concepto"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("det_info"), (String) res.get("det_facturas"));
			}
		} else {
			log.info("Lista Nula");
		}

		if (operacion.getOpeCtaoperacion() != null) {
			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ operacion.getOpeCtaoperacion() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {

					setCuentaD(res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento"));
				}
			} else {
				log.info("Lista Nula");
			}
		}

		if (operacion.getOpeCtacomision() != null) {
			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ operacion.getOpeCtacomision() + "'";

			List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
			if (resultadoC.size() == 1) {
				for (Map<String, Object> res : resultadoC) {

					setCuentaC(res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento"));
				}
			} else {
				log.info("Lista Nula");
			}
		}

	}

	/**
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		detalleO.setDetConcepto(concepto.toUpperCase());

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "cobrreg");
		mapaParametros.put("operacion", operacion);
		mapaParametros.put("detalle", detalleO);
		mapaParametros.put("usuario", usuario);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String nroOpe = (String) mapaRespuesta.get("nroOperacion");
		log.info("Numero de Operacion: " + nroOpe);

		if (!nroOpe.equals("0000")) {
			this.mensaje = "La operación se generó correctamente con el número " + nroOpe + ".";
			this.botonHab = true;
		} else {
			this.mensaje = "Se produjo un error al generar la operación.";
			this.botonHab = true;
		}
	}

	public void setCheques(List<SocOperaciones> cheques) {
		this.cheques = cheques;
	}

	public List<SocOperaciones> getCheques() {
		return cheques;
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public void setDetalleO(SocDetallesope detalleO) {
		this.detalleO = detalleO;
	}

	public SocDetallesope getDetalleO() {
		return detalleO;
	}

	public void setSolicitante(String solicitante) {
		this.solicitante = solicitante;
	}

	public String getSolicitante() {
		return solicitante;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConcepto() {
		return concepto;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

}
