/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.SocBolsinS;
import gob.bcb.portal.sioc.view.SolicitudBean;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;

import org.apache.log4j.Logger;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaBolsinController extends BaseBeanController {
	private BigDecimal tcAnterior;
	private SocBolsin solicitudB = new SocBolsin();
	private SocBolsinS solicitudBS = new SocBolsinS();
	private List<SocBolsinS> solicitudes;
	private List<SocBolsin> listaSoli;

	private Boolean confirmarTC = false;
	private String mensaje = "";
	// whf 20120611 se agrega control de ingreso de tipo de cambio
	// base0 y base deben ser identicos para continuar con el proceso
	private BigDecimal base0 = BigDecimal.valueOf(0);
	private BigDecimal base = BigDecimal.valueOf(0);
	private BigDecimal compra = BigDecimal.valueOf(0);
	private BigDecimal venta = BigDecimal.valueOf(0);

	// parametros para panel de Confirmacion
	private String tituloConfirmacion;
	private String mensajeConfirmacion;

	private Logger log = Logger.getLogger(ListaBolsinController.class);
	private SolicitudBean solicitudBean = new SolicitudBean();
	private String sIOCWEB_TIPOPERACION;

	@PostConstruct
	public void init() {
		recuperarVisit();
		solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
		String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
		String ip = getVisit().getAddress();

		sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
		log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin() + " ==> codEnt: "
				+ codEnt + " ip " + ip);

		this.recuperarSolicitudes();
		this.obtenerTC();
		// mensajes de confirmacion
		tituloConfirmacion = "MENSAJE";
		mensajeConfirmacion = "ESTA SEGURO DE GUARDAR!!!";
	}

	@SuppressWarnings("unchecked")
	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SocBolsinS>();
		this.listaSoli = new ArrayList<SocBolsin>();

		solicitudes = Servicios.getSocBolsinSList("'0'", new Date(), null);
		listaSoli = Servicios.getSocBolsinList("'0'", new Date(), null);
	}

	public void montoChanged(ValueChangeEvent event) {
		log.info("enter changed");
		String montoS = event.getNewValue().toString();
		log.info("montoS:" + montoS);
		Double montoD = Double.parseDouble(montoS);
		log.info("montoD:" + montoD);

		venta = BigDecimal.valueOf(montoD);
		Double diff_cv = Double.valueOf(Servicios.getParam("@diffcv"));
		compra = venta.subtract(BigDecimal.valueOf(diff_cv));
	}

	public void eventoGenerarBtn(ActionEvent action) {
		if (base0 == null || base0.compareTo(BigDecimal.ZERO) == 0 || base == null || base.compareTo(BigDecimal.ZERO) == 0) {
			confirmarTC = false;
		}

		if (base.compareTo(base0) == 0) {
			confirmarTC = true;
		}

		FacesContext fc = FacesContext.getCurrentInstance();
		if (!confirmarTC) {
			mensaje = "Error: el valor de Tipo de Cambio Base con el valor de Tipo de Cambio Base CONFIRMADO SON DIFERENTES";
			fc.addMessage(null, new FacesMessage(mensaje));
			// throw new
			// RuntimeException("No esta soportado que se suba en memoria los archivos");
			return;

		}

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "subasta");

		// enviando objeto del formulario
		mapaParametros.put("solicitudes", listaSoli);
		mapaParametros.put("base", this.base);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		String respMsgerror = (String) mapaRespuesta.get("resp_msgerror");
		if (estado.equals("-1")) {
			mensaje = "Error: Ocurrió un error al procesar la operación " + respMsgerror;
			return;
		}

		String query = "select venta, compra " + "from soc_cambio " + "where cla_estado = 1";

		List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado2) {
			//
			venta = (BigDecimal) res.get("venta");
			compra = (BigDecimal) res.get("compra");
		}

		this.solicitudes = new ArrayList<SocBolsinS>();
		solicitudes = Servicios.getSocBolsinSList("'B','0','1','5','2','3'", new Date(), null, "'G','E'");
//		query = " select s.*, ss.sol_persona " + " from soc_bolsin s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
//				+ " and s.cla_estado <> '0' and s.cla_estado <> '9' and s.cla_estado <> 'Z' and s.cla_estado <> '5' and s.cla_tipsolic in ('G','E') ";
//
//		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
//		for (Map<String, Object> res : resultado) {
//
//			solicitudBS = new SocBolsinS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
//					(Date) res.get("fecha"), (String) res.get("corr"), (Integer) res.get("seq"), (BigDecimal) res.get("cotiz"),
//					(BigDecimal) res.get("montosol"), (BigDecimal) res.get("montoadj"), (String) res.get("cla_estado"), (String) res.get("benef"), "");
//
//			if (solicitudBS.getClaEstado().equals("1"))
//				solicitudBS.setEstado("ADJUDICADO");
//			if (solicitudBS.getClaEstado().equals("2"))
//				solicitudBS.setEstado("PRORRATEADO");
//			if (solicitudBS.getClaEstado().equals("3"))
//				solicitudBS.setEstado("RECHAZADO POR T.C.");
//			solicitudes.add(solicitudBS);
//		}

		log.info("Estado devuelto: " + estado);
		mensaje = "La subasta de la sesión del bolsín se procesó satisfactoriamente.";
	}

	// public void eventoPublicarBtn() {
	public void eventoPublicarBtn(ActionEvent action) {
		log.info("Publicando tc: ");

		Date fecha = new Date();

		// parametros para request hola mundo
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "publicar");

		// enviando objeto del formulario
		mapaParametros.put("fecha", fecha);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		String respMsgerror = (String) mapaRespuesta.get("resp_msgerror");
		log.info("Estado devuelto: " + estado);
		if ("-1".equals(estado)) {
			mensaje = "Se produjo un error en la operación.";
			if (respMsgerror != null)
				mensaje = "Se produjo un error: " + respMsgerror;
		} else {
			mensaje = "El tipo de cambio se publicó satisfactoriamente.";
		}
	}

	public void obtenerTC() {
		log.info("Obteniendo tc: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "obtenerTC");

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}
		this.tcAnterior = (BigDecimal) mapaRespuesta.get("tc");
		log.info("TC anterior: " + this.tcAnterior);
	}

	public String antesGuardar() {
		mensajeConfirmacion = "El Tipo de Cambio Anterior es " + (this.tcAnterior).setScale(2, RoundingMode.HALF_UP)
				+ ", el Tipo de Cambio Ingresado es " + (this.base).setScale(2, RoundingMode.HALF_UP)
				+ ". +Esta seguro de publicar Tipo de Cambio Ingresado?";
		return "";
	}

	public SocBolsin getSolicitudB() {
		return solicitudB;
	}

	public void setSolicitudB(SocBolsin solicitudB) {
		this.solicitudB = solicitudB;
	}

	public SocBolsinS getSolicitudBS() {
		return solicitudBS;
	}

	public void setSolicitudBS(SocBolsinS solicitudBS) {
		this.solicitudBS = solicitudBS;
	}

	public List<SocBolsinS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SocBolsinS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<SocBolsin> getListaSoli() {
		return listaSoli;
	}

	public void setListaSoli(List<SocBolsin> listaSoli) {
		this.listaSoli = listaSoli;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void setBase(BigDecimal base) {
		this.base = base;
	}

	public BigDecimal getBase() {
		return base;
	}

	public void setCompra(BigDecimal compra) {
		this.compra = compra;
	}

	public BigDecimal getCompra() {
		return compra;
	}

	public void setVenta(BigDecimal venta) {
		this.venta = venta;
	}

	public BigDecimal getVenta() {
		return venta;
	}

	public void setBase0(BigDecimal base0) {
		this.base0 = base0;
	}

	public BigDecimal getBase0() {
		return base0;
	}

	public void setConfirmarTC(Boolean confirmarTC) {
		this.confirmarTC = confirmarTC;
	}

	public Boolean getConfirmarTC() {
		return confirmarTC;
	}

	/**
	 * @return the tcAnterior
	 */
	public BigDecimal getTcAnterior() {
		return tcAnterior;
	}

	/**
	 * @param tcAnterior
	 *            the tcAnterior to set
	 */
	public void setTcAnterior(BigDecimal tcAnterior) {
		this.tcAnterior = tcAnterior;
	}

	/**
	 * @return the tituloConfirmacion
	 */
	public String getTituloConfirmacion() {
		return tituloConfirmacion;
	}

	/**
	 * @param tituloConfirmacion
	 *            the tituloConfirmacion to set
	 */
	public void setTituloConfirmacion(String tituloConfirmacion) {
		this.tituloConfirmacion = tituloConfirmacion;
	}

	/**
	 * @return the mensajeConfirmacion
	 */
	public String getMensajeConfirmacion() {
		return mensajeConfirmacion;
	}

	/**
	 * @param mensajeConfirmacion
	 *            the mensajeConfirmacion to set
	 */
	public void setMensajeConfirmacion(String mensajeConfirmacion) {
		this.mensajeConfirmacion = mensajeConfirmacion;
	}

}
