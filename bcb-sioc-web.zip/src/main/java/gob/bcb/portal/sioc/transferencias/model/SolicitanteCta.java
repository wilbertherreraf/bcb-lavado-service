package gob.bcb.portal.sioc.transferencias.model;

public class SolicitanteCta {
	private String solCodigo;
	private String solCodIfa;
	private String solCodCta;
	private String solCodMon;
}
