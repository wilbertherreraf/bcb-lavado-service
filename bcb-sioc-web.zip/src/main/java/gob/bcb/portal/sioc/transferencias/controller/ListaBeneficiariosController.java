/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocPlazas;
import gob.bcb.bpm.pruebaCU.SocSolbenefs;
import gob.bcb.bpm.pruebaCU.SocSolbenefsId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Soli;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.model.SwfPersonacta;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author WHERRERA
 * 
 */
public class ListaBeneficiariosController extends BaseBeanController {
	private Logger log = Logger.getLogger(ListaBeneficiariosController.class);

	private SocBenefs benefi = new SocBenefs();
	private List<CuentasBen> beneficiarios = new ArrayList<CuentasBen>();
	private List<CuentasBen> cuentasBenLista = new ArrayList<CuentasBen>();
	private Soli solic = new Soli();
	private List<Soli> solis = new ArrayList<Soli>();
	private SocCuentas cta = new SocCuentas();
	private SocSolbenefs socSolbenefSelected = new SocSolbenefs();
	private CuentasBen cuentasBenSearch = new CuentasBen();
	private List<SelectItem> bancos = new ArrayList<SelectItem>();
	private List<SelectItem> plazas = new ArrayList<SelectItem>();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> esquemas = new ArrayList<SelectItem>();
	private List<SelectItem> solicitantes = new ArrayList<SelectItem>();
	private List<SelectItem> swfPersonactaBcoBenItems = new ArrayList<SelectItem>();
	private List<SelectItem> swfPersonactaBcoInterItems = new ArrayList<SelectItem>();
	private List<SwfPersonacta> swfPersonactaLista = new ArrayList<SwfPersonacta>();
	private List<BancoPlaza> plazasLista = new ArrayList<BancoPlaza>();
	private BancoPlaza bancoPlazaSelected = new BancoPlaza();

	private String buscarTexto = "";
	private String buscarTextoCta = "";
	private String mensaje = "";
	private boolean modifica = false;
	// private SolicitudBean solicitudBean = new SolicitudBean();
	private String sIOCWEB_TIPOPERACION;

	@PostConstruct
	public void init() {
		recuperarVisit();
		getSolicitudBean().setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
		String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
		String ip = getVisit().getAddress();

		sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
		log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin() + " ==> codEnt: "
				+ codEnt + " ip " + ip);

		SocSolbenefsId socSolbenefsId = new SocSolbenefsId();
		socSolbenefSelected.setId(socSolbenefsId);
		recuperarDatos();

	}

	private void recuperarDatos() {
		if (sIOCWEB_TIPOPERACION.equals("VER_DETBENEFICIARIO")) {
			String puedeModificar = (String) getVisit().getParametro("ACCION_BENEF");
			modifica = (!StringUtils.isBlank(puedeModificar) && (puedeModificar.equalsIgnoreCase("UPD_BENEF") || puedeModificar
					.equalsIgnoreCase("NEW_BENEF")));
			String SIOCWEB_CODBENEF = (String) getVisit().getParametro("SIOCWEB_CODBENEF");
			if (!StringUtils.isBlank(SIOCWEB_CODBENEF)) {
				recuperarBenef(SIOCWEB_CODBENEF);
			}
		}
		List<SocSolicitante> socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");
		
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			solicitantes.add(new SelectItem(socSolicitante.getSolCodigo().trim() + "", socSolicitante.getSolPersona()));
		}
		bancos.clear();
		List<BancoPlaza> bancosLista = getSolicitudBean().getSocBancosDao().getBancosPlazas(null, null);
		for (BancoPlaza cuentasS : bancosLista) {
			bancos.add(new SelectItem(cuentasS.getBcoCodigo(), cuentasS.getBcoNombre() + " [" + cuentasS.getPlaNombre() + "]" + "("
					+ cuentasS.getPlaBic() + ") " + cuentasS.getBcoCodigo()));
		}

		List<Integer> monedaList = new ArrayList<Integer>();
		monedaList.add(Constants.COD_MONEDA_BS);
		List<GenMoneda> genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedasLista(monedaList, false);
		
		for (GenMoneda genMoneda : genMonedaLista) {
			monedas.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}
		
		esquemas = llenarEsquemas();
	}

	private void recuperarCtasBancoBen() {
		swfPersonactaLista = getSolicitudBean().getSwfPersonactaBean().buscarCtasPersona(cta.getBcoCodigo(), null, null, null, null, null, null);

		plazasLista = new ArrayList<BancoPlaza>();
		swfPersonactaBcoBenItems = new ArrayList<SelectItem>();

		for (SwfPersonacta swfPersonacta : swfPersonactaLista) {
			BancoPlaza bancoPlaza = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(swfPersonacta.getId().getPecCodinst());

			bancoPlaza.setPlaNrocuenta(swfPersonacta.getId().getPecNrocta());
			bancoPlaza.setPecEstadocta(swfPersonacta.getPecEstadocta());

			plazasLista.add(bancoPlaza);

			swfPersonactaBcoBenItems
					.add(new SelectItem(bancoPlaza.getPlaNrocuenta(), bancoPlaza.getPlaNrocuenta() + ": " + bancoPlaza.getBcoNombre()));
		}

	}

	private void recuperarCtasBancoInterBen() {
		Map<String, BancoPlaza> bancoPlazaMapaCrtl = new HashMap<String, BancoPlaza>();
		
		plazasLista = new ArrayList<BancoPlaza>();
		swfPersonactaBcoInterItems = new ArrayList<SelectItem>();

		List<BancoPlaza> bancosLista = getSolicitudBean().getSocBancosDao().getBancosPlazas(null, null);
		for (BancoPlaza cuentasS : bancosLista) {
			if (!StringUtils.isBlank(cuentasS.getPlaBic())) {
				if (!bancoPlazaMapaCrtl.containsKey(cuentasS.getPlaBic())) {
					swfPersonactaBcoInterItems.add(new SelectItem(cuentasS.getBcoCodigo(), cuentasS.getBcoNombre() 
							+ "(" + cuentasS.getPlaBic() + ") " + cuentasS.getBcoCodigo()));
					
					bancoPlazaMapaCrtl.put(cuentasS.getPlaBic(), cuentasS); 
				}
			}
		}
	}

	public void botonBuscar(ActionEvent actionEvent) {
		buscar();
	}

	public void verBenef(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		benefi = (SocBenefs) SerializationUtils.clone(this.beneficiarios.get(fila));
		recuperarBenef(benefi.getBenCodigo());
	}

	public void recuperarBenef(String benCodigo) {
		log.info("Recuperar Benef " + benCodigo);
		solis.clear();
		benefi = getSolicitudBean().getSocBenefsDao().getBenefsByBenCodigo(benCodigo);
		List<SocSolbenefs> socSolbenefsLista = getSolicitudBean().getSocSolbenefsDao().getSocSolbenefsByCodigo(null, benCodigo);
		for (SocSolbenefs socSolbenefs : socSolbenefsLista) {
			SocSolicitante socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socSolbenefs.getId().getSolCodigo());
			solic = new Soli(socSolbenefs.getId().getSolCodigo(), socSolicitante.getSolPersona(), socSolbenefs.getClaVigente());
			solis.add(solic);
		}

		cuentasBenLista = getSolicitudBean().getSocBenefsDao().cuentasBenefExterior(null, benefi.getBenCodigo(), null, null, null, null, null, null,null,
				false);
	}

	public void adicionarCuenta(ActionEvent event) {
		log.info("XXX: adicionarCuenta" + benefi.getBenCodigo());
		cta = new SocCuentas();
	}

	public void editarCuenta(CuentasBen cuentasBen) {
		log.info("editando fila: " + cuentasBen.getCtaCodigo());
		cta = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());
		
		recuperarCtasBancoBen();
		recuperarCtasBancoInterBen();
		bancoPlazaSelected = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(cta.getBcoCodigo());
		if (bancoPlazaSelected == null) {
			bancoPlazaSelected = new BancoPlaza();
		}
	}

	public void companyChanged(ValueChangeEvent event) {
		log.info("(String) event.getNewValue()" + (String) event.getNewValue());
	}

	public void adicionarBenef(ActionEvent event) {
		benefi = new SocBenefs();
	}

	public void guardarBenef(ActionEvent event) {
		try {
			if (StringUtils.isBlank(benefi.getBenDireccion()) || StringUtils.isBlank(benefi.getBenPlaza())) {
				// throw new
				// RuntimeException("Datos de beneficiario requeridos");
			}
			String cod = getSolicitudBean().getSocBenefsDao().generarCodigo();
			benefi.setBenCodigo(cod);
			benefi.setClaVigente(Short.valueOf("1"));
			benefi.setEstacion(getVisit().getAddress());
			benefi.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			benefi.setFechaHora(new Date());
			getSolicitudBean().getSocBenefsDao().saveOrUpdate(benefi);

			beneficiarios.clear();
			DropDownBean dropDownBean = getVisit().getMainController();
			log.info("XXX: dropDownBean.getPagina() " + dropDownBean.getPagina());
			dropDownBean.setPagina("/Modulos/Transferencias/listaBeneficiariosDet.xhtml");
			getVisit().setParametro("SIOCWEB_CODBENEF", benefi.getBenCodigo());
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "VER_DETBENEFICIARIO");
			getVisit().setParametro("ACCION_BENEF", "UPD_BENEF");
			recuperarBenef(benefi.getBenCodigo());
			modifica = true;
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void guardarCuenta() {
		Visit visit = Visit.getVisit();
		try {
			log.info("nueva cuenta " + cta.getCtaNrocuenta());
			int cod = getSolicitudBean().getSocCuentasDao().generarCodigo();
			cta.setBenCodigo(benefi.getBenCodigo());
			cta.setEstacion(visit.getAddress());
			cta.setUsrCodigo(visit.getUsuarioSession().getLogin());
			cta.setFechaHora(new Date());

			cta.setCtaCodigo(cod);
			cta.setClaVigente(Short.valueOf("1"));
			cta.setPlaCodigo(1);
			getSolicitudBean().getSocCuentasDao().saveOrUpdate(cta);
			log.info("Se insert� el registro correctamente." + cta.getCtaCodigo());

			recuperarBenef(benefi.getBenCodigo());
		} catch (Exception e) {
			log.info("No se pudo realizar la operacion solicitada.");
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void guardarCuentaM(ActionEvent event) {
		Visit visit = Visit.getVisit();
		try {
			log.info("modificar cuenta " + cta.getCtaCodigo());
			cta.setClaVigente(Short.valueOf("1"));
			cta.setEstacion(visit.getAddress());
			cta.setUsrCodigo(visit.getUsuarioSession().getLogin());
			cta.setFechaHora(new Date());
			cta.setPlaCodigo(1);
			
			getSolicitudBean().getSocCuentasDao().saveOrUpdate(cta);
			log.info("Se modific� el registro correctamente.");

			recuperarBenef(benefi.getBenCodigo());
		} catch (Exception e) {
			log.info("No se pudo realizar la operacion solicitada.");
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void guardarSoli(ActionEvent event) {
		log.info("XXX:idSoliidSoli::: " + socSolbenefSelected.getId().getSolCodigo());
		Visit visit = Visit.getVisit();
		try {
			socSolbenefSelected.getId().setBenCodigo(benefi.getBenCodigo());
			socSolbenefSelected.setClaVigente(Short.valueOf("1"));
			socSolbenefSelected.setEstacion(visit.getAddress());
			socSolbenefSelected.setUsrCodigo(visit.getUsuarioSession().getLogin());
			socSolbenefSelected.setFechaHora(new Date());
			getSolicitudBean().getSocSolbenefsDao().saveOrUpdate(socSolbenefSelected);
			log.info("Se insert� el registro ");

			recuperarBenef(benefi.getBenCodigo());
		} catch (Exception e) {
			log.info("No se pudo realizar la operaci�n solicitada." + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void eliminarCuenta(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();

		CuentasBen cta0 = (CuentasBen) SerializationUtils.clone(this.cuentasBenLista.get(fila));
		log.info("eliminando fila: " + fila + " CtaCodigo " + cta0.getCtaCodigo());
		try {
			cta = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cta0.getCtaCodigo());
			cta.setClaVigente(Short.valueOf("0"));
			cta.setEstacion(getVisit().getAddress());
			cta.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			cta.setFechaHora(new Date());

			getSolicitudBean().getSocCuentasDao().saveOrUpdate(cta);
			log.info("Se dio de baja el registro.");

			recuperarBenef(benefi.getBenCodigo());
		} catch (Exception e) {
			log.info("No se pudo realizar la operaci�n solicitada.");
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void eliminarSoli(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("eliminando fila: " + fila);
		solic = (Soli) SerializationUtils.clone(this.solis.get(fila));

		try {
			SocSolbenefs socSolbenef = getSolicitudBean().getSocSolbenefsDao().getSocSolbenefByCodigo(solic.getSolCodigo(), benefi.getBenCodigo());
			socSolbenef.setEstacion(getVisit().getAddress());
			socSolbenef.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			socSolbenef.setFechaHora(new Date());

			socSolbenef.setClaVigente(Short.valueOf("0"));
			getSolicitudBean().getSocSolbenefsDao().saveOrUpdate(socSolbenef);
			log.info("Se dio de baja el registro. " + socSolbenef.getId().getSolCodigo());

			recuperarBenef(benefi.getBenCodigo());
		} catch (Exception e) {
			log.info("No se pudo realizar la operaci�n solicitada.");
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public List<SelectItem> getPlazas() {
		plazas.clear();

		List<SocPlazas> socPlazasLista = getSolicitudBean().getSocPlazasDao().getSocPlazasByCodigo(cta.getBcoCodigo(), null);
		for (SocPlazas socPlazas : socPlazasLista) {
			plazas.add(new SelectItem(socPlazas.getId().getPlaCodigo(), socPlazas.getPlaNombre()));
		}
		return plazas;
	}

	public void eventoGenerarBtn() {
		log.info("Guardando el solicitante: ");
		try {
			benefi.setEstacion(getVisit().getAddress());
			benefi.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			benefi.setFechaHora(new Date());
			getSolicitudBean().getSocBenefsDao().saveOrUpdate(benefi);

			log.info("Se modific� el registro correctamente.");
			recuperarBenef(benefi.getBenCodigo());
		} catch (Exception e) {
			log.info("No se pudo realizar la operacion solicitada.");
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void buscar() {
		beneficiarios.clear();
		String query = "";
		query = "select b.* ";
		query = query.concat("from soc_benefs b ");
		query = query.concat("where length(b.ben_nombre) > 1 ");

		if (!StringUtils.isBlank(cuentasBenSearch.getBenNombre())) {
			query = query.concat("and upper(b.ben_nombre) like '%" + cuentasBenSearch.getBenNombre().toUpperCase() + "%' ");
		}
		if (!StringUtils.isBlank(cuentasBenSearch.getCtaNroCuenta())) {
			query = query.concat("and exists (select 1 from soc_cuentas c where c.ben_codigo = b.ben_codigo and upper(c.cta_nrocuenta) like '%"
					+ cuentasBenSearch.getCtaNroCuenta().toUpperCase() + "%') ");
		}

		if (!StringUtils.isBlank(cuentasBenSearch.getNit())) {
			query = query.concat("and exists (select 1 from soc_solbenefs sb where sb.ben_codigo = b.ben_codigo and sb.sol_codigo = '"
					+ cuentasBenSearch.getNit() + "') ");
		}

		if (!StringUtils.isBlank(cuentasBenSearch.getBcoCodigo())) {
			query = query
					.concat("and exists (select 1 from soc_cuentas c, soc_plazas p where c.bco_codigo = p.bco_codigo and c.ben_codigo = b.ben_codigo and p.bco_codigo = '"
							+ cuentasBenSearch.getBcoCodigo() + "') ");
		}
		if (!StringUtils.isBlank(cuentasBenSearch.getPlaIntermediario())) {
			query = query
					.concat("and exists (select 1 from soc_cuentas c, soc_plazas p where c.bco_codigo = p.bco_codigo and c.ben_codigo = b.ben_codigo and p.pla_intermediario = '"
							+ cuentasBenSearch.getPlaIntermediario() + "') ");
		}
		if (!StringUtils.isBlank(cuentasBenSearch.getClaEsquema())) {
			query = query.concat("and exists (select 1 from soc_cuentas c where c.ben_codigo = b.ben_codigo and c.cla_esquema = '"
					+ cuentasBenSearch.getClaEsquema() + "') ");
		}
		query = query.concat("order by b.ben_nombre ");

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			CuentasBen benefi0 = new CuentasBen();
			benefi0.setBenCodigo((String) res.get("ben_codigo"));
			benefi0.setBenDireccion((String) res.get("ben_direccion"));
			benefi0.setBenPlaza((String) res.get("ben_plaza"));
			benefi0.setBenNombre((String) res.get("ben_nombre"));
			benefi0.setBenDireccion((String) res.get("ben_direccion"));
			benefi0.setBenPlaza((String) res.get("ben_plaza"));
			beneficiarios.add(benefi0);
		}
	}

	public void bancoBenefChanged(ActionEvent event) {
		recuperarCtasBancoBen();
		recuperarCtasBancoInterBen();
		bancoPlazaSelected = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(cta.getBcoCodigo());
		if (bancoPlazaSelected == null) {
			bancoPlazaSelected = new BancoPlaza();
		}

	}

	public void seleccionarSol(ActionEvent event) {

	}

	public void setBenefi(SocBenefs benefi) {
		this.benefi = benefi;
	}

	public SocBenefs getBenefi() {
		return benefi;
	}

	public void setSolic(Soli solic) {
		this.solic = solic;
	}

	public Soli getSolic() {
		return solic;
	}

	public void setSolis(List<Soli> solis) {
		this.solis = solis;
	}

	public List<Soli> getSolis() {
		return solis;
	}

	public void setCta(SocCuentas cta) {
		this.cta = cta;
	}

	public SocCuentas getCta() {
		return cta;
	}

	public List<SelectItem> getBancos() {
		return bancos;
	}

	public void setBancos(List<SelectItem> bancos) {
		this.bancos = bancos;
	}

	public void setPlazas(List<SelectItem> plazas) {
		this.plazas = plazas;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public List<SelectItem> getEsquemas() {
		return esquemas;
	}

	public void setEsquemas(List<SelectItem> esquemas) {
		this.esquemas = esquemas;
	}

	public List<SelectItem> getSolicitantes() {
		return solicitantes;
	}

	public void setSolicitantes(List<SelectItem> solicitantes) {
		this.solicitantes = solicitantes;
	}

	public void setBuscarTexto(String buscarTexto) {
		this.buscarTexto = buscarTexto;
	}

	public String getBuscarTexto() {
		return buscarTexto;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setSocSolbenefSelected(SocSolbenefs socSolbenefSelected) {
		this.socSolbenefSelected = socSolbenefSelected;
	}

	public SocSolbenefs getSocSolbenefSelected() {
		return socSolbenefSelected;
	}

	public void setBuscarTextoCta(String buscarTextoCta) {
		this.buscarTextoCta = buscarTextoCta;
	}

	public String getBuscarTextoCta() {
		return buscarTextoCta;
	}

	public boolean isModifica() {
		return modifica;
	}

	public void setModifica(boolean modifica) {
		this.modifica = modifica;
	}

	public CuentasBen getCuentasBenSearch() {
		return cuentasBenSearch;
	}

	public void setCuentasBenSearch(CuentasBen cuentasBenSearch) {
		this.cuentasBenSearch = cuentasBenSearch;
	}

	public List<CuentasBen> getBeneficiarios() {
		return beneficiarios;
	}

	public void setBeneficiarios(List<CuentasBen> beneficiarios) {
		this.beneficiarios = beneficiarios;
	}

	public List<CuentasBen> getCuentasBenLista() {
		return cuentasBenLista;
	}

	public void setCuentasBenLista(List<CuentasBen> cuentasBenLista) {
		this.cuentasBenLista = cuentasBenLista;
	}

	public List<SwfPersonacta> getSwfPersonactaLista() {
		return swfPersonactaLista;
	}

	public void setSwfPersonactaLista(List<SwfPersonacta> swfPersonactaLista) {
		this.swfPersonactaLista = swfPersonactaLista;
	}

	public List<SelectItem> getSwfPersonactaBcoBenItems() {
		return swfPersonactaBcoBenItems;
	}

	public void setSwfPersonactaBcoBenItems(List<SelectItem> swfPersonactaBcoBenItems) {
		this.swfPersonactaBcoBenItems = swfPersonactaBcoBenItems;
	}

	public List<SelectItem> getSwfPersonactaBcoInterItems() {
		return swfPersonactaBcoInterItems;
	}

	public void setSwfPersonactaBcoInterItems(List<SelectItem> swfPersonactaBcoInterItems) {
		this.swfPersonactaBcoInterItems = swfPersonactaBcoInterItems;
	}

	public BancoPlaza getBancoPlazaSelected() {
		return bancoPlazaSelected;
	}

	public void setBancoPlazaSelected(BancoPlaza bancoPlazaSelected) {
		this.bancoPlazaSelected = bancoPlazaSelected;
	}
}
