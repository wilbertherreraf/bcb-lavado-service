package gob.bcb.portal.sioc.config;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

public class Constants {
	private static Logger log = Logger.getLogger(Constants.class);	
	public static final String SESSION_KEY_USER = "sessionScope.visit";
	public static final String INIT_PATH_HOME = "oiosaml-j.home";
	public static final String SUCCESS = "Success";
	// asignacion de valores a las constantes (spring).
	private static String urlBroker;
	private String nombreQueueServicio;
	private String servidor;
	public Constants() {
		log.info("creando contansts ...");
	}
	private static Map<String, String> paramsSystem = new ConcurrentHashMap<String, String>();
	static{
		setParamsSystem("bpmPruebaCU", "BCB.SUSTANTIVO.BPM.SIOC.QUEUE");
		setParamsSystem("sioc", "BCB.SUSTANTIVO.BPM.SIOC.QUEUE");
		setParamsSystem("portiaQueue", "BCB.SUSTANTIVO.SERVICIOS.SIOCPORTIASWIFT.QUEUE");
		setParamsSystem("bdwebQueue", "BCB.SUSTANTIVO.SERVICIOS.SIOCWEB.QUEUE");
		setParamsSystem("bolsinQueue", "BCB.SUSTANTIVO.SERVICIOS.SIOCBOLSIN.QUEUE");		
	}

	public static void setParamsSystem(String key, String value) {
		if (paramsSystem == null)
			paramsSystem = new ConcurrentHashMap<String, String>();
		getParamsSystem().put(key, value);
	}

	public static Map<String, String> getParamsSystem() {
		return paramsSystem;
	}

	public static void setUrlBroker(String urlBroker) {
		Constants.urlBroker = urlBroker;
	}

	public static String getUrlBroker() {
		return urlBroker;
	}
	public String returnUrlBroker() {
		log.info("returnUrlBroker ..." + Constants.urlBroker);		
		return Constants.urlBroker;
	}	
}
