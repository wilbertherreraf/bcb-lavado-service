package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

public class GenMonedasController extends BaseBeanController {
	private Logger log = Logger.getLogger(GenMonedasController.class);
	private GenMoneda socHorarioSelected = new GenMoneda();
	private List<GenMoneda> listaHorarios = new ArrayList<GenMoneda>();
	private List<SelectItem> monedaItems = new ArrayList<SelectItem>();

	@PostConstruct
	public void init() {
		log.info("postcontructor en: " + this.getClass().getName());
		recuperarVisit();
		recuperarDatos();
	}

	private void recuperarDatos() {
		listaHorarios = getSolicitudBean().getGenMonedaDao().getMonedas();
	}

	public void editar(GenMoneda genMonedaSel) {
		log.info("editando fila: " + genMonedaSel.getCodMoneda());
		socHorarioSelected = getSolicitudBean().getGenMonedaDao().findByCodMoneda(genMonedaSel.getCodMoneda());
	}

	public void nuevoRegistro(ActionEvent event) {
		log.info("antes de insertaaar : ");
		socHorarioSelected = new GenMoneda();
	}

	public void guardar(GenMoneda genMoneda) {
		try {
			log.info("nuevito registro ." + genMoneda.getCodMoneda());
			genMoneda.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			genMoneda.setEstacion(getVisit().getAddress());
			
			getSolicitudBean().getGenMonedaDao().saveOrUpdate(genMoneda);

			recuperarDatos();
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void guardarRegistro(ActionEvent event) {
		guardar(socHorarioSelected);

	}

	public GenMoneda getSocHorarioSelected() {
		return socHorarioSelected;
	}

	public void setSocHorarioSelected(GenMoneda socHorarioSelected) {
		this.socHorarioSelected = socHorarioSelected;
	}

	public List<GenMoneda> getListaHorarios() {
		return listaHorarios;
	}

	public void setListaHorarios(List<GenMoneda> listaHorarios) {
		this.listaHorarios = listaHorarios;
	}

	public List<SelectItem> getMonedaItems() {
		return monedaItems;
	}

	public void setMonedaItems(List<SelectItem> monedaItems) {
		this.monedaItems = monedaItems;
	}

	private void monedasListas() {
		monedaItems = new ArrayList<SelectItem>();
		List<Integer> monedaList = new ArrayList<Integer>();
		monedaList.add(Constants.COD_MONEDA_BS);
		List<GenMoneda> genMonedaLista = new ArrayList<GenMoneda>();
		genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedasLista(monedaList, false);

		for (GenMoneda genMoneda : genMonedaLista) {
			monedaItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}
	}

}
