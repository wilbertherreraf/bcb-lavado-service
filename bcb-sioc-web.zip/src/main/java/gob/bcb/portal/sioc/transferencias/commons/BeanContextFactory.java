package gob.bcb.portal.sioc.transferencias.commons;

import gob.bcb.service.servicioSiocCoin.ServicioCoinDao;

import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;

import org.apache.activemq.pool.PooledConnectionFactory;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

/**
 * Clase que implementa el patr�n Factory para generar el DAO correspondiente.
 * 
 * @author wherrera
 * 
 */
public class BeanContextFactory {
	private static Logger log = Logger.getLogger(BeanContextFactory.class);
	private static BeanContextFactory instance;
	// private BeanFactory factory;
	private ApplicationContext factory; 

	/**
	 * Constructor que obtiene el BeanFactory de Spring.
	 */
	private BeanContextFactory() {
		ServletContext servletContext = (ServletContext) FacesContext.getCurrentInstance().getExternalContext().getContext();
		WebApplicationContext wac = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		this.factory = wac;
	}

	/**
	 * Crea una instancia de la clase DaoFactory.
	 * 
	 * @return
	 */
	private synchronized static BeanContextFactory newInstance() {
		return new BeanContextFactory();
	}

	/**
	 * M�todo que crea una instancia de DaoFactory si es que no existe una.
	 * 
	 * @return
	 */
	public static BeanContextFactory getInstance() {
		if (instance == null) {
			instance = newInstance();
		}
		return instance;
	}

	public PooledConnectionFactory getPooledConnectionFactory() {
		log.info("XXX:getPooledConnectionFactory2222222");
		PooledConnectionFactory pooledConnectionFactory = null;
		try {		
			pooledConnectionFactory = (PooledConnectionFactory) factory.getBean("pooledConnectionFactory");
		} catch (Exception e) {
			log.error("errorrrrrr", e);
		}
		return pooledConnectionFactory;
	}

	public SiocFactoryDao getSiocFactoryDao() {
		return (SiocFactoryDao) factory.getBean("siocFactoryDao");
	}
	
	public ServicioCoinDao getServicioCoinDao() {
		return (ServicioCoinDao) factory.getBean("servicioCoinDao");
	}	
}
