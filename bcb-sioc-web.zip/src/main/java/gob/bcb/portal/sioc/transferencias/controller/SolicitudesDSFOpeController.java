package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class SolicitudesDSFOpeController extends BaseBeanController {
	private SocSolicitudes solicitud = new SocSolicitudes();
	private SolicitudesS solicitudS = new SolicitudesS();
	private SocDetallessol detalle = new SocDetallessol();
	private CuentasBen cuentaBen = new CuentasBen();
	private List<SolicitudesS> solicitudes;
	private List<SocSolicitudes> listaSoli;

	private String prioridad = "NO";
	private String cuentaD = "";
	private String cuentaC = "";
	private Boolean montoVer = false;
	private Boolean cuentaVer = true;
	private Boolean generada = true;
	private String motivo = "";
	private String usuario = "";
	private String mensaje = "";

	private Logger log = Logger.getLogger(SolicitudesDSFOpeController.class);

	public SolicitudesDSFOpeController() {
		recuperarVisit();
		usuario = getVisit().getUsuarioSession().getLogin();
		this.recuperarSolicitudes();
	}

	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SolicitudesS>();
		this.listaSoli = new ArrayList<SocSolicitudes>();

		String query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
				+ " and s.cla_estado = 'R'" + " and ss.cla_entidad = 'SF' and s.cla_tipo = 'TD' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				//
				solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'B', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");

				solicitudS.setTipo("TRANSFERENCIA DEL EXTERIOR");
				solicitudes.add(solicitudS);

				solicitud = new SocSolicitudes((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_tipo"),
						(Integer) res.get("soc_cuentad"), (String) res.get("soc_nrocuentad"), (String) res.get("moneda"), 'B',
						(Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (Integer) res.get("soc_cuentac"),
						(String) res.get("soc_nrocuentac"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"),
						(BigDecimal) res.get("soc_montomn"), "", (String) res.get("monedat"));

				listaSoli.add(solicitud);
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudS = this.solicitudes.get(fila);
		this.solicitud = this.listaSoli.get(fila);

		String query = " select s.* " + " from soc_detallessol s " + " where s.soc_codigo = '" + solicitud.getSocCodigo() + "'"
				+ " and s.det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				//
				detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), (String) res.get("moneda"),
						(Integer) res.get("det_ctabenef"), (String) res.get("det_concepto"), (String) res.get("det_info"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("monedaT"), (String) res.get("det_facturas"));
			}
		} else {
			log.info("Lista Nula");
		}

		query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
				+ solicitud.getSocCuentad() + "'";

		List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
		if (resultadoD.size() == 1) {
			for (Map<String, Object> res : resultadoD) {
				//
				cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
			}
		} else {
			log.info("Lista Nula");
		}

		query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
				+ solicitud.getSocCuentac() + "'";

		List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
		if (resultadoC.size() == 1) {
			for (Map<String, Object> res : resultadoC) {
				//
				cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
			}
		} else {
			log.info("Lista Nula");
		}

		if (detalle.getDetInfo().equals("1"))
			motivo = "REMESAS DEL EXTERIOR";
		if (detalle.getDetInfo().equals("2"))
			motivo = "EMBAJADAS Y ORGANISMOS INTERNACIONALES";
		if (detalle.getDetInfo().equals("3"))
			motivo = "GIROS";
		if (detalle.getDetInfo().equals("4"))
			motivo = "OPERACIONES PROPIAS DEL BANCO";
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Generando la operacion: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "operacionTD");

		mapaParametros.put("solicitud", solicitud);
		mapaParametros.put("detalle", detalle);
		mapaParametros.put("usuario", usuario);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String numero = (String) mapaRespuesta.get("nroOperacion");
		log.info("Numero asignado desde el BPM: " + numero);

		mensaje = "Se generó la operación satisfactoriamente.";
		this.recuperarSolicitudes();
	}

	public void eventoAnularBtn(ActionEvent action) {
		log.info("Anulando la solicitud: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "anular");

		mapaParametros.put("solicitud", solicitud);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		mensaje = "Se anuló la solicitud registrada.";
		this.recuperarSolicitudes();
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitud) {
		this.solicitud = solicitud;
	}

	public SolicitudesS getSolicitudS() {
		return solicitudS;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudS = solicitudS;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public String getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getCuentaVer() {
		return cuentaVer;
	}

	public void setCuentaVer(Boolean cuentaVer) {
		this.cuentaVer = cuentaVer;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
