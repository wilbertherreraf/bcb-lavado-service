package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocBolsin;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Solicitante;
import gob.bcb.service.servicioSioc.jdbc.QNativesBolsin;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SolicitudesBolsinController extends BaseBeanController {
	// private Logger log = Logger.getLogger(SolicitudesBolsinController.class);
	private static Logger log = Logger.getLogger(SolicitudesBolsinController.class);

	private SocBolsin solicitudB = new SocBolsin();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> departamentos = new ArrayList<SelectItem>();
	private String idSoli = "-1";
	private String mensaje = "";
	private String errorM = "";
	private boolean modifSolicitante = false;
	private BigDecimal montoSol = BigDecimal.valueOf(0.00);
	private BigDecimal montoMN = BigDecimal.valueOf(0.00);
	private BigDecimal cotiz = BigDecimal.valueOf(0.00);
	private Boolean botonHab = false;
	private Boolean errorVer = false;
	private Solicitante socSolicitante = new Solicitante();
	private List<SelectItem> solicitantePGList = new ArrayList<SelectItem>();

	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	public SolicitudesBolsinController() {
		log.info("SolicitudesBolsinController creado...");

		recuperarVisit();

		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
		socSolicitante = new Solicitante();
		idSoli = Visit.getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		solicitudB = new SocBolsin();
		montoSol = BigDecimal.valueOf(0.00);
		cotiz = BigDecimal.valueOf(0.00);

		String query = "";

		query = "select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SF' " + " and cla_vigente = 1 ";

		if (!idSoli.equalsIgnoreCase("900")) {
			query += "and trim(sol_codigo) = '" + idSoli + "'";
		}

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		}

		if (!idSoli.equalsIgnoreCase("900")) {
			cuentasD = getCuentasD();
			if (getCuentasD().size() > 0) {
				solicitudB.setCuentaD((Integer) getCuentasD().get(0).getValue());
			}
			seleccionarTipSolic(null);
			log.info("XXX: hayyyyyyyyyy " + cuentasD.size());
		}

	}

	public List<SelectItem> getCuentasD() {
		log.info("XXX: cuentas a debitaaaaaaaaaa         " + idSoli + "$");
		if (solicitudB.getSolCodigo() == null)
			log.info("XXX: cuentas a debitaa nulooooooooooo " + idSoli + "$");
		
		cuentasD.clear();
		
		if (solicitudB.getSolCodigo() != null && !solicitudB.getSolCodigo().equals("900")) {
			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '"
					+ solicitudB.getSolCodigo() + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					if ((Integer) res.get("moneda") == 69)
						cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-"
								+ res.get("moneda")));
				}
			}
		} 

		return cuentasD;
	}


	public void montoChanged(ValueChangeEvent event) {
		Long montoL = (Long) event.getNewValue();
		Double montoD = montoL.doubleValue();

		if (montoD > 0) {
			System.out.println("monto mayor a cero : " + montoD);
			if (BigDecimal.valueOf(montoD).remainder(BigDecimal.valueOf(100000)).compareTo(BigDecimal.valueOf(0)) > 0) {
				errorM = "El monto solicitado debe ser un múltiplo de 100.000,00";
				setErrorVer(true);
			} else {
				setErrorVer(false);
				BigDecimal tc1 = BigDecimal.valueOf(montoD);
				montoMN = BigDecimal.ZERO;
				if (solicitudB.getCotiz() != null)
					montoMN = tc1.multiply(solicitudB.getCotiz());
				solicitudB.setMontoMN(montoMN);
			}
		} else {
			System.out.println(" ----------------- monto MENOR a cero : " + montoD);
			errorM = "El monto solicitado debe ser mayor a " + montoD;
			setErrorVer(true);
		}
	}

	public void seleccionarParticipante(ActionEvent event) {
		socSolicitante = new Solicitante();
		seleccionarTipSolic(null);
	}

	public void tcChanged(ValueChangeEvent event) {
		String newValue = event.getNewValue().toString();
		if (!(newValue == null) || !(newValue == "")) {
			Double tc = Double.valueOf(newValue);
			// Double tc = (Double) event.getNewValue();
			BigDecimal tc1 = BigDecimal.valueOf(tc);
			if (solicitudB.getMontoSol() != null)
				montoMN = solicitudB.getMontoSol().multiply(tc1);
			solicitudB.setMontoMN(montoMN);
		}
	}

	public void seleccionarTipSolic(ActionEvent event) {
		modifSolicitante = false;
		solicitantePGList.clear();
		if (!StringUtils.isEmpty(solicitudB.getClaTipsolic())) {
			if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("E") || solicitudB.getClaTipsolic().trim().equalsIgnoreCase("ED")) {
				solicitudB.setBenef(null);
				socSolicitante = new Solicitante();
				modifSolicitante = false;
			} else {
				getSolicitantePGList();
				modifSolicitante = true;
			}
		} else {
			solicitudB.setBenef(null);
			socSolicitante = new Solicitante();
			modifSolicitante = false;
		}

		if (!StringUtils.isEmpty(solicitudB.getClaTipsolic())) {
			if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("ED") || solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD")) {
				BigDecimal tc = obtenerTC();
				solicitudB.setCotiz(tc);
			}
		}
	}

	public List<SelectItem> getSolicitantePGList() {
		solicitantePGList.clear();
		String query = "select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'PJ' "
				+ " and cla_vigente = 1 and sol_codigo like '" + solicitudB.getSolCodigo() + "-%' and sol_persona is not null ";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				solicitantePGList.add(new SelectItem(((String) res.get("cod")).trim(), ((String) res.get("sol_persona")).trim()));
			}
		}
		return solicitantePGList;
	}

	public void setSolicitantePGList(List<SelectItem> solicitantePGList) {
		this.solicitantePGList = solicitantePGList;
	}

	public void seleccionarSolicitante(ActionEvent event) {
		String codSolic = solicitudB.getBenef();
		if (!StringUtils.isEmpty(codSolic)) {
			socSolicitante = Servicios.getSocSolicitante(codSolic.trim());
			if (codSolic.trim().startsWith(idSoli + "-")) {
				// se verifica que el usuario haya sido creado por la IFA y
				// exista en BdD
				if (socSolicitante != null)
					modifSolicitante = true;
			}
		}
	}

	public SocBolsin getSolicitudB() {
		return solicitudB;
	}

	public void setSolicitudB(SocBolsin solicitudB) {
		this.solicitudB = solicitudB;
	}

	public void guardarSolic(ActionEvent event) {
		QNativesBolsin qNativesBolsin = new QNativesBolsin();
		socSolicitante.setEstacion(Visit.getVisit().getAddress());
		socSolicitante.setUsrCodigo(Visit.getVisit().getUsuarioSession().getLogin());
		qNativesBolsin.insertSolicitante(socSolicitante);
		modifSolicitante = false;
	}

	public void adicionarSolic(ActionEvent event) {
		socSolicitante = new Solicitante();
		socSolicitante.setSolCodigo(Servicios.getCorrelativoSocSolExternos(idSoli));
		socSolicitante.setClaVigente((short) 1);
		socSolicitante.setClaEntidad("PJ");
		modifSolicitante = !StringUtils.isEmpty(solicitudB.getClaTipsolic())
				&& (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("G") || solicitudB.getClaTipsolic().trim().equalsIgnoreCase("GD"));
	}

	public void modificarSolic(ActionEvent event) {
		modifSolicitante = false;
		if (solicitudB.getBenef() != null && solicitudB.getBenef().trim().startsWith(idSoli + "-")) {
			// se verifica que el usuario haya sido creado por la IFA y exista
			// en BdD
			Solicitante socSol = Servicios.getSocSolicitante(solicitudB.getBenef());

			if (socSol != null)
				modifSolicitante = true;
		}

	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void setErrorM(String errorM) {
		this.errorM = errorM;
	}

	public String getErrorM() {
		return errorM;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public void setErrorVer(Boolean errorVer) {
		this.errorVer = errorVer;
	}

	public Boolean getErrorVer() {
		return errorVer;
	}

	public BigDecimal getMontoMN() {
		return montoMN;
	}

	public void setMontoMN(BigDecimal montoMN) {
		this.montoMN = montoMN;
	}

	public BigDecimal getMontoSol() {
		return montoSol;
	}

	public void setMontoSol(BigDecimal montoSol) {
		this.montoSol = montoSol;
	}

	public BigDecimal getCotiz() {
		return cotiz;
	}

	public void setCotiz(BigDecimal cotiz) {
		this.cotiz = cotiz;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * 
	 * @return
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		String codSolicitante = solicitudB.getSolCodigo();
		if (codSolicitante == null || codSolicitante.trim().isEmpty()) {
			errorM = "No existe solicitante seleccionado";
			setErrorVer(true);
			return;
		}
		if (solicitudB.getClaTipsolic() == null || solicitudB.getClaTipsolic().trim().equals("-1") || solicitudB.getClaTipsolic().trim().isEmpty()) {
			// whf vd
			errorM = "No existe tipo de solicitud seleccionado";
			setErrorVer(true);
		} else {
			if (montoSol.remainder(BigDecimal.valueOf(100000)).compareTo(BigDecimal.valueOf(0)) == 0) {
				String corrs = Servicios.getCorrelativoB(codSolicitante);

				String sigla = Servicios.getSigla(codSolicitante);
				log.info("XXX: guardando " + solicitudB.getSocCodigo() + " " + solicitudB.getSolCodigo() + " " + solicitudB.getCorr());
				solicitudB.setClaEstado('9');
				if (idSoli.equalsIgnoreCase("900")) {
					// si el usuario que ingresa es del bcb
					solicitudB.setClaEstado('B');
				}
				solicitudB.setCorr(sigla + "-" + corrs + "-" + Servicios.obtGestion());
				solicitudB.setEstacion(Visit.getVisit().getAddress());
				solicitudB.setUsrCodigo(Visit.getVisit().getUsuarioSession().getLogin());
				// solicitudB.setCuentaD(Integer.parseInt(idCuenta));
				// solicitudB.setMontoSol(montoSol);
				// solicitudB.setCotiz(cotiz);

				Date date = new Date();
				long time = date.getTime();

				// parametros para request
				String id = new Long(time).toString();

				// mapa de parametros a enviar a BPM
				Map<String, Object> mapaParametros = new HashMap<String, Object>();
				mapaParametros.put("opcion", "nuevaBolsin");
				mapaParametros.put("solicitud", solicitudB);
				log.info("Creando el objeto Request para enviar al BPM " + mapaParametros.toString());
				Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
				if (mapaRespuesta.containsKey("resp_msgerror")) {
					mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
					return;
				}

				String nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
				String resp_msgerror = (String) mapaRespuesta.get("resp_msgerror");
				log.info("Numero de Solicitud: " + nroSolicitud);

				if (!nroSolicitud.equals("-1")) {
					this.mensaje = "La solicitud se registró correctamente con el número " + solicitudB.getCorr() + ".";
					this.botonHab = true;
				} else {
					if (resp_msgerror == null)
						this.mensaje = "Se produjo un error al registrar la solicitud.";
					else
						this.mensaje = "Se produjo un error:" + resp_msgerror;

					//this.botonHab = true;
				}
			} else {
				this.mensaje = "El monto solicitado debe ser un múltiplo de 100.000,00";
				//this.botonHab = false;
			}
		}
	}

	public void setSocSolicitante(Solicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public Solicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setModifSolicitante(boolean modifSolicitante) {
		this.modifSolicitante = modifSolicitante;
	}

	public boolean isModifSolicitante() {
		return modifSolicitante;
	}

	public void setDepartamentos(List<SelectItem> departamentos) {
		this.departamentos = departamentos;
	}

	public List<SelectItem> getDepartamentos() {
		departamentos.clear();
		String query = "select val_codigo, val_nombre from soc_valorescla where cla_codigo = 'cla_depto' ";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				departamentos.add(new SelectItem(((String) res.get("val_nombre")).trim(), ((String) res.get("val_nombre")).trim()));
			}
		}
		return departamentos;
	}

	public BigDecimal obtenerTC() {
		log.info("Obteniendo tc: ");
		BigDecimal tc = BigDecimal.ZERO;
		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "obtenerTC");

		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return tc;
		}
		tc = (BigDecimal) mapaRespuesta.get("tc");

		log.info("TC vigente: " + tc);

		if (tc == null || tc.compareTo(BigDecimal.ZERO) <= 0) {
			tc = BigDecimal.ZERO;
		}
		return tc;
	}
}
