package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocEstadistica;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

public class EstadisticaController extends BaseBeanController {

	private SocEstadistica est = new SocEstadistica();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> tipos = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private String idSoli = "-1";
	private String idTipo = "-1";
	private String mensaje = "";
	private String usuario;
	private BigDecimal montoOrd = BigDecimal.valueOf(0);
	private Boolean generada = true;
	private Boolean botonHab = false;
	private Date fechaValor;

	private Logger log = Logger.getLogger(EstadisticaController.class);

	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	// private static final String ESTACION = "172.29.18.3-curiona";
	private static final String ESTACION = "";

	public EstadisticaController() {

		recuperarVisit();
		usuario = getVisit().getUsuarioSession().getLogin();

		String query = "";

		idSoli = "-1";
		query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_vigente = 1" + " order by sol_persona";

		est = new SocEstadistica();
		est.setMoneda(-1);
		est.setEstMontome(BigDecimal.valueOf(0));

		monedas.add(new SelectItem(34, "DOLARES ESTADOUNIDENSES"));
		monedas.add(new SelectItem(53, "EUROS"));
		monedas.add(new SelectItem(30, "CORONAS SUECAS"));
		// monedas.add(new SelectItem(31, "FRANCOS SUIZOS"));monedas.add(new
		// SelectItem("GBP", "LIBRAS ESTERLINAS"));

		tipos.add(new SelectItem("TE", "TRANSFERENCIA AL EXTERIOR"));
		tipos.add(new SelectItem("VET", "VENTA CON TRANSFERENCIA"));
		tipos.add(new SelectItem("VE", "VENTA DE DIVISAS"));
		tipos.add(new SelectItem("TC", "TRANSFERENCIA LOCAL"));
		tipos.add(new SelectItem("TCC", "TRANSF. LOCAL CON COMPRA"));
		tipos.add(new SelectItem("TD", "TRANSFERENCIA DEL EXTERIOR"));
		tipos.add(new SelectItem("TDC", "TRANSF. DEL EXTERIOR CON COMPRA"));

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());
				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		} else {
			log.info("Lista Nula");
		}

	}

	public void seleccion3Changed(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		log.debug("Valor seleccionado: " + sel);

		if (!sel.equals(-1)) {
			if (sel == 34)
				;
			else
				;
		}
	}

	public void montoChanged(ValueChangeEvent event) {
		log.info("enter changed");
		String montoS = event.getNewValue().toString();
		log.info("montoS:" + montoS);
		Double montoD = Double.parseDouble(montoS);
		log.info("montoD:" + montoD);
	}

	public SocEstadistica getEst() {
		return est;
	}

	public void setEst(SocEstadistica est) {
		this.est = est;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public void setTipos(List<SelectItem> tipos) {
		this.tipos = tipos;
	}

	public List<SelectItem> getTipos() {
		return tipos;
	}

	public void setIdTipo(String idTipo) {
		this.idTipo = idTipo;
	}

	public String getIdTipo() {
		return idTipo;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public BigDecimal getMontoOrd() {
		return montoOrd;
	}

	public void setMontoOrd(BigDecimal montoOrd) {
		this.montoOrd = montoOrd;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public Date getFechaValor() {
		return fechaValor;
	}

	public void setFechaValor(Date fechaValor) {
		this.fechaValor = fechaValor;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "regestadistica");
		mapaParametros.put("socestadistica", est);
		mapaParametros.put("fecha", fechaValor);
		mapaParametros.put("usuario", usuario);

		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String respCodmsg = (String) mapaRespuesta.get("resp_codmsg");
		String respDescripmsg = (String) mapaRespuesta.get("resp_descripmsg");

		if (respCodmsg != null && respCodmsg.equals("0")) {
			log.info(respDescripmsg);
			mensaje = respDescripmsg;
			generada = true;
		} else {
			String resp_msgerror = (String) mapaRespuesta.get("resp_msgerror");
			if (resp_msgerror == null)
				this.mensaje = "Se produjo un error al registrar la solicitud.";
			else
				this.mensaje = "Se produjo un error:" + resp_msgerror;

			log.info(mensaje);
			generada = false;
		}
	}
}
