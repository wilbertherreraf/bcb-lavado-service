/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-mesaDeAyuda
 * gob.bcb.portal.mesaDeAyuda.util.ManejadorBPM
 * 27/06/2011 - 14:41:26
 * Creado por eibanez
 */
package gob.bcb.portal.sioc.transferencias.controller;

import java.util.HashMap;
import java.util.Map;

import javax.jms.ConnectionFactory;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.Utils;
import gob.bcb.portal.sioc.config.Constants;
import gob.bcb.portal.sioc.transferencias.commons.BeanContextFactory;
import gob.bcb.portal.sioc.transferencias.commons.Visit;

/**
 * [JAVADOC_INCOMPLETO: DESARROLLADOR DEBE DOCUMENTAR CLASE]
 * 
 * 
 * @author wherrera
 * 
 */
public class ManejadorServicioBPM {

	private static final Log log = LogFactory.getLog(ManejadorServicioBPM.class);

	public static Map<String, Object> consultaBPM(String nombreBPM, String ipOrigen, String requester, String feature,
			Map<String, Object> parametrosMsg, String id) {
		log.info("Llamando al servicio: " + nombreBPM + "  feature: " + feature + " con parametros: " + parametrosMsg.toString());
		StatusResponse statusResponse = null;
		Map<String, Object> parametros = new HashMap<String, Object>();
		Map<String, Object> mapaRespuesta = new HashMap<String, Object>();
		Visit visit = null;
		visit = Visit.getVisit();
		ConnectionFactory connectionFactory = BeanContextFactory.getInstance().getPooledConnectionFactory();
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(connectionFactory);
		log.info("parametrosMsg.ge(opcion) " + parametrosMsg.get("opcion"));
		try {
			jMSConnectionHandler.before();
			parametros.put("BCBAddress", visit.getAddress());
			parametros.put("BCBIdemisor", gob.bcb.service.servicioSioc.common.Constants.CODAPP_SIOC);
			parametros.put("BCBIddestinatario", Constants.getParamsSystem().get(nombreBPM));
			parametros.put("BCBIdusuario", visit.getUsuarioSession().getLogin());
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", gob.bcb.service.servicioSioc.common.Constants.CODAPP_SIOC);
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			String nroOperacion = Utils.generateUUID().replaceAll("-", "");
			log.info("ID:" + nroOperacion);
			// se recupera la opcion del menu
			String tipooper = (String) visit.getParametro("SIOCWEB_TIPOPERACION");
			log.info("Tipo operacion menu " + tipooper);
			if (!StringUtils.isBlank(tipooper)) {
				parametrosMsg.put("SIOCWEB_TIPOPERACION", tipooper);
			}

			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					nroOperacion, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));

			MessageObjectBean messageObjectBean = new MessageObjectBean();
			messageObjectBean.setTransformedMessage(parametrosMsg);

			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();

			if (statusResponse.getResponse() instanceof MessageObjectBean) {
				MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
				mapaRespuesta = (Map<String, Object>) messageObjectBean1.getTransformedMessage();

			} else {
				mapaRespuesta.put("estado", "-1");
				mapaRespuesta.put("resp_msgerror", statusResponse.getDescrip());

			}

		} catch (Exception e) {
			log.error("Error en mensaje " + nombreBPM, e);
			throw new RuntimeException(e);
		} finally {
			try {
				if (jMSConnectionHandler != null){
					jMSConnectionHandler.close();
					jMSConnectionHandler.after();		
				}
			} catch (Exception e) {
				log.error("Error al cerrar JMS " + e.getMessage(), e);
			}
		}
		return mapaRespuesta;
	}

	public static Map<String, Object> consultaServidor(String nombreServicio, String ipOrigen, String requester, String feature,
			Map<String, Object> parametros, String id) throws Exception {
		// bug whf hasta el momento este metodo es solo para uso de
		// transacciones de consulta de sioccoin,
		// por esta razon se hace este if y en el servicio se debe redigir al
		// servicio
		parametros.put("SIOCServiceId", nombreServicio);
		parametros.put("opcion", nombreServicio);
		return consultaBPM("bpmPruebaCU", ipOrigen, requester, feature, parametros, id);
	}


}
