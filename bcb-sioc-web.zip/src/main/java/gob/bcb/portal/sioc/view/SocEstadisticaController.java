package gob.bcb.portal.sioc.view;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocClaves;
import gob.bcb.bpm.pruebaCU.SocEstadistica;
import gob.bcb.bpm.pruebaCU.SocMensajes;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocValorescla;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;
import gob.bcb.service.servicioSioc.common.Constants;

/**
 * @author eborda
 *
 */
public class SocEstadisticaController extends BaseBeanController {
	
	private SocEstadistica est = new SocEstadistica();
	private Logger log = Logger.getLogger(SocEstadisticaController.class);
	private List<SocEstadistica> socEstadisticasLista = new ArrayList<SocEstadistica>();
	private SocEstadistica socEstadisticaSelected = new SocEstadistica();
	private SolicitudBean solicitudBean = new SolicitudBean();
	private String sIOCWEB_TIPOPERACION;
	
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> tipos = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private String idSoli = "-1";
	private String idTipo = "-1";
	private String usuario;
	private Date fechaDesde;
	private Date fechaHasta;
	private SocEstadistica socEstadisticaBusqueda = new SocEstadistica();
	private List<SelectItem> solicitanteItems = new ArrayList<SelectItem>();
	private List<SelectItem> estadoItems = new ArrayList<SelectItem>();
	

	@PostConstruct
	public void inicio() {
		log.info("=============ooo00OOO00ooo===================");
		log.info("PostConstruct  " + getClass().getName());
//		
		try {
			recuperarVisit();
			String codEnt = getVisit().getUsuarioSession().getSolicitante()
					.getSolCodigo();
			usuario = getVisit().getUsuarioSession().getLogin();
			String ip = getVisit().getAddress();
			solicitudBean.setSessionFactory(getSiocFactoryDao()
					.getHibernateTemplate().getSessionFactory());
			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro(
					"SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION
					+ " usuario: " + usuario + " ==> codEnt: " + codEnt + " ip " + ip);
			
			cargarControles();
			recuperarDatosAlaFecha();
			
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR,
							"OcurriÃ³ un error: " + e.getMessage(), null));
		}
	}
	
	
	public void cargarControles(){
		
		// Inicializar variables
		est = new SocEstadistica();
		est.setMoneda(-1);
		est.setEstMontome(BigDecimal.ZERO);
		est.setEstMontous(BigDecimal.ZERO);
		

		//Cargar control moneda de genMoneda
		
		List<GenMoneda> genMonedas = getSolicitudBean().getGenMonedaDao().getMonedas();
		
		for (GenMoneda genMoneda : genMonedas) {
			monedas.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}
		
		
		// Cargar control tipo operaciones de clave operaciones
		
		List<SocValorescla> socValoresclas = getSolicitudBean().getSocValoresclaDao().getValoresByClave(Constants.CLA_OPERACION_ESTADISTICA_CLAVE);
		
		for (SocValorescla socSolicitante : socValoresclas) {
			tipos.add(new SelectItem(socSolicitante.getId().getValCodigo().trim() + "", socSolicitante.getValNombre()));
		}
		
		socValoresclas = getSolicitudBean().getSocValoresclaDao().getValoresByClave(Constants.CVE_ESTADO_ESTADISTICA_CLAVE);
		
		for (SocValorescla socSolicitante : socValoresclas) {
			estadoItems.add(new SelectItem(socSolicitante.getId().getValCodigo().trim() + "", socSolicitante.getValNombre()));
		}
		
		
		est.setFechaHora(new Date());
		
		List<SocSolicitante> socSolicitanteLista = getSolicitudBean()
				.getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");

		boolean agregarOtros = true;
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			if(agregarOtros){
				solics.add(new SelectItem("Otros","Otros"));
				agregarOtros = false;
			}
			solics.add(new SelectItem(socSolicitante.getSolCodigo()
					.trim() + "", socSolicitante.getSolPersona()));
		}
		
		fechaDesde = new Date();
		
		fechaHasta = new Date();
		
		solicitanteItems = solics;
		
	}

	public void botonBuscar() {
		log.info("en botonBuscar " + socEstadisticaBusqueda.toString());

		recuperarDatos();
	}
	
	public void botonGuardarEstadistica(ActionEvent actionEvent) {
		try {
			log.info("en botonGuardarEstadistica "
					+ est.toString());

			
			est.setClaEstado(Constants.CLAVE_ESTSOLIC_REGIS);
			est.setCveEstado(Constants.CLAVE_ESTSOLIC_VERIFICADO);
			
			log.info(est.toString());
						
			
			String mensajeError = "La operacion se realizó "
					+ est.getEstCodigo();
			log.info("fin botonGuardarEstadistica " + mensajeError + " cod "
					+ est.getEstCodigo());

			// Verificar el tipo de opracion con el tipo de entidad
			if(!"Otros".equalsIgnoreCase(est.getSolCodigo())){
				SocSolicitante socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(est.getSolCodigo());
				if(socSolicitante != null){
					mensajeError = "El tipo de operación no corresponde al solicitante seleccionado";
					//Verificamos que si es una entidad de tipo Sector publico no realice operaciones al Sistema financiero
					if("SP".equalsIgnoreCase(socSolicitante.getClaEntidad())){
						String claOperacion = est.getClaOperacion().substring(0,2);
						if("CSF".equalsIgnoreCase(est.getClaOperacion()) || "OO".equalsIgnoreCase(claOperacion)){
							FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	mensajeError, null));
						} else{
							// registramos solo los mensajes swifts
							solicitudBean.getSocEstadisticaDao().saveOrUpdate(est);
						}
						
					} else{
						// Verificamos que las Entidades del Sistema Financiero no puedan realizar operacioens del Sector Publico
						String claOperacion = est.getClaOperacion().substring(0,2);
						if("VED".equalsIgnoreCase(est.getClaOperacion()) || "OO".equalsIgnoreCase(claOperacion)){
							FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	mensajeError, null));
						} else if("TAE".equalsIgnoreCase(est.getClaOperacion())){
							FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	mensajeError, null));
						} else if("VTE".equalsIgnoreCase(est.getClaOperacion())){
							FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	mensajeError, null));
						} else if("TDE".equalsIgnoreCase(est.getClaOperacion())){
							FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	mensajeError, null));
						} else if("CTE".equalsIgnoreCase(est.getClaOperacion())){
							FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	mensajeError, null));
						} else{
							// registramos solo los mensajes swifts
							solicitudBean.getSocEstadisticaDao().saveOrUpdate(est);
						}
					}
				}
			} else{
				mensajeError = "El tipo de operación no corresponde al solicitante seleccionado";
				// Verificamos que el tipo de institución otros pertenezca solo al tipo de operación otros
				String claOperacion = est.getClaOperacion().substring(0,2);
				if(!"OO".trim().equalsIgnoreCase(claOperacion)){
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	mensajeError, null));
				} else{
					// registramos solo los mensajes swifts
					solicitudBean.getSocEstadisticaDao().saveOrUpdate(est);
				}
			}
			
			
			
			recuperarDatosAlaFecha();

		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: "
							+ e.getMessage(), null));
		}

	}
	
	
	public void botonModificarEstadistica(ActionEvent actionEvent) {
		try {
			log.info("en botonModificarEstadistica "
					+ socEstadisticaSelected.toString());

			socEstadisticaSelected.setClaEstado(Constants.CLAVE_ESTSOLIC_REGIS);
			socEstadisticaSelected.setCveEstado(Constants.CLAVE_ESTSOLIC_VERIFICADO);
			
			log.info(socEstadisticaSelected.toString());
			// registramos solo los mensajes swifts
			solicitudBean.getSocEstadisticaDao().saveOrUpdate(socEstadisticaSelected);
			
			
			String mensajeError = "La operacion se realizó "
					+ socEstadisticaSelected.getEstCodigo();
			log.info("fin botonModificarEstadistica " + mensajeError + " cod "
					+ socEstadisticaSelected.getEstCodigo());

//			FacesContext.getCurrentInstance().addMessage(
//					null,
//					new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError,
//							null));
			recuperarDatosAlaFecha();

		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: "
							+ e.getMessage(), null));
		}

	}
	
	
	public void nuevo(ActionEvent actionEvent) {
		//Inicializamos la variable 
		est = new SocEstadistica();
		est.setFechaHora(new Date());
		// Obtenemos el ultimo id
		String estCodigo = getSolicitudBean().getSocEstadisticaDao().obtenerUlimoEstCod();
		log.info("Resultado :" + estCodigo);
		
		Long estCodNuevo = new Long(estCodigo); 
		
		estCodNuevo += 1;
		log.info("EstCodigo disponible " + estCodNuevo.toString());
		est.setEstCodigo(estCodNuevo.toString());	
		
	}
	
	private void recuperarDatos() {
		socEstadisticaSelected = new SocEstadistica();		
		
		socEstadisticasLista = solicitudBean.getSocEstadisticaDao().obtenerEstadisticasPorFechaSolicitanteYEstado(fechaDesde, fechaHasta, socEstadisticaBusqueda.getSolCodigo(),socEstadisticaBusqueda.getClaEstado());
	}
	
	private void recuperarDatosAlaFecha() {
		socEstadisticaSelected = new SocEstadistica();		
		
		socEstadisticasLista = solicitudBean.getSocEstadisticaDao().obtenerEstadisticasRegistradosAlaFecha();
	}
	
	
	
	
	public void editar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocEstadistica cta0 = (SocEstadistica) SerializationUtils.clone(socEstadisticasLista.get(fila));
		
				
		socEstadisticaSelected =solicitudBean.getSocEstadisticaDao().getEstadistica(cta0.getEstCodigo());
		
		log.info("Estadistica selecccionada socEstadisticaSelected = " + socEstadisticaSelected);
	}
	
	public void remover(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocEstadistica estadisticaRemove = new SocEstadistica();
		
		SocEstadistica cta0 = (SocEstadistica) SerializationUtils.clone(socEstadisticasLista.get(fila));
		
		log.info("Estadistica selecccionada por Fila" + cta0);
		
		estadisticaRemove =solicitudBean.getSocEstadisticaDao().getEstadistica(cta0.getEstCodigo());
		
		log.info("Removiendo Estadistica  = " + estadisticaRemove);
		
		try {
			estadisticaRemove.setClaEstado(Constants.CLAVE_ESTSOLIC_ANULADO);
			
			// registramos solo los mensajes swifts
			solicitudBean.getSocEstadisticaDao().saveOrUpdate(estadisticaRemove);
			
			
			String mensajeError = "La operacion se realizó "
					+ estadisticaRemove.getEstCodigo();
			log.info("fin botonModificarEstadistica " + mensajeError + " cod "
					+ estadisticaRemove.getEstCodigo());

			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError, null));
//			recuperaEstadistica(Constants.CLAVE_ESTSOLIC_REGIS);
//			socEstadisticaBusqueda.setSolCodigo(estadisticaRemove.getSolCodigo());
//			socEstadisticaBusqueda.setClaOperacion(estadisticaRemove.getClaOperacion());
//			socEstadisticaBusqueda.setClaEstado(Constants.CLAVE_ESTSOLIC_REGIS);
			socEstadisticaBusqueda.setClaEstado('R');
			recuperarDatos();
		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: "
							+ e.getMessage(), null));
		}
		
	}
	
	
	public void aprobar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocEstadistica estadisticaAprobar = new SocEstadistica();
		
		SocEstadistica cta0 = (SocEstadistica) SerializationUtils.clone(socEstadisticasLista.get(fila));
		
		log.info("Estadistica selecccionada por Fila" + cta0);
		
		estadisticaAprobar =solicitudBean.getSocEstadisticaDao().getEstadistica(cta0.getEstCodigo());
		
		log.info("Removiendo Estadistica  = " + estadisticaAprobar);
		
		try {
			estadisticaAprobar.setClaEstado(Constants.CLAVE_ESTSOLIC_APROBADO);
			
			// registramos solo los mensajes swifts
			solicitudBean.getSocEstadisticaDao().saveOrUpdate(estadisticaAprobar);
			
			
			String mensajeError = "La operacion se realizó "
					+ estadisticaAprobar.getEstCodigo();
			log.info("fin botonModificarEstadistica " + mensajeError + " cod "
					+ estadisticaAprobar.getEstCodigo());

			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError,
							null));
//			recuperaEstadistica(Constants.CLAVE_ESTSOLIC_REGIS);
//			socEstadisticaBusqueda.setSolCodigo(estadisticaAprobar.getSolCodigo());
//			socEstadisticaBusqueda.setClaOperacion(estadisticaAprobar.getClaOperacion());
//			socEstadisticaBusqueda.setClaEstado(Constants.CLAVE_ESTSOLIC_REGIS);
			
			socEstadisticaBusqueda.setClaEstado('R');
			
			recuperarDatos();

		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(
					null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: "
							+ e.getMessage(), null));
		}
		
	}
	
	
	public String getSolicitanteNombre(String solCodigo){
		SocSolicitante benefs = new SocSolicitante();
		String resultado = "";
		
		if(!"Otros".equalsIgnoreCase(solCodigo)){
			benefs = solicitudBean.getSocSolicitanteDao().solicitanteByCod(
					solCodigo);
			if(benefs != null){
				resultado = benefs.getSolPersona();
			}
		} else{
			resultado = solCodigo;
		}		
				
		return resultado;
	}
	
	public String getMonedaNombre(int codMoneda) {
		GenMoneda benefs = new GenMoneda();
		String resultado = "";
		benefs = solicitudBean.getGenMonedaDao().findByCodigo(codMoneda);
		if (benefs != null) {
			resultado = benefs.getMonNombre();
		}

		return resultado;
	}
	
	
	public String getStyle(Character claEstado) {
		GenMoneda benefs = new GenMoneda();
		String resultado = "izquierda";
		if(claEstado.equals('D')){
			resultado = "izquierdaVerde";
		} else if(!claEstado.equals('D') && !claEstado.equals('R')){
			resultado = "izquierdaRojo";
		}
		
		return resultado;
	}
	

	public List<SocEstadistica> getSocEstadisticasLista() {
		return socEstadisticasLista;
	}

	public void setSocEstadisticasLista(List<SocEstadistica> socEstadisticasLista) {
		this.socEstadisticasLista = socEstadisticasLista;
	}

	public SocEstadistica getSocEstadisticaSelected() {
		return socEstadisticaSelected;
	}

	public void setSocEstadisticaSelected(SocEstadistica socEstadisticaSelected) {
		this.socEstadisticaSelected = socEstadisticaSelected;
	}

	public SolicitudBean getSolicitudBean() {
		return solicitudBean;
	}

	public void setSolicitudBean(SolicitudBean solicitudBean) {
		this.solicitudBean = solicitudBean;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public SocEstadistica getEst() {
		return est;
	}

	public void setEst(SocEstadistica est) {
		this.est = est;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public List<SelectItem> getTipos() {
		return tipos;
	}

	public void setTipos(List<SelectItem> tipos) {
		this.tipos = tipos;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	
	public SocEstadistica getSocEstadisticaBusqueda() {
		return socEstadisticaBusqueda;
	}


	public void setSocEstadisticaBusqueda(SocEstadistica socEstadisticaBusqueda) {
		this.socEstadisticaBusqueda = socEstadisticaBusqueda;
	}


	public List<SelectItem> getEstadoItems() {
		return estadoItems;
	}


	public void setEstadoItems(List<SelectItem> estadoItems) {
		this.estadoItems = estadoItems;
	}


	public List<SelectItem> getSolicitanteItems() {
		return solicitanteItems;
	}

	public void setSolicitanteItems(List<SelectItem> solicitanteItems) {
		this.solicitanteItems = solicitanteItems;
	}
	
	

}
