package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.core.utils.UtilsDate;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;

public class ReportesEst2Controller {

	private String f1 = "";
	private String f2 = "";
	private Date fecha1;
	private Date fecha2;

	private String urlReporte;

	private Logger log = Logger.getLogger(ReportesEst2Controller.class);

	public ReportesEst2Controller() {

	}

	public void setFecha1(Date fecha1) {
		this.fecha1 = fecha1;
	}

	public Date getFecha1() {
		return fecha1;
	}

	public void setFecha2(Date fecha2) {
		this.fecha2 = fecha2;
	}

	public Date getFecha2() {
		return fecha2;
	}

	private static String getRaiz() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = request.getRequestURL().toString();
		String direccionRaiz = null;
		if (url.indexOf("/faces") > 0)
			direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
		else
			direccionRaiz = url;
		return direccionRaiz;
	}

	public String getUrlReporte() {
//		log.info("XXX:rr:" + fecha1 + " :: " + fecha2);
//		if (fecha1 != null && fecha2 != null) {
//			DateTime ff1 = new DateTime(fecha1);
//			DateTime ff2 = new DateTime(fecha2);
//			log.info("f1:" + ff1.toString());
//			log.info("f2:" + ff2.toString());
//			f1 = completeDigits(ff1.getDayOfMonth()) + "/" + completeDigits(ff1.getMonthOfYear()) + "/" + ff1.getYear();
//			f2 = completeDigits(ff2.getDayOfMonth()) + "/" + completeDigits(ff2.getMonthOfYear()) + "/" + ff2.getYear();
//			log.info("f1:" + f1);
//			log.info("f2:" + f2);
//		}
		log.info("rr: SE,f1:" + f1 + ",f2:" + f2);
		//urlReporte = getRaiz() + "reporte?cod=0&tipo=SE" + "&f1=" + f1 + "&f2=" + f2;
		urlReporte = getRaiz() + "reporte";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	private String completeDigits(int number) {
		return (number > 9) ? "" + number : "0" + number;
	}

	public void mostrarReporte(ActionEvent event) {
		
		String strFechaDesde = UtilsDate.stringFromDate(fecha1, "dd/MM/yyyy");
		String strFechaAl = UtilsDate.stringFromDate(fecha2, "dd/MM/yyyy");
		log.info("XXX: mostrarReporte " + strFechaDesde + " " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		DateTime ff1 = new DateTime(fecha1);
		DateTime ff2 = new DateTime(fecha2);		
		parametros.put("FECHA_DESDE", fecha1);
		parametros.put("FECHA_HASTA", fecha2);
		parametros.put("tipo", "SE");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("cod", "0");
		request.getSession().setAttribute("tipo", "SE");
		request.getSession().setAttribute("parametros", parametros);		
	}

}