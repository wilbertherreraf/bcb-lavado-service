package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Solicitante;
import gob.bcb.service.servicioSioc.jdbc.QNativesBolsin;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SolBolsinIntController extends BaseBeanController {

	private SocBolsin solicitudB = new SocBolsin();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> departamentos = new ArrayList<SelectItem>();
	private String idSoli = "-1";
	private String idSoli2 = "-1";
	private String idCuenta = "-1";
	private String mensaje = "";
	private String errorM = "";
	private String usuario = "";
	private BigDecimal montoSol = BigDecimal.valueOf(0.00);
	private BigDecimal montoMN = BigDecimal.valueOf(0.00);
	private BigDecimal cotiz = BigDecimal.valueOf(0.00);
	private Boolean botonHab = true;
	private Boolean errorVer = false;

	private Logger log = Logger.getLogger(SolBolsinIntController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";// UsuarioGenerico.g
												// etIpMaquinaUsuario();

	private Solicitante socSolicitante = new Solicitante();
	private boolean modifSolicitante = false;

	private String solCodigo = "-1";
	private List<SelectItem> solicitantePGList = new ArrayList<SelectItem>();

	@SuppressWarnings("unchecked")
	public SolBolsinIntController() {
		// TODO Auto-generated constructor stub

		recuperarVisit();
		usuario = getVisit().getUsuarioSession().getLogin();

		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		List<SelectItem> listaCuenta = this.getCuentasD();
		if (listaCuenta.size() == 1) {
			idCuenta = (String) (listaCuenta.get(0).getValue()).toString();
		} else {
			idCuenta = "-1";
		}

		idSoli2 = idSoli;
		montoSol = BigDecimal.valueOf(0.00);
		cotiz = BigDecimal.valueOf(0.00);

		String query = "";

		if (!idSoli.equals("900")) {
			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SF' "
					+ " and cla_vigente = 1" + " and trim(sol_codigo) = '" + idSoli + "'";
		} else {
			// idSoli = "-1";
			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SF' "
					+ " and cla_vigente = 1" + " order by sol_persona";
		}

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public List<SelectItem> getCuentasD() {
		if (!idSoli.equals("900")) {
			cuentasD.clear();

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					if ((Integer) res.get("moneda") == 69)
						cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-"
								+ res.get("moneda")));
				}
			}
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public void montoChanged(ValueChangeEvent event) {
		Long montoL = (Long) event.getNewValue();
		Double montoD = montoL.doubleValue();
		if (BigDecimal.valueOf(montoD).remainder(BigDecimal.valueOf(100000)).compareTo(BigDecimal.valueOf(0)) > 0) {
			errorM = "El monto solicitado debe ser un m�ltiplo de 100.000,00";
			setErrorVer(true);
		} else {
			setErrorVer(false);
		}
	}

	public void tcChanged(ValueChangeEvent event) {
		log.info("enter tc");
		Double tc = (Double) event.getNewValue();
		BigDecimal tc1 = BigDecimal.valueOf(tc);
		montoMN = montoSol.multiply(tc1);
		solicitudB.setMontoMN(montoMN);
	}

	public SocBolsin getSolicitudB() {
		return solicitudB;
	}

	public void setSolicitudB(SocBolsin solicitudB) {
		this.solicitudB = solicitudB;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void setErrorM(String errorM) {
		this.errorM = errorM;
	}

	public String getErrorM() {
		return errorM;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public void setErrorVer(Boolean errorVer) {
		this.errorVer = errorVer;
	}

	public Boolean getErrorVer() {
		return errorVer;
	}

	public BigDecimal getMontoMN() {
		return montoMN;
	}

	public void setMontoMN(BigDecimal montoMN) {
		this.montoMN = montoMN;
	}

	public BigDecimal getMontoSol() {
		return montoSol;
	}

	public void setMontoSol(BigDecimal montoSol) {
		this.montoSol = montoSol;
	}

	public BigDecimal getCotiz() {
		return cotiz;
	}

	public void setCotiz(BigDecimal cotiz) {
		this.cotiz = cotiz;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * 
	 * @return
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar [" + solicitudB.getClaTipsolic() + "]");

		if (montoSol.remainder(BigDecimal.valueOf(100000)).compareTo(BigDecimal.valueOf(0)) == 0) {
			String corrs = "";
			String sigla = "";
			if (!StringUtils.isEmpty(solicitudB.getClaTipsolic())) {
				if (solicitudB.getClaTipsolic().trim().equalsIgnoreCase("G")) {
					corrs = Servicios.getCorrelativoB("GRAL");
					sigla = "GRAL";
				}
			}
			if (corrs.equals("")) {
				sigla = Servicios.getSigla(idSoli);
				corrs = Servicios.getCorrelativoB(idSoli);
			}

			solicitudB.setSolCodigo(idSoli);
			solicitudB.setClaEstado('B');
			solicitudB.setCorr(sigla + "-" + corrs + "-" + Servicios.obtGestion());
			solicitudB.setCuentaD(Integer.parseInt(idCuenta));
			solicitudB.setMontoSol(montoSol);
			solicitudB.setCotiz(cotiz);
			solicitudB.setEstacion(Visit.getVisit().getAddress());
			solicitudB.setUsrCodigo(Visit.getVisit().getUsuarioSession().getLogin());

			Date date = new Date();
			long time = date.getTime();
			log.info("->Creando el objeto Request para enviar al BPM " + solicitudB.getBenef());

			// parametros para request
			String id = new Long(time).toString();

			// mapa de parametros a enviar a BPM
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "nuevaBolsin");
			mapaParametros.put("solicitud", solicitudB);

			Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
			if (mapaRespuesta.containsKey("resp_msgerror")) {
				mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
				return;
			}

			String nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
			String respmsgerror = (String) mapaRespuesta.get("resp_msgerror");
			log.info("Numero de Solicitud: " + nroSolicitud);
			if (!nroSolicitud.equals("-1")) {

				this.mensaje = "La solicitud se registr� correctamente con el n�mero " + solicitudB.getCorr() + ".";
				this.botonHab = true;
			} else {
				this.mensaje = "Error al registrar la solicitud:" + respmsgerror;
				this.botonHab = true;
			}
		} else {
			this.mensaje = "El monto solicitado debe ser un m�ltiplo de 100.000,00";
			this.botonHab = false;
		}
	}

	public void eventoGuardarBtnPG(ActionEvent action) throws Exception {
		solicitudB.setClaTipsolic("G");

		eventoGuardarBtn(action);
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getSolCodigo() {
		return solCodigo;
	}

	public List<SelectItem> getSolicitantePGList() {
		solicitantePGList.clear();
		String query = "select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'PJ' "
				+ " and cla_vigente = 1 and sol_codigo like '" + idSoli2.trim() + "-%' and sol_persona is not null ";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				solicitantePGList.add(new SelectItem(((String) res.get("cod")).trim(), ((String) res.get("sol_persona")).trim()));
			}
		}
		return solicitantePGList;
	}

	public void seleccionarSolicitante(ActionEvent event) {
		String codSolic = solicitudB.getBenef();
		if (!StringUtils.isEmpty(codSolic)) {
			socSolicitante = Servicios.getSocSolicitante(codSolic.trim());
			if (codSolic.trim().startsWith(idSoli + "-")) {
			}
		}
	}

	public void setSolicitantePGList(List<SelectItem> solicitantePGList) {
		this.solicitantePGList = solicitantePGList;
	}

	public void adicionarSolic(ActionEvent event) {
		socSolicitante = new Solicitante();
		socSolicitante.setSolCodigo(Servicios.getCorrelativoSocSolExternos(idSoli));
		socSolicitante.setClaVigente((short) 1);
		socSolicitante.setClaEntidad("PJ");
		// modifSolicitante = !StringUtils.isEmpty(solicitudB.getClaTipsolic())
		// && solicitudB.getClaTipsolic().trim().equalsIgnoreCase("G");
	}

	public void modificarSolic(ActionEvent event) {
		modifSolicitante = false;
		if (solicitudB.getBenef() != null) {
			// se verifica que el usuario haya sido creado por la IFA y exista
			// en BdD
			Solicitante socSol = Servicios.getSocSolicitante(solicitudB.getBenef());
			socSolicitante = Servicios.getSocSolicitante(solicitudB.getBenef().trim());
			// if (socSol != null)
			// modifSolicitante = true;
		}

	}

	public void setSocSolicitante(Solicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public Solicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setModifSolicitante(boolean modifSolicitante) {
		this.modifSolicitante = modifSolicitante;
	}

	public boolean isModifSolicitante() {
		return modifSolicitante;
	}

	public void guardarSolic(ActionEvent event) {
		QNativesBolsin qNativesBolsin = new QNativesBolsin();
		socSolicitante.setEstacion(Visit.getVisit().getAddress());
		socSolicitante.setUsrCodigo(Visit.getVisit().getUsuarioSession().getLogin());
		qNativesBolsin.insertSolicitante(socSolicitante);
		getSolicitantePGList();
		// modifSolicitante = false;
	}

	public void setDepartamentos(List<SelectItem> departamentos) {
		this.departamentos = departamentos;
	}

	public List<SelectItem> getDepartamentos() {
		departamentos.clear();
		String query = "select val_codigo, val_nombre from soc_valorescla where cla_codigo = 'cla_depto' ";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				departamentos.add(new SelectItem(((String) res.get("val_nombre")).trim(), ((String) res.get("val_nombre")).trim()));
			}
		}
		return departamentos;
	}
}
