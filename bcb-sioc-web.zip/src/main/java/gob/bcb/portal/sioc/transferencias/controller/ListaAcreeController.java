/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;

import gob.bcb.portal.menu.DropDownBean;import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Acree;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaAcreeController extends BaseBeanController {
	private Acree acree = new Acree();
	private List<Acree> acrees;
	private SocDetallesope detalleO = new SocDetallesope();
	private SocOperaciones operacion = new SocOperaciones();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private String idBenef = "-1";
	private Integer idCuenta = -1;
	private String banco = "";
	private String banco1 = "";
	private String cuenta = "";
	private String nombreF = "";
	private String tipo = "";
	private String nit = "";
	private String mon = "";
	private String mon11 = "";
	private String concepto = "";
	private String mensaje = "";
	private String usuario;
	private Boolean botonHab = true;
	private Boolean cuentaHab = false;

	// private String urlReporte;

	private Logger log = Logger.getLogger(ListaAcreeController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	public ListaAcreeController() {
		
recuperarVisit();
		usuario = 
getVisit().getUsuarioSession().getLogin();

		this.recuperarAcree();
		Visit visit = Visit.getVisit();
		String tipooper = (String) visit.getParametro("SIOCWEB_TIPOPERACION");
		log.info("XXX: tipoopertipoopertipooper " + tipooper);
	}

	private void recuperarAcree() {
		this.acrees = new ArrayList<Acree>();

		String query = " select p.ope_codigo, p.ope_montome, p.soc_correlativo, p.ope_fecha, p.ope_montomn, p.moneda " + "from soc_operaciones p  "
				+ "where p.cla_estado = 'A' " + "and p.cla_operacion = 'TD' " + "and substr(p.soc_correlativo,1,1) = '('";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				log.debug("resultado" + res.toString());

				acree = new Acree((String) res.get("ope_codigo"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("ope_montome"),
						(Date) res.get("ope_fecha"), (BigDecimal) res.get("ope_montomm"), (Integer) res.get("moneda"));
				acrees.add(acree);
			}
		}
	}

	public void verAcreedor(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		acree = this.acrees.get(fila);

		String query = " select * " + " from soc_detallesope " + " where ope_codigo = '" + acree.getOpeCodigo() + "'" + " and det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				log.debug("resultado" + res.toString());

				operacion = new SocOperaciones(acree.getOpeCodigo(), "900", "TD", acree.getOpeFecha(), acree.getOpeMontome(), acree.getOpeMontomn(),
						acree.getMoneda(), null, null, 'P', null, acree.getSocCorrelativo(), null);
				detalleO = new SocDetallesope(new SocDetallesopeId((String) res.get("ope_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ins_codigo"), (String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"),
						(Integer) res.get("moneda"), (String) res.get("det_ctabenef"), (String) res.get("det_concepto"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("det_info"), (String) res.get("det_facturas"));
			}
		} else {
			log.info("Lista Nula");
		}

		query = " select ben_codigo, ben_nombre " + " from soc_benefsexp " + " where cla_vigente = 1" + " order by ben_nombre";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado != null) {
			for (Map<String, Object> res : resultado) {
				// log.debug("resultado" + res.toString());
				solics.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
			}
		} else {
			log.info("Lista Nula");
		}

		//concepto = "EN COMPROBANTE G-" + detalleO.getInsCodigo();
		concepto = "";
	}

	public List<SelectItem> getCuentasD() {
		// log.info("enter getcuentasD");
		if (!idBenef.equals("-1")) {
			cuentasD.clear();

			String query = " select cta_codigo, cta_nrocuenta" + " from soc_cuentasexp " + " where cla_vigente = 1 and ben_codigo = '" + idBenef
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());
					cuentasD.add(new SelectItem(res.get("cta_codigo"), (String) res.get("cta_nrocuenta")));
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		idCuenta = sel;
		log.info("Valor seleccionado: " + sel);

		if (idCuenta != -1) {
			String query = " select c.bco_codigo, c.moneda, s.sol_persona, c.bco_codigo1" + " from soc_cuentasexp c, soc_solicitante s"
					+ " where c.cla_vigente = 1 and c.cta_codigo = '" + idCuenta + "'" + " and c.bco_codigo = s.sol_codigo";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());
					setBanco((String) res.get("sol_persona"));
					Integer mon1 = (Integer) res.get("moneda");
					if (mon1 == 34)
						setMon("DOLARES ESTADOUNIDENSES");
					else
						setMon("BOLIVIANOS");
					String bco = (String) res.get("bco_codigo1");
					if (bco != null) {
						query = " select c.bco_codigo1, c.moneda1, s.sol_persona, c.cta_nrocuenta1" + " from soc_cuentasexp c, soc_solicitante s"
								+ " where c.cla_vigente = 1 and c.cta_codigo = '" + idCuenta + "'" + " and c.bco_codigo1 = s.sol_codigo";
						List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
						if (resultado2.size() == 1) {
							for (Map<String, Object> res2 : resultado2) {
								// log.info("resultado" + res2.toString());
								setBanco1((String) res2.get("sol_persona"));
								setCuenta((String) res2.get("cta_nrocuenta1"));
								mon1 = (Integer) res2.get("moneda1");
								if (mon1 == 34)
									setMon11("DOLARES ESTADOUNIDENSES");
								else
									setMon11("BOLIVIANOS");
								setCuentaHab(true);
							}
						}
					} else {
						setCuentaHab(false);
					}
				}
			} else {
				setBanco("");
				setMon("");
				log.info("Lista Nula");
			}
		}
	}

	public void seleccionBChanged(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idBenef = sel;
		log.info("Valor seleccionado: " + sel);

		if (!idBenef.equals("-1")) {
			String query = " select ben_factura, ben_nit, cla_entidad" + " from soc_benefsexp" + " where cla_vigente = 1 and ben_codigo = '"
					+ idBenef + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());
					setNombreF((String) res.get("ben_factura"));
					setNit((String) res.get("ben_nit"));
					tipo = (String) res.get("cla_entidad");
				}
			} else {
				setNombreF("");
				setNit("");
				log.info("Lista Nula");
			}
		}
	}

	/**
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");
		
		if (!StringUtils.isBlank(operacion.getGlosaRefencia())){
			operacion.setGlosaRefencia(operacion.getGlosaRefencia().toUpperCase());			
		}

		detalleO.setBenCodigo(idBenef);
		detalleO.setDetCtabenef(idCuenta.toString());
		detalleO.setDetConcepto(concepto.toUpperCase());

		log.info("concepto:" + detalleO.getDetConcepto());

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		if (tipo.equals("SP"))
			mapaParametros.put("opcion", "acreedorSP");
		else
			mapaParametros.put("opcion", "acreedor");
		mapaParametros.put("operacion", operacion);
		mapaParametros.put("detalle", detalleO);
		mapaParametros.put("usuario", usuario);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String nroOpe = (String) mapaRespuesta.get("nroOperacion");
		log.info("Numero de Operacion: " + nroOpe);

		if (!nroOpe.equals("0000")) {
			this.mensaje = "La operación se generó correctamente con el número " + nroOpe + ".";
			this.botonHab = true;
		} else {
			this.mensaje = "Se produjo un error al generar la operación.";
			this.botonHab = true;
		}
	}

	public Acree getAcree() {
		return acree;
	}

	public void setAcree(Acree acree) {
		this.acree = acree;
	}

	public List<Acree> getAcrees() {
		return acrees;
	}

	public void setAcrees(List<Acree> acrees) {
		this.acrees = acrees;
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public void setDetalleO(SocDetallesope detalleO) {
		this.detalleO = detalleO;
	}

	public SocDetallesope getDetalleO() {
		return detalleO;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Integer idCuenta) {
		this.idCuenta = idCuenta;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco1(String banco1) {
		this.banco1 = banco1;
	}

	public String getBanco1() {
		return banco1;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setNombreF(String nombreF) {
		this.nombreF = nombreF;
	}

	public String getNombreF() {
		return nombreF;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public void setMon(String mon) {
		this.mon = mon;
	}

	public String getMon() {
		return mon;
	}

	public void setMon11(String mon11) {
		this.mon11 = mon11;
	}

	public String getMon11() {
		return mon11;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConcepto() {
		return concepto;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

}
