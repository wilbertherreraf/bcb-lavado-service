package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.Beneficiario;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBenefsloc;
import gob.bcb.bpm.pruebaCU.SocCuentasloc;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocSolbenefsloc;
import gob.bcb.bpm.pruebaCU.SocSolbenefslocId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SocBenefslocController extends BaseBeanController {
	private Logger log = Logger.getLogger(SocBenefslocController.class);

	private SocBenefsloc socBenefslocSearch = new SocBenefsloc();
	private CuentasBen cuentasBenSearch = new CuentasBen();
	private SocBenefsloc socBenefslocSelected = new SocBenefsloc();
	private SocCuentasloc socCuentaslocSelected = new SocCuentasloc();
	private List<SelectItem> socSolicitanteItems = new ArrayList<SelectItem>();
	private List<Beneficiario> beneficiariosLista = new ArrayList<Beneficiario>();
	private List<SocSolbenefsloc> socSolbenefslocLista = new ArrayList<SocSolbenefsloc>();
	private List<SocCuentasloc> socCuentaslocLista = new ArrayList<SocCuentasloc>();
	private List<CuentasBen> cuentasBenLista = new ArrayList<CuentasBen>();

	private List<SelectItem> socCuentassolItems = new ArrayList<SelectItem>();
	private List<SelectItem> monedaItems = new ArrayList<SelectItem>();
	private SocSolbenefsloc socSolbeneflocSelected = new SocSolbenefsloc();

	private String sIOCWEB_TIPOPERACION;

	@PostConstruct
	public void init() {
		log.info("PostConstruct SolicitudController - " + getClass().getName());
		try {
			recuperarVisit();
			inicializar();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		} finally {
			getVisit().removeParametro("SIOCWEB_TIPOPERACION");
			getVisit().removeParametro("SIOCWEB_CODBENL");
		}

	}

	private void inicializar() {
			String SIOCWEB_CODBENEF = (String) getVisit().getParametro("SIOCWEB_CODBENL");

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");

			recuperarListas();

			if (!StringUtils.isBlank(SIOCWEB_CODBENEF)) {
				recuperarBeneficiario(SIOCWEB_CODBENEF);
			} else {
				if (!StringUtils.isBlank(sIOCWEB_TIPOPERACION)) {
					if (sIOCWEB_TIPOPERACION.equals("NUEBENL")) {
						socSolbeneflocSelected = new SocSolbenefsloc();
					} 
				}
			}
			getVisit().removeParametro("SIOCWEB_TIPOPERACION");
			getVisit().removeParametro("SIOCWEB_CODBENL");

	}
	private void recuperarListas() {
		socSolicitanteItems = new ArrayList<SelectItem>();

		List<SocSolicitante> socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");

		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			socSolicitanteItems.add(new SelectItem("" + socSolicitante.getSolCodigo().trim() + "", socSolicitante.getSolPersona() + " ["
					+ socSolicitante.getSolCodigo() + "]"));
		}

		socCuentassolItems = new ArrayList<SelectItem>();
		List<SocCuentassol> socCuentassolList = getSolicitudBean().getSocCuentassolDao().getCtasParaBenefs();
		for (SocCuentassol cuentasS : socCuentassolList) {
			socCuentassolItems.add(new SelectItem(cuentasS.getCtaCodigo(), cuentasS.getCtaNommovimiento() + " - " + cuentasS.getCtaMovimiento() + " "
					+ cuentasS.getMoneda()));
		}

		monedaItems.add(new SelectItem(34, "DOLARES ESTADOUNIDENSES"));
		monedaItems.add(new SelectItem(69, "BOLIVIANOS"));
	}

	private void recuperarBeneficiario(String codBenef) {
		socBenefslocSelected = getSolicitudBean().getSocBenefslocDao().getBenefsByBenCodigo(codBenef);
		socCuentaslocLista = getSolicitudBean().getSocCuentaslocDao().findSocCuentasloc(null, codBenef, null, null, null);
		socSolbenefslocLista = getSolicitudBean().getSocSolbenefslocDao().getSocSolbenefslocByCodigo(null, codBenef);
		cuentasBenLista = getSolicitudBean().getSocBenefsDao().cuentasBenefLocal(null, codBenef, null, null, null, null, null);
	}

	private void recuperarBeneficiarios() {
		beneficiariosLista = getSolicitudBean().getSocBenefslocDao().beneficiarios(cuentasBenSearch.getBenNombre(), cuentasBenSearch.getBcoCodigo(),
				cuentasBenSearch.getCtaNroCuenta(), cuentasBenSearch.getMoneda(), null);
	}

	public void botonGuardarBenef() {
		try {
			socBenefslocSelected = getSolicitudBean().getSocBenefslocDao().guardarBenef(socBenefslocSelected);
			recuperarBeneficiario(socBenefslocSelected.getBenCodigo());
			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAgregarSolicitante() {
		try {
			log.info("botonAgregarSolicitante " + socBenefslocSelected.getBenCodigo());
			socSolbeneflocSelected = new SocSolbenefsloc();
			SocSolbenefslocId socSolbenefslocId = new SocSolbenefslocId();
			socSolbenefslocId.setBenCodigo(socBenefslocSelected.getBenCodigo());
			socSolbeneflocSelected.setId(socSolbenefslocId);
			socSolbeneflocSelected.setClaVigente(Short.valueOf("1"));
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonGuardarSolBenef() {
		try {
			socSolbeneflocSelected.setEstacion(getVisit().getAddress());
			socSolbeneflocSelected.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocSolbenefslocDao().saveOrUpdate(socSolbeneflocSelected);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBeneficiario(socBenefslocSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEliminarSolBenef(SocSolbenefsloc socSolbenefslocSel) {
		try {
			socSolbenefslocSel.setClaVigente(Short.valueOf("0"));
			socSolbenefslocSel.setEstacion(getVisit().getAddress());
			socSolbenefslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocSolbenefslocDao().saveOrUpdate(socSolbenefslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBeneficiario(socBenefslocSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonVigentarSolBenef(SocSolbenefsloc socSolbenefslocSel) {
		try {
			socSolbenefslocSel.setClaVigente(Short.valueOf("1"));
			socSolbenefslocSel.setEstacion(getVisit().getAddress());
			socSolbenefslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocSolbenefslocDao().saveOrUpdate(socSolbenefslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBeneficiario(socBenefslocSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAgregarCtaBenef() {
		try {
			socCuentaslocSelected = new SocCuentasloc();

			socCuentaslocSelected.setBenCodigo(socBenefslocSelected.getBenCodigo());
			socCuentaslocSelected.setClaVigente(Short.valueOf("1"));
			socCuentaslocSelected.setCveTconcepto(Constants.CVE_TCONCEPTO_VARIOS);

		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonGuardarCtaBenef() {
		try {
			socCuentaslocSelected.setEstacion(getVisit().getAddress());
			socCuentaslocSelected.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocCuentaslocDao().saveOrUpdate(socCuentaslocSelected);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBeneficiario(socBenefslocSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}
	public void botonEliminarCtaBenef(CuentasBen cuentasBen) {
		try {
			SocCuentasloc socCuentaslocSel = getSolicitudBean().getSocCuentaslocDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());
			
			socCuentaslocSel.setClaVigente(Short.valueOf("0"));
			socCuentaslocSel.setEstacion(getVisit().getAddress());
			socCuentaslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocCuentaslocDao().saveOrUpdate(socCuentaslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBeneficiario(socBenefslocSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonVigentarCtaBenef(CuentasBen cuentasBen) {
		try {
			SocCuentasloc socCuentaslocSel = getSolicitudBean().getSocCuentaslocDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());
			
			socCuentaslocSel.setClaVigente(Short.valueOf("1"));
			socCuentaslocSel.setEstacion(getVisit().getAddress());
			socCuentaslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocCuentaslocDao().guardar(socCuentaslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBeneficiario(socBenefslocSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}
	
	public void botonEditarCtaBenef(CuentasBen cuentasBen) {
		try {

			socCuentaslocSelected = getSolicitudBean().getSocCuentaslocDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());

		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonBuscar(){
		log.info("En buscar ");
		recuperarBeneficiarios();
	}

	public void irDetalle(Beneficiario beneficiario) {
		try {
			log.info("irDetalleSwift " + beneficiario.getBenCodigo());
			SocBenefsloc socBenefsloc = getSolicitudBean().getSocBenefslocDao().getBenefsByBenCodigo(beneficiario.getBenCodigo());

			if (socBenefsloc == null) {
				throw new BusinessException("Beneficiario inexistente " + beneficiario.getBenCodigo());
			}

			getVisit().setParametro("SIOCWEB_CODBENL", beneficiario.getBenCodigo());
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "VERBENL");
			irAPagina("/view/Parametros/socbenefsloc_det.xhtml");
			inicializar();

		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAgregarBenef() {
		try {
			log.info("botonAgregarBenef ");
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "NUEBENL");
			irAPagina("/view/Parametros/socbenefsloc_det.xhtml");
			inicializar();
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public SocBenefsloc getSocBenefslocSelected() {
		return socBenefslocSelected;
	}

	public void setSocBenefslocSelected(SocBenefsloc socBenefslocSelected) {
		this.socBenefslocSelected = socBenefslocSelected;
	}

	public List<Beneficiario> getBeneficiariosLista() {
		return beneficiariosLista;
	}

	public void setBeneficiariosLista(List<Beneficiario> beneficiariosLista) {
		this.beneficiariosLista = beneficiariosLista;
	}

	public SocCuentasloc getSocCuentaslocSelected() {
		return socCuentaslocSelected;
	}

	public void setSocCuentaslocSelected(SocCuentasloc socCuentaslocSelected) {
		this.socCuentaslocSelected = socCuentaslocSelected;
	}

	public List<SelectItem> getSocSolicitanteItems() {
		return socSolicitanteItems;
	}

	public void setSocSolicitanteItems(List<SelectItem> socSolicitanteItems) {
		this.socSolicitanteItems = socSolicitanteItems;
	}

	public List<SocSolbenefsloc> getSocSolbenefslocLista() {
		return socSolbenefslocLista;
	}

	public void setSocSolbenefslocLista(List<SocSolbenefsloc> socSolbenefslocLista) {
		this.socSolbenefslocLista = socSolbenefslocLista;
	}

	public List<SocCuentasloc> getSocCuentaslocLista() {
		return socCuentaslocLista;
	}

	public void setSocCuentaslocLista(List<SocCuentasloc> socCuentaslocLista) {
		this.socCuentaslocLista = socCuentaslocLista;
	}

	public List<CuentasBen> getCuentasBenLista() {
		return cuentasBenLista;
	}

	public void setCuentasBenLista(List<CuentasBen> cuentasBenLista) {
		this.cuentasBenLista = cuentasBenLista;
	}

	public SocSolbenefsloc getSocSolbeneflocSelected() {
		return socSolbeneflocSelected;
	}

	public void setSocSolbeneflocSelected(SocSolbenefsloc socSolbeneflocSelected) {
		this.socSolbeneflocSelected = socSolbeneflocSelected;
	}

	public SocBenefsloc getSocBenefslocSearch() {
		return socBenefslocSearch;
	}

	public void setSocBenefslocSearch(SocBenefsloc socBenefslocSearch) {
		this.socBenefslocSearch = socBenefslocSearch;
	}

	public CuentasBen getCuentasBenSearch() {
		return cuentasBenSearch;
	}

	public void setCuentasBenSearch(CuentasBen cuentasBenSearch) {
		this.cuentasBenSearch = cuentasBenSearch;
	}

	public List<SelectItem> getSocCuentassolItems() {
		return socCuentassolItems;
	}

	public void setSocCuentassolItems(List<SelectItem> socCuentassolItems) {
		this.socCuentassolItems = socCuentassolItems;
	}

	public List<SelectItem> getMonedaItems() {
		return monedaItems;
	}

	public void setMonedaItems(List<SelectItem> monedaItems) {
		this.monedaItems = monedaItems;
	}

}
