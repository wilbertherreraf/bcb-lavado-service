package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.Opecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.CuentasBen;


import gob.bcb.portal.menu.DropDownBean;import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;
import gob.bcb.service.servicioSioc.common.MensSwiftUtiles;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;

public class SolicitudesASFIntController extends BaseBeanController {

  private SocSolicitudes solicitud = new SocSolicitudes();
  private SocDetallessol detalle = new SocDetallessol();
  private List<SelectItem> solics = new ArrayList<SelectItem>();
  private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
  private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
  private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
  private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
  private Opecomi comision = new Opecomi();
  private List<Opecomi> comisiones = new ArrayList<Opecomi>();
  private List<Datosmen> listaCampos;
  private String usuario;
  private String nroOperacion;
  private String codIns;
  private String nroSolicitud = "";
  private String idSoli = "-1";
  private String idBenef = "-1";
  private String idCuenta = "-1";
  private String idCuentaC = "-1";
  private String benef = "";
  private String concepto = "";
  private String banco = "";
  private String plaza = "";
  private String info = "";
  private String mensaje = "";
  private BigDecimal total = BigDecimal.valueOf(0);
  private Boolean botonHab = true;
  private Boolean comiVer = false;
  private Boolean generada = true;
  private Date fechaValor;
  
  private String urlReporte;
  
  private Logger log = Logger.getLogger(SolicitudesASFIntController.class);
  private static final String CLIENTE = "cliente";
  private static final String CONSULTA = "consulta";
  private static final String BPMSIOC = "bpmPruebaCU";
  private static final String ESTACION = "";
  
  public SolicitudesASFIntController() {
    
    
recuperarVisit();
    usuario = 
getVisit().getUsuarioSession().getLogin();
    
    String query = "";
    
      idSoli = "-1";
      query = " select trim(sol_codigo) as cod, sol_persona "
        + " from soc_solicitante "
        + " where cla_entidad = 'SF' "
        + " and cla_vigente = 1"
        + " order by sol_persona";
    
    List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
    if (resultado1 != null)
    {
      for (Map<String, Object>res : resultado1)
      {
        
        solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
      }
    }
    else
    {
      log.info("Lista Nula");
    }
  }
    
  public List<SelectItem> getCuentasD()
  {
    log.info("enter getcuentasD");
    if (!idSoli.equals("-1"))
    {
      cuentasD.clear();
      
    String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
      + " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable "
      + " from soc_solcuentas sc, soc_cuentassol cc "
      + " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 "
      + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli + "'";
    
    List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
    if (resultado1.size() > 0)
    {
      for (Map<String, Object>res : resultado1)
      {
        
        if ((Integer) res.get("moneda") != 69)
          cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")));
        cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")));
      }
    }
    else
    {
      log.info("Lista Nula");
    }
    
    query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
        + "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
        + "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '" + idSoli + "'";

      List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
      if (resultado.size() == 1)
      {
        for (Map<String, Object>res : resultado)
        {
          
          idBenef = (String) res.get("ben_codigo");
          benef = (String) res.get("ben_nombre");
        }
      }
      else
      {
        log.info("Lista Nula");
      }
    }
    else
    {
      cuentasD.clear();
    }
    
    return cuentasD;
  }
  
  public List<SelectItem> getCuentasB()
  {
	  cuentasB.clear();
	  banco = "";
	  info = "";
	  String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
	      + " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta "
	      + " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
	      + " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
	      + " AND pp.bco_codigo = bb.bco_codigo AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

	    List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
	    if (resultado.size() > 0)
	    {
	      for (Map<String, Object>res1 : resultado)
	      {
	        log.info("resultado" + res1.toString());
	        cuentasB.add(new SelectItem(res1.get("cta_codigo"), res1.get("cta_nrocuenta") + "-" + res1.get("moneda")));
	        listaCuentasB.add(new CuentasBen((Integer) res1.get("cta_codigo"), (String) res1.get("cta_nrocuenta"), (String) res1.get("cta_info"),
	          (Integer) res1.get("moneda"), (String) res1.get("bco_nombre"), (String) res1.get("pla_nombre"), (String)res1.get("pla_bic"), 
	          (String) res1.get("pla_intermediario"), (String) res1.get("pla_nrocuenta")));
	      }
	    }
	    else
	    {
	      log.info("Lista Nula");
	    }
	    
	    return cuentasB;
  }
  
  public void seleccionChanged(ValueChangeEvent event)
  {
    Integer sel = (Integer) event.getNewValue();
    log.info("Valor seleccionado: " + sel);

    if (sel != -1)
    {
      for (CuentasBen cuentaB : listaCuentasB)
      {
        if (cuentaB.getCtaCodigo().compareTo(sel) == 0)
        {
          banco = cuentaB.getBcoNombre() + " - " + cuentaB.getPlaNombre();
          info = cuentaB.getCtaInfo();
        }
      }
    }
    else
    {
      banco = "";
      info = "";
    }
  }
  
  public void montoChanged(ValueChangeEvent event)
  {
    log.info("enter changed");
    Long montoL = (Long) event.getNewValue();
    Double montoD = montoL.doubleValue();
    setComiVer(true);
    calcularComisiones(BigDecimal.valueOf(montoD));
  }
  
  private void calcularComisiones(BigDecimal monto)
  {
    Date fecha = new Date();
    int monUS = 34;
    BigDecimal tc1 = BigDecimal.valueOf(0.00);
    comisiones.clear();
    total = BigDecimal.valueOf(0);
    
    Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
    mapaParametros1.put("fecha", fecha);
    mapaParametros1.put("moneda", monUS);
    mapaParametros1.put("consulta", "tc");

    String iid1 = new Long(new Date().getTime()).toString();

    // Metodo estatico que se encarga de manejar las consultas al servicio
    log.info("Llamando al servicio de coin: factor_conv_mn");
    Map<String, Object> mapaResultado1;
    try 
    {
      mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros1, iid1);
      tc1 = (BigDecimal) mapaResultado1.get("tc");
    } 
    catch (Exception e) {
     // TODO Auto-generated catch block
      e.printStackTrace();
    }

    BigDecimal comi = monto.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRF"))).
        divide(BigDecimal.valueOf(100))).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
    comision = new Opecomi();
    comision.setOcoMonto(comi.multiply(tc1).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
    comision.setDescripcion("TRANSFERENCIA AL EXTERIOR");
    comisiones.add(comision);
    total = total.add(comision.getOcoMonto());
    comision = new Opecomi();
    comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))));
    comision.setDescripcion("GASTOS DE COMUNICACION");
    comisiones.add(comision);
    total = total.add(comision.getOcoMonto());
    comision = new Opecomi();
    comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL"))));
    comision.setDescripcion("EMISI�N DE COMPROBANTES");
    comisiones.add(comision);
    total = total.add(comision.getOcoMonto());
  }
  
  private String cortarConcepto()
  {
    String concCortado = "";
    Boolean cortado = false;
    int i = 34;
    int j;
    String texto = "";
    String ln = System.getProperty("line.separator");

    if (concepto.length() > 35)
    {
      texto = concepto;
      do 
      {
        if (concepto.charAt(i) == ' ' || concepto.charAt(i) == '.' || concepto.charAt(i) == ',')
        {
        texto = concepto.substring(0, i) + ln + concepto.substring(i + 1);
        cortado = true;
        }
        i--;
      } while (!cortado);

      concCortado = texto;
      log.debug("Cortado: " + concCortado);
      j = texto.indexOf(ln);
      texto = concCortado.substring(j + ln.length());
      log.debug("texto: " + texto);
      if (texto.length() > 35)
      {
        cortado = false;
        i = 34;
        do
        {
          if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',')
          {
            texto = texto.substring(0, i) + ln + texto.substring(i + 1);
            cortado = true;
          }
          i--;
        } while (!cortado);
         concCortado = concCortado.substring(0, j + ln.length()) + texto;
         log.debug("Cortado: " + concCortado);
         j = texto.indexOf(ln);
         texto = texto.substring(j + ln.length());
         log.debug("texto: " + texto);
         if (texto.length() > 35)
         {
           cortado = false;
           i = 34;
           do
           {
             if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',')
             {
               texto = texto.substring(0, i) + ln + texto.substring(i + 1);
               cortado = true;
             }
             i--;
           } while (!cortado);
           i = concCortado.indexOf(ln);
           j = concCortado.indexOf(ln, i + 1);
           concCortado = concCortado.substring(0, j + ln.length()) + texto;
           log.debug("Cortado: " + concCortado);
           j = texto.indexOf(ln);
           texto = texto.substring(j + ln.length());
           log.debug("texto: " + texto);
           if (texto.length() > 35)
           {
             concCortado = "-1";
          }
        }
      }
    }
    else
    {
    concCortado = concepto;
    }
    
    return concCortado;
  }
  
  public SocSolicitudes getSolicitud() {
    return solicitud;
  }

  public void setSolicitud(SocSolicitudes solicitudTest) {
    this.solicitud = solicitudTest;
  }
  
  public SocDetallessol getDetalle() {
    return detalle;
  }

  public void setDetalle(SocDetallessol detalle) {
    this.detalle = detalle;
  }
  
  public List<SelectItem> getSolics()
  {
    return solics;
  }
  
  public void setSolics(List<SelectItem> solics)
  {
    this.solics = solics;
  }
  
  /*public List<SelectItem> getCuentasD()
  {
    return cuentasD;
  }*/
  
  public void setCuentasD(List<SelectItem> cuentasD)
  {
    this.cuentasD = cuentasD;
  }
  
  public List<SelectItem> getCuentasC()
  {
    return cuentasC;
  }
  
  public void setCuentasC(List<SelectItem> cuentasC)
  {
    this.cuentasC = cuentasC;
  }
  
  /*public List<SelectItem> getCuentasB()
  {
    return cuentasB;
  }*/
  
  public void setCuentasB(List<SelectItem> cuentasB)
  {
    this.cuentasB = cuentasB;
  }
  
  public List<CuentasBen> getListaCuentasB() {
    return listaCuentasB;
  }

  public void setListaCuentasB(List<CuentasBen> listaCuentasB) {
    this.listaCuentasB = listaCuentasB;
  }

  public void setComision(Opecomi comision) {
    this.comision = comision;
  }

  public Opecomi getComision() {
    return comision;
  }

  public void setComisiones(List<Opecomi> comisiones) {
    this.comisiones = comisiones;
  }

  public List<Opecomi> getComisiones() {
    return comisiones;
  }
  
  public List<Datosmen> getListaCampos() {
    return listaCampos;
  }
  
  public void setListaCampos(List<Datosmen> listaCampos) {
    this.listaCampos = listaCampos;
  }
  
  public String getIdSoli() {
	return idSoli;
}

public void setIdSoli(String idSoli) {
	this.idSoli = idSoli;
}

public String getIdBenef()
  {
    return idBenef;
  }

  public void setIdBenef(String idBenef)
  {
    this.idBenef = idBenef;
  }
  
  public String getBenef()
  {
    return benef;
  }

  public void setBenef(String benef)
  {
    this.benef = benef;
  }
  
  public String getIdCuenta()
  {
    return idCuenta;
  }

  public void setIdCuenta(String idCuenta)
  {
    this.idCuenta = idCuenta;
  }
  
  public String getIdCuentaC()
  {
    return idCuentaC;
  }

  public void setIdCuentaC(String idCuentaC)
  {
    this.idCuentaC = idCuentaC;
  }
  
  public String getBanco() {
    return banco;
  }

  public void setBanco(String banco) {
    this.banco = banco;
  }

  public String getPlaza() {
    return plaza;
  }

  public void setPlaza(String plaza) {
    this.plaza = plaza;
  }

  public String getConcepto() {
    return concepto;
  }

  public void setConcepto(String concepto) {
    this.concepto = concepto;
  }

  public String getInfo() {
    return info;
  }

  public void setInfo(String info) {
    this.info = info;
  }

  public String getMensaje() {
    return mensaje;
  }

  public void setTotal(BigDecimal total) {
    this.total = total;
  }

  public BigDecimal getTotal() {
    return total;
  }
  
  public void setMensaje(String mensaje) {
    this.mensaje = mensaje;
  }
  
  public Boolean getBotonHab() {
    return botonHab;
  }

  public void setBotonHab(Boolean botonHab) {
    this.botonHab = botonHab;
  }
  
  public void setComiVer(Boolean comiVer) {
    this.comiVer = comiVer;
  }

  public Boolean getComiVer() {
    return comiVer;
  }

  public void setGenerada(Boolean generada) {
    this.generada = generada;
  }

  public Boolean getGenerada() {
    return generada;
  }
  
  public Date getFechaValor() {
    return fechaValor;
  }

  public void setFechaValor(Date fechaValor) {
    this.fechaValor = fechaValor;
  }

 
  public String getUrlReporte() {
    urlReporte = getRaiz() + "reporte?cod=" + codIns + "&tipo=SW";
    return urlReporte;
  }

  public void setUrlReporte(String urlReporte) {
    this.urlReporte = urlReporte;
  }
  
  /**
   * 
   * Metodo que responde al evento de guardado del formulario
   * 
   * @throws Exception 
   */
  public void eventoGuardarBtn(ActionEvent action) throws Exception
  {
    log.info("Ingresando al boton Guardar");

    if (MensSwiftUtiles.validarConcepto(concepto) > 0)
    {
      concepto = this.cortarConcepto();
      if (!concepto.equals("-1"))
      {
        DateTime fecha = new DateTime();
        DateTime fechaV = new DateTime(fechaValor);
        log.debug("fecha: " + fecha);
        log.debug("valor: " + fechaV);
        
        if (fechaV.getDayOfMonth() >= fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear() && fechaV.getYear() == fecha.getYear())
        {
        solicitud.setSolCodigo(idSoli + "   ");
        solicitud.setClaTipo("TE");
        solicitud.setClaEstado('I');
        solicitud.setSocCuentad(Integer.parseInt(idCuenta));
        solicitud.setSocCuentac(Integer.parseInt(idCuentaC));
        solicitud.setMoneda("USD");
        solicitud.setMonedaT("USD");
        solicitud.setSocMontoord(BigDecimal.valueOf(0));
        detalle.setBenCodigo(idBenef);
        detalle.setDetMonto(solicitud.getSocMontome());
        detalle.setDetMontoord(solicitud.getSocMontoord());
        detalle.setMoneda(solicitud.getMoneda());
    
        detalle.setDetConcepto(concepto.toUpperCase());
        detalle.setDetInfo(info);

        Date date = new Date();
        long time = date.getTime();
        log.info("Creando el objeto Request para enviar al BPM");

        // parametros para request
        String id = new Long(time).toString();
    
        // mapa de parametros a enviar a BPM
        Map<String, Object> mapaParametros = new HashMap<String, Object>();
        mapaParametros.put("opcion", "nuevaInt");
        mapaParametros.put("solicitud", solicitud);
        mapaParametros.put("detalle", detalle);
        mapaParametros.put("fecha", fechaValor);
        mapaParametros.put("usuario", usuario);

        // Metodo estatico que se encarga de manejar las consultas al BPM
        Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);if (mapaRespuesta.containsKey("resp_msgerror")){mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");return;}

        nroOperacion = (String) mapaRespuesta.get("nroOperacion");
        codIns = (String) mapaRespuesta.get("nroInst");

        if (!nroOperacion.equals("0000"))
        {
          log.info("Numero de Operación asignada desde el BPM: " + nroOperacion);

          setGenerada(true);
        
          this.listaCampos = new ArrayList<Datosmen>();
        
          String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre "
            + " from soc_datosmen d, soc_campos c "
            + " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'"
            + " and d.ins_codigo = '" + codIns + "'";
        
          List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
          if (resultado1 != null)
          {
            for (Map<String, Object>res : resultado1)
            {
              log.debug("resultado" + res.toString());
       
              String ln = System.getProperty("line.separator");
              
                String alto;
                String valor = "";
                String valor1 = (String) res.get("dam_valor");
                if (res.get("cam_codigo").equals(":32A"))
                {
                  valor = valor1;
                  valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
                }
          
                if (res.get("cam_codigo").equals(":33B"))
                {
                  valor = valor1;
                  valor1 = valor.substring(0, 3) + ln + valor.substring(3);
                }
          
                int i = StringUtils.countMatches(valor1, ln);
                i = (i + 1) * 16;
                alto = " height : " + i + "px;";
          
                listaCampos.add(new Datosmen ((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto, (String) res.get("cam_nombre")));
            }
          }
          else
          {
            log.info("Lista Nula");
          }
      }
        else
        {
          log.info("No se pudo generar la operación.");
          mensaje = "No se pudo generar la operación. No existe tipo de cambio para la fecha especificada.";
          setGenerada(false);
        }
      }
      else
      {
        log.info("No se puede generar la operación con fecha anterior.");
      mensaje = "No se puede generar la operación con fecha valor anterior a la fecha actual.";
      setGenerada(false);
      }
      }
      else
      {
        this.mensaje = "El concepto de la transferencia excede la longitud permitida para este campo.";
        this.botonHab = false;
      }
    }
    else
    {
      this.mensaje = "Existen caracteres no válidos en el concepto de la transferencia.";
      this.botonHab = false;
    }
  }

}
