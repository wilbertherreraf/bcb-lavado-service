/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

//import java.math.BigDecimal;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.OperacionesS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class OperacionesModController extends BaseBeanController {
	private SocOperaciones operacion = new SocOperaciones();
	private OperacionesS operacionS = new OperacionesS();
	private SocDetallesope detalleO = new SocDetallesope();
	private CuentasBen cuentaBen = new CuentasBen();

	private List<SelectItem> benefs = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();

	private List<SocOperaciones> operaciones;
	private List<OperacionesS> listaOper;
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> referencias = new ArrayList<SelectItem>();
	private String mensaje = "";
	private String nroOperacion;
	private String idMoneda = "";
	private String idBenef = "-1";
	private String idRefer = "-1";
	private Integer idCuenta = -1;
	private String moneda;
	private String cuentaD = "";
	private String cuentaC = "";
	private String cuentaB = "";
	private String cuentaBC = "";
	private String nombre = "";
	private String nombreF = "";
	private String nit = "";
	private String banco = "";
	private String banco1 = "";
	private String cuenta = "";
	private String monC = "";
	private String mon11 = "";
	private String nroCuenta = "";
	private String men = "";
	private String concepto = "";
	private String usuario;
	private BigDecimal montoMN;
	private Boolean swiftVer = true;
	private Boolean interVer = false;
	private Boolean nroVer = false;
	private Boolean nroCVer = false;
	private Boolean extVer = true;
	private Boolean localVer = false;
	private Boolean opVer = true;
	private Boolean swVer = true;
	private Boolean cuentaHab = false;

	private Logger log = Logger.getLogger(OperacionesModController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	public OperacionesModController() {

		recuperarVisit();
		usuario = getVisit().getUsuarioSession().getLogin();

		this.recuperarOperaciones();
	}

	private void recuperarOperaciones() {
		this.operaciones = new ArrayList<SocOperaciones>();
		this.listaOper = new ArrayList<OperacionesS>();

		String query = " select o.*, ss.sol_persona " + " from soc_operaciones o, soc_solicitante ss " + " where o.sol_codigo = ss.sol_codigo"
				+ " and o.cla_estado = 'P'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				operacionS = new OperacionesS((String) res.get("ope_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_operacion"), (Integer) res.get("moneda"), 'P', (Date) res.get("ope_fecha"),
						(BigDecimal) res.get("ope_montome"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("ope_montomn"), "");

				if (operacionS.getClaOperacion().equals("TD")) {
					operacionS.setTipo("TRANSFERENCIA DEL EXTERIOR");
					if (operacionS.getSolCodigo() != null && operacionS.getSolCodigo().trim().equals("900")) {
						if (operacionS.getSocCorrelativo() != null) {
							if (operacionS.getSocCorrelativo().indexOf("(CC:H-", 0) < 0)
								operacionS.setSolicitante("EXPORTADORES");
							else
								operacionS.setSolicitante("ACREEDORES");
						} else {
							operacionS.setSolicitante("EXPORTADORES");
						}
						operacionS.setPanel1(false);
						operacionS.setPanel2(false);
						operacionS.setPanel3(false);
						operacionS.setPanel4(true);
						operacionS.setPanel5(false);
					} else {
						operacionS.setPanel1(false);
						operacionS.setPanel2(false);
						operacionS.setPanel3(false);
						operacionS.setPanel4(false);
						operacionS.setPanel5(true);
					}
				}

				listaOper.add(operacionS);

				operacion = new SocOperaciones((String) res.get("ope_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_operacion"),
						(Date) res.get("ope_fecha"), (BigDecimal) res.get("ope_montome"), (BigDecimal) res.get("ope_montomn"),
						(Integer) res.get("moneda"), (Integer) res.get("ope_ctaoperacion"), (Integer) res.get("ope_ctacomision"),
						(String) res.get("usr_codigo"), (Date) res.get("fecha_hora"), (String) res.get("estacion"), 'P',
						(String) res.get("ope_nrocuentac"), (String) res.get("soc_correlativo"), (String) res.get("ope_nrocuentad"));
				operaciones.add(operacion);

			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void verOperacion(ActionEvent event) {
		log.info("enter ver");
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.operacion = this.operaciones.get(fila);
		this.operacionS = this.listaOper.get(fila);
		nroOperacion = operacion.getOpeCodigo();
		log.info("resultado:" + nroOperacion);

		monedas.add(new SelectItem("USD", "DOLARES ESTADOUNIDENSES"));

		String query = " select d.* " + " from soc_detallesope d " + " where d.ope_codigo = '" + nroOperacion + "'" + " and d.det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {

				detalleO = new SocDetallesope(new SocDetallesopeId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ins_codigo"), (String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"),
						(Integer) res.get("moneda"), (String) res.get("det_ctabenef"), (String) res.get("det_concepto"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("det_info"), (String) res.get("det_facturas"));
			}
		} else {
			log.info("Lista Nula");
		}

		if (operacion.getOpeCtaoperacion() != null) {
			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ operacion.getOpeCtaoperacion() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
				}
			} else {
				log.info("Lista Nula");
			}
		}

		if (operacion.getOpeCtaoperacion() != null)
			setNroVer(true);
		else
			setNroVer(false);

		if (operacion.getOpeCtacomision() != null) {
			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ operacion.getOpeCtacomision() + "'";

			List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
			if (resultadoC.size() == 1) {
				for (Map<String, Object> res : resultadoC) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
				}
			} else {
				log.info("Lista Nula");
			}
		}

		if (operacion.getClaOperacion().equals("TD")) // transferencia delext
		{
			if (operacion.getSolCodigo() != null && operacion.getSolCodigo().trim().equals("900")) // exportadores
			{
				referencias.add(new SelectItem("MS", "MENSAJE SWIFT"));
				referencias.add(new SelectItem("EB", "EXTRACTO BANCARIO"));

				query = " select ben_codigo, ben_nombre " + " from soc_benefsexp " + " where cla_vigente = 1" + " order by ben_nombre";

				List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
				if (resultado2 != null) {
					for (Map<String, Object> res : resultado2) {
						//
						benefs.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
					}
				} else {
					log.info("Lista Nula");
				}

				idMoneda = "USD";
				idBenef = detalleO.getBenCodigo();
				this.getCuentasD();
				idCuenta = Integer.parseInt(detalleO.getDetCtabenef().trim());
				concepto = detalleO.getDetConcepto();
				men = detalleO.getDetInfo();
				if (men != null) {
					idRefer = "MS";
				} else {
					idRefer = "EB";
				}

				query = " select d.*, b.ben_nombre, b.ben_nit, b.ben_factura, c.cta_nrocuenta, c.moneda, s.sol_persona "
						+ " from soc_detallesope d, soc_benefsexp b, soc_cuentasexp c, soc_solicitante s " + " where d.ope_codigo = '" + nroOperacion
						+ "'" + " and d.det_codigo = 1" + " and d.ben_codigo = b.ben_codigo " + " and d.det_ctabenef = c.cta_codigo "
						+ " and c.bco_codigo = s.sol_codigo";

				List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
				if (resultado3.size() > 0) {
					for (Map<String, Object> res : resultado3) {

						nombre = (String) res.get("ben_nombre");
						cuentaB = (String) res.get("cta_nrocuenta");
						banco = (String) res.get("sol_persona");
						Integer mon = (Integer) res.get("moneda");
						if (mon == 34)
							setMonC("DOLARES ESTADOUNIDENSES");
						else
							setMonC("BOLIVIANOS");
						nombreF = (String) res.get("ben_factura");
						nit = (String) res.get("ben_nit");
					}
				} else {
					log.info("Lista Nula");
				}
				setExtVer(true);
			} else
			// sector p�blico
			{
				nroCuenta = Servicios.getNroCuenta(operacion.getSolCodigo(), operacion.getOpeCtaoperacion());
			}
		}

	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		if (!idBenef.equals("-1")) {
			cuentasD.clear();

			String query = " select cta_codigo, cta_nrocuenta" + " from soc_cuentasexp " + " where cla_vigente = 1 and ben_codigo = '" + idBenef
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					// log.debug("resultado" + res.toString());
					cuentasD.add(new SelectItem(res.get("cta_codigo"), (String) res.get("cta_nrocuenta")));
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		idCuenta = sel;
		log.info("Valor seleccionado: " + sel);

		if (idCuenta != -1) {
			String query = " select c.bco_codigo, c.moneda, s.sol_persona, c.bco_codigo1" + " from soc_cuentasexp c, soc_solicitante s"
					+ " where c.cla_vigente = 1 and c.cta_codigo = '" + idCuenta + "'" + " and c.bco_codigo = s.sol_codigo";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					//
					banco = (String) res.get("sol_persona");
					Integer mon1 = (Integer) res.get("moneda");
					if (mon1 == 34)
						monC = "DOLARES ESTADOUNIDENSES";
					else
						monC = "BOLIVIANOS";
					String bco = (String) res.get("bco_codigo1");
					if (bco != null) {
						query = " select c.bco_codigo1, c.moneda1, s.sol_persona, c.cta_nrocuenta1" + " from soc_cuentasexp c, soc_solicitante s"
								+ " where c.cla_vigente = 1 and c.cta_codigo = '" + idCuenta + "'" + " and c.bco_codigo1 = s.sol_codigo";
						List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
						if (resultado2.size() == 1) {
							for (Map<String, Object> res2 : resultado2) {
								log.info("resultado" + res2.toString());
								setBanco1((String) res2.get("sol_persona"));
								setCuenta((String) res2.get("cta_nrocuenta1"));
								mon1 = (Integer) res2.get("moneda1");
								if (mon1 == 34)
									setMon11("DOLARES ESTADOUNIDENSES");
								else
									setMon11("BOLIVIANOS");
								setCuentaHab(true);
							}
						}
					} else {
						setCuentaHab(false);
					}
				}
			} else {
				banco = "";
				monC = "";
				log.info("Lista Nula");
			}
		}
	}

	public void seleccion2Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idRefer = sel;
		log.info("Valor seleccionado: " + sel);

		if (!idRefer.equals("-1")) {
			if (idRefer.equals("MS")) {
				swiftVer = true;
			} else {
				swiftVer = false;
				concepto = "EXTRACTO BANCARIO DE FECHA ";
			}
		} else {
			swiftVer = false;
		}
	}

	public void swiftChanged(ValueChangeEvent event) {
		log.info("enter changed");
		men = (String) event.getNewValue();

		concepto = "MENSAJE SWIFT " + men + " DE LA FECHA ";
	}

	public void seleccionBChanged(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idBenef = sel;
		log.info("Valor seleccionado: " + sel);

		if (!idBenef.equals("-1")) {
			String query = " select ben_factura, ben_nit" + " from soc_benefsexp" + " where cla_vigente = 1 and ben_codigo = '" + idBenef + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					//
					nombreF = (String) res.get("ben_factura");
					nit = (String) res.get("ben_nit");
				}
			} else {
				nombreF = "";
				nit = "";
				log.info("Lista Nula");
			}
		}
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Modificando la operación: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "modificarTDE");
		mapaParametros.put("operacion", operacion);
		mapaParametros.put("detalle", detalleO);
		mapaParametros.put("usuario", usuario);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String nroOpe = (String) mapaRespuesta.get("nroOperacion");
		log.info("Numero de Operacion: " + nroOpe);

		if (!nroOpe.equals("0000")) {
			this.mensaje = "La operación se generó correctamente con el número " + nroOpe + ".";
			// this.botonHab = true;
		} else {
			this.mensaje = "Se produjo un error al generar la operación.";
			// this.botonHab = true;
		}

		this.recuperarOperaciones();

	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public OperacionesS getOperacionS() {
		return operacionS;
	}

	public void setOperacionS(OperacionesS operacionS) {
		this.operacionS = operacionS;
	}

	public SocDetallesope getDetalleO() {
		return detalleO;
	}

	public void setDetalleO(SocDetallesope detalleO) {
		this.detalleO = detalleO;
	}

	public List<SelectItem> getBenefs() {
		return benefs;
	}

	public void setBenefs(List<SelectItem> benefs) {
		this.benefs = benefs;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public List<SocOperaciones> getOperaciones() {
		return operaciones;
	}

	public void setOperaciones(List<SocOperaciones> operaciones) {
		this.operaciones = operaciones;
	}

	public List<OperacionesS> getListaOper() {
		return listaOper;
	}

	public void setListaOper(List<OperacionesS> listaOper) {
		this.listaOper = listaOper;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public List<SelectItem> getReferencias() {
		return referencias;
	}

	public void setReferencias(List<SelectItem> referencias) {
		this.referencias = referencias;
	}

	public String getNroOperacion() {
		return nroOperacion;
	}

	public void setNroOperacion(String nroOperacion) {
		this.nroOperacion = nroOperacion;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public void setCuentaB(String cuentaB) {
		this.cuentaB = cuentaB;
	}

	public String getCuentaB() {
		return cuentaB;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Integer idCuenta) {
		this.idCuenta = idCuenta;
	}

	public String getIdRefer() {
		return idRefer;
	}

	public void setIdRefer(String idRefer) {
		this.idRefer = idRefer;
	}

	public String getIdMoneda() {
		return idMoneda;
	}

	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setNombreF(String nombreF) {
		this.nombreF = nombreF;
	}

	public String getNombreF() {
		return nombreF;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getBanco() {
		return banco;
	}

	public String getBanco1() {
		return banco1;
	}

	public void setBanco1(String banco1) {
		this.banco1 = banco1;
	}

	public void setMontoMN(BigDecimal montoMN) {
		this.montoMN = montoMN;
	}

	public BigDecimal getMontoMN() {
		return montoMN;
	}

	public void setMonC(String monC) {
		this.monC = monC;
	}

	public String getMonC() {
		return monC;
	}

	public String getMon11() {
		return mon11;
	}

	public void setMon11(String mon11) {
		this.mon11 = mon11;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public void setCuentaBC(String cuentaBC) {
		this.cuentaBC = cuentaBC;
	}

	public String getCuentaBC() {
		return cuentaBC;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getMen() {
		return men;
	}

	public void setMen(String men) {
		this.men = men;
	}

	public Boolean getSwiftVer() {
		return swiftVer;
	}

	public void setSwiftVer(Boolean swiftVer) {
		this.swiftVer = swiftVer;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setNroVer(Boolean nroVer) {
		this.nroVer = nroVer;
	}

	public Boolean getNroVer() {
		return nroVer;
	}

	public void setNroCVer(Boolean nroCVer) {
		this.nroCVer = nroCVer;
	}

	public Boolean getNroCVer() {
		return nroCVer;
	}

	public void setExtVer(Boolean extVer) {
		this.extVer = extVer;
	}

	public Boolean getExtVer() {
		return extVer;
	}

	public void setLocalVer(Boolean localVer) {
		this.localVer = localVer;
	}

	public Boolean getLocalVer() {
		return localVer;
	}

	public void setOpVer(Boolean opVer) {
		this.opVer = opVer;
	}

	public Boolean getOpVer() {
		return opVer;
	}

	public void setSwVer(Boolean swVer) {
		this.swVer = swVer;
	}

	public Boolean getSwVer() {
		return swVer;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
