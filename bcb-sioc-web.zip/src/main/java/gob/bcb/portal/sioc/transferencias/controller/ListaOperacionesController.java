/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

//import java.math.BigDecimal;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.Opecomi;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.OperacionesS;
import gob.bcb.portal.sioc.transferencias.model.Venta;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.commons.lang.SerializationUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 *
 * @author Cecilia Uriona
 *
 */
public class ListaOperacionesController {
	private SocOperaciones operacion = new SocOperaciones();
	private OperacionesS operacionS = new OperacionesS();
	private SocDetallesope detalleO = new SocDetallesope();
	private CuentasBen cuentaBen = new CuentasBen();
	private List<SocOperaciones> operaciones;
	private List<OperacionesS> listaOper;
	private Opecomi comision;
	private List<Opecomi> comisiones;
	private Venta venta;
	private List<Venta> ventas;

	private String nroOperacion;
	private String moneda;
	private String cuentaD = "";
	private String cuentaC = "";
	private String cuentaB = "";
	private String cuentaBC = "";
	private String nombre = "";
	private String nombreF = "";
	private String banco = "";
	private String label1 = "BIC:";
	private String bic = "";
	private String monC = "";
	private String subtipo = "";
	private String mensaje = "";
	private String nroCuenta = "";
	private BigDecimal comis;
	private BigDecimal comisU;
	private BigDecimal montoMN;
	private BigDecimal montoEquiv;
	private BigDecimal diff = BigDecimal.valueOf(0.00);
	private Boolean interVer = false;
	private Boolean nroVer = false;
	private Boolean nroCVer = false;
	private Boolean extVer = true;
	private Boolean localVer = false;
	private Boolean opVer = true;
	private Boolean equiv = false;
	private String subTipo;

	private Logger log = Logger.getLogger(ListaOperacionesController.class);

	public ListaOperacionesController() {
		this.recuperarOperaciones();

	}

	private void recuperarOperaciones() {
		this.operaciones = new ArrayList<SocOperaciones>();
		this.listaOper = new ArrayList<OperacionesS>();

		String query = " select o.*, ss.sol_persona " + " from soc_operaciones o, soc_solicitante ss " + " where o.sol_codigo = ss.sol_codigo"
				+ " and o.cla_estado = '1'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				operacionS = new OperacionesS((String) res.get("ope_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_operacion"), (Integer) res.get("moneda"), '1', (Date) res.get("ope_fecha"),
						(BigDecimal) res.get("ope_montome"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("ope_montomn"), "");

				if (operacionS.getClaOperacion().equals("TE") || operacionS.getClaOperacion().equals("OB")) {
					operacionS.setTipo("TRANSFERENCIA AL EXTERIOR");
					operacionS.setPanel1(true);
					operacionS.setPanel2(false);
					operacionS.setPanel3(false);
					operacionS.setPanel4(false);
					operacionS.setPanel5(false);
				} else {
					if (operacionS.getClaOperacion().equals("VE")) {
						operacionS.setTipo("VENTA DE DIVISAS");
						operacionS.setPanel1(false);
						operacionS.setPanel2(true);
						operacionS.setPanel3(false);
						operacionS.setPanel4(false);
						operacionS.setPanel5(false);
					} else {
						if (operacionS.getClaOperacion().equals("TC")) {
							operacionS.setTipo("TRANSFERENCIA CUENTA A CUENTA");
							operacionS.setPanel1(false);
							operacionS.setPanel2(false);
							operacionS.setPanel3(true);
							operacionS.setPanel4(false);
							operacionS.setPanel5(false);
						} else {
							if (operacionS.getClaOperacion().equals("TD")) {
								operacionS.setTipo("TRANSFERENCIA DEL EXTERIOR");
								if (operacionS.getSolCodigo() != null && operacionS.getSolCodigo().trim().equals("900")) {
									if (operacionS.getSocCorrelativo() != null) {
										if (operacionS.getSocCorrelativo().indexOf("(CC:H-", 0) < 0)
											operacionS.setSolicitante("EXPORTADORES");
										else
											operacionS.setSolicitante("ACREEDORES");
									} else {
										operacionS.setSolicitante("EXPORTADORES");
									}
									operacionS.setPanel1(false);
									operacionS.setPanel2(false);
									operacionS.setPanel3(false);
									operacionS.setPanel4(true);
									operacionS.setPanel5(false);
								} else {
									operacionS.setPanel1(false);
									operacionS.setPanel2(false);
									operacionS.setPanel3(false);
									operacionS.setPanel4(false);
									operacionS.setPanel5(true);
								}
							}
						}
					}
				}

				listaOper.add(operacionS);

				operacion = new SocOperaciones((String) res.get("ope_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_operacion"),
						(Date) res.get("ope_fecha"), (BigDecimal) res.get("ope_montome"), (BigDecimal) res.get("ope_montomn"),
						(Integer) res.get("moneda"), (Integer) res.get("ope_ctaoperacion"), (Integer) res.get("ope_ctacomision"), '1',
						(String) res.get("ope_nrocuentac"), (String) res.get("soc_correlativo"), (String) res.get("ope_nrocuentad"));
				operaciones.add(operacion);
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void verOperacion(ActionEvent event) {
		log.info("enter ver");
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.operacion = this.operaciones.get(fila);
		this.operacionS = this.listaOper.get(fila);
		nroOperacion = operacion.getOpeCodigo();
		log.info("resultado" + nroOperacion);

		String query = " select d.* " + " from soc_detallesope d " + " where d.ope_codigo = '" + nroOperacion + "'" + " and d.det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {

				detalleO = new SocDetallesope(new SocDetallesopeId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ins_codigo"), (String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"),
						(Integer) res.get("moneda"), (String) res.get("det_ctabenef"), (String) res.get("det_concepto"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("det_info"), (String) res.get("det_facturas"));
			}
		} else {
			log.info("Lista Nula");
		}

		if (operacion.getOpeCtaoperacion() != null) {
			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ operacion.getOpeCtaoperacion() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
				}
			} else {
				log.info("Lista Nula");
			}
		}

		if (operacion.getOpeCtaoperacion() != null)
			setNroVer(true);
		else
			setNroVer(false);

		if (operacion.getOpeCtacomision() != null) {
			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ operacion.getOpeCtacomision() + "'";

			List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
			if (resultadoC.size() == 1) {
				for (Map<String, Object> res : resultadoC) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
				}
			} else {
				log.info("Lista Nula");
			}
		}

		if (operacion.getClaOperacion().equals("TC")) // transferencia local
		{
			query = " select d.*, b.ben_nombre, b.ben_nit, b.ben_factura, c.cta_nrocuenta, c.moneda, c.cta_nrocuenta1, s.cta_nommovimiento "
					+ " from soc_detallesope d, soc_benefsloc b, soc_cuentasloc c, soc_cuentassol s " + " where d.ope_codigo = '" + nroOperacion
					+ "'" + " and d.det_codigo = 1" + " and d.ben_codigo = b.ben_codigo " + " and d.det_ctabenef = c.cta_codigo "
					+ " and c.cta_ctacodigo = s.cta_codigo";

			List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
			if (resultado2.size() > 0) {
				for (Map<String, Object> res : resultado2) {

					nombre = (String) res.get("ben_nombre");
					cuentaB = (String) res.get("cta_nrocuenta");
					cuentaBC = (String) res.get("cta_nrocuenta1");
					if (cuentaBC != null)
						opVer = true;
					else
						opVer = false;
					banco = (String) res.get("cta_nommovimiento");
					nombreF = (String) res.get("ben_factura");
					bic = (String) res.get("ben_nit");
				}
			} else {
				log.info("Lista Nula");
			}

			if (operacion.getOpeCtacomision() != null) {
				setLocalVer(true);
				setExtVer(false);
			} else {
				setLocalVer(false);
				setExtVer(true);
			}
		} else {
			if (operacion.getClaOperacion().equals("TD")) // transferencia
															// delext
			{
				if (operacion.getSolCodigo().equals("900   ")) // exportadores
				{
					if (detalleO.getBenCodigo().equals("9999"))
						subTipo = "CC";

					query = " select d.*, b.ben_nombre, b.ben_nit, b.ben_factura, c.cta_nrocuenta, c.moneda, s.sol_persona "
							+ " from soc_detallesope d, soc_benefsexp b, soc_cuentasexp c, soc_solicitante s " + " where d.ope_codigo = '"
							+ nroOperacion + "'" + " and d.det_codigo = 1" + " and d.ben_codigo = b.ben_codigo "
							+ " and d.det_ctabenef = c.cta_codigo " + " and c.bco_codigo = s.sol_codigo";

					List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
					if (resultado2.size() > 0) {
						for (Map<String, Object> res : resultado2) {

							nombre = (String) res.get("ben_nombre");
							cuentaB = (String) res.get("cta_nrocuenta");
							banco = (String) res.get("sol_persona");
							Integer mon = (Integer) res.get("moneda");
							if (mon == 34)
								setMonC("DOLARES ESTADOUNIDENSES");
							else
								setMonC("BOLIVIANOS");
							nombreF = (String) res.get("ben_factura");
							bic = (String) res.get("ben_nit");
						}
					} else {
						log.info("Lista Nula");
					}
					setExtVer(true);
				} else
				// sector p�blico
				{
					setNroCuenta(Servicios.getNroCuenta(operacion.getSolCodigo(), operacion.getOpeCtaoperacion()));
				}
			} else {
				if (operacion.getClaOperacion().equals("TE") || operacionS.getClaOperacion().equals("OB")) // TRANSFERENCIA
																											// AL
																											// EXTERIOR
				{
					query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
							+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
							+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND ss.sol_codigo = '" + operacion.getSolCodigo() + "' "
							+ "AND trim(ss.ben_codigo) = '" + detalleO.getBenCodigo() + "'";

					List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
					if (resultado.size() == 1) {
						for (Map<String, Object> res : resultado) {

							nombre = (String) res.get("ben_nombre");
						}
					} else {
						log.info("Lista Nula");
					}

					query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
							+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
							+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
							+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalleO.getDetCtabenef() + "'";

					List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
					if (resultado3.size() == 1) {
						for (Map<String, Object> res : resultado3) {

							cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"),
									(String) res.get("cta_info"), (Integer) res.get("moneda"), (String) res.get("bco_nombre"),
									(String) res.get("pla_nombre"), (String) res.get("pla_bic"));
						}
					} else {
						log.info("Lista Nula");
					}

					DateTime fecha = new DateTime(operacion.getFechaHora());
					DateTime fechaV = new DateTime(operacion.getOpeFecha());
					if (fecha.getDayOfMonth() != fechaV.getDayOfMonth()) {
						if (operacion.getMoneda() != 34) {
							equiv = true;
							BigDecimal tc = getTipoCambio(34);
							montoEquiv = operacion.getOpeMontomn().divide(tc, 2, RoundingMode.HALF_UP);
						} else
							equiv = false;
					}
				} else
				// VENTA DE DIVISAS
				{
					this.ventas = new ArrayList<Venta>();

					if (operacion.getOpeCtaoperacion() == 5)
						nroCVer = false;
					else
						nroCVer = true;

					query = "select soc_montomn " + "from soc_solicitudes " + "where soc_correlativo = '" + operacion.getSocCorrelativo() + "'";

					List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
					if (resultado3.size() == 1) {
						for (Map<String, Object> res : resultado3) {

							montoMN = (BigDecimal) res.get("soc_montomn");
						}
						// whf rq01
						BigDecimal tc = Servicios.getTipoCambio(35);
						diff = montoMN.subtract(operacion.getOpeMontome().multiply(tc));
					} else {
						log.info("Lista Nula");
					}

					query = "select ben_codigo from soc_detallesope where ope_codigo = '" + operacion.getOpeCodigo() + "' and det_codigo = 1";

					List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
					if (resultado.size() == 1) {
						for (Map<String, Object> res : resultado) {
							subtipo = (String) res.get("ben_codigo");
						}
					} else {
						log.info("Lista Nula");
					}

					if (subtipo.equals("999999")) {
						subTipo = "TC";
						interVer = false;
						setExtVer(false);
						setLocalVer(true);
						opVer = true;
						query = " select d.*, b.*, c.cta_nommovimiento "
								+ " from soc_detallesope d, soc_benefslocal b, soc_cuentassol c, soc_operaciones o, soc_solicitudes s  "
								+ " where d.ope_codigo = '" + operacion.getOpeCodigo() + "'" + " and d.ope_codigo = o.ope_codigo "
								+ " and o.soc_correlativo = s.soc_correlativo " + " and b.soc_codigo = s.soc_codigo "
								+ " and b.det_codigo = d.det_codigo" + " and c.cta_codigo = b.cta_banco;";

						List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
						if (resultado2.size() > 0) {
							for (Map<String, Object> res : resultado2) {

								Integer mon = (Integer) res.get("moneda");
								venta = new Venta((String) res.get("beneficiario"), (String) res.get("cta_benef"),
										(String) res.get("cta_nommovimiento"), (BigDecimal) res.get("det_monto"), "999999", mon.toString(), 0, "",
										(Integer) res.get("det_codigo"));
								ventas.add(venta);
							}
						} else {
							log.info("Lista Nula");
						}
					} else {
						if (subtipo.equals("999998")) {
							subTipo = "OP";
							interVer = false;
							extVer = false;
							localVer = true;
							opVer = false;
							query = " select d.*, b.*" + " from soc_detallesope d, soc_benefslocal b, soc_operaciones o, soc_solicitudes s"
									+ " where d.ope_codigo = '" + operacion.getOpeCodigo() + "'" + " and d.ope_codigo = o.ope_codigo "
									+ " and o.soc_correlativo = s.soc_correlativo " + " and b.soc_codigo = s.soc_codigo "
									+ " and b.det_codigo = d.det_codigo";

							List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
							if (resultado2.size() > 0) {
								for (Map<String, Object> res : resultado2) {

									Integer mon = (Integer) res.get("moneda");
									venta = new Venta((String) res.get("beneficiario"), (String) res.get("cta_benef"), "",
											(BigDecimal) res.get("det_monto"), "999998", mon.toString(), 0, "", (Integer) res.get("det_codigo"));
									ventas.add(venta);
								}
							} else {
								log.info("Lista Nula");
							}
						} else {
							subTipo = "TE";
							setExtVer(true);
							setLocalVer(false);
							opVer = true;

							query = "select o.*, b.ben_nombre, c.cta_nrocuenta, bb.bco_nombre, p.pla_nombre "
									+ "from soc_detallesope o, soc_benefs b, soc_plazas p, soc_bancos bb, soc_cuentas c "
									+ "where b.ben_codigo = o.ben_codigo and c.cta_codigo = o.det_ctabenef "
									+ "and c.bco_codigo = bb.bco_codigo and p.bco_codigo = bb.bco_codigo "
									+ "and c.pla_codigo = p.pla_codigo and o.ope_codigo = '" + operacion.getOpeCodigo() + "'";

							List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
							if (resultado2.size() > 0) {
								for (Map<String, Object> res : resultado2) {

									Integer mon = (Integer) res.get("moneda");
									String mon1 = "";
									if (mon == 34)
										mon1 = "USD";
									else
										mon1 = "EUR";
									String cta = (String) res.get("det_ctabenef");
									cta = cta.trim();
									venta = new Venta((String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"),
											(String) res.get("bco_nombre") + " - " + (String) res.get("pla_nombre"),
											(BigDecimal) res.get("det_monto"), (String) res.get("ben_codigo"), mon1, Integer.valueOf(cta),
											(String) res.get("det_info"), (Integer) res.get("det_codigo"));
									ventas.add(venta);
								}
							} else {
								log.info("Lista Nula");
							}
						}
					}
				}
			}
		}
	}

	public void verBenef(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		venta = (Venta) SerializationUtils.clone(this.ventas.get(fila));

		String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
				+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
				+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
				+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
				+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
				+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			interVer = true;
			for (Map<String, Object> res : resultado) {

				cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
						(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"),
						(String) res.get("pla_intermediario"), (String) res.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1"));
			}
			label1 = "Cuenta:";
			bic = cuentaBen.getPlaNroCuenta();
		} else {
			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
					+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				interVer = false;
				for (Map<String, Object> res : resultado1) {

					cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
							(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"));
				}
				label1 = "BIC:";
				bic = cuentaBen.getPlaBic();
			} else {
				interVer = false;
				log.info("Lista Nula");
			}
		}
	}

	@SuppressWarnings("unchecked")
	public void recuperarComisiones(ActionEvent event) {
		this.comision = new Opecomi();
		this.comisiones = new ArrayList<Opecomi>();

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "comisiones");
		mapaParametros.put("codOperacion", nroOperacion);

		log.info("Llamando al BPM: con una consulta");
		Map<String, Object> mapaResultado = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaResultado.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaResultado.get("resp_msgerror");
			return;
		}
		comisiones = (List<Opecomi>) mapaResultado.get("lista");
		comis = (BigDecimal) mapaResultado.get("total");
		setComisU((BigDecimal) mapaResultado.get("totalU"));
		log.info("Devolviendo del BPM la lista de tamanio: " + (comisiones == null ? "NULL" : comisiones.size()));

	}

	private BigDecimal getTipoCambio(int mon) {
		BigDecimal tc = BigDecimal.valueOf(0);
		Date fecha = new Date();

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("fecha", fecha);
		mapaParametros1.put("moneda", mon);
		mapaParametros1.put("consulta", "tc");

		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: factor_conv_mn");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros1, iid1);
			tc = (BigDecimal) mapaResultado1.get("tc");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return tc;
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Autorizando la operación: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("codOperacion", operacion.getOpeCodigo());
		mapaParametros.put("opcion", "autorizar");
		mapaParametros.put("subtipo", subTipo);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		this.recuperarOperaciones();

		if (estado.equals("A")) {
			this.setMensaje("La operación se autorizó correctamente.");
		} else {
			if (estado.equals("S"))
				this.setMensaje("No se pudo autorizar la operación. Existe sobregiro en las cuentas.");
			else
				this.setMensaje("Se produjo un error al autorizar la operación.");
		}
	}

	public void eventoAnularBtn(ActionEvent action) {
		log.info("Rechazando la operación: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "rechazar");
		mapaParametros.put("codOperacion", operacion.getOpeCodigo());

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		this.recuperarOperaciones();
	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public OperacionesS getOperacionS() {
		return operacionS;
	}

	public void setOperacionS(OperacionesS operacionS) {
		this.operacionS = operacionS;
	}

	public SocDetallesope getDetalleO() {
		return detalleO;
	}

	public void setDetalleO(SocDetallesope detalleO) {
		this.detalleO = detalleO;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public List<SocOperaciones> getOperaciones() {
		return operaciones;
	}

	public void setOperaciones(List<SocOperaciones> operaciones) {
		this.operaciones = operaciones;
	}

	public List<OperacionesS> getListaOper() {
		return listaOper;
	}

	public Venta getVenta() {
		return venta;
	}

	public void setVenta(Venta venta) {
		this.venta = venta;
	}

	public void setListaOper(List<OperacionesS> listaOper) {
		this.listaOper = listaOper;
	}

	public List<Venta> getVentas() {
		return ventas;
	}

	public void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

	public Opecomi getComision() {
		return comision;
	}

	public void setComision(Opecomi comision) {
		this.comision = comision;
	}

	public List<Opecomi> getComisiones() {
		return comisiones;
	}

	public void setComisiones(List<Opecomi> comisiones) {
		this.comisiones = comisiones;
	}

	public String getNroOperacion() {
		return nroOperacion;
	}

	public void setNroOperacion(String nroOperacion) {
		this.nroOperacion = nroOperacion;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public void setCuentaB(String cuentaB) {
		this.cuentaB = cuentaB;
	}

	public String getCuentaB() {
		return cuentaB;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setNombreF(String nombreF) {
		this.nombreF = nombreF;
	}

	public String getNombreF() {
		return nombreF;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getBanco() {
		return banco;
	}

	public void setCuentaBC(String cuentaBC) {
		this.cuentaBC = cuentaBC;
	}

	public String getCuentaBC() {
		return cuentaBC;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getMensaje() {
		return mensaje;
	}

	public BigDecimal getComis() {
		return comis;
	}

	public void setComis(BigDecimal comis) {
		this.comis = comis;
	}

	public void setComisU(BigDecimal comisU) {
		this.comisU = comisU;
	}

	public BigDecimal getComisU() {
		return comisU;
	}

	public void setMontoMN(BigDecimal montoMN) {
		this.montoMN = montoMN;
	}

	public BigDecimal getMontoMN() {
		return montoMN;
	}

	public void setDiff(BigDecimal diff) {
		this.diff = diff;
	}

	public BigDecimal getDiff() {
		return diff;
	}

	public void setMontoEquiv(BigDecimal montoEquiv) {
		this.montoEquiv = montoEquiv;
	}

	public BigDecimal getMontoEquiv() {
		return montoEquiv;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getMonC() {
		return monC;
	}

	public void setMonC(String monC) {
		this.monC = monC;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setNroVer(Boolean nroVer) {
		this.nroVer = nroVer;
	}

	public Boolean getNroVer() {
		return nroVer;
	}

	public void setNroCVer(Boolean nroCVer) {
		this.nroCVer = nroCVer;
	}

	public Boolean getNroCVer() {
		return nroCVer;
	}

	public void setExtVer(Boolean extVer) {
		this.extVer = extVer;
	}

	public Boolean getExtVer() {
		return extVer;
	}

	public void setLocalVer(Boolean localVer) {
		this.localVer = localVer;
	}

	public Boolean getLocalVer() {
		return localVer;
	}

	public void setOpVer(Boolean opVer) {
		this.opVer = opVer;
	}

	public Boolean getOpVer() {
		return opVer;
	}

	public void setEquiv(Boolean equiv) {
		this.equiv = equiv;
	}

	public Boolean getEquiv() {
		return equiv;
	}
}
