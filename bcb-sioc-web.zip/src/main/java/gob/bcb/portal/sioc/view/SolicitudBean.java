package gob.bcb.portal.sioc.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;

import gob.bcb.bpm.pruebaCU.GenFeriadoDao;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocBenefsexpDao;
import gob.bcb.bpm.pruebaCU.SocBenefslocDao;
import gob.bcb.bpm.pruebaCU.SocBenefsregDao;
import gob.bcb.bpm.pruebaCU.SocComitipoopeDao;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocCuentasDao;
import gob.bcb.bpm.pruebaCU.SocCuentaslocDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDatosmenDao;
import gob.bcb.bpm.pruebaCU.SocDetallesopeDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocEstadisticaDao;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocHorarioDao;
import gob.bcb.bpm.pruebaCU.SocMensajes;
import gob.bcb.bpm.pruebaCU.SocMensajesDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOrdenesPagoDao;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.bpm.pruebaCU.SocParticipanteDao;
import gob.bcb.bpm.pruebaCU.SocPlazasDao;
import gob.bcb.bpm.pruebaCU.SocRengesqDao;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocSolbenefsDao;
import gob.bcb.bpm.pruebaCU.SocSolbenefslocDao;
import gob.bcb.bpm.pruebaCU.SocSolcuentasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.SocUsuariosolDao;
import gob.bcb.bpm.pruebaCU.SocValoresclaDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.controller.ManejadorServicioBPM;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.ProcesosSolicitud;
import gob.bcb.service.servicioSioc.pojos.ComprobanteDet;
import gob.bcb.swift.dao.SwfDetmensajeBean;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.dao.SwfMttransferBean;
import gob.bcb.swift.dao.SwfMttransferdetBean;
import gob.bcb.swift.dao.SwfPersonactaBean;

public class SolicitudBean implements Serializable {
	private Logger log = Logger.getLogger(SolicitudBean.class);
	private String codRespuesta;
	private String descRespuesta;
	private SessionFactory sessionFactory;

	private List<ComprobanteDet> detalleMontosLista = new ArrayList<ComprobanteDet>();

	private SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
	private SocDetallesopeDao detallesopeDao = new SocDetallesopeDao();
	private SocComitipoopeDao socComitipoopeDao = new SocComitipoopeDao();
	private SocFacturasDao socFacturasDao = new SocFacturasDao();
	private SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
	private SocRengesqDao socRengesqDao = new SocRengesqDao();
	private SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
	private SocBenefsDao socBenefsDao = new SocBenefsDao();
	private SocBenefsexpDao socBenefsexpDao = new SocBenefsexpDao();	
	private SocMensajesDao socMensajesDao = new SocMensajesDao();
	private SocDatosmenDao socDatosmenDao = new SocDatosmenDao();
	private SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
	private SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
	private SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private SocComprobanteDao socComprobanteDao = new SocComprobanteDao();
	private SocRengscompDao socRengscompDao = new SocRengscompDao();
	private GenMonedaDao genMonedaDao = new GenMonedaDao();
	private SocCuentasDao socCuentasDao = new SocCuentasDao();
	private SocBancosDao socBancosDao = new SocBancosDao();
	private SocPlazasDao socPlazasDao = new SocPlazasDao();
	private SocSolbenefsDao socSolbenefsDao = new SocSolbenefsDao();
	private SocSolbenefslocDao socSolbenefslocDao = new SocSolbenefslocDao();
	private SocHorarioDao socHorarioDao = new SocHorarioDao();
	private SocEstadisticaDao socEstadisticaDao = new SocEstadisticaDao(); 

	private SocBenefslocDao socBenefslocDao = new SocBenefslocDao();
	private SocBenefsregDao socBenefsregDao = new SocBenefsregDao();	
	private SocCuentaslocDao socCuentaslocDao = new SocCuentaslocDao();
	private SocSolcuentasDao socSolcuentasDao = new SocSolcuentasDao();
	private GenFeriadoDao genFeriadoDao = new GenFeriadoDao();
	private SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
	private SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
	private SocParametrosDao socParametrosDao = new SocParametrosDao();
	private SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();	
	private SocParticipanteDao socParticipanteDao = new SocParticipanteDao();
	private ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
	
	private SwfMttransferdetBean swfMttransferdetBean = new SwfMttransferdetBean();
	private SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
	private SwfMttransferBean swfMttransferBean = new SwfMttransferBean(); 
	private SwfDetmensajeBean swfDetmensajeBean = new SwfDetmensajeBean();
	private SwfPersonactaBean swfPersonactaBean = new SwfPersonactaBean();	

	public Solicitud procesar0(SocSolicitudes socSolicitudes, String tipoOperacion) {
		Solicitud solicitudTO = new Solicitud();

		solicitudTO.setSolicitud(socSolicitudes);

		return procesar(solicitudTO, tipoOperacion);

	}

	public Solicitud procesar(Solicitud solicitudTO, String tipoOperacion) {

		codRespuesta = "";
		descRespuesta = "";
		try {
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", tipoOperacion);
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al PROCESAR JMS: " + e.getMessage(),e);
			throw new RuntimeException("NullPointerException error PROCESAR JMS : " + e.getMessage(),e);
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public Solicitud guardarFechaValor(SocSolicitudes socSolicitudes, String tipoOperacion) {
		log.info("guardarFechaValor : " + socSolicitudes.getSocCodigo());
		codRespuesta = "";
		descRespuesta = "";
		try {
			Solicitud solicitudTO = new Solicitud();

			solicitudTO.setSolicitud(socSolicitudes);

			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", tipoOperacion);
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			return solicitudTO;
		} catch (NullPointerException e) {
			log.error("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
			throw new RuntimeException("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public Solicitud preAutoriza(SocSolicitudes socSolicitudes, String tipoOperacion) {
		log.info("preAutoriza : " + socSolicitudes.getSocCodigo());
		codRespuesta = "";
		descRespuesta = "";
		try {
			Solicitud solicitudTO = new Solicitud();

			solicitudTO.setSolicitud(socSolicitudes);

			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", tipoOperacion);
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
			throw new RuntimeException("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public Solicitud generarSwifts(Solicitud solicitudTMP, SocMensajes socMensajes) {
		log.info("generarSwifts : " + solicitudTMP.getSolicitud().getSocCodigo());
		codRespuesta = "";
		descRespuesta = "";
		try {
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "generarmensswift");
			mapaParametros.put("socMensajes", socMensajes);
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTMP);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al recuperar datos : " + solicitudTMP.getSolicitud().getSocCodigo());
			throw new RuntimeException("NullPointerException error al recuperar datos : " + solicitudTMP.getSolicitud().getSocCodigo());
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public Solicitud autorizarSwifts(SocSolicitudes socSolicitudes) {
		log.info("autorizarSwifts : " + socSolicitudes.getSocCodigo());
		codRespuesta = "";
		descRespuesta = "";
		try {
			Solicitud solicitudTO = new Solicitud();

			solicitudTO.setSolicitud(socSolicitudes);

			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "autorizarswift");
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
			throw new RuntimeException("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

	}

	public Solicitud anularSolicitud(Solicitud solicitudTemp) {
		log.info("autorizarSwifts : " + solicitudTemp.getSolicitud().getSocCodigo());
		codRespuesta = "";
		descRespuesta = "";
		try {

			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "anularsolicitud");
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTemp);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al recuperar datos : " + solicitudTemp.getSolicitud().getSocCodigo());
			throw new RuntimeException("NullPointerException error al recuperar datos : " + solicitudTemp.getSolicitud().getSocCodigo());
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public Solicitud autorizarTransfer(Solicitud solicitudTO) {
		log.info("autorizarTransfer : " + solicitudTO.getSolicitud().getSocCodigo());
		codRespuesta = "";
		descRespuesta = "";
		try {
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "autorizartransfer");
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);

			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al recuperar datos : " + solicitudTO.getSolicitud().getSocCodigo());
			throw new RuntimeException("NullPointerException error al recuperar datos : " + solicitudTO.getSolicitud().getSocCodigo());
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public Solicitud notificaMEFP(SocSolicitudes socSolicitudes) {

		log.info("autoriza solicitud : " + socSolicitudes.getSocCodigo());
		codRespuesta = "";
		descRespuesta = "";
		try {
			Solicitud solicitudTO = new Solicitud();

			solicitudTO.setSolicitud(socSolicitudes);

			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "notificardebito");
			mapaParametros.put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);
			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			if (respuesta.containsKey("resp_codmsg")) {
				codRespuesta = (String) respuesta.get("resp_codmsg");
				descRespuesta = (String) respuesta.get("resp_descripmsg");
			}
			return (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		} catch (NullPointerException e) {
			log.error("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
			throw new RuntimeException("NullPointerException error al recuperar datos : " + socSolicitudes.getSocCodigo());
		} catch (Exception e) {
			log.error("Ocurrio un error al recuperar datos : " + e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// public List<Comprobante> recuperarDatosComprob(String opeCodigo, Integer
	// detCodigo) {
	public List<ComprobanteDet> armarResumen(SocDetallessol socDetallessol) {
		detalleMontosLista.clear();

		Integer detCodigo = 0;
		if (socDetallessol != null) {
			detCodigo = socDetallessol.getId().getDetCodigo();
		}

		List<ComprobanteDet> comprobanteList = new ArrayList<ComprobanteDet>();
		StringBuilder query = new StringBuilder();
		query.append("select s.soc_codigo, vs.cla_comision,vs.det_codigo,vs.oco_monto,vs.monto_mo,vs.cod_moneda, ");
		query.append("vs.nro_cuenta,vs.cve_tipocomis,s.fecha,date(s.fecha_reg) fecha_reg,vs.tipo_cambio,vs.cla_estadovar, ");
		query.append("(select vc.val_nombre from soc_valorescla vc where vc.cla_codigo = 'cla_tipovariab' and vc.val_codigo = vs.cla_comision) cla_comisiondesc, ");
		query.append("(select m.mon_sigla from gen_moneda m where m.cod_moneda = vs.cod_moneda) cod_monedasigla, ");
		query.append("(select count(ds.det_codigo) from soc_detallessol ds where ds.soc_codigo = s.soc_codigo) nro_detalle ");
		query.append("from soc_solicitudes s, soc_opecomi vs ");
		query.append("where s.soc_codigo = vs.ope_codigo ");
		query.append("and vs.det_codigo = " + detCodigo + " ");
		query.append("and vs.monto_mo != 0 ");
		query.append("and vs.cve_tipocomis = 'V' ");
		query.append("AND vs.cla_comision in ('TOTALPROV','VENTAUSD','TOTDEBITO','DIFERTC','TOTDETMT','COMSWIFT','COMUTIL','COMCTRA','TOTCOMISION') ");
		query.append("and s.soc_codigo = '" + socDetallessol.getId().getSocCodigo() + "' ");

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query.toString());
		for (Map<String, Object> res : resultado) {
			ComprobanteDet comprobante = new ComprobanteDet();

			comprobante.setRenCodigo(9);
			comprobante.setMovi((String) res.get("cla_comision"));
			comprobante.setCpbGlosa((String) res.get("cla_comisiondesc"));
			comprobante.setDebe((BigDecimal) res.get("monto_mo"));
			comprobante.setCodMoneda((Integer) res.get("cod_moneda"));

			comprobanteList.add(comprobante);
		}
		return comprobanteList;
	}

	/****************************/
	/****************************/
	/****************************/

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}

	public void inicializar() {

		socEsquemasDao.setSessionFactory(getSessionFactory());
		detallesopeDao.setSessionFactory(getSessionFactory());
		socComitipoopeDao.setSessionFactory(getSessionFactory());
		socFacturasDao.setSessionFactory(getSessionFactory());
		socSolicitanteDao.setSessionFactory(getSessionFactory());
		socRengesqDao.setSessionFactory(getSessionFactory());
		socDetallessolDao.setSessionFactory(getSessionFactory());
		socBenefsDao.setSessionFactory(getSessionFactory());
		socBenefsexpDao.setSessionFactory(getSessionFactory());
		socMensajesDao.setSessionFactory(getSessionFactory());
		socDatosmenDao.setSessionFactory(getSessionFactory());
		socCuentassolDao.setSessionFactory(getSessionFactory());
		socSolicitudctasDao.setSessionFactory(getSessionFactory());
		socSolicitudesDao.setSessionFactory(getSessionFactory());
		socOpecomiDao.setSessionFactory(getSessionFactory());
		socComprobanteDao.setSessionFactory(getSessionFactory());
		socRengscompDao.setSessionFactory(getSessionFactory());
		genMonedaDao.setSessionFactory(getSessionFactory());
		socCuentasDao.setSessionFactory(getSessionFactory());
		socBancosDao.setSessionFactory(getSessionFactory());
		socPlazasDao.setSessionFactory(getSessionFactory());
		socSolbenefsDao.setSessionFactory(getSessionFactory());
		socSolbenefslocDao.setSessionFactory(getSessionFactory());
		socEstadisticaDao.setSessionFactory(getSessionFactory());
		socBenefslocDao.setSessionFactory(getSessionFactory());
		socBenefsregDao.setSessionFactory(getSessionFactory());
		socCuentaslocDao.setSessionFactory(getSessionFactory());
		socSolcuentasDao.setSessionFactory(getSessionFactory());
		socHorarioDao.setSessionFactory(getSessionFactory());
		genFeriadoDao.setSessionFactory(getSessionFactory());
		socUsuariosolDao.setSessionFactory(getSessionFactory());
		socValoresclaDao.setSessionFactory(getSessionFactory());
		socParametrosDao.setSessionFactory(getSessionFactory());
		socParticipanteDao.setSessionFactory(getSessionFactory());
		socOrdenesPagoDao.setSessionFactory(getSessionFactory());		
		procesosSolicitud.setSessionFactory(getSessionFactory());

		swfMttransferdetBean.setSessionFactory(getSessionFactory());
		swfMensajeBean.setSessionFactory(getSessionFactory());
		swfDetmensajeBean.setSessionFactory(getSessionFactory());
		swfMttransferBean.setSessionFactory(getSessionFactory());
		swfPersonactaBean.setSessionFactory(getSessionFactory());
		
		QueryProcessor.setSessionFactory(getSessionFactory());
		log.info("XXX:inicializadoooooooooooo ");
	}

	public SocBenefsDao getSocBenefsDao() {
		return socBenefsDao;
	}

	public SocCuentasDao getSocCuentasDao() {
		return socCuentasDao;
	}

	public SocBancosDao getSocBancosDao() {
		return socBancosDao;
	}

	public SocPlazasDao getSocPlazasDao() {
		return socPlazasDao;
	}

	public SocSolicitanteDao getSocSolicitanteDao() {
		return socSolicitanteDao;
	}

	public SocSolbenefsDao getSocSolbenefsDao() {
		return socSolbenefsDao;
	}

	public SocHorarioDao getSocHorarioDao() {
		return socHorarioDao;
	}

	public SocBenefslocDao getSocBenefslocDao() {
		return socBenefslocDao;
	}

	public SocCuentaslocDao getSocCuentaslocDao() {
		return socCuentaslocDao;
	}

	public SocCuentassolDao getSocCuentassolDao() {
		return socCuentassolDao;
	}

	public String getCodRespuesta() {
		return codRespuesta;
	}

	public void setCodRespuesta(String codRespuesta) {
		this.codRespuesta = codRespuesta;
	}

	public String getDescRespuesta() {
		return descRespuesta;
	}

	public void setDescRespuesta(String descRespuesta) {
		this.descRespuesta = descRespuesta;
	}

	public SocSolcuentasDao getSocSolcuentasDao() {
		return socSolcuentasDao;
	}

	public GenFeriadoDao getGenFeriadoDao() {
		return genFeriadoDao;
	}

	public SocSolicitudesDao getSocSolicitudesDao() {
		return socSolicitudesDao;
	}

	public SocDetallessolDao getSocDetallessolDao() {
		return socDetallessolDao;
	}

	public SocComprobanteDao getSocComprobanteDao() {
		return socComprobanteDao;
	}

	public SocRengscompDao getSocRengscompDao() {
		return socRengscompDao;
	}

	public SocUsuariosolDao getSocUsuariosolDao() {
		return socUsuariosolDao;
	}

	public SocValoresclaDao getSocValoresclaDao() {
		return socValoresclaDao;
	}

	public SocParametrosDao getSocParametrosDao() {
		return socParametrosDao;
	}

	public SocParticipanteDao getSocParticipanteDao() {
		return socParticipanteDao;
	}

	public GenMonedaDao getGenMonedaDao() {
		return genMonedaDao;
	}

	public SocEsquemasDao getSocEsquemasDao() {
		return socEsquemasDao;
	}

	public void setSocEsquemasDao(SocEsquemasDao socEsquemasDao) {
		this.socEsquemasDao = socEsquemasDao;
	}

	public ProcesosSolicitud getProcesosSolicitud() {
		return procesosSolicitud;
	}

	public void setProcesosSolicitud(ProcesosSolicitud procesosSolicitud) {
		this.procesosSolicitud = procesosSolicitud;
	}

	public SocMensajesDao getSocMensajesDao() {
		return socMensajesDao;
	}

	public void setSocMensajesDao(SocMensajesDao socMensajesDao) {
		this.socMensajesDao = socMensajesDao;
	}

	public SocOpecomiDao getSocOpecomiDao() {
		return socOpecomiDao;
	}

	public void setSocOpecomiDao(SocOpecomiDao socOpecomiDao) {
		this.socOpecomiDao = socOpecomiDao;
	}

	public SocSolicitudctasDao getSocSolicitudctasDao() {
		return socSolicitudctasDao;
	}

	public void setSocSolicitudctasDao(SocSolicitudctasDao socSolicitudctasDao) {
		this.socSolicitudctasDao = socSolicitudctasDao;
	}

	public SwfMttransferdetBean getSwfMttransferdetBean() {
		return swfMttransferdetBean;
	}

	public void setSwfMttransferdetBean(SwfMttransferdetBean swfMttransferdetBean) {
		this.swfMttransferdetBean = swfMttransferdetBean;
	}

	public SwfMensajeBean getSwfMensajeBean() {
		return swfMensajeBean;
	}

	public void setSwfMensajeBean(SwfMensajeBean swfMensajeBean) {
		this.swfMensajeBean = swfMensajeBean;
	}

	public SwfDetmensajeBean getSwfDetmensajeBean() {
		return swfDetmensajeBean;
	}

	public void setSwfDetmensajeBean(SwfDetmensajeBean swfDetmensajeBean) {
		this.swfDetmensajeBean = swfDetmensajeBean;
	}

	public void setSocBenefslocDao(SocBenefslocDao socBenefslocDao) {
		this.socBenefslocDao = socBenefslocDao;
	}

	public SocSolbenefslocDao getSocSolbenefslocDao() {
		return socSolbenefslocDao;
	}

	public void setSocSolbenefslocDao(SocSolbenefslocDao socSolbenefslocDao) {
		this.socSolbenefslocDao = socSolbenefslocDao;
	}

	public SwfPersonactaBean getSwfPersonactaBean() {
		return swfPersonactaBean;
	}

	public void setSwfPersonactaBean(SwfPersonactaBean swfPersonactaBean) {
		this.swfPersonactaBean = swfPersonactaBean;
	}

	public SocFacturasDao getSocFacturasDao() {
		return socFacturasDao;
	}

	public void setSocFacturasDao(SocFacturasDao socFacturasDao) {
		this.socFacturasDao = socFacturasDao;
	}

	public SwfMttransferBean getSwfMttransferBean() {
		return swfMttransferBean;
	}

	public void setSwfMttransferBean(SwfMttransferBean swfMttransferBean) {
		this.swfMttransferBean = swfMttransferBean;
	}

	public SocOrdenesPagoDao getSocOrdenesPagoDao() {
		return socOrdenesPagoDao;
	}

	public void setSocOrdenesPagoDao(SocOrdenesPagoDao socOrdenesPagoDao) {
		this.socOrdenesPagoDao = socOrdenesPagoDao;
	}

	public SocBenefsregDao getSocBenefsregDao() {
		return socBenefsregDao;
	}

	public void setSocBenefsregDao(SocBenefsregDao socBenefsregDao) {
		this.socBenefsregDao = socBenefsregDao;
	}

	public SocEstadisticaDao getSocEstadisticaDao() {
		return socEstadisticaDao;
	}

	public SocBenefsexpDao getSocBenefsexpDao() {
		return socBenefsexpDao;
	}

}
