/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.richfaces.component.html.HtmlDataTable;

import org.apache.commons.lang.SerializationUtils;
import org.apache.log4j.Logger;

import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.OrdenPago;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaOrdenPController {
  private OrdenPago opa = new OrdenPago();
  private List<OrdenPago> opas;

  private String mensaje = "";
  private boolean generada;
  
  //private String urlReporte;
  
  private Logger log = Logger.getLogger(ListaOrdenPController.class);

  public ListaOrdenPController() {
    this.recuperarOrdenes();
  }

  @SuppressWarnings("unchecked")
  private void recuperarOrdenes() {
    this.opas = new ArrayList<OrdenPago>();
    
    String query = " select o.ins_codigo, o.opa_nroordenpago, o.opa_fechavenc, o.opa_reng, o.opa_imp, o.opa_benef, "
      + "i.ins_monto, i.moneda, i.ins_concepto, p.ope_fecha "
      + "from soc_ordenespago o, soc_instrumento i, soc_detallesope d, soc_operaciones p "
      + "where o.ins_codigo = i.ins_codigo "
      + "and i.ins_codigo = d.ins_codigo "
      + "and d.ope_codigo = p.ope_codigo "
      + "and o.cla_estadoopa = 'C'";
    
    List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
    if (resultado.size() > 0)
    {
      for (Map<String, Object>res : resultado)
      {
        
        
        opa = new OrdenPago((String) res.get("ins_codigo"), (String) res.get("opa_nroordenpago"), (Date) res.get("opa_fechavenc"), (Integer) res.get("opa_reng"),
          (Integer) res.get("opa_imp"), (String) res.get("opa_benef"), (BigDecimal) res.get("ins_monto"), (Integer) res.get("moneda"),
          (String) res.get("ins_concepto"), (Date) res.get("ope_fecha"));
        opas.add(opa);
      }
    }
    else
    {
      log.info("Lista Nula");
    }
  }
  
  public void autorizarOP(ActionEvent event)
  {
    HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
    int fila = dataTable.getRowIndex();
    opa = (OrdenPago) SerializationUtils.clone(this.opas.get(fila));
    
    log.info("Autorizando la OP: ");
    // parametros para request
    String id = new Long(new Date().getTime()).toString();

    // mapa de parametros a enviar a BPM
    Map<String, Object> mapaParametros = new HashMap<String, Object>();
    mapaParametros.put("opcion", "autorizarOP");

    // enviando objeto del formulario
    mapaParametros.put("codigo", opa.getInsCodigo());

    // Metodo estatico que se encarga de manejar las consultas al BPM
    // parametros
    // nombre BPM, ipRequest, requester, feature, mapaParametros, id
    Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(
        "bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);if (mapaRespuesta.containsKey("resp_msgerror")){mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");return;}

    String estado = (String) mapaRespuesta.get("estado");

    if (estado.equals("P"))
    {
      log.info("Estado asignado desde el BPM: " + estado);
      mensaje = "La orden de pago fue autorizada.";
      
      this.recuperarOrdenes();
    }
    
    else
    {
      log.info("No se pudo autorizar la OP.");
      mensaje = "No se pudo autorizar la orden de pago.";
    }
    
  }

  public OrdenPago getOpa() {
    return opa;
  }

  public void setOpa(OrdenPago opa) {
    this.opa = opa;
  }

  public List<OrdenPago> getOpas() {
    return opas;
  }

  public void setOpas(List<OrdenPago> opas) {
    this.opas = opas;
  }

  public String getMensaje() {
    return mensaje;
  }

  public void setMensaje(String mensaje) {
    this.mensaje = mensaje;
  }
  
  /*public String getUrlReporte() {
    urlReporte = "http://10.2.11.93:8180/bcb-web-sioc/reporte?cod=" + codIns;
    return urlReporte;
  }

  public void setUrlReporte(String urlReporte) {
    this.urlReporte = urlReporte;
  }*/

  public void setGenerada(boolean generada) {
    this.generada = generada;
  }

  public boolean isGenerada() {
    return generada;
  }
  
}
