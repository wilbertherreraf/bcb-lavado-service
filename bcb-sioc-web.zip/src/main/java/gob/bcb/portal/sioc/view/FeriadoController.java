package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.GenFeriado;
import gob.bcb.bpm.pruebaCU.GenFeriadoPK;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocHorario;
import gob.bcb.bpm.pruebaCU.SocSolbenefs;
import gob.bcb.bpm.pruebaCU.SocSolcuentas;
import gob.bcb.bpm.pruebaCU.SocSolcuentasPK;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Soli;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

public class FeriadoController  extends BaseBeanController {
	private Logger log = Logger.getLogger(FeriadoController.class);
	private GenFeriado socHorarioSelected = new GenFeriado();
	private List<GenFeriado> listaHorarios = new ArrayList<GenFeriado>();
	private List<SelectItem> monedaItems = new ArrayList<SelectItem>();
	
	@PostConstruct
	public void init() {
		log.info("postcontructor en: " + this.getClass().getName());
		recuperarVisit();
		monedasListas();
		recuperarDatos();
	}

	private void recuperarDatos() {
		listaHorarios =getSolicitudBean().getGenFeriadoDao().getGenFeriadoList();
	}
	public void editar(GenFeriado genFeriado) {
		log.info("editando fila: " + genFeriado.getId().getCodMoneda());
		socHorarioSelected = getSolicitudBean().getGenFeriadoDao().getByFechaMoneda(genFeriado.getId().getFechaFeriado(), genFeriado.getId().getCodMoneda());
	}

	public void nuevoRegistro(ActionEvent event) {
		log.info("antes de insertaaar : ");		
		GenFeriadoPK id = new GenFeriadoPK();
		socHorarioSelected = new GenFeriado();
		socHorarioSelected.setId(id);
	}
	
	public void guardar(GenFeriado genFeriado) {
		try {
			log.info("nuevito registro ." + genFeriado.getId().getFechaFeriado());
			getSolicitudBean().getGenFeriadoDao().saveOrUpdate(genFeriado);

			recuperarDatos();
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}
	public void eliminar(GenFeriado genFeriadoSel) {
		socHorarioSelected = genFeriadoSel;
		try {
			GenFeriado socSolbenef = getSolicitudBean().getGenFeriadoDao().getByFechaMoneda(socHorarioSelected.getId().getFechaFeriado(), socHorarioSelected.getId().getCodMoneda());
			getSolicitudBean().getGenFeriadoDao().eliminar(socSolbenef);
			log.info("Se dio de baja el registro. " + socSolbenef.getId().getFechaFeriado());

			recuperarDatos();
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}
	public void guardarRegistro(ActionEvent event) {
		log.info("guardando registro : fecha: " + socHorarioSelected.getId().getFechaFeriado() + " moneda: " +socHorarioSelected.getId().getCodMoneda() + " desc: "  + socHorarioSelected.getDescFeriado());		
		guardar(socHorarioSelected);
		
	}

	public GenFeriado getSocHorarioSelected() {
		return socHorarioSelected;
	}

	public void setSocHorarioSelected(GenFeriado socHorarioSelected) {
		this.socHorarioSelected = socHorarioSelected;
	}

	public List<GenFeriado> getListaHorarios() {
		return listaHorarios;
	}

	public void setListaHorarios(List<GenFeriado> listaHorarios) {
		this.listaHorarios = listaHorarios;
	}

	public List<SelectItem> getMonedaItems() {
		return monedaItems;
	}

	public void setMonedaItems(List<SelectItem> monedaItems) {
		this.monedaItems = monedaItems;
	}

	private void monedasListas() {
		monedaItems = new ArrayList<SelectItem>();
		List<Integer> monedaList = new ArrayList<Integer>();
		monedaList.add(Constants.COD_MONEDA_BS);
		List<GenMoneda> genMonedaLista = new ArrayList<GenMoneda>();
		genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedasLista(monedaList, false);
		
		for (GenMoneda genMoneda : genMonedaLista) {
			monedaItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}		
	}
}
