package gob.bcb.portal.sioc.transferencias.commons;

import gob.bcb.portal.sioc.transferencias.model.Solicitante;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioSession implements Serializable{
	private String login;
	private List<String> recursos;
	private List<String> roles;
	private Solicitante solicitante;
	private Map<String, Boolean> recAutorizadosMapa = new HashMap<String, Boolean>();
	public UsuarioSession(String login)
	{
		super();
		this.login = login;
	}
	public String getLogin()
	{
		return login;
	}
	public void setLogin(String login)
	{
		this.login = login;
	}
	public void setRecursos(List<String> recursos) {
		if (recAutorizadosMapa != null){
			recAutorizadosMapa.clear();
		} else {
			recAutorizadosMapa = new HashMap<String, Boolean>();
		}
		for (String recurso : recursos) {
			recAutorizadosMapa.put(recurso, true);
		}
		this.recursos = recursos;
	}
	public List<String> getRecursos() {
		return recursos;
	}
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	public List<String> getRoles() {
		return roles;
	}
	public void setRecAutorizadosMapa(Map<String, Boolean> recAutorizadosMapa) {
		this.recAutorizadosMapa = recAutorizadosMapa;
	}
	public Map<String, Boolean> getRecAutorizadosMapa() {
		return recAutorizadosMapa;
	}
	public void setSolicitante(Solicitante solicitante) {
		this.solicitante = solicitante;
	}
	public Solicitante getSolicitante() {
		return solicitante;
	}

}
