package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.controller.ManejadorServicioBPM;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.richfaces.component.html.HtmlDataTable;

public class ParametrosSistController extends BaseBeanController {
	private static final Log log = LogFactory.getLog(ParametrosSistController.class);
	private SolicitudBean solicitudBean = new SolicitudBean();
	private List<SocParametros> socParametrosLista = new ArrayList<SocParametros>();
	private SocParametros socParametrosSelected = new SocParametros();
	private String mensaje = "";	
	private String sIOCWEB_TIPOPERACION;	
	
	@PostConstruct
	public void init() {
		log.info("PostConstruct - " + getClass().getName());
		try {
			recuperarVisit();

			solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			recuperarDatos();
			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			getVisit().setParametro("pagretorno", dd.getPagina());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "OcurriÃƒÂ³ un error: " + e.getMessage(), null));
		}
		
	}
	private void recuperarDatos() {
		socParametrosSelected = new SocParametros();		
		
		socParametrosLista = solicitudBean.getSocParametrosDao().getParams();
	}
	public void adicionar(ActionEvent event) {
		socParametrosSelected = new SocParametros();
	}

	public void editar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocParametros cta0 = (SocParametros) SerializationUtils.clone(socParametrosLista.get(fila));
		socParametrosSelected =solicitudBean.getSocParametrosDao().getByCodigo(cta0.getParCodigo());
	}
	public void guardar(SocParametros socBanco) {
		socBanco.setEstacion(getVisit().getAddress());
		socBanco.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
		socBanco.setFechaHora(new Date());
		solicitudBean.getSocParametrosDao().saveOrUpdate(socBanco);		
	}
	public void guardar(ActionEvent event) {
		try {
			guardar(socParametrosSelected);
			recuperarDatos();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}
	
	//public void reiniciarProcesos(ActionEvent event) {
	public String reiniciarProcesos() {		
		try {

			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "reiniciarprocesos");

			Map<String, Object> respuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "ESTACION", "cliente", "consulta", mapaParametros, null);

			if (respuesta.containsKey("resp_msgerror")) {
				throw new RuntimeException((String) respuesta.get("resp_msgerror"));
			}
			return "";
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
			return null;
		}
		
	}
	
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public List<SocParametros> getSocParametrosLista() {
		return socParametrosLista;
	}
	public void setSocParametrosLista(List<SocParametros> socParametrosLista) {
		this.socParametrosLista = socParametrosLista;
	}
	public SocParametros getSocParametrosSelected() {
		return socParametrosSelected;
	}
	public void setSocParametrosSelected(SocParametros socParametrosSelected) {
		this.socParametrosSelected = socParametrosSelected;
	}
}
