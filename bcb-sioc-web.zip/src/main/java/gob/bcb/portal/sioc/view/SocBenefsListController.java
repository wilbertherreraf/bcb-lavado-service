package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsreg;
import gob.bcb.bpm.pruebaCU.SocSolbenefs;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.controller.ListaBeneficiariosController;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

public class SocBenefsListController extends BaseBeanController {
	private Logger log = Logger.getLogger(ListaBeneficiariosController.class);

	private SocBenefs benefi = new SocBenefs();
	private Beneficiario beneficiarioSearch = new Beneficiario();
	private List<CuentasBen> beneficiarios = new ArrayList<CuentasBen>();
	private List<Beneficiario> beneficiariosLista = new ArrayList<Beneficiario>();
	private List<SelectItem> solicitanteItems = new ArrayList<SelectItem>();

	private SocSolbenefs socSolbenefSelected = new SocSolbenefs();

	private Integer nroBenefsPendientesR = 0;
	private Integer nroBenefsPendientes1 = 0;
	// private SolicitudBean solicitudBean = new SolicitudBean();
	private String sIOCWEB_TIPOPERACION;
	private String accionBenef;

	@PostConstruct
	public void inicio() {
		log.info("PostConstruct SolicitudSearchPanel - " + getClass().getName());
		try {
			recuperarVisit();
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");

			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			crearObjetosPorDefecto();
			accionBenef = "BLISTINI";
			recuperarBeneficiarios("BLISTINI", null);

			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			getVisit().setParametro("pagretorno", dd.getPagina());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "OcurriÃ³ un error: " + e.getMessage(), null));
		} finally {
			getVisit().removeParametro("SIOCWEB_TIPOPERACION");
			getVisit().removeParametro("SIOCWEB_CODBEN");
			getVisit().removeParametro("pagretorno0");

			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
			sesiones.remove("socBenefsController");
		}
	}

	private void crearObjetosPorDefecto() {
		recuperarListaSolicitantes("SP,SF");
	}

	private void recuperarListaSolicitantes(String claTipoEntidad) {
		solicitanteItems = new ArrayList<SelectItem>();
		List<SocSolicitante> socSolicitanteLista = new ArrayList<SocSolicitante>();

		if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, claTipoEntidad);
		} else {
			SocSolicitante socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(
					getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
			if (socSolicitante != null) {
				socSolicitanteLista.add(socSolicitante);
				beneficiarioSearch.setSolCodigo(socSolicitante.getSolCodigo());
			}
		}
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			solicitanteItems.add(new SelectItem("" + socSolicitante.getSolCodigo().trim() + "", socSolicitante.getSolPersona() + " ["
					+ socSolicitante.getSolCodigo() + "]"));
		}
	}

	public void botonBuscar() {

		recuperarBeneficiarios("BLISTBUSCAR", null);
	}

	private void recuperarBeneficiarios(String tipoOperacion, String benEstcta) {
		beneficiariosLista.clear();

		if (tipoOperacion.equals("BLISTINI")) {
			if (!getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				beneficiariosLista = getSolicitudBean().getSocBenefsDao().beneficiariosExt(beneficiarioSearch.getBenNombre(),
						beneficiarioSearch.getSolCodigo(), beneficiarioSearch.getBenNit(), null);
			}
			accionBenef = "VERBEN";
		} else if (tipoOperacion.equals("BLISTBUSCAR")) {
			beneficiariosLista = getSolicitudBean().getSocBenefsDao().beneficiariosExt(beneficiarioSearch.getBenNombre(),
					beneficiarioSearch.getSolCodigo(), beneficiarioSearch.getBenNit(), null);
			accionBenef = "VERBEN";

		} else if (tipoOperacion.equals("BLISTPEN")) {
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				beneficiariosLista = getSolicitudBean().getSocBenefsDao().beneficiariosPendientes(null, benEstcta);
				
				if (benEstcta.equals(Constants.CVE_ESTBENEF_REG)){
					accionBenef = "PRAUTBEN";					
				} else if (benEstcta.equals(Constants.CVE_ESTBENEF_VERIF)){
					accionBenef = "AUTBEN";
				}
			}
		}

		if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			List<SocBenefsreg> socBenefsListaPend = getSolicitudBean().getSocBenefsDao().findBenefsPendientes(null, Constants.CVE_ESTBENEF_REG);
			nroBenefsPendientesR = socBenefsListaPend.size();

			socBenefsListaPend = getSolicitudBean().getSocBenefsDao().findBenefsPendientes(null, Constants.CVE_ESTBENEF_VERIF);
			nroBenefsPendientes1 = socBenefsListaPend.size();
		}

	}

	public void botonBenefsPendientes(String benEstcta) {
		recuperarBeneficiarios("BLISTPEN", benEstcta);
	}

	public void irDetalle(Beneficiario beneficiario) {
		try {
			log.info("irDetalleBenef " + beneficiario.getBenCodigo());
			getVisit().setParametro("pagretorno0", getVisit().getParametro("paginaact"));
			log.info("XXX: retrono 0 " + getVisit().getParametro("paginaact"));

			if (accionBenef.equals("VERBEN")) {
				getVisit().setParametro("SIOCWEB_CODBEN", beneficiario.getBenCodigo());
				getVisit().setParametro("SIOCWEB_ACTION", accionBenef);
				irAPagina("/view/Parametros/socBenefs_view.xhtml");

			} else if (accionBenef.equals("PRAUTBEN")) {
				getVisit().setParametro("SIOCWEB_CODBEN", beneficiario.getBenCodigo());
				getVisit().setParametro("SIOCWEB_NROREGBEN", beneficiario.getSocBenefsreg().getNroRegbenef());				
				getVisit().setParametro("SIOCWEB_ACTION", accionBenef);
				irAPagina("/view/Parametros/socBenefsreg_reg.xhtml");
				
			} else if (accionBenef.equals("AUTBEN")) {
				getVisit().setParametro("SIOCWEB_CODBEN", beneficiario.getBenCodigo());
				getVisit().setParametro("SIOCWEB_NROREGBEN", beneficiario.getSocBenefsreg().getNroRegbenef());				
				getVisit().setParametro("SIOCWEB_ACTION", accionBenef);
				irAPagina("/view/Parametros/socBenefsreg_verif.xhtml");
				
			}

		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAgregarBenef() {
		try {
			log.info("botonAgregarBenef ");
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "NUEBEN");
			irAPagina("/view/Parametros/socBenefsreg_reg.xhtml");
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void setBenefi(SocBenefs benefi) {
		this.benefi = benefi;
	}

	public SocBenefs getBenefi() {
		return benefi;
	}

	public void setSocSolbenefSelected(SocSolbenefs socSolbenefSelected) {
		this.socSolbenefSelected = socSolbenefSelected;
	}

	public SocSolbenefs getSocSolbenefSelected() {
		return socSolbenefSelected;
	}

	public List<CuentasBen> getBeneficiarios() {
		return beneficiarios;
	}

	public void setBeneficiarios(List<CuentasBen> beneficiarios) {
		this.beneficiarios = beneficiarios;
	}

	public Integer getNroBenefsPendientes1() {
		return nroBenefsPendientes1;
	}

	public void setNroBenefsPendientes1(Integer nroBenefsPendientes1) {
		this.nroBenefsPendientes1 = nroBenefsPendientes1;
	}

	public Integer getNroBenefsPendientesR() {
		return nroBenefsPendientesR;
	}

	public void setNroBenefsPendientesR(Integer nroBenefsPendientesR) {
		this.nroBenefsPendientesR = nroBenefsPendientesR;
	}

	public List<Beneficiario> getBeneficiariosLista() {
		return beneficiariosLista;
	}

	public void setBeneficiariosLista(List<Beneficiario> beneficiariosLista) {
		this.beneficiariosLista = beneficiariosLista;
	}

	public List<SelectItem> getSolicitanteItems() {
		return solicitanteItems;
	}

	public void setSolicitanteItems(List<SelectItem> solicitanteItems) {
		this.solicitanteItems = solicitanteItems;
	}

	public Beneficiario getBeneficiarioSearch() {
		return beneficiarioSearch;
	}

	public void setBeneficiarioSearch(Beneficiario beneficiarioSearch) {
		this.beneficiarioSearch = beneficiarioSearch;
	}
}
