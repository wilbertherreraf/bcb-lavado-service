package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocDetallessol;

import gob.bcb.bpm.pruebaCU.SocSolicitudes;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.log4j.Logger;

public class SolicitudesDSFController extends BaseBeanController {

	private SocSolicitudes solicitud = new SocSolicitudes();
	private SocDetallessol detalle = new SocDetallessol();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> motivos = new ArrayList<SelectItem>();
	private String idSoli = "-1";
	private String idBenef = "-1";
	private String idCuenta = "-1";
	private Integer idCuentaC = -1;
	private String idDescuento = "NO";
	private String idMotivo = "-1";
	private String concepto = "";
	private String conc = "-1";
	private String mensaje = "";
	private String label1 = "";
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean botonHab = true;

	private Logger log = Logger.getLogger(SolicitudesDSFController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	@SuppressWarnings("unchecked")
	public SolicitudesDSFController() {

		recuperarVisit();
		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		String query = "";

		if (!idSoli.equals("900")) {
			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SF' "
					+ " and cla_vigente = 1" + " and trim(sol_codigo) = '" + idSoli + "'";
		} else {
			idSoli = "-1";
			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SF' "
					+ " and cla_vigente = 1" + " order by sol_persona";
		}

		// TODO Auto-generated constructor stub

		motivos.add(new SelectItem("1", "REMESAS DEL EXTERIOR"));
		motivos.add(new SelectItem("2", "EMBAJADAS Y ORGANISMOS INTERNACIONALES"));
		motivos.add(new SelectItem("3", "GIROS"));
		motivos.add(new SelectItem("4", "OPERACIONES PROPIAS DEL BANCO"));

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {

				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		if (!idSoli.equals("-1")) {
			cuentasD.clear();

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") != 69)
						cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-"
								+ res.get("moneda")));
				}
			}

			query = "SELECT ss.ben_codigo " + "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '" + idSoli + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {

					idBenef = (String) res.get("ben_codigo");
				}
			}

			query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and cc.moneda = 69 and sc.cla_vigente = 1 "
					+ " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli + "'";

			List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
			if (resultado2.size() == 1) {
				for (Map<String, Object> res : resultado2) {
					log.info("resultado2" + res.toString());
					idCuentaC = (Integer) res.get("cta_codigo");
				}
			}
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitudTest) {
		this.solicitud = solicitudTest;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public void setIdCuentaC(Integer idCuentaC) {
		this.idCuentaC = idCuentaC;
	}

	public Integer getIdCuentaC() {
		return idCuentaC;
	}

	public List<SelectItem> getMotivos() {
		return motivos;
	}

	public void setMotivos(List<SelectItem> motivos) {
		this.motivos = motivos;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConc() {
		return conc;
	}

	public void setConc(String conc) {
		this.conc = conc;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getIdDescuento() {
		return idDescuento;
	}

	public void setIdDescuento(String idDescuento) {
		this.idDescuento = idDescuento;
	}

	public String getIdMotivo() {
		return idMotivo;
	}

	public void setIdMotivo(String idMotivo) {
		this.idMotivo = idMotivo;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * 
	 * @return
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		String corrs = Servicios.getCorrelativo(idSoli);

		String sigla = Servicios.getSigla(idSoli);

		solicitud.setSolCodigo(idSoli + "   ");
		solicitud.setClaTipo("TD");
		solicitud.setClaEstado('R');
		solicitud.setSocCuentad(Integer.parseInt(idCuenta));
		solicitud.setSocCuentac(idCuentaC);
		solicitud.setSocCorrelativo(sigla + "-" + corrs + "-" + Servicios.obtGestion());
		solicitud.setSocMontoord(BigDecimal.valueOf(0));
		solicitud.setMoneda("USD");
		solicitud.setMonedaT("USD");
		detalle = new SocDetallessol();
		detalle.setBenCodigo(idBenef);
		detalle.setDetMonto(solicitud.getSocMontome());
		detalle.setDetMontoord(solicitud.getSocMontoord());
		detalle.setMoneda(solicitud.getMoneda());
		detalle.setMonedaT(solicitud.getMonedaT());
		detalle.setDetConcepto(concepto.toUpperCase());
		detalle.setDetInfo(idMotivo);

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "nueva");
		mapaParametros.put("solicitud", solicitud);
		mapaParametros.put("detalle", detalle);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
		log.info("Numero de Solicitud: " + nroSolicitud);

		if (!nroSolicitud.equals("-1")) {
			this.mensaje = "El aviso fue enviado correctamente con el n�mero " + solicitud.getSocCorrelativo() + ".";
			this.botonHab = true;
		} else {
			this.mensaje = "Se produjo un error al enviar el aviso.";
			this.botonHab = true;
		}
	}

}
