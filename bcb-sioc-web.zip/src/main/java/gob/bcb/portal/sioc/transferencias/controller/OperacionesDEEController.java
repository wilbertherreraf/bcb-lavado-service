package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocDetallesope;

import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class OperacionesDEEController {

	private SocOperaciones operacion = new SocOperaciones();
	private SocDetallesope detalleO = new SocDetallesope();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> referencias = new ArrayList<SelectItem>();
	private String idSoli = "-1";
	private String idMoneda = "";
	private String idBenef = "-1";
	private String idRefer = "-1";
	private Integer idCuenta = -1;
	private String banco = "";
	private String banco1 = "";
	private String cuenta = "";
	private String nombreF = "";
	private String nit = "";
	private String mon = "";
	private String mon11 = "";
	private String men = "";
	private String concepto = "";
	private String mensaje = "";
	private String usuario;
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean botonHab = true;
	private Boolean swiftVer = false;
	private boolean deshabilitado = false;

	private Logger log = Logger.getLogger(OperacionesDEEController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";
	private String sIOCWEB_TIPOPERACION;

	public OperacionesDEEController() {

		Visit visit = Visit.getVisit();
		usuario = visit.getUsuarioSession().getLogin();
		idSoli = visit.getUsuarioSession().getSolicitante().getSolCodigo();

		sIOCWEB_TIPOPERACION = (String) visit.getParametro("SIOCWEB_TIPOPERACION");

		log.info("enter sIOCWEB_TIPOPERACION " + sIOCWEB_TIPOPERACION);

		monedas.add(new SelectItem("USD", "DOLARES ESTADOUNIDENSES"));
		// monedas.add(new SelectItem("EUR", "EUROS"));

		referencias.add(new SelectItem("MS", "MENSAJE SWIFT"));
		referencias.add(new SelectItem("EB", "EXTRACTO BANCARIO"));

		String query = "";

		if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT_EXPORT")) {
			query = " select ben_codigo, ben_nombre " + " from soc_benefsexp " + " where cla_vigente = 1" + " order by ben_nombre";
			
		} else if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT_EMBA")) {
			query = " select ben_codigo, ben_nombre " + " from soc_benefsexp " + " where cla_vigente = 1" + " and cla_entidad = 'EMB'"
					+ " order by ben_nombre";
			
		} else if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT_ORD_PAG")) {
			query = " select ben_codigo, ben_nombre " + " from soc_benefsexp " + " where cla_vigente = 1" + " and cla_entidad = 'OTR'"
					+ " order by ben_nombre";
		}

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				solics.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
			}
		}

	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		cuentasD.clear();
		if (!idBenef.equals("-1")) {

			String query = " select cta_codigo, cta_nrocuenta" + " from soc_cuentasexp " + " where cla_vigente = 1 and ben_codigo = '" + idBenef
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					cuentasD.add(new SelectItem(res.get("cta_codigo"), (String) res.get("cta_nrocuenta")));
				}
			}
		}

		return cuentasD;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		Integer mon1 = 0;
		mensaje = null;
		idCuenta = sel;
		log.info("Valor seleccionado: " + sel);

		banco = "";
		mon = "";
		cuentaHab = false;
		this.deshabilitado = false;
		if (idCuenta != -1) {
			String query = " select c.bco_codigo, c.moneda, s.sol_persona, c.bco_codigo1" + " from soc_cuentasexp c, soc_solicitante s"
					+ " where c.cla_vigente = 1 and c.cta_codigo = '" + idCuenta + "'" + " and c.bco_codigo = s.sol_codigo";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					//
					banco = (String) res.get("sol_persona");
					if (res.get("moneda") == null) {

						this.mensaje = "Error no  existe moneda para el  Nro de Cta:" + idCuenta;
						this.botonHab = true;
						this.deshabilitado = true;

						return;
					} else {
						mon1 = (Integer) res.get("moneda");
					}

					if (mon1 == 34)
						mon = "DOLARES ESTADOUNIDENSES";
					else
						mon = "BOLIVIANOS";
					String bco = (String) res.get("bco_codigo1");
					if (bco != null) {
						query = " select c.bco_codigo1, c.moneda1, s.sol_persona, c.cta_nrocuenta1" + " from soc_cuentasexp c, soc_solicitante s"
								+ " where c.cla_vigente = 1 and c.cta_codigo = '" + idCuenta + "'" + " and c.bco_codigo1 = s.sol_codigo";
						List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
						if (resultado2.size() == 1) {
							for (Map<String, Object> res2 : resultado2) {
								log.info("resultado" + res2.toString());
								banco1 = (String) res2.get("sol_persona");
								cuenta = (String) res2.get("cta_nrocuenta1");
								mon1 = (Integer) res2.get("moneda1");
								if (mon1 == 34)
									mon11 = "DOLARES ESTADOUNIDENSES";
								else
									mon11 = "BOLIVIANOS";
								cuentaHab = true;
							}
						}
					}
				}
			}
		}
	}

	public void seleccionBChanged(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idBenef = sel;
		log.info("Valor seleccionado: " + sel);

		nombreF = "";
		nit = "";
		banco = "";
		mon = "";
		idCuenta = null;
		cuentasD.clear();
		mensaje = null;
		if (!idBenef.equals("-1")) {
			String query = " select ben_factura, ben_nit" + " from soc_benefsexp" + " where cla_vigente = 1 and ben_codigo = '" + idBenef + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					//
					nombreF = (String) res.get("ben_factura");
					nit = (String) res.get("ben_nit");
				}
			}
		}
	}

	public void seleccion2Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idRefer = sel;
		log.info("Valor seleccionado: " + sel);
		swiftVer = false;
		if (!idRefer.equals("-1")) {
			if (idRefer.equals("MS")) {
				swiftVer = true;
				// detalleO.setDetConcepto("SEGoN MENSAJE SWIFT ");
			} else {
				concepto = "EXTRACTO BANCARIO DE FECHA ";
			}
		}
	}

	public void swiftChanged(ValueChangeEvent event) {
		men = (String) event.getNewValue();

		concepto = "MENSAJE SWIFT " + men;
		if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT_ORD_PAG")) {
			concepto = "MENSAJE SWIFT " + men;
		}
	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public SocDetallesope getDetalleO() {
		return detalleO;
	}

	public void setDetalleO(SocDetallesope detalleO) {
		this.detalleO = detalleO;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public void setReferencias(List<SelectItem> referencias) {
		this.referencias = referencias;
	}

	public List<SelectItem> getReferencias() {
		return referencias;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Integer idCuenta) {
		this.idCuenta = idCuenta;
	}

	public String getIdMoneda() {
		return idMoneda;
	}

	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}

	public void setIdRefer(String idRefer) {
		this.idRefer = idRefer;
	}

	public String getIdRefer() {
		return idRefer;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getBanco() {
		return banco;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setMon(String mon) {
		this.mon = mon;
	}

	public String getMon() {
		return mon;
	}

	public void setBanco1(String banco1) {
		this.banco1 = banco1;
	}

	public String getBanco1() {
		return banco1;
	}

	public void setMon11(String mon11) {
		this.mon11 = mon11;
	}

	public String getMon11() {
		return mon11;
	}

	public void setMen(String men) {
		this.men = men;
	}

	public String getMen() {
		return men;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setNombreF(String nombreF) {
		this.nombreF = nombreF;
	}

	public String getNombreF() {
		return nombreF;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public void setSwiftVer(Boolean swiftVer) {
		this.swiftVer = swiftVer;
	}

	public Boolean getSwiftVer() {
		return swiftVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * 
	 * @return
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		deshabilitado = false;

		log.info("Ingresando al boton Guardar");

		if (!StringUtils.isBlank(operacion.getGlosaRefencia())) {
			operacion.setGlosaRefencia(operacion.getGlosaRefencia().toUpperCase());
		}
		operacion.setSolCodigo("900");
		operacion.setClaOperacion("TD");
		operacion.setClaEstado('P');
		if (idMoneda.equals("USD"))
			operacion.setMoneda(34);
		else
			operacion.setMoneda(53);

		detalleO = new SocDetallesope();
		detalleO.setBenCodigo(idBenef);
		detalleO.setDetCtabenef(idCuenta.toString());
		detalleO.setDetMonto(operacion.getOpeMontome());
		detalleO.setDetMontoOrd(operacion.getOpeMontome());
		detalleO.setMoneda(operacion.getMoneda());
		detalleO.setDetInfo(men);
		detalleO.setDetConcepto(concepto.toUpperCase());

		log.info("concepto:" + detalleO.getDetConcepto());

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();
		// whfr01 glosas
		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT_EXPORT")) {
			mapaParametros.put("opcion", "exportador");
		} else if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT_EMBA")) {
			mapaParametros.put("opcion", "exportadorEMB");
		} else if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT_ORD_PAG")) {
			mapaParametros.put("opcion", "exportadorOP");
		}
		mapaParametros.put("operacion", operacion);
		mapaParametros.put("detalle", detalleO);
		mapaParametros.put("usuario", usuario);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String nroOpe = (String) mapaRespuesta.get("nroOperacion");
		log.info("Numero de Operacion: " + nroOpe);

		this.botonHab = true;
		if (!nroOpe.equals("0000")) {
			this.mensaje = "La operacion se genero correctamente con el numero " + nroOpe + ".";
		} else {
			this.mensaje = "Se produjo un error al generar la operacion.";
		}
	}

	public boolean isDeshabilitado() {
		return deshabilitado;
	}

	public void setDeshabilitado(boolean deshabilitado) {
		this.deshabilitado = deshabilitado;
	}

}
