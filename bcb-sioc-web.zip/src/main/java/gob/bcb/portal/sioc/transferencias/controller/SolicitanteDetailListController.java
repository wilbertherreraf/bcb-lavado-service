package gob.bcb.portal.sioc.transferencias.controller;

public class SolicitanteDetailListController {

}
