package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;

//import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
//import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class OperacionesDEController {

	private SocOperaciones operacion = new SocOperaciones();
	private SocDetallesope detalleO = new SocDetallesope();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private String idSoli = "-1";
	private String idMoneda = "";
	private String idBenef = "999999";
	private String idCuenta = "-1";
	private String idCuentaC = "-1";
	private String concepto = "";
	private String mensaje = "";
	private String usuario;
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean botonHab = true;

	private Logger log = Logger.getLogger(OperacionesDEController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	private String sIOCWEB_TIPOPERACION;

	public OperacionesDEController() {

		Visit visit = Visit.getVisit();
		usuario = visit.getUsuarioSession().getLogin();
		idSoli = visit.getUsuarioSession().getSolicitante().getSolCodigo();

		sIOCWEB_TIPOPERACION = (String) visit.getParametro("SIOCWEB_TIPOPERACION");

		log.info("enter sIOCWEB_TIPOPERACION " + sIOCWEB_TIPOPERACION);
		concepto = "";

		if (sIOCWEB_TIPOPERACION.equals("OP_CHEQ_COB")) {
			concepto = "ENVIO DE CHEQUE EN COBRANZA NO. ";
			idMoneda = "USD";
		}

		monedas.add(new SelectItem("USD", "DOLARES AMERICANOS"));
		monedas.add(new SelectItem("EUR", "EUROS"));

		String query = "";

		query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SP' " + " and cla_vigente = 1 "
				+ " order by sol_persona";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		}

	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		cuentasD.clear();
		if (!idSoli.equals("-1")) {

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					//
					if (res.get("cta_numero") != null) {
						cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-"
								+ res.get("cta_numero")));
					} else {
						cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")));
					}
				}
			}

		}

		return cuentasD;
	}

	public List<SelectItem> getCuentasC() {
		log.info("enter getcuentasC");
		String moneda = "";
		cuentasC.clear();
		if (!idSoli.equals("-1")) {

			String query = " SELECT sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " FROM soc_solcuentas sc, soc_cuentassol cc "
					+ " WHERE sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {
					//
					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					if (res.get("cta_numero") != null) {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda
								+ "-" + res.get("cta_numero")));
					} else {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda));
					}
				}
			}
		}

		return cuentasC;
	}

	public void swiftChanged(ValueChangeEvent event) {
		log.info("enter changed");
		String men = (String) event.getNewValue();

		if (sIOCWEB_TIPOPERACION.equals("OP_CHEQ_COB")) {
			concepto = concepto + men + " A FAVOR DE ";
		} else if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT")) {
			concepto = "MENSAJE SWIFT " + men;
		}
	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public SocDetallesope getDetalleO() {
		return detalleO;
	}

	public void setDetalleO(SocDetallesope detalleO) {
		this.detalleO = detalleO;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdMoneda() {
		return idMoneda;
	}

	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public String getIdCuentaC() {
		return idCuentaC;
	}

	public void setIdCuentaC(String idCuentaC) {
		this.idCuentaC = idCuentaC;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConcepto() {
		return concepto;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * 
	 * @return
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		if (!StringUtils.isBlank(operacion.getGlosaRefencia())) {
			operacion.setGlosaRefencia(operacion.getGlosaRefencia().toUpperCase());
		}
		operacion.setSolCodigo(idSoli);
		operacion.setClaEstado('P');
		operacion.setOpeCtaoperacion(Integer.parseInt(idCuenta));
		String nroCuenta = Servicios.getNroCuenta(idSoli, operacion.getOpeCtaoperacion());
		operacion.setOpeNrocuentad(nroCuenta);
		nroCuenta = "";
		operacion.setOpeCtacomision(Integer.parseInt(idCuentaC));
		nroCuenta = Servicios.getNroCuenta(idSoli, operacion.getOpeCtacomision());
		operacion.setOpeNrocuentac(nroCuenta);
		if (idMoneda.equals("USD"))
			operacion.setMoneda(34);
		else
			operacion.setMoneda(53);

		detalleO.setBenCodigo(idBenef);
		detalleO.setDetMonto(operacion.getOpeMontome());
		detalleO.setDetMontoOrd(operacion.getOpeMontome());
		detalleO.setMoneda(operacion.getMoneda());
		detalleO.setDetConcepto(concepto.toUpperCase());

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		if (sIOCWEB_TIPOPERACION.equals("OP_TRANS_DEL_EXT")) {
			operacion.setClaOperacion("TD");
			mapaParametros.put("opcion", "delext");
		} else if (sIOCWEB_TIPOPERACION.equals("OP_CHEQ_COB")) {
			operacion.setClaOperacion("CE");
			mapaParametros.put("opcion", "cobrenv");
		}
		mapaParametros.put("operacion", operacion);
		mapaParametros.put("detalle", detalleO);
		mapaParametros.put("usuario", usuario);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String nroOpe = (String) mapaRespuesta.get("nroOperacion");
		log.info("Numero de Operacion: " + nroOpe);

		if (!nroOpe.equals("-1")) {
			this.mensaje = "La operacion se genero correctamente con el numero " + nroOpe + ".";
			this.botonHab = true;
		} else {
			this.mensaje = "Se produjo un error al generar la operacion.";
			this.botonHab = true;
		}
	}

}
