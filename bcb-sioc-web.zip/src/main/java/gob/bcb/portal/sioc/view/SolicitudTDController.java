package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOrdenesPago;
import gob.bcb.bpm.pruebaCU.SocSolcuentas;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasPK;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.NumeroALetra;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.CalcularVariables;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.service.servicioSioc.pojos.ComprobanteDet;
import gob.bcb.service.servicioSioc.pojos.Detallesol;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransferdet;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

public class SolicitudTDController extends BaseBeanController {
	private Logger log = Logger.getLogger(SolicitudTDController.class);

	private List<SelectItem> monedaItems = new ArrayList<SelectItem>();
	private List<SelectItem> monedaTransferItems = new ArrayList<SelectItem>();
	private List<SelectItem> monedasItemsSigla = null;

	private String sIOCWEB_TIPOPERACION;
	private SocSolicitudes socSolicitudes = new SocSolicitudes();
	private List<SocDetallessol> socDetallessolLista = new ArrayList<SocDetallessol>();
	private List<Detallesol> detallesolLista = new ArrayList<Detallesol>();
	private List<SocFacturas> socFacturasLista = new ArrayList<SocFacturas>();
	private Detallesol detallesolSelected = new Detallesol();
	private SocEsquemas socEsquemasSelected = new SocEsquemas();
	private SocSolicitante socSolicitante = new SocSolicitante();
	// ////////////////
	private SocSolicitudctas socSolicitudctasDestino = new SocSolicitudctas();
	private SocSolicitudctas socSolicitudctasMovProv = new SocSolicitudctas();
	private SocSolicitudctas socSolicitudctasComGAdm = new SocSolicitudctas();
	private SocSolicitudctas socSolicitudctasComCTra = new SocSolicitudctas();
	private SocCuentassol socCuentassolDestino = new SocCuentassol();
	private SocCuentassol socCuentassolMovProv = new SocCuentassol();
	private SocCuentassol socCuentassolComGAdm = new SocCuentassol();
	private SocCuentassol socCuentassolComCTra = new SocCuentassol();

	private SocDetallessol socDetallessolSelected = new SocDetallessol();

	private List<SelectItem> socSolicitanteItems = new ArrayList<SelectItem>();
	private List<SelectItem> socSolcuentasItems = new ArrayList<SelectItem>();
	private List<SelectItem> socSolcuentasComisItems = new ArrayList<SelectItem>();
	private List<SelectItem> socCuentassolItems = new ArrayList<SelectItem>();
	private List<SelectItem> socCuentassolFVItems = new ArrayList<SelectItem>();
	private List<SelectItem> socCuentassolComisItems = new ArrayList<SelectItem>();
	private List<SelectItem> socBenefsItemsExt = new ArrayList<SelectItem>();
	private List<SelectItem> socBenefsItemsLoc = new ArrayList<SelectItem>();

	// detalle bneficiarios
	private Beneficiario beneficiarioSelected = new Beneficiario();

	private List<SelectItem> socBenefsItems = new ArrayList<SelectItem>();
	private List<SelectItem> nroCuentabcoItems = new ArrayList<SelectItem>();
	private List<SelectItem> nroCtasCtasComisBenefItems = new ArrayList<SelectItem>();
	private List<SelectItem> socBancosPlazaItems = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasContabsItems = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasContabsNroAfectItems = new ArrayList<SelectItem>();
	private BancoPlaza bancoPlazaSelected = new BancoPlaza();
	private BancoPlaza bancoPlazaSelectedInter = new BancoPlaza();

	private List<ComprobanteDet> comprobanteLista = new ArrayList<ComprobanteDet>();
	private List<ComprobanteDet> comprobanteRenglonesLista = new ArrayList<ComprobanteDet>();
	private SocComprobante socComprobanteSelected = new SocComprobante();
	private BigDecimal debeSuma = BigDecimal.valueOf(0.00);
	private BigDecimal haberSuma = BigDecimal.valueOf(0.00);

	private SocOpecomi socOpecomiTOTTRANS;
	private SocOpecomi socOpecomiTOTDETMT;
	private SocOpecomi socOpecomiVENTAUSD;
	private SocOpecomi socOpecomiDIFERTC;
	private SocOpecomi socOpecomiCOMCTRA;
	private SocOpecomi socOpecomiTOTCOMISION;
	private SocOpecomi socOpecomiTOTDEBITO;

	@PostConstruct
	public void inicio() {
		log.info("=============ooo00OOO00ooo===================");
		log.info("PostConstruct SolicitudController - " + getClass().getName());
		try {
			recuperarVisit();
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			String sIOCWEB_SUBTIPOPER = (String) getVisit().getParametro("SIOCWEB_SUBTIPOPER");
			String sIOCWEB_CODTIPOOPER = (String) getVisit().getParametro("SIOCWEB_CODTIPOOPER");
			String socCodigo = (String) getVisit().getParametro("SIOCWEB_SOCCODIGO");
			String sIOCWEB_ACTION = (String) getVisit().getParametro("SIOCWEB_ACTION");

			log.info("XXX:sIOCWEB_CODTIPOOPER " + sIOCWEB_CODTIPOOPER);

			if (!StringUtils.isBlank(socCodigo)) {
				if (!StringUtils.isBlank(sIOCWEB_ACTION)) {
					if (sIOCWEB_ACTION.equals("SOL_EDIT")) {
						actualizarSolicitud(socCodigo);
						recuperarListaSolicitantes(socSolicitudes, socSolicitante.getClaEntidad());						
						actualizar();
						monedasListas();
						actualizarCuentasDestino(socSolicitudes);
					} else {
						actualizarSolicitud(socCodigo);
					}
				} else {
					actualizarSolicitud(socCodigo);
				}
			} else {
				if (sIOCWEB_CODTIPOOPER != null) {

					String sIOCWEB_ESQREF = (String) getVisit().getParametro("SIOCWEB_ESQREF");
					String sIOCWEB_CTAPROV = (String) getVisit().getParametro("SIOCWEB_CTAPROV");
					String sIOCWEB_CLAENTIDAD = (String) getVisit().getParametro("SIOCWEB_CLAENTIDAD");
					String sIOCWEB_TIPOTRANSFER = (String) getVisit().getParametro("SIOCWEB_TIPOTRANSFER");
					String sIOCWEB_CODESQ = (String) getVisit().getParametro("SIOCWEB_CODESQ");

					socEsquemasSelected.setCodTipooper(sIOCWEB_CODTIPOOPER);
					socEsquemasSelected.setCveSubtipooper(sIOCWEB_SUBTIPOPER);
					if (NumberUtils.isNumber(sIOCWEB_ESQREF))
						socEsquemasSelected.setCodEsqref((sIOCWEB_ESQREF != null ? Integer.valueOf(sIOCWEB_ESQREF) : null));
					if (NumberUtils.isNumber(sIOCWEB_CODESQ))
						socEsquemasSelected.setEsqCodigo((sIOCWEB_CODESQ != null ? Integer.valueOf(sIOCWEB_CODESQ) : null));
					socEsquemasSelected.setProvisiona(sIOCWEB_CTAPROV);
					socEsquemasSelected.setTipoTransfer(sIOCWEB_TIPOTRANSFER);
					// retencion de comisiones sin descuento
					socEsquemasSelected.setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);
					socSolicitante.setClaEntidad(sIOCWEB_CLAENTIDAD);
					nuevaSolicitud();
					inicializarSolicitud(socSolicitudes);

					recuperarListaSolicitantes(socSolicitudes, socSolicitante.getClaEntidad());
					monedasListas();
					actualizarCuentasDestino(socSolicitudes);
				}
			}

		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		} finally {
			getVisit().removeParametro("SIOCWEB_SOCCODIGO");
			getVisit().removeParametro("SOL_ACTION");
			getVisit().removeParametro("SOL_ESTADO");
			getVisit().removeParametro("SIOCWEB_CODTIPOOPER");
			getVisit().removeParametro("SIOCWEB_CLAOPERACION");
			getVisit().removeParametro("SIOCWEB_SUBTIPOPER");
			getVisit().removeParametro("SIOCWEB_ESQREF");
			getVisit().removeParametro("SIOCWEB_CTAPROV");
			getVisit().removeParametro("SIOCWEB_CLAENTIDAD");
			getVisit().removeParametro("SIOCWEB_TIPOTRANSFER");
			getVisit().removeParametro("SIOCWEB_CODESQ");
			getVisit().removeParametro("SIOCWEB_ACTION");
			
			// la desesperada!! esto no debería estar aqui
			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
			sesiones.remove("solicitudSearchPanel");			
		}

	}

	private void nuevaSolicitud() {
		log.info("nuevaSolicitud: Creando por defecto");
		socSolicitudes = new SocSolicitudes();

		socSolicitudes.setSolEntsolic(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		if (!getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitudes.setSolCodigo(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		}
	}

	private void inicializarSolicitud(SocSolicitudes socSolicitudes) {
		socCuentassolItems = new ArrayList<SelectItem>();
		socSolcuentasItems = new ArrayList<SelectItem>();

		socSolicitudes.setSocMontome(BigDecimal.ZERO);
		socSolicitudes.setSocMontomn(BigDecimal.ZERO);
		socSolicitudes.setSocMontoord(BigDecimal.ZERO);
		socSolicitudes.setCodMoneda(Constants.COD_MONEDA_USD);
		socSolicitudes.setCodMonedat(Constants.COD_MONEDA_USD);

		socSolicitudes.setClaTipo(socEsquemasSelected.getCodTipooper());
		socSolicitudes.setCveSubtipooper(socEsquemasSelected.getCveSubtipooper());
		socSolicitudes.setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);
		socSolicitudes.setSocTipnegociacion(Constants.CLAVE_TIPNEGOCIA_NORMAL);
		// generado por sistema sioc
		socSolicitudes.setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
		socSolicitudes.setFecha(new Date());

		SocSolicitudctasPK socSolicitudctasPK = new SocSolicitudctasPK();
		socSolicitudctasMovProv = new SocSolicitudctas();
		socSolicitudctasMovProv.setId(socSolicitudctasPK);
		socSolicitudctasMovProv.getId().setTipoCuenta(Constants.COD_CLAVE_MOVPROVISION);
		socSolicitudctasMovProv.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);
		
		SocSolicitudctasPK socSolicitudctasPKDest = new SocSolicitudctasPK();
		socSolicitudctasDestino = new SocSolicitudctas();
		socSolicitudctasDestino.setId(socSolicitudctasPKDest);
		socSolicitudctasDestino.getId().setTipoCuenta(Constants.COD_CLAVE_MOVDESTINO);
		socSolicitudctasDestino.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);		

		SocSolicitudctasPK socSolicitudctasPKga = new SocSolicitudctasPK();
		socSolicitudctasComGAdm = new SocSolicitudctas();
		socSolicitudctasComGAdm.setId(socSolicitudctasPKga);
		socSolicitudctasComGAdm.getId().setTipoCuenta(Constants.COD_CLAVE_COMGADM);
		socSolicitudctasComGAdm.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);

		SocSolicitudctasPK socSolicitudctasPKct = new SocSolicitudctasPK();
		socSolicitudctasComCTra = new SocSolicitudctas();
		socSolicitudctasComCTra.setId(socSolicitudctasPKct);
		socSolicitudctasComCTra.getId().setTipoCuenta(Constants.COD_CLAVE_COMCTRA);
		socSolicitudctasComCTra.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);

		// recuperamos la moneda de la provision

		if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			socSolicitudes.setCodMoneda(Constants.COD_MONEDA_USD);
			socSolicitudes.setCodMonedat(Constants.COD_MONEDA_USD);
			socSolicitudctasMovProv.setCodMoneda(Constants.COD_MONEDA_USD);
		}

		if (socEsquemasSelected.getEsqCodigo() != null && socEsquemasSelected.getEsqCodigo().compareTo(0) > 0) {
			socEsquemasSelected = getSolicitudBean().getSocEsquemasDao().esquemaByCod(socEsquemasSelected.getEsqCodigo());
			socSolicitudes.setEsqCodigo(socEsquemasSelected.getEsqCodigo());
		}

		if (socSolicitudes.getEsqCodigo() == null) {
			recuperarEsquemas(socSolicitudes);
		}

		actualizar();

		socDetallessolSelected = new SocDetallessol();
		socDetallessolLista = new ArrayList<SocDetallessol>();
		detallesolLista = new ArrayList<Detallesol>();
	}

	private void monedasListas() {
		monedaItems = new ArrayList<SelectItem>();
		monedaTransferItems = new ArrayList<SelectItem>();

		List<GenMoneda> genMonedaLista = new ArrayList<GenMoneda>();
		List<GenMoneda> genMonedaTransferLista = new ArrayList<GenMoneda>();

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			List<Integer> monedaList = new ArrayList<Integer>();
			monedaList.add(Constants.COD_MONEDA_BS);
			genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedasLista(monedaList, false);

			List<Integer> monedaList0 = new ArrayList<Integer>();
			monedaList0.add(Constants.COD_MONEDA_BS);
			monedaList0.add(Constants.COD_MONEDA_USD);
			genMonedaTransferLista = getSolicitudBean().getGenMonedaDao().getMonedasLista(monedaList0, true);
		}

		for (GenMoneda genMoneda : genMonedaLista) {
			monedaItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}

		for (GenMoneda genMoneda : genMonedaTransferLista) {
			monedaTransferItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}

	}

	private void actualizarSolicitud(String socCodigo) {
		log.info("actualizando solicitud : '" + socCodigo + "'");

		Solicitud solicitudTO = getSolicitudBean().getProcesosSolicitud().recuperarSolicitudSimple(socCodigo);
		socSolicitudes = solicitudTO.getSolicitud();

		socDetallessolLista = solicitudTO.getSocDetallessolLista();
		detallesolLista = getSolicitudBean().getSocDetallessolDao().recuperarListaDetallessol(socSolicitudes, socDetallessolLista);

		recuperarDatosDetalle(socSolicitudes, socDetallessolLista);

		socSolicitante = solicitudTO.getSocSolicitante();
		if (solicitudTO.getSocEsquemas() != null) {
			socEsquemasSelected = solicitudTO.getSocEsquemas();
		}

		comprobanteLista = new ArrayList<ComprobanteDet>();
		if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			comprobanteLista = getSolicitudBean().getSocComprobanteDao().comprobantesGenerados(socCodigo);
		}

		socOpecomiTOTTRANS = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "TOTTRANSMT");
		socOpecomiVENTAUSD = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "VENTAUSD");
		socOpecomiDIFERTC = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "DIFERTC");
		socOpecomiTOTCOMISION = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "TOTCOMISION");
		socOpecomiCOMCTRA = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, Constants.COD_VAR_COMTRANSF);
		socOpecomiTOTDEBITO = getSolicitudBean().getSocOpecomiDao().getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0, "TOTDEBITO");

		socSolicitudctasDestino = getSolicitudBean().getSocSolicitudctasDao().getCuenta(socSolicitudes.getSocCodigo(),
				Constants.COD_CLAVE_MOVDESTINO, null, null, null, null);

		socSolicitudctasMovProv = getSolicitudBean().getSocSolicitudctasDao().getCuenta(socSolicitudes.getSocCodigo(),
				Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);

		socSolicitudctasComGAdm = getSolicitudBean().getSocSolicitudctasDao().getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMGADM,
				null, null, null, null);

		socSolicitudctasComCTra = getSolicitudBean().getSocSolicitudctasDao().getCuenta(socSolicitudes.getSocCodigo(), Constants.COD_CLAVE_COMCTRA,
				null, null, null, null);

		if (socSolicitudctasMovProv != null) {
			socCuentassolMovProv = getSolicitudBean().getSocCuentassolDao().getByAfectable(socSolicitudctasMovProv.getCtaAfectable());
			if (socCuentassolMovProv == null)
				socCuentassolMovProv = new SocCuentassol();
		}

		if (socSolicitudctasDestino != null) {
			socCuentassolDestino = getSolicitudBean().getSocCuentassolDao().getByAfectable(socSolicitudctasDestino.getCtaAfectable());
			if (socCuentassolDestino == null)
				socCuentassolDestino = new SocCuentassol();
		}

		if (socSolicitudctasComGAdm != null) {
			socCuentassolComGAdm = getSolicitudBean().getSocCuentassolDao().getByAfectable(socSolicitudctasComGAdm.getCtaAfectable());
			if (socCuentassolComGAdm == null)
				socCuentassolComGAdm = new SocCuentassol();
		}

		if (socSolicitudctasComCTra != null) {
			socCuentassolComCTra = getSolicitudBean().getSocCuentassolDao().getByAfectable(socSolicitudctasComCTra.getCtaAfectable());
			if (socCuentassolComCTra == null)
				socCuentassolComCTra = new SocCuentassol();
		}

	}

	private void actualizar() {
		actualizarCuentasProvSolicitante(socSolicitudes);
		actualizarCtasdeCtasSolicitante(socSolicitudes, socSolicitudctasDestino);
		actualizarListasComisSolicitante(socSolicitudes);
		actualizarCtasdeCtasComisSolic(socSolicitudes, socSolicitudctasComGAdm);
		 recuperarListaSolicitantes(socSolicitudes,
		 socSolicitante.getClaEntidad());

	}

	private void recuperarListaSolicitantes(SocSolicitudes socSolicitudes, String claTipoEntidad) {
		socSolicitanteItems = new ArrayList<SelectItem>();
		List<SocSolicitante> socSolicitanteLista = new ArrayList<SocSolicitante>();

		if (!StringUtils.isBlank(socSolicitudes.getSocCodigo())) {
			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socSolicitudes.getSolCodigo());
			if (socSolicitante != null)
				socSolicitanteLista.add(socSolicitante);
		} else {
			if (StringUtils.isBlank(socSolicitudes.getSolCodigo())
					&& getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, claTipoEntidad);

			} else if (!StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
				socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socSolicitudes.getSolCodigo());
				if (socSolicitante != null)
					socSolicitanteLista.add(socSolicitante);
			}
		}
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			socSolicitanteItems.add(new SelectItem("" + socSolicitante.getSolCodigo().trim() + "", socSolicitante.getSolPersona() + " ["
					+ socSolicitante.getSolCodigo() + "]"));
		}

	}

	public void solicitanteChanged(ActionEvent event) {
		log.info("solicitanteChanged " + socSolicitudes.getSolCodigo());
		inicializarSolicitud(socSolicitudes);

	}

	private void actualizarCuentasDestino(SocSolicitudes socSolicitudes) {
		// actualiza listas segun valores en la solicitud
		socCuentassolFVItems = new ArrayList<SelectItem>();
		// lista de cuentas de la entidad solicitante
		Map<String, SocCuentassol> mapaCrtl = new HashMap<String, SocCuentassol>();
		List<SocCuentassol> socCuentassolLista0 = getSolicitudBean().getSocCuentassolDao().findByClaveCuenta(Constants.COD_CLAVE_FONDOSVISTA);

		for (SocCuentassol socCuentassol : socCuentassolLista0) {
			if (!StringUtils.isBlank(socCuentassol.getCtaAfectable())) {
				if (!mapaCrtl.containsKey(socCuentassol.getCtaAfectable())) {
					socCuentassolFVItems.add(new SelectItem(StringUtils.trim(socCuentassol.getCtaAfectable()), socCuentassol.getCtaMovimiento()
							+ " - " + socCuentassol.getCtaNommovimiento() + " " + socCuentassol.getMoneda()));
					mapaCrtl.put(socCuentassol.getCtaAfectable(), socCuentassol);
				}
			}
		}
	}

	/**
	 * Actualiza todos los datos del solicitante, listas combos, mapas segun el
	 * codigo solicitante en la solicitud
	 * 
	 * @param socSolicitudes
	 * @param socSolicitanteSel
	 */
	private void actualizarCuentasProvSolicitante(SocSolicitudes socSolicitudes) {
		log.info("recuperando listas Solicitud codsol: " + socSolicitudes.getSolCodigo());
		// actualiza listas segun valores en la solicitud
		socCuentassolItems = new ArrayList<SelectItem>();
		// lista de cuentas de la entidad solicitante

		if (StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
			return;
		}

		List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasSolicitante(socSolicitudes.getSolCodigo(), null, null,
				null, null, null, null);

		for (SocCuentassol socCuentassol : socCuentassolLista) {
			if (!StringUtils.isBlank(socCuentassol.getCtaAfectable())) {
				socCuentassolItems.add(new SelectItem(StringUtils.trim(socCuentassol.getCtaAfectable()), socCuentassol.getCtaMovimiento() + " - "
						+ socCuentassol.getCtaNommovimiento() + " " + socCuentassol.getMoneda()));
			}
		}
	}

	private void actualizarListasComisSolicitante(SocSolicitudes socSolicitudes) {
		log.info("recuperando listas Solicitud Comisiones codsol: " + socSolicitudes.getSolCodigo());
		// actualiza listas segun valores en la solicitud
		socCuentassolComisItems = new ArrayList<SelectItem>();
		if (StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
			return;
		}
		List<SocCuentassol> socCuentassolComisLista = getSolicitudBean().getSocCuentassolDao().ctasSolicitante(socSolicitudes.getSolCodigo(), null,
				null, null, null, null, null);
		for (SocCuentassol socCuentassol : socCuentassolComisLista) {
			socCuentassolComisItems.add(new SelectItem(socCuentassol.getCtaAfectable().trim(), socCuentassol.getCtaMovimiento() + " - "
					+ socCuentassol.getCtaNommovimiento() + " " + socCuentassol.getMoneda()));
		}

	}

	private void actualizarCtasdeCtasSolicitante(SocSolicitudes socSolicitudes, SocSolicitudctas socSolicitudctas) {
		// lista de cuentas propias de una institucion p.e. la CUT tiene
		// libreras, el BUSA tiene cuentas de clientes
		socSolcuentasItems = new ArrayList<SelectItem>();

		log.info("En actualizarCtasdeCtasSolicitante " + socSolicitudes.getSolCodigo() + " CtaAfectable: " + socSolicitudctas.getCtaAfectable());
		if (StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
			return;
		}

		if (socSolicitudctas != null && (!StringUtils.isBlank(socSolicitudctas.getCtaAfectable()))) {
			List<SocSolcuentas> socSolcuentasLista = getSolicitudBean().getSocSolcuentasDao().cuentasEnCuentaSolicitante(
					socSolicitudes.getSolCodigo(), socSolicitudctas.getNroCuenta(), socSolicitudctas.getCtaAfectable(),
					socSolicitudctas.getCodMoneda(), null, null);

			for (SocSolcuentas socSolcuentas : socSolcuentasLista) {
				if (!StringUtils.isBlank(socSolcuentas.getCtaNumero())) {
					socSolcuentasItems.add(new SelectItem(socSolcuentas.getCtaNumero().trim(), socSolcuentas.getCtaNumero() + ": "
							+ socSolcuentas.getCtaNombre()));
				}
			}
		}
	}

	private void actualizarCtasdeCtasComisSolic(SocSolicitudes socSolicitudes, SocSolicitudctas socSolicitudctas) {
		// lista de cuentas propias de una institucion p.e. la CUT tiene
		// libreras, el BUSA tiene cuentas de clientes
		socSolcuentasComisItems = new ArrayList<SelectItem>();

		if (StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
			return;
		}

		if (socSolicitudctas != null && (!StringUtils.isBlank(socSolicitudctas.getCtaAfectable()))) {
			List<SocSolcuentas> socSolcuentasLista = getSolicitudBean().getSocSolcuentasDao().cuentasEnCuentaSolicitante(
					socSolicitudes.getSolCodigo(), socSolicitudctas.getNroCuenta(), socSolicitudctas.getCtaAfectable(),
					socSolicitudctas.getCodMoneda(), null, null);

			for (SocSolcuentas socSolcuentas : socSolcuentasLista) {
				if (!StringUtils.isBlank(socSolcuentas.getCtaNumero())) {
					socSolcuentasComisItems.add(new SelectItem(socSolcuentas.getCtaNumero().trim(), socSolcuentas.getCtaNumero() + ": "
							+ socSolcuentas.getCtaNombre()));
				}
			}
		}
	}

	public void ctaProvisionChanged(ActionEvent event) {
		log.info("En ctaProvisionChanged " + socSolicitudctasMovProv.getCtaAfectable());
		monedaItems = new ArrayList<SelectItem>();

		socSolicitudes.setCodMoneda(null);
		if (!StringUtils.isBlank(socSolicitudctasMovProv.getCtaAfectable())) {
			List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasUnicas(null,
					socSolicitudctasMovProv.getCtaAfectable(), null, true);

			if (socCuentassolLista.size() > 0) {
				socSolicitudctasMovProv.setCodMoneda(socCuentassolLista.get(0).getMoneda());
				socSolicitudctasMovProv.setNroCuenta(socCuentassolLista.get(0).getCtaMovimiento());

				socSolicitudes.setCodMoneda(socSolicitudctasMovProv.getCodMoneda());

				GenMoneda genMoneda = getSolicitudBean().getGenMonedaDao().findByCodMoneda(socSolicitudctasMovProv.getCodMoneda());

				monedaItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
			}
		}
	}

	public void ctaDestinoChanged(ActionEvent event) {
		log.info("En ctaDestinoChanged " + socSolicitudctasDestino.getCtaAfectable());

		List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasUnicas(null, socSolicitudctasDestino.getCtaAfectable(),
				null, true);
		if (socCuentassolLista.size() == 1) {
			socSolicitudctasDestino.setCodMoneda(socCuentassolLista.get(0).getMoneda());
			socSolicitudctasDestino.setNroCuenta(socCuentassolLista.get(0).getCtaMovimiento());

			socSolicitudes.setCodMonedat(socSolicitudctasDestino.getCodMoneda());
		}
		actualizarCtasdeCtasSolicitante(socSolicitudes, socSolicitudctasDestino);
	}

	public void monedaMontoChanged(ActionEvent event) {
		log.info("monedaMontoChanged " + socSolicitudes.getCodMoneda() + " " + socSolicitudes.getCodMonedat());
		calcularMontos();
	}

	/**
	 * evento al cambiar el tipo de retencion en transferencias al exterior, es
	 * con descuento la cta de comision sera la misma que de provision
	 * 
	 * @param event
	 */
	public void tipoRetencionChanged(ActionEvent event) {
		log.info("tipoRetencionChanged " + socSolicitudctasComCTra.getCveTipocomis());

	}

	public void tipoRetencionCtaComisChanged(ActionEvent event) {
		log.info("tipoRetencionCtaComisChanged " + socSolicitudctasComGAdm.getCveTipocomis());
	}

	public void ctaComisionComisChanged(ActionEvent event) {
		log.info("En ctaComisionGAdmChanged " + socSolicitudctasComGAdm.getCtaAfectable());

		List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasUnicas(null, socSolicitudctasComGAdm.getCtaAfectable(),
				null, true);
		if (socCuentassolLista.size() == 1) {
			socSolicitudctasComGAdm.setCodMoneda(socCuentassolLista.get(0).getMoneda());
			socSolicitudctasComGAdm.setNroCuenta(socCuentassolLista.get(0).getCtaMovimiento());
		}

		actualizarCtasdeCtasComisSolic(socSolicitudes, socSolicitudctasComGAdm);
		calcularMontos();		
	}

	private void inicializarNuevoBeneficiario(SocSolicitudes socSolicitudesSel, SocDetallessol socDetallessol) {
		log.info("inicializarNuevoBeneficiario " + socSolicitudesSel.getSolCodigo());
		socDetallessol.setCodBanco(null);
		socDetallessol.setNroCuentabco(socSolicitudctasDestino.getNroCuenta());
		socDetallessol.setDetInfo(null);
		socDetallessol.setCtaCodigo(null);
		socDetallessol.setDetFacturas(null);
		socDetallessol.setBeneficiario(socSolicitudes.getSolCodigo());
		socDetallessol.setCodBancointer(null);
		socDetallessol.setNroCuentabcointer(null);
		socDetallessol.setDetCodttransfer(null);
		socDetallessol.setDetMonto(socSolicitudes.getSocMontome());
		socDetallessol.setCodMoneda(socSolicitudes.getCodMoneda());

		socBancosPlazaItems = new ArrayList<SelectItem>();
		cuentasContabsItems = new ArrayList<SelectItem>();
		cuentasContabsNroAfectItems = new ArrayList<SelectItem>();
		nroCuentabcoItems = new ArrayList<SelectItem>();
		nroCtasCtasComisBenefItems = new ArrayList<SelectItem>();

		beneficiarioSelected = new Beneficiario();
		bancoPlazaSelected = new BancoPlaza();
		bancoPlazaSelectedInter = new BancoPlaza();
	}

	/**
	 * recupera los datos de un detalle
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private void actualizarListaBeneficiarios(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel) {
		log.info("recuperando lista Benefs Solic " + socDetallessolSel.getId().getDetCodigo());

		socBenefsItemsExt = new ArrayList<SelectItem>();

		List<Beneficiario> beneficiarios = getSolicitudBean().getSocBenefsDao().recuperarBeneficiariosSolicitante(socSolicitudes,
				socDetallessolSel.getBenCodigo(), socSolicitudes.getCodMonedat(), null, true);

		for (Beneficiario beneficiario : beneficiarios) {
			socBenefsItemsExt.add(new SelectItem(beneficiario.getBenCodigo().trim(), beneficiario.getBenNombre() + " [" + beneficiario.getBenCodigo()
					+ "]"));
		}
	}

	/**
	 * Actualiza los datos del beneficiario dado un registro detalle del
	 * beneficiario
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private void actualizarListaCtasBenef(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel) {
		log.info("recuperando lista actualizarDatosBeneficiario " + socDetallessolSel.getBenCodigo());

		Map<String, BancoPlaza> bancoPlazaMapaCrtl = new HashMap<String, BancoPlaza>();

		socBancosPlazaItems = new ArrayList<SelectItem>();
		cuentasContabsItems = new ArrayList<SelectItem>();
		beneficiarioSelected = new Beneficiario();

		if (StringUtils.isBlank(socDetallessolSel.getBenCodigo())) {
			return;
		}

		beneficiarioSelected = getSolicitudBean().getSocBenefsDao().recuperarBeneficiario(socSolicitudes, socDetallessolSel);

		if (beneficiarioSelected == null) {
			return;
		}

		List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
		if (socDetallessolSel.getId().getDetCodigo() != null) {
			listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(),
					socSolicitudes.getCodMonedat(), socDetallessolSel.getCodBanco(), null, null, socDetallessolSel.getNroCuentabcointer());
		} else {
			listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(),
					socSolicitudes.getCodMonedat(), null, null, null, null);
		}

		for (CuentasBen cuentasBen : listaCuentasB) {
			if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA))) {

				if (!bancoPlazaMapaCrtl.containsKey(cuentasBen.getCtaAfectable())) {
					cuentasContabsItems.add(new SelectItem(cuentasBen.getCtaAfectable(), cuentasBen.getCtaNombre() + " ["
							+ cuentasBen.getCtaCodigoCont() + "]"));

					bancoPlazaMapaCrtl.put(cuentasBen.getCtaAfectable(), null);
				}
			}

			if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {

				if (!bancoPlazaMapaCrtl.containsKey(cuentasBen.getBcoCodigo())) {
					socBancosPlazaItems.add(new SelectItem(cuentasBen.getBcoCodigo(), cuentasBen.getBcoNombre() + " [" + cuentasBen.getBcoCodigo()
							+ "]"));
					bancoPlazaMapaCrtl.put(cuentasBen.getBcoCodigo(), null);
				}
			}

		}

	}

	/**
	 * si es tranfer local y la cta de comisiones es al beneficiario recupera la
	 * lista de cuentas del beneficiario
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private void actualizarListaCtasComisBeneficiario(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel,
			SocSolicitudctas socSolicitudctas) {
		log.info("recuperando lista actualizarDatosBeneficiario " + socDetallessolSel.getBenCodigo());

		Map<String, BancoPlaza> mapaCrtl = new HashMap<String, BancoPlaza>();

		cuentasContabsNroAfectItems = new ArrayList<SelectItem>();

		if (StringUtils.isBlank(socDetallessolSel.getBenCodigo())) {
			return;
		}

		if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA))) {
			if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_BENEF)) {
				List<CuentasBen> listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes,
						socDetallessolSel.getBenCodigo(), null, null, null, null, null);

				for (CuentasBen cuentasBen : listaCuentasB) {

					if (!mapaCrtl.containsKey(String.valueOf(cuentasBen.getCtaAfectable()))) {

						cuentasContabsNroAfectItems.add(new SelectItem(cuentasBen.getCtaAfectable(), cuentasBen.getCtaNombre() + " ["
								+ cuentasBen.getCtaCodigoCont() + "]"));
						mapaCrtl.put(String.valueOf(cuentasBen.getCtaAfectable()), null);

					}
				}
			}
		}
	}

	/**
	 * recupera los nros de cuenta del beneficiario dado
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private void actualizarListaNroCtasBenef(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel) {
		log.info("recuperando lista actualizarListaNroCtasBenef " + socDetallessolSel.getBenCodigo());

		nroCuentabcoItems = new ArrayList<SelectItem>();

		Map<String, BancoPlaza> bancoPlazaMapaCrtl = new HashMap<String, BancoPlaza>();

		if (StringUtils.isBlank(socDetallessolSel.getBenCodigo())) {
			return;
		}

		List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();

		listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(),
				socSolicitudes.getCodMonedat(), socDetallessolSel.getCodBanco(), null, null, socDetallessolSel.getNroCuentabcointer());

		for (CuentasBen cuentasBen : listaCuentasB) {
			if (!bancoPlazaMapaCrtl.containsKey(cuentasBen.getCtaNroCuenta())) {
				nroCuentabcoItems
						.add(new SelectItem(cuentasBen.getCtaNroCuenta(), cuentasBen.getCtaNroCuenta() + " [" + cuentasBen.getMoneda() + "]"));
				bancoPlazaMapaCrtl.put(cuentasBen.getCtaNroCuenta(), null);
			}
		}
	}

	/**
	 * recupera la lista de nro de cuenta del beneficiario si la cta de
	 * comisiones es al beneficiario
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 * @param socSolicitudctas
	 */
	private void actualizarListaNroCtasComisBenef(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel, SocSolicitudctas socSolicitudctas) {

		log.info("recuperando lista actualizarListaNroCtasComisBenef " + socDetallessolSel.getBenCodigo() + " " + socSolicitudctas.getCtaAfectable());
		nroCtasCtasComisBenefItems = new ArrayList<SelectItem>();

		Map<String, BancoPlaza> bancoPlazaMapaCrtl = new HashMap<String, BancoPlaza>();

		if (StringUtils.isBlank(socDetallessolSel.getBenCodigo())) {
			return;
		}

		if (socSolicitudctas.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_BENEF)) {
			if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {

				List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();

				listaCuentasB = getSolicitudBean().getSocBenefsDao().recuperarCuentasB(socSolicitudes, socDetallessolSel.getBenCodigo(),
						socSolicitudctas.getCodMoneda(), socSolicitudctas.getCtaAfectable(), null, null, socSolicitudctas.getCtaAfectable());

				for (CuentasBen cuentasBen : listaCuentasB) {
					if (!bancoPlazaMapaCrtl.containsKey(cuentasBen.getCtaNroCuenta())) {
						nroCtasCtasComisBenefItems.add(new SelectItem(cuentasBen.getCtaNroCuenta(), cuentasBen.getCtaNroCuenta() + " ["
								+ cuentasBen.getMoneda() + "]"));
						bancoPlazaMapaCrtl.put(cuentasBen.getCtaNroCuenta(), null);
					}
				}
			}
		}
	}

	/**
	 * retorna los datos del banco en el exterior seleccionado, metodo solo para
	 * transferencias al exterior
	 * 
	 * @param socSolicitudes
	 * @param socDetallessolSel
	 */
	private void actualizarBancoBenefExt(SocSolicitudes socSolicitudes, SocDetallessol socDetallessolSel) {
		log.info("En actualizarDatosBanco " + socDetallessolSel.getCodBanco());

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			bancoPlazaSelected = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socDetallessolSel.getCodBanco());

			bancoPlazaSelectedInter = new BancoPlaza();
			if (bancoPlazaSelected == null) {
				bancoPlazaSelected = new BancoPlaza();
			}

			if (!StringUtils.isBlank(socDetallessolSel.getCodBancointer())) {
				bancoPlazaSelectedInter = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socDetallessolSel.getCodBancointer());

			}

			if (bancoPlazaSelectedInter == null) {
				bancoPlazaSelectedInter = new BancoPlaza();
			}
		}

	}

	public void beneficiarioChanged(ActionEvent event) {
		log.info("En ctaComisionGAdmChanged " + socDetallessolSelected.getBenCodigo());

		inicializarNuevoBeneficiario(socSolicitudes, socDetallessolSelected);
		actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected);
		actualizarListaCtasComisBeneficiario(socSolicitudes, socDetallessolSelected, socSolicitudctasComGAdm);
	}

	public void beneficiarioBancoChanged(ActionEvent event) {

		log.info("En beneficiarioBancoChanged " + socDetallessolSelected.getCodBanco());
		socDetallessolSelected.setNroCuentabco(null);
		socDetallessolSelected.setDetInfo(null);
		socDetallessolSelected.setCtaCodigo(null);

		actualizarBancoBenefExt(socSolicitudes, socDetallessolSelected);
		actualizarListaNroCtasBenef(socSolicitudes, socDetallessolSelected);

	}

	public void beneficiarioCtaCodigoChanged(ActionEvent event) {
		log.info("En beneficiarioBancoChanged " + socDetallessolSelected.getNroCuentabcointer());

		actualizarListaNroCtasBenef(socSolicitudes, socDetallessolSelected);
		getSolicitudBean().getSocDetallessolDao().completarDatosDetalle(socSolicitudes, socDetallessolSelected);
	}

	public void beneficiarioBancoComisChanged(ActionEvent event) {
		log.info("En ctaComisionGAdmChanged " + socSolicitudctasComGAdm.getCtaAfectable());

		List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasUnicas(null, socSolicitudctasComGAdm.getCtaAfectable(),
				null, true);

		if (socCuentassolLista.size() == 1) {
			socSolicitudctasComGAdm.setCodMoneda(socCuentassolLista.get(0).getMoneda());
			socSolicitudctasComGAdm.setNroCuenta(socCuentassolLista.get(0).getCtaMovimiento());
		}

		actualizarListaNroCtasComisBenef(socSolicitudes, socDetallessolSelected, socSolicitudctasComGAdm);

	}

	public void beneficiarioCtaChanged(ActionEvent event) {
		// al seleccionar la cuenta del benef se determina el tipo de mensaje y
		// se verifica los campos 56A, 57A, 57D
		log.info("En beneficiarioCtaChanged " + socDetallessolSelected.getNroCuentabco());
		botonActInfoDetalle();
	}

	public void botonActInfoDetalle() {
		log.info("En botonActInfoDetalle " + socDetallessolSelected.getNroCuentabco());
		bancoPlazaSelectedInter = new BancoPlaza();

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			getSolicitudBean().getSocDetallessolDao().completarDatosDetalle(socSolicitudes, socDetallessolSelected);

			SwfMttransferdet swfMttransferdet = getSolicitudBean().getSwfMttransferdetBean().findByCodigo(
					socDetallessolSelected.getDetCodttransfer(), "56A", 4);

			if (swfMttransferdet != null) {
				// es con intermediario
				bancoPlazaSelectedInter = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socDetallessolSelected.getCodBancointer());

				if (bancoPlazaSelectedInter == null) {
					bancoPlazaSelectedInter = new BancoPlaza();
				}
			}

		}

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
			getSolicitudBean().getSocDetallessolDao().completarDatosDetalle(socSolicitudes, socDetallessolSelected);
		}

	}

	private void completarCtaCTra() {
		socDetallessolLista = new ArrayList<SocDetallessol>();
		SocDetallessolId socDetallessolId = new SocDetallessolId();
		socDetallessolId.setDetCodigo(1);
		
		socDetallessolSelected = new SocDetallessol();
		socDetallessolSelected.setId(socDetallessolId);
		socDetallessolSelected.setCodBanco(null);
		socDetallessolSelected.setNroCuentabco(socSolicitudctasDestino.getNroCuenta());
		socDetallessolSelected.setDetInfo(null);
		socDetallessolSelected.setCtaCodigo(null);
		socDetallessolSelected.setDetFacturas(null);
		socDetallessolSelected.setBeneficiario(null);
		socDetallessolSelected.setBenCodigo(socSolicitudes.getSolCodigo());		
		socDetallessolSelected.setCodBancointer(null);
		socDetallessolSelected.setNroCuentabcointer(null);
		socDetallessolSelected.setDetCodttransfer(null);
		socDetallessolSelected.setDetMonto(socSolicitudes.getSocMontome());
		socDetallessolSelected.setCodMoneda(socSolicitudes.getCodMoneda());		
		socDetallessolLista.add(socDetallessolSelected);
	}


	private Solicitud populateSolicitudTO() {
		Solicitud solicitudTO = new Solicitud();
		solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);

		solicitudTO.setSolicitud(socSolicitudes);
		solicitudTO.setSocDetallessolLista(socDetallessolLista);

		List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();

		socSolicitudctasLista.add(socSolicitudctasMovProv);
		socSolicitudctasLista.add(socSolicitudctasComGAdm);
		//socSolicitudctasLista.add(socSolicitudctasComCTra);
		socSolicitudctasLista.add(socSolicitudctasDestino);		

		solicitudTO.setSocSolicitudctasLista(socSolicitudctasLista);

		return solicitudTO;
	}

	private void recuperarEsquemas(SocSolicitudes socSolicitudes) {
		log.info("recuperando esquemas");
		List<SocEsquemas> socEsquemasLista = new ArrayList<SocEsquemas>();

		if (socSolicitudes.getEsqCodigo() != null && socEsquemasSelected.getEsqCodigo() != null) {
			SocEsquemas socEsquemas0 = getSolicitudBean().getSocEsquemasDao().esquemaByCod(socEsquemasSelected.getEsqCodigo());
			socEsquemasLista.add(socEsquemas0);
		} else
			socEsquemasLista = getSolicitudBean().getSocSolicitudesDao().obtenerEsquemas(socSolicitudes, socEsquemasSelected, socSolicitudctasMovProv);

		if (socEsquemasLista.size() == 1) {
			if (StringUtils.isBlank(socSolicitudes.getSocCodigo()) || socSolicitudes.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)) {
				log.info("=>Seteando esquema " + socEsquemasLista.get(0).getEsqCodigo());
				socSolicitudes.setEsqCodigo(socEsquemasLista.get(0).getEsqCodigo());
			}
		}
	}

	private void recuperarDatosDetalle(SocSolicitudes socSolicitudes, List<SocDetallessol> socDetallessolLista) {
		log.info("recuperarDatosDetalle : '" + socDetallessolLista.size() + "'");
		detallesolLista = getSolicitudBean().getSocDetallessolDao().recuperarListaDetallessol(socSolicitudes, socDetallessolLista);
	}

	public void verDetalle(SocDetallessol socDetallessolSel) {
		try {
			log.info("verDetalle : '" + socDetallessolSel.getId().getDetCodigo() + "'");
			socDetallessolSelected = socDetallessolSel;
			//
			actualizarListaBeneficiarios(socSolicitudes, socDetallessolSelected);
			actualizarListaCtasBenef(socSolicitudes, socDetallessolSelected);
			actualizarBancoBenefExt(socSolicitudes, socDetallessolSelected);
			actualizarListaNroCtasBenef(socSolicitudes, socDetallessolSelected);
			actualizarListaCtasComisBeneficiario(socSolicitudes, socDetallessolSelected, socSolicitudctasComGAdm);
			actualizarListaNroCtasComisBenef(socSolicitudes, socDetallessolSelected, socSolicitudctasComGAdm);
		} catch (Exception e) {
			log.error("error al verDetalle " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verDetallesol(SocDetallessol socDetallessolSel) {
		try {
			log.info("verDetallesol : '" + socDetallessolSel.getId().getDetCodigo() + "'");
			detallesolSelected = getSolicitudBean().getSocDetallessolDao().recuperarDetallesol(socSolicitudes, socDetallessolSel);
			if (detallesolSelected == null) {
				throw new BusinessException("Detalle beneficiario " + socDetallessolSel.getId().getDetCodigo() + " inexistente");
			}

		} catch (Exception e) {
			log.error("error al recuperar detalle " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verDetalleComprobante(ComprobanteDet comprobanteDetSel) {
		try {
			log.info("verDetalleComprobante : '" + comprobanteDetSel.getCpbCodigo() + "'");
			socComprobanteSelected = getSolicitudBean().getSocComprobanteDao().getComprobante(comprobanteDetSel.getCpbCodigo());
			if (socComprobanteSelected == null) {
				throw new BusinessException("Detalle comprobante " + comprobanteDetSel.getCpbCodigo() + " inexistente");
			}
			comprobanteRenglonesLista = getSolicitudBean().getSocComprobanteDao().recuperarComprobReng(socComprobanteSelected.getCpbCodigo());
			debeSuma = BigDecimal.ZERO;
			haberSuma = BigDecimal.ZERO;
			for (ComprobanteDet comprobanteDet : comprobanteRenglonesLista) {
				debeSuma = debeSuma.add(comprobanteDet.getDebe());
				haberSuma = haberSuma.add(comprobanteDet.getHaber());
			}

		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verDetalleFacturasComprob(ComprobanteDet comprobanteDetSel) {
		try {
			log.info("verDetalleFacturasComprob : '" + comprobanteDetSel.getCpbCodigo() + "'");
			socComprobanteSelected = getSolicitudBean().getSocComprobanteDao().getComprobante(comprobanteDetSel.getCpbCodigo());
			if (socComprobanteSelected == null) {
				throw new BusinessException("Detalle comprobante " + comprobanteDetSel.getCpbCodigo() + " inexistente");
			}
			socFacturasLista = getSolicitudBean().getSocFacturasDao().getFacturas(socComprobanteSelected.getCpbCodigo());

		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void irDetalleSwift(SocDetallessol socDetallessolSel) {
		try {
			log.info("irDetalleSwift " + socDetallessolSel.getId().getSocCodigo() + " " + socDetallessolSel.getId().getDetCodigo());
			if (StringUtils.isBlank(socDetallessolSel.getId().getSocCodigo())) {
				throw new BusinessException("Operacion no generada");
			}
			SwfMensaje swfMensaje = getSolicitudBean().getSwfMensajeBean().findByCodoperacion(socDetallessolSel.getId().getSocCodigo(),
					socDetallessolSel.getId().getDetCodigo());

			if (swfMensaje == null) {
				throw new BusinessException("Mensaje swift inexistente, actualice la operacion");
			}
			getVisit().setParametro("SIOCWEB_CODMENSWFT", swfMensaje.getMenCodmen());
			getVisit().setParametro("SIOCWEB_ACTION", "SWFTEDT");

			irAPagina("/view/Mensajes/swiftDetail.xhtml");

		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	/***********************************/
	public void guardarSolicitud() {
		log.info("Guardando Solicitud TD");
		Date fecha = socSolicitudes.getFechaCont();

		completarCtaCTra();

		Solicitud solicitudTO = populateSolicitudTO();

		try {
			solicitudTO = getSolicitudBean().procesar(solicitudTO, "REG_SOLICITUD");

			if (StringUtils.isBlank(solicitudTO.getSolicitud().getSocCodigo())) {
				throw new BusinessException("El servicio no retorna el codigo de la solicitud");
			}
			solicitudTO.getSolicitud().setFechaCont(fecha);
			solicitudTO = getSolicitudBean().procesar(solicitudTO, "PREAUT");

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente " + solicitudTO.getSolicitud().getSocCodigo());

			// si es usuario del bcb se va al proceso de autorizar
			irAPagina("/view/Solicitud/solicitud_view.xhtml");
			getVisit().setParametro("pagretorno0", "/view/Solicitud/solicitudes_list_pend.xhtml");
			// se va con
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
			getVisit().setParametro("SIOCWEB_SOCCODIGO", solicitudTO.getSolicitud().getSocCodigo());
			actualizarSolicitud(solicitudTO.getSolicitud().getSocCodigo());

			return;
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

		try {
			actualizarSolicitud(solicitudTO.getSolicitud().getSocCodigo());
			actualizar();
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}
	
	private void actualizarAFechaValor() {
		if (StringUtils.isBlank(socSolicitudes.getSocCodigo())) {
			return;
		}
		log.info("en actualizarAFechaValor " + socSolicitudes.getSocCodigo());

		Solicitud solicitudTO = populateSolicitudTO();

		try {
			solicitudTO = getSolicitudBean().procesar(solicitudTO, "ACT_A_FECHA");

			String mensajeError = "La operacion " + socSolicitudes.getSocCodigo() + " se actualizo a fecha valor "
					+ UtilsDate.stringFromDate(socSolicitudes.getFecha(), "dd/MM/yyyy");

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));
		} catch (Exception e) {
			log.error("error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonActualizarAFechaValor() {
		log.info("en botonActualizarAFechaValor " + socSolicitudes.getSocCodigo());
		if (StringUtils.isBlank(socSolicitudes.getSocCodigo())) {
			return;
		}

		actualizarAFechaValor();

		Solicitud solicitudTO = populateSolicitudTO();

		try {
			getSolicitudBean().procesar(solicitudTO, "ctrlcompros");
		} catch (Exception e) {
			log.error("error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

		actualizarSolicitud(socSolicitudes.getSocCodigo());
	}

	public void botonPreAutorizar() {
		try {
			log.info("en botonPreAutorizar " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();
			getSolicitudBean().procesar(solicitudTO, "PREAUT");

			String mensajeError = "La operacion se genero exitosamente para solicitud " + socSolicitudes.getSocCodigo() + " a fecha valor "
					+ UtilsDate.stringFromDate(socSolicitudes.getFechaCont(), "dd/MM/yyyy");

			actualizarSolicitud(socSolicitudes.getSocCodigo());

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina((String) getVisit().getParametro("pagretorno0"));
			getVisit().removeParametro("pagretorno");
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAutorizarSolSist() {
		try {
			log.info("en botonAutorizarSolSist " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();

			if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
				getSolicitudBean().procesar(solicitudTO, "AUTSWFT");

			}
			getSolicitudBean().procesar(solicitudTO, "AUTSOL");

			if (solicitudTO.getSolicitud().getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
				if (!StringUtils.isBlank(solicitudTO.getSolicitud().getCodSolicitudorig())) {
					if (!StringUtils.isBlank(solicitudTO.getSolicitud().getClaEstadows())) {
						getSolicitudBean().procesar(solicitudTO, "NOTIFMEFP");
					}
				}
			}

			String mensajeError = "La operacion se genero exitosamente para solicitud " + socSolicitudes.getSocCodigo() + " a fecha valor "
					+ UtilsDate.stringFromDate(socSolicitudes.getFecha(), "dd/MM/yyyy");

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina("/view/Solicitud/solicitudes_list_aut.xhtml");
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonAprobarSolSist() {
		try {
			log.info("en botonAutorizarSolSist " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();
			getSolicitudBean().procesar(solicitudTO, "APROSOL");

			String mensajeError = "La operacion se genero exitosamente para solicitud " + socSolicitudes.getSocCodigo() + " a fecha valor "
					+ UtilsDate.stringFromDate(socSolicitudes.getFecha(), "dd/MM/yyyy");

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina("/view/Solicitud/solicitudes_list_aut.xhtml");
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonRechazar() {
		try {
			log.info("en botonRechazar " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();

			getSolicitudBean().procesar(solicitudTO, "RECHAZARSOL");

			String mensajeError = "La operacion se proceso exitosamente para solicitud " + socSolicitudes.getSocCodigo();

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina((String) getVisit().getParametro("pagretorno0"));
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonAnular() {
		try {
			log.info("en botonAnular " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();

			getSolicitudBean().procesar(solicitudTO, "ANULARSOL");

			String mensajeError = "La operacion se proceso exitosamente para solicitud " + socSolicitudes.getSocCodigo();

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			irAPagina((String) getVisit().getParametro("pagretorno0"));
			getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAutorizarSwifts(ActionEvent actionEvent) {
		try {
			log.info("en botonAutorizarSwift " + socSolicitudes.toString());
			getSolicitudBean().autorizarSwifts(socSolicitudes);
			actualizarSolicitud(socSolicitudes.getSocCodigo());
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
			// return "";
		}
	}

	public void botonRevalidaOP(SocDetallessol socDetallessolSel) {
		try {
			log.info("en botonRevalidaOP " + socSolicitudes.toString());
			Solicitud solicitudTO = populateSolicitudTO();
			SocOrdenesPago socOrdenesPago = getSolicitudBean().getSocOrdenesPagoDao().getOrdenBySocCod(socDetallessolSel.getId().getSocCodigo(),
					socDetallessolSel.getId().getDetCodigo());
			if (socOrdenesPago != null) {

				solicitudTO.getSocOrdenesPagoLista().add(socOrdenesPago);
				getSolicitudBean().procesar(solicitudTO, "REVOP");

				String mensajeError = "La operacion se proceso exitosamente";

				addMessageInfo("Aviso", (StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean()
						.getDescRespuesta()));
			}
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void retornarDeSolicituesHa() {
		irAPagina("/view/Solicitud/solicitudes_list_ha.xhtml");
	}

	private void calcularMontos() {
		try {
			log.info("en calcularMontos " + socSolicitudes.toString());
			if (socSolicitudctasMovProv.getCodMoneda() == null ) {
				return;
			}

			completarCtaCTra();
			Solicitud solicitudTO = populateSolicitudTO();

			CalcularVariables calcularVariables = getSolicitudBean().getProcesosSolicitud().calculoMontosSolicitud(solicitudTO);

			socOpecomiTOTTRANS = calcularVariables.buscarClaComision("TOTTRANSMT", 0);
			socOpecomiTOTDEBITO = calcularVariables.buscarClaComision("TOTALPROV", 0);
			socOpecomiVENTAUSD = calcularVariables.buscarClaComision("VENTAUSD", 0);
			socOpecomiTOTCOMISION = calcularVariables.buscarClaComision("TOTCOMISION", 0);
			socOpecomiCOMCTRA = calcularVariables.buscarClaComision(Constants.COD_VAR_COMTRANSF, 0);

		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public String botonRetornar() {
		log.info("en botonRetornar ");

		DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
		log.info("XXX: botonRetornar this.pagina= " + dd.getPagina());

		String pagretorno = (String) getVisit().getParametro("pagretorno");
		log.info("pagretorno " + pagretorno);

		dd.setPagina(pagretorno);
		getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);

		return "";
	}

	public void mostrarReporte(ActionEvent event) {
		log.info("Antes de reporte " + socSolicitudes.getSocCodigo());
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codigo", socSolicitudes.getSocCodigo());
		parametros.put("tipo", "soldetalle");
		parametros.put("TITULO", "DETALLE DE OPERACION");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "solicitudresu.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void mostrarReporteOP(SocDetallessol socDetallessolSel) {
		SocOrdenesPago socOrdenesPago = getSolicitudBean().getSocOrdenesPagoDao().getOrdenBySocCod(socDetallessolSel.getId().getSocCodigo(),
				socDetallessolSel.getId().getDetCodigo());
		if (socOrdenesPago != null) {
			String literal = NumeroALetra.Convertir(socOrdenesPago.getMonto().toString(), true);
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("codigo", socOrdenesPago.getInsCodigo());
			parametros.put("tipo", "ordendepago");
			parametros.put("TITULO", "ORDEN DE PAGO");
			parametros.put("literal", literal);
			parametros.put("usuario", getVisit().getUsuarioSession().getLogin());			
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
			request.getSession().setAttribute("parametros", parametros);
		}
	}

	public String getUrlReporte() {
		String urlReporte = getRaiz() + "reporte";
		return urlReporte;
	}

	public SocSolicitudes getSocSolicitudes() {
		return socSolicitudes;
	}

	public void setSocSolicitudes(SocSolicitudes socSolicitudes) {
		this.socSolicitudes = socSolicitudes;
	}

	public List<SocDetallessol> getSocDetallessolLista() {
		return socDetallessolLista;
	}

	public void setSocDetallessolLista(List<SocDetallessol> socDetallessolLista) {
		this.socDetallessolLista = socDetallessolLista;
	}

	public List<SelectItem> getSocSolicitanteItems() {
		return socSolicitanteItems;
	}

	public void setSocSolicitanteItems(List<SelectItem> socSolicitanteItems) {
		this.socSolicitanteItems = socSolicitanteItems;
	}

	public List<SelectItem> getSocSolcuentasItems() {
		return socSolcuentasItems;
	}

	public void setSocSolcuentasItems(List<SelectItem> socSolcuentasItems) {
		this.socSolcuentasItems = socSolcuentasItems;
	}

	public List<SelectItem> getSocCuentassolItems() {
		return socCuentassolItems;
	}

	public void setSocCuentassolItems(List<SelectItem> socCuentassolItems) {
		this.socCuentassolItems = socCuentassolItems;
	}

	public List<SelectItem> getMonedasItemsSigla() {
		if (monedasItemsSigla == null) {
			monedasItemsSigla = new ArrayList<SelectItem>();
			List<GenMoneda> genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedas();

			for (GenMoneda genMoneda : genMonedaLista) {
				monedasItemsSigla.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonSigla()));
			}
		}
		return monedasItemsSigla;
	}

	public void setMonedasItemsSigla(List<SelectItem> monedasItemsSigla) {
		this.monedasItemsSigla = monedasItemsSigla;
	}

	public SocSolicitudctas getSocSolicitudctasMovProv() {
		return socSolicitudctasMovProv;
	}

	public void setSocSolicitudctasMovProv(SocSolicitudctas socSolicitudctasMovProv) {
		this.socSolicitudctasMovProv = socSolicitudctasMovProv;
	}

	public SocSolicitudctas getSocSolicitudctasComGAdm() {
		return socSolicitudctasComGAdm;
	}

	public void setSocSolicitudctasComGAdm(SocSolicitudctas socSolicitudctasComGAdm) {
		this.socSolicitudctasComGAdm = socSolicitudctasComGAdm;
	}

	public List<SelectItem> getSocCuentassolComisItems() {
		return socCuentassolComisItems;
	}

	public void setSocCuentassolComisItems(List<SelectItem> socCuentassolComisItems) {
		this.socCuentassolComisItems = socCuentassolComisItems;
	}

	public List<SelectItem> getSocSolcuentasComisItems() {
		return socSolcuentasComisItems;
	}

	public void setSocSolcuentasComisItems(List<SelectItem> socSolcuentasComisItems) {
		this.socSolcuentasComisItems = socSolcuentasComisItems;
	}

	public SocDetallessol getSocDetallessolSelected() {
		return socDetallessolSelected;
	}

	public void setSocDetallessolSelected(SocDetallessol socDetallessolSelected) {
		this.socDetallessolSelected = socDetallessolSelected;
	}

	public List<SelectItem> getSocBenefsItemsExt() {
		return socBenefsItemsExt;
	}

	public void setSocBenefsItemsExt(List<SelectItem> socBenefsItemsExt) {
		this.socBenefsItemsExt = socBenefsItemsExt;
	}

	public List<SelectItem> getSocBenefsItemsLoc() {
		return socBenefsItemsLoc;
	}

	public void setSocBenefsItemsLoc(List<SelectItem> socBenefsItemsLoc) {
		this.socBenefsItemsLoc = socBenefsItemsLoc;
	}

	public List<SelectItem> getSocBenefsItems() {
		return socBenefsItems;
	}

	public void setSocBenefsItems(List<SelectItem> socBenefsItems) {
		this.socBenefsItems = socBenefsItems;
	}

	public BancoPlaza getBancoPlazaSelected() {
		return bancoPlazaSelected;
	}

	public void setBancoPlazaSelected(BancoPlaza bancoPlazaSelected) {
		this.bancoPlazaSelected = bancoPlazaSelected;
	}

	public List<SelectItem> getMonedaItems() {
		return monedaItems;
	}

	public void setMonedaItems(List<SelectItem> monedaItems) {
		this.monedaItems = monedaItems;
	}

	public SocEsquemas getSocEsquemasSelected() {
		return socEsquemasSelected;
	}

	public void setSocEsquemasSelected(SocEsquemas socEsquemasSelected) {
		this.socEsquemasSelected = socEsquemasSelected;
	}

	public SocSolicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setSocSolicitante(SocSolicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public List<SelectItem> getMonedaTransferItems() {
		return monedaTransferItems;
	}

	public void setMonedaTransferItems(List<SelectItem> monedaTransferItems) {
		this.monedaTransferItems = monedaTransferItems;
	}

	public List<SelectItem> getSocBancosPlazaItems() {
		return socBancosPlazaItems;
	}

	public void setSocBancosPlazaItems(List<SelectItem> socBancosPlazaItems) {
		this.socBancosPlazaItems = socBancosPlazaItems;
	}

	public BancoPlaza getBancoPlazaSelectedInter() {
		return bancoPlazaSelectedInter;
	}

	public void setBancoPlazaSelectedInter(BancoPlaza bancoPlazaSelectedInter) {
		this.bancoPlazaSelectedInter = bancoPlazaSelectedInter;
	}

	public Beneficiario getBeneficiarioSelected() {
		return beneficiarioSelected;
	}

	public void setBeneficiarioSelected(Beneficiario beneficiarioSelected) {
		this.beneficiarioSelected = beneficiarioSelected;
	}

	public List<SelectItem> getCuentasContabsItems() {
		return cuentasContabsItems;
	}

	public void setCuentasContabsItems(List<SelectItem> cuentasContabsItems) {
		this.cuentasContabsItems = cuentasContabsItems;
	}

	public List<SelectItem> getCuentasContabsNroAfectItems() {
		return cuentasContabsNroAfectItems;
	}

	public void setCuentasContabsNroAfectItems(List<SelectItem> cuentasContabsNroAfectItems) {
		this.cuentasContabsNroAfectItems = cuentasContabsNroAfectItems;
	}

	public List<SelectItem> getNroCtasCtasComisBenefItems() {
		return nroCtasCtasComisBenefItems;
	}

	public void setNroCtasCtasComisBenefItems(List<SelectItem> nroCtasCtasComisBenefItems) {
		this.nroCtasCtasComisBenefItems = nroCtasCtasComisBenefItems;
	}

	public List<SelectItem> getNroCuentabcoItems() {
		return nroCuentabcoItems;
	}

	public void setNroCuentabcoItems(List<SelectItem> nroCuentabcoItems) {
		this.nroCuentabcoItems = nroCuentabcoItems;
	}

	public List<Detallesol> getDetallesolLista() {
		return detallesolLista;
	}

	public void setDetallesolLista(List<Detallesol> detallesolLista) {
		this.detallesolLista = detallesolLista;
	}

	public Detallesol getDetallesolSelected() {
		return detallesolSelected;
	}

	public void setDetallesolSelected(Detallesol detallesolSelected) {
		this.detallesolSelected = detallesolSelected;
	}

	public List<ComprobanteDet> getComprobanteLista() {
		return comprobanteLista;
	}

	public void setComprobanteLista(List<ComprobanteDet> comprobanteLista) {
		this.comprobanteLista = comprobanteLista;
	}

	public SocComprobante getSocComprobanteSelected() {
		return socComprobanteSelected;
	}

	public void setSocComprobanteSelected(SocComprobante socComprobanteSelected) {
		this.socComprobanteSelected = socComprobanteSelected;
	}

	public BigDecimal getDebeSuma() {
		return debeSuma;
	}

	public void setDebeSuma(BigDecimal debeSuma) {
		this.debeSuma = debeSuma;
	}

	public BigDecimal getHaberSuma() {
		return haberSuma;
	}

	public void setHaberSuma(BigDecimal haberSuma) {
		this.haberSuma = haberSuma;
	}

	public List<ComprobanteDet> getComprobanteRenglonesLista() {
		return comprobanteRenglonesLista;
	}

	public void setComprobanteRenglonesLista(List<ComprobanteDet> comprobanteRenglonesLista) {
		this.comprobanteRenglonesLista = comprobanteRenglonesLista;
	}

	public SocCuentassol getSocCuentassolMovProv() {
		return socCuentassolMovProv;
	}

	public void setSocCuentassolMovProv(SocCuentassol socCuentassolMovProv) {
		this.socCuentassolMovProv = socCuentassolMovProv;
	}

	public SocCuentassol getSocCuentassolComGAdm() {
		return socCuentassolComGAdm;
	}

	public void setSocCuentassolComGAdm(SocCuentassol socCuentassolComGAdm) {
		this.socCuentassolComGAdm = socCuentassolComGAdm;
	}

	public SocOpecomi getSocOpecomiTOTTRANS() {
		return socOpecomiTOTTRANS;
	}

	public void setSocOpecomiTOTTRANS(SocOpecomi socOpecomiTOTTRANS) {
		this.socOpecomiTOTTRANS = socOpecomiTOTTRANS;
	}

	public SocOpecomi getSocOpecomiTOTDETMT() {
		return socOpecomiTOTDETMT;
	}

	public void setSocOpecomiTOTDETMT(SocOpecomi socOpecomiTOTDETMT) {
		this.socOpecomiTOTDETMT = socOpecomiTOTDETMT;
	}

	public SocOpecomi getSocOpecomiVENTAUSD() {
		return socOpecomiVENTAUSD;
	}

	public void setSocOpecomiVENTAUSD(SocOpecomi socOpecomiVENTAUSD) {
		this.socOpecomiVENTAUSD = socOpecomiVENTAUSD;
	}

	public SocOpecomi getSocOpecomiDIFERTC() {
		return socOpecomiDIFERTC;
	}

	public void setSocOpecomiDIFERTC(SocOpecomi socOpecomiDIFERTC) {
		this.socOpecomiDIFERTC = socOpecomiDIFERTC;
	}

	public SocOpecomi getSocOpecomiCOMCTRA() {
		return socOpecomiCOMCTRA;
	}

	public void setSocOpecomiCOMCTRA(SocOpecomi socOpecomiCOMCTRA) {
		this.socOpecomiCOMCTRA = socOpecomiCOMCTRA;
	}

	public SocOpecomi getSocOpecomiTOTCOMISION() {
		return socOpecomiTOTCOMISION;
	}

	public void setSocOpecomiTOTCOMISION(SocOpecomi socOpecomiTOTCOMISION) {
		this.socOpecomiTOTCOMISION = socOpecomiTOTCOMISION;
	}

	public SocOpecomi getSocOpecomiTOTDEBITO() {
		return socOpecomiTOTDEBITO;
	}

	public void setSocOpecomiTOTDEBITO(SocOpecomi socOpecomiTOTDEBITO) {
		this.socOpecomiTOTDEBITO = socOpecomiTOTDEBITO;
	}

	public List<SocFacturas> getSocFacturasLista() {
		return socFacturasLista;
	}

	public void setSocFacturasLista(List<SocFacturas> socFacturasLista) {
		this.socFacturasLista = socFacturasLista;
	}

	public SocSolicitudctas getSocSolicitudctasComCTra() {
		return socSolicitudctasComCTra;
	}

	public void setSocSolicitudctasComCTra(SocSolicitudctas socSolicitudctasComCTra) {
		this.socSolicitudctasComCTra = socSolicitudctasComCTra;
	}

	public SocCuentassol getSocCuentassolComCTra() {
		return socCuentassolComCTra;
	}

	public void setSocCuentassolComCTra(SocCuentassol socCuentassolComCTra) {
		this.socCuentassolComCTra = socCuentassolComCTra;
	}

	public List<SelectItem> getSocCuentassolFVItems() {
		return socCuentassolFVItems;
	}

	public void setSocCuentassolFVItems(List<SelectItem> socCuentassolFVItems) {
		this.socCuentassolFVItems = socCuentassolFVItems;
	}

	public SocSolicitudctas getSocSolicitudctasDestino() {
		return socSolicitudctasDestino;
	}

	public void setSocSolicitudctasDestino(SocSolicitudctas socSolicitudctasDestino) {
		this.socSolicitudctasDestino = socSolicitudctasDestino;
	}

	public SocCuentassol getSocCuentassolDestino() {
		return socCuentassolDestino;
	}

	public void setSocCuentassolDestino(SocCuentassol socCuentassolDestino) {
		this.socCuentassolDestino = socCuentassolDestino;
	}

}
