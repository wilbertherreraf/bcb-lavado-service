/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBancos;
import gob.bcb.bpm.pruebaCU.SocBenefsloc;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocPlazas;
import gob.bcb.bpm.pruebaCU.SocPlazasId;
import gob.bcb.bpm.pruebaCU.SocSolbenefsloc;
import gob.bcb.bpm.pruebaCU.SocSolbenefslocId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.view.SolicitudBean;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.model.SwfPersonacta;
import gob.bcb.swift.model.SwfPersonactaPK;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaBancosController extends BaseBeanController {
	private Logger log = Logger.getLogger(ListaBancosController.class);

	private SocBancos socBancosSelected = new SocBancos();
	private SocPlazas socPlazasSelected = new SocPlazas();
	private BancoPlaza bancoPlaza = new BancoPlaza();
	private List<BancoPlaza> bancos = new ArrayList<BancoPlaza>();
	private List<BancoPlaza> plazasLista = new ArrayList<BancoPlaza>();
	private List<SocPlazas> socPlazasLista = new ArrayList<SocPlazas>();
	private List<SelectItem> bancosInterItems = new ArrayList<SelectItem>();
	private SwfPersonacta swfPersonactaSelected = new SwfPersonacta();
	private SwfPersonacta swfPersonactaSelectedEdit = new SwfPersonacta();
	private List<SwfPersonacta> swfPersonactaLista = new ArrayList<SwfPersonacta>();
	private SocPlazas socPlazas = new SocPlazas();
	private boolean modifica = false;
	private String mensaje = "";
	private String sIOCWEB_TIPOPERACION;

	private List<SelectItem> socBancosItems = new ArrayList<SelectItem>();

	@PostConstruct
	public void init() {
		log.info("PostConstruct ListaBancosController - " + getClass().getName());
		try {
			recuperarVisit();
			inicializa();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		} finally {
			getVisit().removeParametro("SIOCWEB_TIPOPERACION");
			getVisit().removeParametro("SIOCWEB_CODBCO");
		}

	}

	private void inicializa() {
		String SIOCWEB_CODBCO = (String) getVisit().getParametro("SIOCWEB_CODBCO");

		sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");

		crearObjetosPorDefecto();

		if (!StringUtils.isBlank(SIOCWEB_CODBCO)) {
			recuperarBancos(SIOCWEB_CODBCO);
		} else {
			if (!StringUtils.isBlank(sIOCWEB_TIPOPERACION)) {
				if (sIOCWEB_TIPOPERACION.equals("NUEBCO")) {
					adicionarBanco();
				}
			}
		}
		getVisit().removeParametro("SIOCWEB_TIPOPERACION");
		getVisit().removeParametro("SIOCWEB_CODBCO");
	}

	private void crearObjetosPorDefecto() {
	}

	private void recuperarBancosInter(String codBco) {
		List<BancoPlaza> bancosInter = getSolicitudBean().getSocBancosDao().getBancosPlazas(codBco, null);

		socBancosItems = new ArrayList<SelectItem>();
		for (BancoPlaza cuentasS : bancosInter) {
			socBancosItems.add(new SelectItem(cuentasS.getBcoCodigo().trim(), cuentasS.getBcoNombre() + " (" + cuentasS.getPlaNombre() + ")" + " ["
					+ (StringUtils.isBlank(cuentasS.getPlaBic()) ? "" : cuentasS.getPlaBic()) + "]-" + cuentasS.getBcoCodigo()));
		}

	}

	private void recuperarBancos(String codRegistro) {
		log.info("en recuperarBancos " + codRegistro);
		socBancosSelected = getSolicitudBean().getSocBancosDao().getSocBancoByCodigo(codRegistro);
		socPlazas = getSolicitudBean().getSocPlazasDao().getSocPlazaByCodigo(codRegistro, 1);

		swfPersonactaLista = getSolicitudBean().getSwfPersonactaBean().buscarCtasPersona(socBancosSelected.getBcoCodigo(), null, null, null, null,
				null, null);

		plazasLista = new ArrayList<BancoPlaza>();

		for (SwfPersonacta swfPersonacta : swfPersonactaLista) {
			BancoPlaza bancoPlaza = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(swfPersonacta.getId().getPecCodinst());

			bancoPlaza.setPlaNrocuenta(swfPersonacta.getId().getPecNrocta());
			bancoPlaza.setPecEstadocta(swfPersonacta.getPecEstadocta());

			plazasLista.add(bancoPlaza);
		}
	}

	public void botonBuscar() {
		log.info("en botonBuscar " + bancoPlaza.toString());
		bancos = getSolicitudBean().getSocBancosDao().buscarBancosPlazas(bancoPlaza.getBcoNombre(), bancoPlaza.getBcoCodigo(),
				bancoPlaza.getPlaNombre(), bancoPlaza.getPlaBic(), bancoPlaza.getPlaNrocuenta());
	}

	public void irDetalle(BancoPlaza bancoPlaza) {
		try {
			log.info("irDetalle banco " + bancoPlaza.getBcoCodigo());
			SocBancos socBenefsloc = getSolicitudBean().getSocBancosDao().getSocBancoByCodigo(bancoPlaza.getBcoCodigo());

			if (socBenefsloc == null) {
				throw new BusinessException("Banco inexistente " + bancoPlaza.getBcoCodigo());
			}

			getVisit().setParametro("SIOCWEB_CODBCO", socBenefsloc.getBcoCodigo());
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "VERBCO");
			irAPagina("/Modulos/Transferencias/listaBancosDet.xhtml");
			inicializa();
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAgregarBanco() {
		try {
			log.info("botonAgregarBanco ");
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "NUEBCO");
			irAPagina("/Modulos/Transferencias/listaBancosDet.xhtml");
			inicializa();
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void buscar() {
		bancos.clear();
		String query = "";
		query = "select b.*, p.pla_nombre, p.pla_bic, p.pla_nrocuenta, p.pla_intermediario  ";
		query = query.concat("from soc_bancos b, soc_plazas p where b.bco_codigo = p.bco_codigo  ");

		if (!StringUtils.isBlank(bancoPlaza.getBcoNombre())) {
			query = query.concat("and upper(b.bco_nombre) like '%" + bancoPlaza.getBcoNombre().toUpperCase() + "%' ");
		}

		if (!StringUtils.isBlank(bancoPlaza.getPlaNombre())) {
			query = query.concat("and exists (select 1 from soc_plazas c where c.bco_codigo = b.bco_codigo and upper(c.pla_nombre) like '%"
					+ bancoPlaza.getPlaNombre() + "%' ) ");
		}

		if (!StringUtils.isBlank(bancoPlaza.getPlaBic())) {
			query = query.concat("and exists (select 1 from soc_plazas c where c.bco_codigo = b.bco_codigo and upper(c.pla_bic) like '%"
					+ bancoPlaza.getPlaBic() + "%' ) ");
		}

		if (!StringUtils.isBlank(bancoPlaza.getPlaNrocuenta())) {
			query = query.concat("and exists (select 1 from soc_plazas c where c.bco_codigo = b.bco_codigo and upper(c.pla_nrocuenta) like '%"
					+ bancoPlaza.getPlaNrocuenta() + "%' ) ");
		}

		if (!StringUtils.isBlank(bancoPlaza.getPlaIntermediario())) {
			query = query.concat("and exists (select 1 from soc_plazas c where c.bco_codigo = b.bco_codigo and upper(c.pla_intermediario) like '%"
					+ bancoPlaza.getPlaIntermediario() + "%' ) ");
		}
		query = query.concat("union ");
		query = query.concat("select b1.*, '' pla_nombre, '' pla_bic, '' pla_nrocuenta, '' pla_intermediario ");
		query = query.concat("from soc_bancos b1 ");
		query = query.concat("where not exists (select 1 from soc_plazas c where c.bco_codigo = b1.bco_codigo ) ");
		query = query.concat("order by 1 ");

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			BancoPlaza bancoPlaza = getSolicitudBean().getSocBancosDao().bancoPlazaByCod((String) res.get("bco_codigo"));
			if (bancoPlaza != null) {
				bancos.add(bancoPlaza);
			}

		}
	}

	private void adicionarBanco() {
		socBancosSelected = new SocBancos();
		SocPlazasId socPlazasId = new SocPlazasId();
		socPlazas = new SocPlazas();
		socPlazas.setId(socPlazasId);
	}

	public void botonAgregarPersonactaFeedware() {
		try {
			log.info("botonAgregarPersonacta " + socBancosSelected.getBcoCodigo());

			swfPersonactaSelected = new SwfPersonacta();
			SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
			// swfPersonactaPK.setPecCodpersona(socBancosSelected.getBcoCodigo());
			swfPersonactaPK.setPecCodinst(ConstantsSwift.PEC_CODBCOFEEDWARE);
			swfPersonactaSelected.setId(swfPersonactaPK);
			swfPersonactaSelected.setPecEstadocta(ConstantsSwift.PAR_ESTADOCTAACTIVA);

			recuperarBancosInter(swfPersonactaSelected.getId().getPecCodinst());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAgregarPersonacta() {
		try {
			log.info("botonAgregarPersonacta " + socBancosSelected.getBcoCodigo());
			swfPersonactaSelected = new SwfPersonacta();
			SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
			// swfPersonactaPK.setPecCodpersona(socBancosSelected.getBcoCodigo());
			swfPersonactaSelected.setId(swfPersonactaPK);
			swfPersonactaSelected.setPecEstadocta(ConstantsSwift.PAR_ESTADOCTAACTIVA);

			recuperarBancosInter(null);
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonGuardarPersonacta() {
		try {
			log.info("Salvando persona cuenta...");
			swfPersonactaSelected.setPecAuditwst(getVisit().getAddress());
			swfPersonactaSelected.setPecAuditusr(getVisit().getUsuarioSession().getLogin());

			if (StringUtils.isBlank(swfPersonactaSelected.getId().getPecCodpersona())) {
				swfPersonactaSelected.setPecEstadocta(ConstantsSwift.PAR_ESTADOCTAACTIVA);
				swfPersonactaSelected.getId().setPecCodpersona(socBancosSelected.getBcoCodigo());
				getSolicitudBean().getSwfPersonactaBean().getHibernateTemplate().saveOrUpdate(swfPersonactaSelected);
			} else {
				SwfPersonacta swfPersonactaOld = getSolicitudBean().getSwfPersonactaBean().findByCodigo(
						swfPersonactaSelected.getId().getPecCodpersona(), swfPersonactaSelected.getId().getPecCodinst(),
						swfPersonactaSelectedEdit.getId().getPecNrocta());
				
				if (swfPersonactaOld != null) {
					log.info("Salvando persona cuenta..." + swfPersonactaSelected.getId().getPecNrocta() + " swfPersonactaOld " +swfPersonactaOld.getId().getPecNrocta());
					swfPersonactaOld.getId().setPecNrocta(swfPersonactaSelected.getId().getPecNrocta());
					
					getSolicitudBean().getSwfPersonactaBean().getHibernateTemplate().saveOrUpdate(swfPersonactaOld);

				}
				// getSolicitudBean().getSwfPersonactaBean().guardarCuenta(swfPersonactaSelected);
			}

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBancos(socBancosSelected.getBcoCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEliminarPersonacta(BancoPlaza bancoPlaza) {
		try {

			SwfPersonacta swfPersonactaSel = getSolicitudBean().getSwfPersonactaBean().findByCodigo(socBancosSelected.getBcoCodigo(),
					bancoPlaza.getBcoCodigo(), bancoPlaza.getPlaNrocuenta());

			swfPersonactaSel.setPecEstadocta(ConstantsSwift.PAR_ESTADOCTANOAACTIVA);
			swfPersonactaSel.setPecAuditwst(getVisit().getAddress());
			swfPersonactaSel.setPecAuditusr(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSwfPersonactaBean().guardarCuenta(swfPersonactaSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBancos(socBancosSelected.getBcoCodigo());

		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonVigentarPersonacta(BancoPlaza bancoPlaza) {
		try {
			SwfPersonacta swfPersonactaSel = getSolicitudBean().getSwfPersonactaBean().findByCodigo(socBancosSelected.getBcoCodigo(),
					bancoPlaza.getBcoCodigo(), bancoPlaza.getPlaNrocuenta());

			swfPersonactaSel.setPecEstadocta(ConstantsSwift.PAR_ESTADOCTAACTIVA);
			swfPersonactaSel.setPecAuditwst(getVisit().getAddress());
			swfPersonactaSel.setPecAuditusr(getVisit().getUsuarioSession().getLogin());

			getSolicitudBean().getSwfPersonactaBean().guardarCuenta(swfPersonactaSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			recuperarBancos(socBancosSelected.getBcoCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEditarPersonacta(BancoPlaza bancoPlaza) {
		try {
			swfPersonactaSelectedEdit = new SwfPersonacta();
			SwfPersonactaPK swfPersonactaPK = new SwfPersonactaPK();
			// swfPersonactaPK.setPecCodpersona(socBancosSelected.getBcoCodigo());
			swfPersonactaSelectedEdit.setId(swfPersonactaPK);

			swfPersonactaSelected = getSolicitudBean().getSwfPersonactaBean().findByCodigo(socBancosSelected.getBcoCodigo(),
					bancoPlaza.getBcoCodigo(), bancoPlaza.getPlaNrocuenta());

			swfPersonactaSelectedEdit.getId().setPecNrocta(swfPersonactaSelected.getId().getPecNrocta());

			recuperarBancosInter(swfPersonactaSelected.getId().getPecCodinst());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonGuardarBanco() {
		log.info("Guardando el banco: ");
		try {
			socBancosSelected.setEstacion(getVisit().getAddress());
			socBancosSelected.setUsrCodigo(getVisit().getUsuarioSession().getLogin());

			socBancosSelected = getSolicitudBean().getSocBancosDao().saveOrUpdate(socBancosSelected, socPlazas);

			log.info("Se modific� el registro correctamente.");
			recuperarBancos(socBancosSelected.getBcoCodigo());

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public List<BancoPlaza> getBancos() {
		return bancos;
	}

	public void setBancos(List<BancoPlaza> bancos) {
		this.bancos = bancos;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getMensaje() {
		return mensaje;
	}

	public List<SocPlazas> getSocPlazasLista() {
		return socPlazasLista;
	}

	public void setSocPlazasLista(List<SocPlazas> socPlazasLista) {
		this.socPlazasLista = socPlazasLista;
	}

	public BancoPlaza getBancoPlaza() {
		return bancoPlaza;
	}

	public void setBancoPlaza(BancoPlaza bancoPlaza) {
		this.bancoPlaza = bancoPlaza;
	}

	public SocPlazas getSocPlazas() {
		return socPlazas;
	}

	public void setSocPlazas(SocPlazas socPlazas) {
		this.socPlazas = socPlazas;
	}

	public List<SelectItem> getBancosInterItems() {
		return bancosInterItems;
	}

	public void setBancosInterItems(List<SelectItem> bancosInterItems) {
		this.bancosInterItems = bancosInterItems;
	}

	public List<BancoPlaza> getPlazasLista() {
		return plazasLista;
	}

	public void setPlazasLista(List<BancoPlaza> plazasLista) {
		this.plazasLista = plazasLista;
	}

	public boolean isModifica() {
		return modifica;
	}

	public void setModifica(boolean modifica) {
		this.modifica = modifica;
	}

	public SocPlazas getSocPlazasSelected() {
		return socPlazasSelected;
	}

	public void setSocPlazasSelected(SocPlazas socPlazasSelected) {
		this.socPlazasSelected = socPlazasSelected;
	}

	public SocBancos getSocBancosSelected() {
		return socBancosSelected;
	}

	public void setSocBancosSelected(SocBancos socBancosSelected) {
		this.socBancosSelected = socBancosSelected;
	}

	public SwfPersonacta getSwfPersonactaSelected() {
		return swfPersonactaSelected;
	}

	public void setSwfPersonactaSelected(SwfPersonacta swfPersonactaSelected) {
		this.swfPersonactaSelected = swfPersonactaSelected;
	}

	public List<SwfPersonacta> getSwfPersonactaLista() {
		return swfPersonactaLista;
	}

	public void setSwfPersonactaLista(List<SwfPersonacta> swfPersonactaLista) {
		this.swfPersonactaLista = swfPersonactaLista;
	}

	public List<SelectItem> getSocBancosItems() {
		return socBancosItems;
	}

	public void setSocBancosItems(List<SelectItem> socBancosItems) {
		this.socBancosItems = socBancosItems;
	}

}
