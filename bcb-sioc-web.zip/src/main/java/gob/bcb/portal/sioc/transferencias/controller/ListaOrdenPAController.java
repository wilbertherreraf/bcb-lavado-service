/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.richfaces.component.html.HtmlDataTable;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBenefslocal;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocOperaciones;

import gob.bcb.portal.menu.DropDownBean;import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;
import gob.bcb.portal.sioc.transferencias.model.OrdenPago;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaOrdenPAController extends BaseBeanController {
	private OrdenPago opa = new OrdenPago();
	private List<OrdenPago> opas;
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
	private List<SelectItem> benefs = new ArrayList<SelectItem>();
	private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
	private List<Datosmen> listaCampos;
	private SocOperaciones operacion;
	private SocDetallesope detalle;
	private SocBenefslocal benef;

	private String idSoli = "-1";
	private Integer idCuenta = -1;
	private Integer idCuentaC = -1;
	private String codIns = "";
	private String numero = "";
	private String cite = "";
	private String concepto = "";
	private String idBenef = "-1";
	private Integer idCuentaB = -1;
	private String label1 = "BIC:";
	private String bic = "";
	private String banco = "";
	private String bic1 = "";
	private String plaza = "";
	private String info = "";
	private String adicional = "";
	private String cod = "";
	private String usuario;
	private String mensaje = "";
	private Boolean interVer = false;
	private Boolean verSwift = false;
	private Boolean verLocal = false;
	private Boolean generada = true;
	private Boolean verOp;
	private Boolean mostrarMensajeConfirmacion;
	private Boolean mostrarLinkInpresion;

	private String urlReporte;

	private Logger log = Logger.getLogger(ListaOrdenPAController.class);

	public ListaOrdenPAController() {
		
recuperarVisit();
		usuario = 
getVisit().getUsuarioSession().getLogin();
		this.mostrarMensajeConfirmacion = false;
		this.mostrarLinkInpresion =  false;
		this.recuperarOrdenes();
	}

	@SuppressWarnings("unchecked")
	private void recuperarOrdenes() {
		this.opas = new ArrayList<OrdenPago>();

		String query = " select o.ins_codigo, o.opa_nroordenpago, o.opa_fechavenc, o.opa_reng, o.opa_imp, o.opa_benef, "
				+ "i.ins_monto, i.moneda, i.ins_concepto, p.ope_fecha "
				+ "from soc_ordenespago o, soc_instrumento i, soc_detallesope d, soc_operaciones p "
				+ "where o.ins_codigo = i.ins_codigo "
				+ "and i.ins_codigo = d.ins_codigo "
				+ "and d.ope_codigo = p.ope_codigo "
				+ "and o.cla_estadoopa = 'P'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				opa = new OrdenPago((String) res.get("ins_codigo"),
						(String) res.get("opa_nroordenpago"),
						(Date) res.get("opa_fechavenc"),
						(Integer) res.get("opa_reng"),
						(Integer) res.get("opa_imp"),
						(String) res.get("opa_benef"),
						(BigDecimal) res.get("ins_monto"),
						(Integer) res.get("moneda"),
						(String) res.get("ins_concepto"),
						(Date) res.get("ope_fecha"));
				opas.add(opa);
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void imprimirOP(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent()
				.getParent().getParent();
		int fila = dataTable.getRowIndex();
		opa = (OrdenPago) SerializationUtils.clone(this.opas.get(fila));
		log.info(opa.getInsCodigo());
		setNumero(opa.getNroOrdenpago() + opa.getOpaReng() + opa.getOpaImp());
		codIns = opa.getInsCodigo();
		concepto ="";
	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD:: changos!!! " + codIns);

		String query = "select sol_codigo from soc_ordenespago p, soc_detallesope d, soc_operaciones o "
				+ "where p.ins_codigo = d.ins_codigo "
				+ "and d.ope_codigo = o.ope_codigo "
				+ "and p.ins_codigo = '"
				+ codIns + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() >= 1) {
			
//			for (Map<String, Object> res1 : resultado) {
//				log.debug("resultado" + res1.toString());
//				idSoli = (String) res1.get("sol_codigo");
//				idSoli = idSoli.trim();
//			}
			
				log.debug("resultado" + resultado.get(0).toString());
				idSoli = (String) resultado.get(0).get("sol_codigo");
				idSoli = idSoli.trim();
			
			
		} else {
			idSoli = "-1";
		}
		if (!idSoli.equals("-1")) {
			cuentasD.clear();

			query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable "
					+ " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 "
					+ " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '"
					+ idSoli + "'";

			List<Map<String, Object>> resultado1 = Servicios
					.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());
					if ((Integer) res.get("moneda") == 69) {
						if (res.get("cta_numero") != null) {
							cuentasD.add(new SelectItem(res.get("cta_codigo"),
									res.get("cta_movimiento") + "-"
											+ res.get("cta_nommovimiento")
											+ "-" + res.get("cta_numero")));
						} else {
							cuentasD.add(new SelectItem(res.get("cta_codigo"),
									res.get("cta_movimiento") + "-"
											+ res.get("cta_nommovimiento")));
						}
					}
				}
			} else {
				log.info("Lista Nula");
			}
			cuentasD.add(new SelectItem(5,
					"4088-OPERACIONES A APROPIAR TGN - GOI"));
			cuentasD.add(new SelectItem(20, "NEW YORK - CTA. 3544020682001"));
			cuentasD.add(new SelectItem(63,
					"ORDENES DE PAGO - GERENCIA DE OP. INTERNACIONALES"));

			query = " select cta_codigo, cta_movimiento, moneda, cta_nommovimiento, cta_afectable "
					+ " from soc_cuentassol "
					+ " where cla_vigente = 1 and moneda = '34' and cta_nommovimiento like '%ENCAJE%'";

			List<Map<String, Object>> resultado2 = Servicios
					.ejecutarQuery(query);
			if (resultado2 != null) {
				for (Map<String, Object> res : resultado2) {
					cuentasD.add(new SelectItem(res.get("cta_codigo"), res
							.get("cta_movimiento")
							+ "-"
							+ res.get("cta_nommovimiento")));
				}
			} else {
				log.info("Lista Nula");
			}

		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public List<SelectItem> getCuentasC() {
		log.info("enter getcuentasC");

		if (!idSoli.equals("-1")) {
			cuentasC.clear();

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable "
					+ " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 "
					+ " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '"
					+ idSoli + "'";

			List<Map<String, Object>> resultado1 = Servicios
					.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());
					if ((Integer) res.get("moneda") == 69) {
						if (res.get("cta_numero") != null) {
							cuentasC.add(new SelectItem(res.get("cta_codigo"),
									res.get("cta_movimiento") + "-"
											+ res.get("cta_nommovimiento")
											+ "-" + res.get("cta_numero")));
						} else {
							cuentasC.add(new SelectItem(res.get("cta_codigo"),
									res.get("cta_movimiento") + "-"
											+ res.get("cta_nommovimiento")));
						}
					}
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			cuentasC.clear();
		}

		return cuentasC;
	}

	public List<SelectItem> getBenefs() {
		if (idSoli != "-1") {

			benefs.clear();

			String query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '"
					+ idSoli + "' " + "ORDER BY bb.ben_nombre ";

			List<Map<String, Object>> resultado = Servicios
					.ejecutarQuery(query);
			if (resultado != null) {
				for (Map<String, Object> res : resultado) {

					benefs.add(new SelectItem(res.get("ben_codigo"),
							(String) res.get("ben_nombre")));
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			benefs.clear();
		}

		return benefs;
	}

	public List<SelectItem> getCuentasB() {
		cuentasB.clear();
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		info = "";

		if (idBenef != "-1") {
			String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
					+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, "
					+ " pp1.pla_nombre as pla1"
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
					+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
					+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.ben_codigo = '"
					+ idBenef + "'";

			List<Map<String, Object>> resultado = Servicios
					.ejecutarQuery(query);
			if (resultado.size() > 0) {
				interVer = true;
				for (Map<String, Object> res : resultado) {

					cuentasB.add(new SelectItem(res.get("cta_codigo"),
							(String) res.get("cta_nrocuenta")));
					listaCuentasB.add(new CuentasBen((Integer) res
							.get("cta_codigo"), (String) res
							.get("cta_nrocuenta"),
							(String) res.get("cta_info"), (Integer) res
									.get("moneda"), (String) res
									.get("bco_nombre"), (String) res
									.get("pla_nombre"), (String) res
									.get("pla_bic"), (String) res
									.get("pla_intermediario"), (String) res
									.get("pla_nrocuenta"), (String) res
									.get("bco1"), (String) res.get("pla1")));
				}
			} else {
				interVer = false;
				log.info("Lista Nula");
			}
			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
					+ " pp.pla_nombre, pp.pla_bic "
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
					+ " AND pp.bco_codigo = bb.bco_codigo "
					+ " AND pp.pla_intermediario is null"
					+ " AND cc.cla_vigente = 1 AND cc.ben_codigo = '"
					+ idBenef
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios
					.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				interVer = false;
				for (Map<String, Object> res : resultado1) {

					cuentasB.add(new SelectItem(res.get("cta_codigo"),
							(String) res.get("cta_nrocuenta")));
					listaCuentasB.add(new CuentasBen((Integer) res
							.get("cta_codigo"), (String) res
							.get("cta_nrocuenta"),
							(String) res.get("cta_info"), (Integer) res
									.get("moneda"), (String) res
									.get("bco_nombre"), (String) res
									.get("pla_nombre"), (String) res
									.get("pla_bic")));
				}
			} else {
				interVer = false;
				log.info("Lista Nula");
			}
		}

		return cuentasB;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		log.info("Valor seleccionado: " + sel);

		info = "";
		if (sel != -1) {
			for (CuentasBen cuentaB : listaCuentasB) {
				if (cuentaB.getCtaCodigo().compareTo(sel) == 0) {
					if (!interVer) {
						bic = cuentaB.getPlaBic();
						if (bic != null)
							setLabel1("BIC:");
						else {
							bic = cuentaB.getPlaNroCuenta();
							setLabel1("Cuenta:");
						}
					} else {
						bic = cuentaB.getPlaNroCuenta();
						if (bic != null)
							setLabel1("Cuenta:");
						else {
							bic = cuentaB.getPlaBic();
							setLabel1("BIC:");
						}
					}
					// cuenta = cuentaB.getCtaNroCuenta();
					banco = cuentaB.getBcoNombre() + " - "
							+ cuentaB.getPlaNombre();
					bic1 = cuentaB.getPlaIntermediario();
					plaza = cuentaB.getBcoNombreI() + " - "
							+ cuentaB.getPlaNombreI();
					info = cuentaB.getCtaInfo();

					/*
					 * if (montoVer) { String query =
					 * "SELECT ben_nit, ben_factura " +
					 * "FROM soc_benefs bb WHERE ben_codigo = '" + idBenef +
					 * "' " + "AND cla_vigente = 1";
					 * 
					 * List<Map<String, Object>> resultado =
					 * Servicios.ejecutarQuery(query); if (resultado.size() ==
					 * 1) { for (Map<String, Object>res : resultado) {
					 * log.debug("resultado" + res.toString()); setNit((String)
					 * res.get("ben_nit")); setFact((String)
					 * res.get("ben_factura")); } } else {
					 * log.info("Lista Nula"); } }
					 */
				}
			}
		} else {
			// cuenta = "";
			bic = "";
			bic1 = "";
			banco = "";
			plaza = "";
			info = "";
			/*
			 * nit = ""; fact = "";
			 */
		}
	}

	public void seleccion1Changed(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		log.info("Valor seleccionado: " + sel);

		if (sel == 20) {
			setVerSwift(true);
			verLocal = false;
			setVerOp(false);
		} else {
			if (sel == 63) {
				setVerOp(true);
			} else {
				String nom = Servicios.getNomCuenta(sel);
				if (nom.contains("ENCAJE")) {
					setVerSwift(false);
					interVer = false;
					verLocal = true;
					setVerOp(false);
				} else {
					setVerSwift(false);
					interVer = false;
					verLocal = false;
					setVerOp(false);
				}
			}
		}
	}

	public void eventoAnularBtn(ActionEvent event) {
		this.mostrarMensajeConfirmacion = false;
		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		operacion = new SocOperaciones();
		operacion.setSolCodigo(idSoli + "   ");
		operacion.setClaOperacion("RG");
		operacion.setOpeMontome(opa.getInsMonto());
		operacion.setMoneda(opa.getMoneda());
		operacion.setOpeCtaoperacion(idCuenta);
		operacion.setOpeCtacomision(idCuentaC);
		operacion.setSocCorrelativo(cite);
		operacion.setClaEstado('P');

		String nroCuenta = Servicios.getNroCuenta(idSoli, idCuentaC);
		operacion.setOpeNrocuentac(nroCuenta);
		detalle = new SocDetallesope();
		log.info("cta:" + idCuenta);
		if (!verSwift) {
			if (verLocal) {
				detalle.setBenCodigo("999999");
				detalle.setDetInfo(info);
			} else {
				if (verOp == null) {					
					this.mensaje = "No existe Cuenta a Acreditar para el Nro.:"+ numero;
					this.mostrarMensajeConfirmacion = true;					
					return;
				} else if (verOp) {
					detalle.setBenCodigo("999998");
					detalle.setDetInfo(info);

					benef = new SocBenefslocal();
					benef.setBeneficiario(adicional);
					benef.setCtaBenef(codIns);

				} else {
					detalle.setBenCodigo("0000");
				}
			}
		} else {
			detalle.setBenCodigo(idBenef);
			detalle.setDetCtabenef(Integer.toString(idCuentaB));
			detalle.setDetInfo(info + " " + adicional);
			detalle.setDetMontoOrd(BigDecimal.valueOf(0.00));
		}

		detalle.setInsCodigo(codIns);
		detalle.setDetMonto(opa.getInsMonto());
		detalle.setMoneda(opa.getMoneda());
		detalle.setDetConcepto(concepto.toUpperCase());

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		if (!verOp) {
			mapaParametros.put("opcion", "anularOP");
		} else {
			mapaParametros.put("opcion", "anularOPOP");
			mapaParametros.put("benef", benef);
		}
		mapaParametros.put("operacion", operacion);
		mapaParametros.put("detalle", detalle);
		mapaParametros.put("usuario", usuario);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(
				"bpmPruebaCU", "172.29.18.3", "cliente", "consulta",
				mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: "
					+ mapaRespuesta.get("resp_msgerror");
			return;
		}

		String ee = (String) mapaRespuesta.get("nroOperacion");
		cod = (String) mapaRespuesta.get("nroInst");
		if ((cod == null) || (cod.equals("")))
		{
			mostrarLinkInpresion = false;		
			System.out.println("codIns nuloooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo");
		}
		else	{
			mostrarLinkInpresion =  true;
		}
			
		log.info("nro: " + ee);

		if (!cod.equals("") && verSwift) {
			setGenerada(true);
			String ln = System.getProperty("line.separator");

			this.listaCampos = new ArrayList<Datosmen>();

			String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre "
					+ " from soc_datosmen d, soc_campos c "
					+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'"
					+ " and d.ins_codigo = '" + cod + "'";

			List<Map<String, Object>> resultado1 = Servicios
					.ejecutarQuery(query1);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {
					log.debug("resultado" + res.toString());

					String alto;
					String valor = "";
					String valor1 = (String) res.get("dam_valor");
					if (res.get("cam_codigo").equals(":32A")) {
						valor = valor1;
						valor1 = valor.substring(0, 6) + ln
								+ valor.substring(6, 9) + ln
								+ valor.substring(9);
					}

					if (res.get("cam_codigo").equals(":33B")) {
						valor = valor1;
						valor1 = valor.substring(0, 3) + ln
								+ valor.substring(3);
					}

					int i = StringUtils.countMatches(valor1, ln);
					i = (i + 1) * 16;
					alto = " height : " + i + "px;";

					listaCampos.add(new Datosmen(
							(String) res.get("cam_codigo"), (String) res
									.get("ins_codigo"), valor1, alto,
							(String) res.get("cam_nombre")));
				}
			} else {
				log.info("Lista Nula");
			}
			mensaje = "La orden de pago fue anulada y se gener� el mensaje de transferencia correspondiente.";
		} else {
			setGenerada(false);
			mensaje = "La orden de pago fue anulada.";
		}

		this.recuperarOrdenes();
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public OrdenPago getOpa() {
		return opa;
	}

	public void setOpa(OrdenPago opa) {
		this.opa = opa;
	}

	public SocBenefslocal getBenef() {
		return benef;
	}

	public void setBenef(SocBenefslocal benef) {
		this.benef = benef;
	}

	public List<OrdenPago> getOpas() {
		return opas;
	}

	public void setOpas(List<OrdenPago> opas) {
		this.opas = opas;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public List<Datosmen> getListaCampos() {
		return listaCampos;
	}

	public void setListaCampos(List<Datosmen> listaCampos) {
		this.listaCampos = listaCampos;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Integer idCuenta) {
		this.idCuenta = idCuenta;
	}

	public void setIdCuentaC(Integer idCuentaC) {
		this.idCuentaC = idCuentaC;
	}

	public Integer getIdCuentaC() {
		return idCuentaC;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getNumero() {
		return numero;
	}

	public void setCite(String cite) {
		this.cite = cite;
	}

	public String getCite() {
		return cite;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public void setCuentasB(List<SelectItem> cuentasB) {
		this.cuentasB = cuentasB;
	}

	public void setBenefs(List<SelectItem> benefs) {
		this.benefs = benefs;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public Integer getIdCuentaB() {
		return idCuentaB;
	}

	public void setIdCuentaB(Integer idCuentaB) {
		this.idCuentaB = idCuentaB;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getBic1() {
		return bic1;
	}

	public void setBic1(String bic1) {
		this.bic1 = bic1;
	}

	public String getPlaza() {
		return plaza;
	}

	public void setPlaza(String plaza) {
		this.plaza = plaza;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getAdicional() {
		return adicional;
	}

	public void setAdicional(String adicional) {
		this.adicional = adicional;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getLabel1() {
		return label1;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setVerSwift(Boolean verSwift) {
		this.verSwift = verSwift;
	}

	public Boolean getVerSwift() {
		return verSwift;
	}

	public void setVerLocal(Boolean verLocal) {
		this.verLocal = verLocal;
	}

	public Boolean getVerLocal() {
		return verLocal;
	}

	public void setVerOp(Boolean verOp) {
		this.verOp = verOp;
	}

	public Boolean getVerOp() {
		return verOp;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + cod + "&tipo=SW";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	public Boolean getMostrarMensajeConfirmacion() {
		return mostrarMensajeConfirmacion;
	}

	public void setMostrarMensajeConfirmacion(Boolean mostrarMensajeConfirmacion) {
		this.mostrarMensajeConfirmacion = mostrarMensajeConfirmacion;
	}

	public Boolean getMostrarLinkInpresion() {
		return mostrarLinkInpresion;
	}

	public void setMostrarLinkInpresion(Boolean mostrarLinkInpresion) {
		this.mostrarLinkInpresion = mostrarLinkInpresion;
	}
	
	

}
