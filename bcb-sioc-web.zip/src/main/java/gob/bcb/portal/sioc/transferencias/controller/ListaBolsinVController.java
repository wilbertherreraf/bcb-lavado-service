/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocBolsin;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.SocBolsinS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaBolsinVController extends BaseBeanController {

	private SocBolsin solicitudB = new SocBolsin();
	private SocBolsinS solicitudBS = new SocBolsinS();
	private List<SocBolsinS> solicitudes;
	private List<SocBolsin> listaSoli;
	private String idSoli = "-1";
	private String cuentaD;
	private Boolean generada = true;
	private String mensaje = "";

	private Logger log = Logger.getLogger(ListaBolsinVController.class);

	public ListaBolsinVController() {

		recuperarVisit();
		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
		log.info("idSoli " + idSoli);
		this.recuperarSolicitudes();
	}

	@SuppressWarnings("unchecked")
	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SocBolsinS>();
		this.listaSoli = new ArrayList<SocBolsin>();

		if (idSoli.equalsIgnoreCase("900")) {
			solicitudes = Servicios.getSocBolsinSList("'B'", null, null);
			listaSoli = Servicios.getSocBolsinList("'B'", null, null);
		} else {
			solicitudes = Servicios.getSocBolsinSList("'9'", null, idSoli);
			listaSoli = Servicios.getSocBolsinList("'9'", null, idSoli);
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudBS = this.solicitudes.get(fila);
		this.solicitudB = this.listaSoli.get(fila);

		String query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
				+ solicitudB.getCuentaD() + "'";

		List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
		if (resultadoD.size() == 1) {
			for (Map<String, Object> res : resultadoD) {

				setCuentaD(res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento"));
			}
		}
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Generando la operaci�n: ");

		solicitudB.setClaEstado('0');
		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "autBolsin");
		mapaParametros.put("solicitud", solicitudB);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");

		this.recuperarSolicitudes();

		log.info("Estado devuelto: " + estado);

		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}
		if (estado.equals("0"))
			mensaje = "Se autoriz� la solicitud y se realiz� la provisi�n de fondos satisfactoriamente.";
		else
			mensaje = "Se produjo un error al autorizar la provisi�n de fondos.";
	}

	public void eventoAnularBtn(ActionEvent action) {
		log.info("Generando la operaci�n: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "anularBolsin");
		mapaParametros.put("solicitud", solicitudB);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado devuelto: " + estado);

		this.recuperarSolicitudes();

	}

	public SocBolsin getSolicitudB() {
		return solicitudB;
	}

	public void setSolicitudB(SocBolsin solicitudB) {
		this.solicitudB = solicitudB;
	}

	public SocBolsinS getSolicitudBS() {
		return solicitudBS;
	}

	public void setSolicitudBS(SocBolsinS solicitudBS) {
		this.solicitudBS = solicitudBS;
	}

	public List<SocBolsinS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SocBolsinS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<SocBolsin> getListaSoli() {
		return listaSoli;
	}

	public void setListaSoli(List<SocBolsin> listaSoli) {
		this.listaSoli = listaSoli;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
