/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por wherrera
 */
package gob.bcb.portal.sioc.transferencias.controller;

//import java.math.BigDecimal;
import gob.bcb.bpm.pruebaCU.CuentasBen;

import gob.bcb.bpm.pruebaCU.Opecomi;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocFacturasId;
import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;
import gob.bcb.portal.sioc.transferencias.model.OperacionesS;
import gob.bcb.portal.sioc.transferencias.model.OrdenPago;
import gob.bcb.portal.sioc.transferencias.model.Venta;
import gob.bcb.service.servicioSioc.pojos.ComprobanteDet;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaOperacionesPController {
	private SocOperaciones operacion = new SocOperaciones();
	private OperacionesS operacionS = new OperacionesS();
	private SocDetallesope detalleO = new SocDetallesope();
	private CuentasBen cuentaBen = new CuentasBen();
	private OrdenPago opa = new OrdenPago();

	private List<SocOperaciones> operaciones;
	private List<OperacionesS> listaOper;
	private Opecomi comision;
	private List<Opecomi> comisiones;
	private SocFacturas fac;
	private List<SocFacturas> facturas;
	private List<ComprobanteDet> comprobante;
	private List<ComprobanteDet> comprobanteList;	
	private List<Datosmen> listaCampos;
	private Venta venta;
	private List<Venta> ventas;

	private String nroOperacion;
	private String moneda;
	private String cuentaD = "";
	private String cuentaC = "";
	private String cuentaB = "";
	private String cuentaBC = "";
	private String nombre = "";
	private String nombreF = "";
	private String banco = "";
	private String label1 = "BIC:";
	private String bic = "";
	private String monC = "";
	private String codBenCodigo = "";
	private String mensaje = "";
	private String inst = "";
	private String nroCuenta = "";
	private String numero = "";
	private String benef;
	private String glosa = "";
	private BigDecimal comis;
	private BigDecimal comisU;
	private BigDecimal montoMN;
	private BigDecimal montoEquiv;
	private BigDecimal diff = BigDecimal.valueOf(0.00);
	private BigDecimal debeT = BigDecimal.valueOf(0.00);
	private BigDecimal haberT = BigDecimal.valueOf(0.00);
	private Boolean swiftVer = true;
	private Boolean interVer = false;
	private Boolean nroVer = false;
	private Boolean nroCVer = false;
	private Boolean extVer = true;
	private Boolean localVer = false;
	private Boolean opVer = true;
	private Boolean swVer = true;
	private Boolean equiv = false;
	private Boolean mostrarGenOperacion = false;
	private String subTipoOperacion;
	private String tipoOperacionFecValor = "";

	private String urlReporte;

	private Logger log = Logger.getLogger(ListaOperacionesPController.class);

	private String sIOCWEB_TIPOPERACION;

	public ListaOperacionesPController() {

		this.recuperarOperaciones();

	}

	private void recuperarOperaciones() {
		operaciones = new ArrayList<SocOperaciones>();
		listaOper = new ArrayList<OperacionesS>();
		operacionS.setPanel1(false); // opePanel
		operacionS.setPanel2(false); // opePanelV
		operacionS.setPanel3(false); // opePanelL
		operacionS.setPanel4(false);// opePanelD
		operacionS.setPanel5(false);// opePanelDSP
		operacionS.setPanel6(false);// opePanelR
		operacionS.setPanel7(false);// opePanelCE

		swiftVer = false;

		Visit visit = Visit.getVisit();

		sIOCWEB_TIPOPERACION = (String) visit.getParametro("SIOCWEB_TIPOPERACION");
		log.info("enter sIOCWEB_TIPOPERACION " + sIOCWEB_TIPOPERACION);
		String SIOCWEB_CODOPERACION = (String) visit.getParametro("SIOCWEB_CODOPERACION");

		if (!StringUtils.isBlank(SIOCWEB_CODOPERACION)) {
			log.info("XXX: yupiiiiii landiayyy " + SIOCWEB_CODOPERACION);
			recuperarOperacion(SIOCWEB_CODOPERACION);
			log.info("XXX: yupiiiiii landia " + operacion.getSocCorrelativo());
			//recuperarDatosComprob(nroOperacion);
			recuperarDatosComprobList(nroOperacion);
		} else {
			String query = " select o.*, ss.sol_persona " + " from soc_operaciones o, soc_solicitante ss " + " where o.sol_codigo = ss.sol_codigo"
					+ " and o.cla_estado = 'P'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() > 0) {
				for (Map<String, Object> res : resultado) {

					operacionS = new OperacionesS((String) res.get("ope_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
							(String) res.get("cla_operacion"), (Integer) res.get("moneda"), 'P', (Date) res.get("ope_fecha"),
							(BigDecimal) res.get("ope_montome"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("ope_montomn"), "");

					if (operacionS.getClaOperacion().equals("TE") || operacionS.getClaOperacion().equals("OB")) {
						operacionS.setTipo("TRANSFERENCIA AL EXTERIOR");
						operacionS.setPanel1(true);
						swiftVer = true;
					} else if (operacionS.getClaOperacion().equals("VE")) {
						operacionS.setTipo("VENTA DE DIVISAS");
						operacionS.setPanel2(true);

					} else if (operacionS.getClaOperacion().equals("TC")) {
						operacionS.setTipo("TRANSFERENCIA CUENTA A CUENTA");
						operacionS.setPanel3(true);

					} else if (operacionS.getClaOperacion().equals("TD")) {
						operacionS.setTipo("TRANSFERENCIA DEL EXTERIOR");
						if (operacionS.getSolCodigo() != null && operacionS.getSolCodigo().trim().equals("900")) {
							if (!StringUtils.isBlank(operacionS.getSocCorrelativo())) {
								if (operacionS.getSocCorrelativo().indexOf("(CC:H-", 0) < 0)
									operacionS.setSolicitante("EXPORTADORES:" + operacionS.getSolicitante());
								else
									operacionS.setSolicitante("ACREEDORES:" + operacionS.getSolicitante());
							} else {
								operacionS.setSolicitante("EXPORTADORES:" + operacionS.getSolicitante());
							}
							operacionS.setPanel4(true);
						} else {
							operacionS.setPanel5(true);
						}
					} else if (operacionS.getClaOperacion().equals("CE")) {
						operacionS.setTipo("CHEQUES EN COBRANZA");
						operacionS.setPanel7(true);
					} else {
						operacionS.setTipo("REGULARIZACION ORDEN DE PAGO");
						operacionS.setPanel6(true);
					}

					DateTime fecha = new DateTime();
					DateTime fechaV = new DateTime(res.get("ope_fecha"));

					if (fechaV.getDayOfMonth() == fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear()) {
						listaOper.add(operacionS);

						operacion = new SocOperaciones((String) res.get("ope_codigo"), (String) res.get("sol_codigo"),
								(String) res.get("cla_operacion"), (Date) res.get("ope_fecha"), (BigDecimal) res.get("ope_montome"),
								(BigDecimal) res.get("ope_montomn"), (Integer) res.get("moneda"), (Integer) res.get("ope_ctaoperacion"),
								(Integer) res.get("ope_ctacomision"), (String) res.get("usr_codigo"), (Date) res.get("fecha_hora"),
								(String) res.get("estacion"), 'P', (String) res.get("ope_nrocuentac"), (String) res.get("soc_correlativo"),
								(String) res.get("ope_nrocuentad"), (String) res.get("soc_codigo"));
						operaciones.add(operacion);
					}
				}
			}
		}
	}

	public void verOperacion(ActionEvent event) {
		log.info("enter ver");
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();

		operacion = operaciones.get(fila);
		operacionS = listaOper.get(fila);

		recuperarOperacion(operacion.getOpeCodigo());
	}

	public void recuperarOperacion(String opeCodigo) {
		String query = " select o.*, ss.sol_persona " + " from soc_operaciones o, soc_solicitante ss " + " where o.sol_codigo = ss.sol_codigo"
				+ " and o.ope_codigo = '" + opeCodigo + "'";

		List<Map<String, Object>> resultadoOper = Servicios.ejecutarQuery(query);

		for (Map<String, Object> regOper : resultadoOper) {

			operacionS = new OperacionesS((String) regOper.get("ope_codigo"), (String) regOper.get("sol_codigo"),
					(String) regOper.get("sol_persona"), (String) regOper.get("cla_operacion"), (Integer) regOper.get("moneda"), 'P',
					(Date) regOper.get("ope_fecha"), (BigDecimal) regOper.get("ope_montome"), (String) regOper.get("soc_correlativo"),
					(BigDecimal) regOper.get("ope_montomn"), "");

			if (operacionS.getClaOperacion().equals("TE") || operacionS.getClaOperacion().equals("OB")) {
				operacionS.setTipo("TRANSFERENCIA AL EXTERIOR");
				operacionS.setPanel1(true);
				swiftVer = true;
			} else if (operacionS.getClaOperacion().equals("VE")) {
				operacionS.setTipo("VENTA DE DIVISAS");
				operacionS.setPanel2(true);

			} else if (operacionS.getClaOperacion().equals("TC")) {
				operacionS.setTipo("TRANSFERENCIA CUENTA A CUENTA");
				operacionS.setPanel3(true);

			} else if (operacionS.getClaOperacion().equals("TD")) {
				operacionS.setTipo("TRANSFERENCIA DEL EXTERIOR");
				if (operacionS.getSolCodigo() != null && operacionS.getSolCodigo().trim().equals("900")) {
					if (!StringUtils.isBlank(operacionS.getSocCorrelativo())) {
						if (operacionS.getSocCorrelativo().indexOf("(CC:H-", 0) < 0)
							operacionS.setSolicitante("EXPORTADORES:" + operacionS.getSolicitante());
						else
							operacionS.setSolicitante("ACREEDORES:" + operacionS.getSolicitante());
					} else {
						operacionS.setSolicitante("EXPORTADORES:" + operacionS.getSolicitante());
					}
					operacionS.setPanel4(true);
				} else {
					operacionS.setPanel5(true);
				}
			} else if (operacionS.getClaOperacion().equals("CE")) {
				operacionS.setTipo("CHEQUES EN COBRANZA");
				operacionS.setPanel7(true);
			} else {
				operacionS.setTipo("REGULARIZACION ORDEN DE PAGO");
				operacionS.setPanel6(true);
			}

			operacion = new SocOperaciones((String) regOper.get("ope_codigo"), (String) regOper.get("sol_codigo"),
					(String) regOper.get("cla_operacion"), (Date) regOper.get("ope_fecha"), (BigDecimal) regOper.get("ope_montome"),
					(BigDecimal) regOper.get("ope_montomn"), (Integer) regOper.get("moneda"), (Integer) regOper.get("ope_ctaoperacion"),
					(Integer) regOper.get("ope_ctacomision"), (String) regOper.get("usr_codigo"), (Date) regOper.get("fecha_hora"),
					(String) regOper.get("estacion"), 'P', (String) regOper.get("ope_nrocuentac"), (String) regOper.get("soc_correlativo"),
					(String) regOper.get("ope_nrocuentad"), (String) regOper.get("soc_codigo"));
			nroOperacion = operacion.getOpeCodigo();

			log.info("resultado " + nroOperacion);

			mostrarGenOperacion = false;
			tipoOperacionFecValor = "";

			query = " select d.* " + " from soc_detallesope d " + " where d.ope_codigo = '" + nroOperacion + "'" + " and d.det_codigo = 1";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);

			for (Map<String, Object> res : resultado1) {

				detalleO = new SocDetallesope(new SocDetallesopeId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ins_codigo"), (String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"),
						(Integer) res.get("moneda"), (String) res.get("det_ctabenef"), (String) res.get("det_concepto"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("det_info"), (String) res.get("det_facturas"));
			}

			if (operacion.getOpeCtaoperacion() != null) {
				query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
						+ operacion.getOpeCtaoperacion() + "'";

				List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
				if (resultadoD.size() == 1) {
					for (Map<String, Object> res : resultadoD) {

						if ((Integer) res.get("moneda") == 34)
							moneda = "-USD";
						if ((Integer) res.get("moneda") == 69)
							moneda = "";
						cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
					}
				}
			}

			nroVer = (operacion.getOpeCtaoperacion() != null);

			if (operacion.getOpeCtacomision() != null) {
				query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
						+ operacion.getOpeCtacomision() + "'";

				List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
				if (resultadoC.size() == 1) {
					for (Map<String, Object> res : resultadoC) {

						if ((Integer) res.get("moneda") == 34)
							moneda = "-USD";
						if ((Integer) res.get("moneda") == 69)
							moneda = "";
						cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
					}
				}
			}

			if (operacion.getClaOperacion().equals("TC")) {
				// transferencia local
				query = " select d.*, b.ben_nombre, b.ben_nit, b.ben_factura, c.cta_nrocuenta, c.moneda, c.cta_nrocuenta1, s.cta_nommovimiento "
						+ " from soc_detallesope d, soc_benefsloc b, soc_cuentasloc c, soc_cuentassol s " + " where d.ope_codigo = '" + nroOperacion
						+ "'" + " and d.det_codigo = 1" + " and d.ben_codigo = b.ben_codigo " + " and d.det_ctabenef = c.cta_codigo "
						+ " and c.cta_ctacodigo = s.cta_codigo";

				List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
				for (Map<String, Object> res : resultado2) {

					nombre = (String) res.get("ben_nombre");
					cuentaB = (String) res.get("cta_nrocuenta");
					cuentaBC = (String) res.get("cta_nrocuenta1");

					opVer = (cuentaBC != null);

					banco = (String) res.get("cta_nommovimiento");
					nombreF = (String) res.get("ben_factura");
					bic = (String) res.get("ben_nit");
				}

				if (operacion.getOpeCtacomision() != null) {
					localVer = true;
					extVer = false;
				} else {
					localVer = false;
					extVer = true;
				}
			} else if (operacion.getClaOperacion().equals("TD")) {
				// transferencia
				// delext
				log.info("XXX: operacion.getSolCodigo() " + operacion.getSolCodigo());
				if (operacion.getSolCodigo() != null && operacion.getSolCodigo().trim().equals("900")) {
					// exportadores
					if (detalleO.getBenCodigo().equals("9999"))
						subTipoOperacion = "CC";

					query = " select d.*, b.ben_nombre, b.ben_nit, b.ben_factura, c.cta_nrocuenta, c.moneda, s.sol_persona "
							+ " from soc_detallesope d, soc_benefsexp b, soc_cuentasexp c, soc_solicitante s " + " where d.ope_codigo = '"
							+ nroOperacion + "'" + " and d.det_codigo = 1" + " and d.ben_codigo = b.ben_codigo "
							+ " and d.det_ctabenef = c.cta_codigo " + " and c.bco_codigo = s.sol_codigo";

					List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
					for (Map<String, Object> res : resultado2) {

						nombre = (String) res.get("ben_nombre");
						cuentaB = (String) res.get("cta_nrocuenta");
						banco = (String) res.get("sol_persona");
						Integer mon = (Integer) res.get("moneda");
						if (mon == 34)
							setMonC("DOLARES ESTADOUNIDENSES");
						else
							setMonC("BOLIVIANOS");
						nombreF = (String) res.get("ben_factura");
						bic = (String) res.get("ben_nit");
					}
					extVer = true;
				} else {
					// sector pï¿½blico
					nroCuenta = Servicios.getNroCuenta(operacion.getSolCodigo(), operacion.getOpeCtaoperacion());
				}
			} else if (operacion.getClaOperacion().equals("TE") || operacion.getClaOperacion().equals("OB")) {
				// TRANSFERENCIA
				// AL
				// EXTERIOR
				DateTime fecha = new DateTime(operacion.getFechaHora());
				DateTime fechaV = new DateTime(operacion.getOpeFecha());
				log.info("fecha:" + Integer.toString(fecha.getDayOfMonth()));
				log.info("fechaV:" + Integer.toString(fechaV.getDayOfMonth()));
				if (fecha.getDayOfMonth() != fechaV.getDayOfMonth()) {
					mostrarGenOperacion = true;
					tipoOperacionFecValor = "TE";
					// actualizarTC("TE");
					if (operacion.getMoneda() != 34)
						equiv = true;
					else
						equiv = false;
				}

				query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
						+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
						+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND ss.sol_codigo = '" + operacion.getSolCodigo() + "' "
						+ "AND trim(ss.ben_codigo) = '" + detalleO.getBenCodigo() + "'";

				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
				if (resultado.size() == 1) {
					for (Map<String, Object> res : resultado) {
						nombre = (String) res.get("ben_nombre");
					}
				}

				query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
						+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
						+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
						+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalleO.getDetCtabenef() + "'";

				List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
				if (resultado3.size() == 1) {
					for (Map<String, Object> res : resultado3) {
						cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
								(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"),
								(String) res.get("pla_bic"));
					}
				}
			} else if (operacion.getClaOperacion().equals("RG")) {
				subTipoOperacion = "RG";
				query = " select o.ins_codigo, o.opa_nroordenpago, o.opa_fechavenc, o.opa_reng, o.opa_imp, o.opa_benef, "
						+ "i.ins_monto, i.moneda, i.ins_concepto, p.ope_fecha "
						+ "from soc_ordenespago o, soc_instrumento i, soc_detallesope d, soc_operaciones p " + "where o.ins_codigo = i.ins_codigo "
						+ "and i.ins_codigo = d.ins_codigo " + "and d.ope_codigo = p.ope_codigo " + "and p.ope_codigo = '" + nroOperacion + "'";

				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);

				for (Map<String, Object> res : resultado) {

					opa = new OrdenPago((String) res.get("ins_codigo"), (String) res.get("opa_nroordenpago"), (Date) res.get("opa_fechavenc"),
							(Integer) res.get("opa_reng"), (Integer) res.get("opa_imp"), (String) res.get("opa_benef"),
							(BigDecimal) res.get("ins_monto"), (Integer) res.get("moneda"), (String) res.get("ins_concepto"),
							(Date) res.get("ope_fecha"));
					setNumero(opa.getNroOrdenpago() + opa.getOpaReng() + opa.getOpaImp());
				}

				if (detalleO.getBenCodigo().equals("999998")) {
					subTipoOperacion = "RGOP";
					query = "select beneficiario from soc_benefslocal " + "where soc_codigo = '" + operacion.getOpeCodigo() + "'";

					List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
					if (resultado2.size() > 0) {
						for (Map<String, Object> res : resultado2) {
							benef = (String) res.get("beneficiario");
							log.info("ben:" + benef);
						}
					}
				}

			} else if (operacion.getClaOperacion().equals("CE")) {
				nroCuenta = Servicios.getNroCuenta(operacion.getSolCodigo(), operacion.getOpeCtaoperacion());
			} else {
				// VENTA DE DIVISAS
				this.ventas = new ArrayList<Venta>();

				if (operacion.getOpeCtaoperacion() == 5)
					nroCVer = false;
				else
					nroCVer = true;

				query = "select soc_montomn " + "from soc_solicitudes " + "where soc_correlativo = '" + operacion.getSocCorrelativo() + "'";

				List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
				if (resultado3.size() == 1) {
					for (Map<String, Object> res : resultado3) {
						montoMN = (BigDecimal) res.get("soc_montomn");
					}
					diff = montoMN.subtract(operacion.getOpeMontome().multiply(Servicios.getTipoCambio(35)));
				}

				query = "select ben_codigo from soc_detallesope where ope_codigo = '" + operacion.getOpeCodigo() + "' and det_codigo = 1";

				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
				if (resultado.size() == 1) {
					for (Map<String, Object> res : resultado) {
						codBenCodigo = (String) res.get("ben_codigo");
					}
				}

				if (codBenCodigo.equals("999998")) {
					subTipoOperacion = "OP";
					interVer = false;
					extVer = false;
					localVer = true;
					opVer = false;
					swVer = false;
					query = " select d.*, b.*" + " from soc_detallesope d, soc_benefslocal b, soc_operaciones o, soc_solicitudes s"
							+ " where d.ope_codigo = '" + operacion.getOpeCodigo() + "'" + " and d.ope_codigo = o.ope_codigo "
							+ " and o.soc_correlativo = s.soc_correlativo " + " and b.soc_codigo = s.soc_codigo "
							+ " and b.det_codigo = d.det_codigo";

					List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);

					for (Map<String, Object> res : resultado2) {

						Integer mon = (Integer) res.get("moneda");
						venta = new Venta((String) res.get("beneficiario"), (String) res.get("cta_benef"), "", (BigDecimal) res.get("det_monto"),
								"999998", mon.toString(), 0, "", (Integer) res.get("det_codigo"));
						ventas.add(venta);
					}

				} else if (codBenCodigo.charAt(0) != '0') {
					subTipoOperacion = "TC";
					interVer = false;
					extVer = false;
					localVer = true;
					opVer = true;
					swVer = false;

					query = " select d.*, b.ben_nombre, c.cta_nrocuenta, c.moneda, s.cta_nommovimiento "
							+ " from soc_detallesope d, soc_benefsloc b, soc_cuentasloc c, soc_cuentassol s " + " where d.ope_codigo = '"
							+ nroOperacion + "'" + " and d.ben_codigo = b.ben_codigo " + " and d.det_ctabenef = c.cta_codigo "
							+ " and c.cta_ctacodigo = s.cta_codigo";

					List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);

					for (Map<String, Object> res : resultado2) {

						Integer mon = (Integer) res.get("moneda");
						venta = new Venta((String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_nommovimiento"),
								(BigDecimal) res.get("det_monto"), "999999", mon.toString(), 0, "", (Integer) res.get("det_codigo"));
						ventas.add(venta);
					}

				} else {
					subTipoOperacion = "TE";
					extVer = true;
					localVer = false;
					opVer = true;
					swVer = true;

					DateTime fecha = new DateTime(operacion.getFechaHora());
					DateTime fechaV = new DateTime(operacion.getOpeFecha());
					log.info("fecha:" + Integer.toString(fecha.getDayOfMonth()));
					log.info("fechaV:" + Integer.toString(fechaV.getDayOfMonth()));

					if (fecha.getDayOfMonth() != fechaV.getDayOfMonth()) {
						mostrarGenOperacion = true;
						tipoOperacionFecValor = "VE";
					}

					query = "select o.*, b.ben_nombre, c.cta_nrocuenta, bb.bco_nombre, p.pla_nombre "
							+ "from soc_detallesope o, soc_benefs b, soc_plazas p, soc_bancos bb, soc_cuentas c "
							+ "where b.ben_codigo = o.ben_codigo and c.cta_codigo = o.det_ctabenef "
							+ "and c.bco_codigo = bb.bco_codigo and p.bco_codigo = bb.bco_codigo "
							+ "and c.pla_codigo = p.pla_codigo and o.ope_codigo = '" + operacion.getOpeCodigo() + "' " + "order by o.det_codigo";

					List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);

					for (Map<String, Object> res : resultado2) {

						Integer mon = (Integer) res.get("moneda");
						String mon1 = "";
						if (mon == 34)
							mon1 = "USD";
						else
							mon1 = "EUR";
						String cta = (String) res.get("det_ctabenef");
						cta = cta.trim();
						venta = new Venta((String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"), (String) res.get("bco_nombre") + " - "
								+ (String) res.get("pla_nombre"), (BigDecimal) res.get("det_monto"), (String) res.get("ben_codigo"), mon1,
								Integer.valueOf(cta), (String) res.get("det_info"), (Integer) res.get("det_codigo"));
						ventas.add(venta);
					}

				}

			}
		}
	}

	private void actualizarTC(String tipo) {
		String id = new Long(new Date().getTime()).toString();

		BigDecimal tc = Servicios.getTipoCambio(operacion.getMoneda());
		montoMN = operacion.getOpeMontome().multiply(tc).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		diff = montoMN.subtract(operacion.getOpeMontomn()).abs();
		BigDecimal tcUS = Servicios.getTipoCambio(34);
		montoEquiv = montoMN.divide(tcUS, 2, RoundingMode.HALF_UP);

		operacion.setOpeMontomn(montoMN);

		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("tc", tc);
		mapaParametros.put("operacion", operacion);

		String opcion = "";
		if (tipo.equals("TE")) {
			log.info("Actualizando la operacion transferencia: ");
			opcion = "actualizar";
		} else if (tipo.equals("VE")) {
			log.info("Actualizando la operacion venta: ");
			opcion = "actualizarV";
		}

		if (!opcion.equals("")) {
			// parametros para request
			mapaParametros.put("opcion", opcion);

			Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros,
					id);
			if (mapaRespuesta.containsKey("resp_msgerror")) {
				mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
				return;
			}

			String estado = (String) mapaRespuesta.get("estado");
			log.info("Estado asignado desde el BPM: " + estado);

			if (!estado.equals("1")) {
				mensaje = "Se produjo un error al generar el comprobante en otras monedas";
				return;
			}
		}

	}

	public void verBenef(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		venta = (Venta) SerializationUtils.clone(this.ventas.get(fila));

		String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
				+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
				+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
				+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
				+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
				+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			interVer = true;
			for (Map<String, Object> res : resultado) {

				cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
						(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"),
						(String) res.get("pla_intermediario"), (String) res.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1"));
			}
			label1 = "Cuenta:";
			bic = cuentaBen.getPlaNroCuenta();
		} else {
			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
					+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				interVer = false;
				for (Map<String, Object> res : resultado1) {

					cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
							(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"));
				}
				label1 = "BIC:";
				bic = cuentaBen.getPlaBic();
			} else {
				interVer = false;
			}
		}
	}

	public void verSwift(ActionEvent event) {
		String insCodigo = "";
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		venta = (Venta) SerializationUtils.clone(this.ventas.get(fila));

		String query = "SELECT ins_codigo " + " FROM soc_detallesope " + " WHERE ope_codigo = '" + nroOperacion + "'" + " AND det_codigo = '"
				+ venta.getDetCodigo() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {

				insCodigo = (String) res.get("ins_codigo");
				inst = insCodigo;
			}
			String ln = System.getProperty("line.separator");

			this.listaCampos = new ArrayList<Datosmen>();

			String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
					+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + insCodigo + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);

			for (Map<String, Object> res : resultado1) {
				String alto;
				String valor = "";
				String valor1 = (String) res.get("dam_valor");
				if (res.get("cam_codigo").equals(":32A")) {
					valor = valor1;
					valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
				}

				if (res.get("cam_codigo").equals(":33B")) {
					valor = valor1;
					valor1 = valor.substring(0, 3) + ln + valor.substring(3);
				}

				int i = StringUtils.countMatches(valor1, ln);
				i = (i + 1) * 16;
				alto = " height : " + i + "px;";

				listaCampos.add(new Datosmen((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto, (String) res
						.get("cam_nombre")));
			}

		}
	}

	@SuppressWarnings("unchecked")
	public void recuperarComisiones(ActionEvent event) {
		this.comision = new Opecomi();
		this.comisiones = new ArrayList<Opecomi>();

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "comisiones");
		mapaParametros.put("codOperacion", nroOperacion);

		log.info("Llamando al BPM: con una consulta");
		Map<String, Object> mapaResultado = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaResultado.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaResultado.get("resp_msgerror");
			return;
		}
		comisiones = (List<Opecomi>) mapaResultado.get("lista");
		comis = (BigDecimal) mapaResultado.get("total");
		comisU = (BigDecimal) mapaResultado.get("totalU");
		log.info("Devolviendo del BPM la lista de tamanio: " + (comisiones == null ? "NULL" : comisiones.size()));

	}

	public void recuperarFactura(ActionEvent event) {
		// this.fac = new SocFacturas();
		this.facturas = new ArrayList<SocFacturas>();

		String query = " select f.* " + " from soc_facturas f, soc_comprobante c " + " where f.cpb_codigo = c.cpb_codigo and c.ope_codigo = '"
				+ nroOperacion + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			facturas.add(new SocFacturas(new SocFacturasId((String) res.get("cpb_codigo"), (Integer) res.get("ren_codigo"), (Integer) res
					.get("fac_codigo")), (String) res.get("fac_nit"), (String) res.get("fac_nombre"), (BigDecimal) res.get("fac_montomn"),
					(BigDecimal) res.get("fac_montoiva"), (BigDecimal) res.get("fac_montoexcento"), (BigDecimal) res.get("fac_preciounitario"),
					(String) res.get("fac_concepto"), 'N'));
		}

	}

	public void recuperarComprobante(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		ComprobanteDet comprobante = (ComprobanteDet) SerializationUtils.clone(this.comprobanteList.get(fila));
		log.info("11111111Devolviendo recuperarDatosComprob: " + nroOperacion  + "  "  + comprobante.getCpbCodigo());
		recuperarDatosComprob(nroOperacion, comprobante.getCpbCodigo());
		log.info("Devolviendo recuperarDatosComprob: " + nroOperacion );		
	}
	public void recuperarDatosComprobList(String opeCodigo) {
		comprobanteList = new ArrayList<ComprobanteDet>();		
		setGlosa("");
		debeT = BigDecimal.valueOf(0.00);
		haberT = BigDecimal.valueOf(0.00);
		String query = " select c.cpb_codigo, c.cpb_glosa "
				+ " from soc_comprobante c "
				+ " where c.ope_codigo = '" + opeCodigo + "'";
		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			ComprobanteDet comprobante = new ComprobanteDet();
			comprobante.setCpbCodigo((String) res.get("cpb_codigo"));
			comprobante.setCpbGlosa((String) res.get("cpb_glosa"));
			comprobanteList.add(comprobante);
		}
	}
	
	public void recuperarDatosComprob(String opeCodigo, String cpbCodigo) {
		this.setComprobante(new ArrayList<ComprobanteDet>());		
		setGlosa("");
		debeT = BigDecimal.valueOf(0.00);
		haberT = BigDecimal.valueOf(0.00);
		String query = " select distinct r.*, c.cpb_glosa, s.cta_movimiento, s.cta_nommovimiento"
				+ " from soc_rengscomp r, soc_comprobante c, soc_cuentassol s" + " where r.cpb_codigo = c.cpb_codigo"
				+ " and r.ren_afectable = s.cta_afectable" + " and c.ope_codigo = '" + opeCodigo + "'"
				+ " and c.cpb_codigo = '" + cpbCodigo + "'"
				+ " and s.cta_codigo <> 6 and s.cta_codigo <> 7";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			ComprobanteDet comprobanteDet = new ComprobanteDet();

			comprobanteDet.setCpbCodigo((String) res.get("cpb_codigo"));
			comprobanteDet.setRenCodigo((Integer) res.get("ren_codigo"));
			comprobanteDet.setMovi((String) res.get("cta_movimiento") + "-" + (String) res.get("cta_nommovimiento"));
			comprobanteDet.setClaDebehaber(((String) res.get("cla_debehaber")));
			comprobanteDet.setRenTipocambio((BigDecimal) res.get("ren_tipocambio"));
			comprobanteDet.setRenMontomo((BigDecimal) res.get("ren_montomo"));
			comprobanteDet.setRenMontomn((BigDecimal) res.get("ren_montomn"));				
			comprobanteDet.setRenAfectable((String) res.get("ren_afectable"));
			comprobanteDet.setRenGlosa((String) res.get("ren_glosa"));
			comprobanteDet.setCodMoneda((Integer) res.get("moneda"));
			comprobanteDet.setDebe(BigDecimal.ZERO);			
			comprobanteDet.setHaber(BigDecimal.ZERO);
			if (res.get("cla_debehaber").equals("D")) {
				comprobanteDet.setDebe(comprobanteDet.getRenMontomn());
				glosa = (String) res.get("cpb_glosa");
				debeT = debeT.add((BigDecimal) res.get("ren_montomn"));
			
			} else {
				comprobanteDet.setHaber(comprobanteDet.getRenMontomn());				
				glosa = (String) res.get("cpb_glosa");
				haberT = haberT.add((BigDecimal) res.get("ren_montomn"));
				
			}
			comprobante.add(comprobanteDet);			
		}
	}

	public void recuperarDatos(ActionEvent event) {
		String ln = System.getProperty("line.separator");

		this.listaCampos = new ArrayList<Datosmen>();

		String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
				+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + detalleO.getInsCodigo() + "'";

		inst = detalleO.getInsCodigo();

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				//

				String alto;
				String valor = "";
				String valor1 = (String) res.get("dam_valor");
				if (res.get("cam_codigo").equals(":32A")) {
					valor = valor1;
					valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
				}

				if (res.get("cam_codigo").equals(":33B")) {
					valor = valor1;
					valor1 = valor.substring(0, 3) + ln + valor.substring(3);
				}

				int i = StringUtils.countMatches(valor1, ln);
				i = (i + 1) * 16;
				alto = " height : " + i + "px;";

				listaCampos.add(new Datosmen((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto, (String) res
						.get("cam_nombre")));

			}
		}

	}

	public void generarOperacionFechaValor(ActionEvent action) {
		log.info("ingresando a generarOperacionFechaValor: ");
		actualizarTC(tipoOperacionFecValor);
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Preautorizando la operacion: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("codOperacion", operacion.getOpeCodigo());
		// mapaParametros.put("opcion", "preautorizar");
		mapaParametros.put("opcion", "autorizar");
		mapaParametros.put("subtipo", subTipoOperacion);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		this.recuperarOperaciones();

		if (estado.equals("A")) {
			this.setMensaje("La operacion se autorizo correctamente.");
			Visit visit = Visit.getVisit();
			visit.removeParametro("SIOCWEB_CODOPERACION");			
		} else if (estado.equals("S"))
			this.setMensaje("El mensaje swift se envio correctamente. No se pudo autorizar la operacion debido a sobregiro en cuentas.");
		else
			this.setMensaje("Se produjo un error al autorizar la operacion.");

	}

	public void eventoAnularBtn(ActionEvent action) {
		log.info("Rechazando la operaciï¿½n: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "rechazar");
		mapaParametros.put("codOperacion", operacion.getOpeCodigo());

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		this.recuperarOperaciones();
	}

	public SocOperaciones getOperacion() {
		return operacion;
	}

	public void setOperacion(SocOperaciones operacion) {
		this.operacion = operacion;
	}

	public OperacionesS getOperacionS() {
		return operacionS;
	}

	public void setOperacionS(OperacionesS operacionS) {
		this.operacionS = operacionS;
	}

	public SocDetallesope getDetalleO() {
		return detalleO;
	}

	public void setDetalleO(SocDetallesope detalleO) {
		this.detalleO = detalleO;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public List<SocOperaciones> getOperaciones() {
		return operaciones;
	}

	public void setOperaciones(List<SocOperaciones> operaciones) {
		this.operaciones = operaciones;
	}

	public List<OperacionesS> getListaOper() {
		return listaOper;
	}

	public Venta getVenta() {
		return venta;
	}

	public void setVenta(Venta venta) {
		this.venta = venta;
	}

	public void setListaOper(List<OperacionesS> listaOper) {
		this.listaOper = listaOper;
	}

	public List<Venta> getVentas() {
		return ventas;
	}

	public void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

	public OrdenPago getOpa() {
		return opa;
	}

	public void setOpa(OrdenPago opa) {
		this.opa = opa;
	}

	public Opecomi getComision() {
		return comision;
	}

	public void setComision(Opecomi comision) {
		this.comision = comision;
	}

	public List<Opecomi> getComisiones() {
		return comisiones;
	}

	public void setComisiones(List<Opecomi> comisiones) {
		this.comisiones = comisiones;
	}

	public void setFac(SocFacturas fac) {
		this.fac = fac;
	}

	public SocFacturas getFac() {
		return fac;
	}

	public void setFacturas(List<SocFacturas> facturas) {
		this.facturas = facturas;
	}

	public List<SocFacturas> getFacturas() {
		return facturas;
	}

	public void setComprobante(List<ComprobanteDet> comprobante) {
		this.comprobante = comprobante;
	}

	public List<ComprobanteDet> getComprobante() {
		return comprobante;
	}

	public String getNroOperacion() {
		return nroOperacion;
	}

	public void setNroOperacion(String nroOperacion) {
		this.nroOperacion = nroOperacion;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public void setCuentaB(String cuentaB) {
		this.cuentaB = cuentaB;
	}

	public String getCuentaB() {
		return cuentaB;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setNombreF(String nombreF) {
		this.nombreF = nombreF;
	}

	public String getNombreF() {
		return nombreF;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getBanco() {
		return banco;
	}

	public BigDecimal getComis() {
		return comis;
	}

	public void setComis(BigDecimal comis) {
		this.comis = comis;
	}

	public void setComisU(BigDecimal comisU) {
		this.comisU = comisU;
	}

	public BigDecimal getComisU() {
		return comisU;
	}

	public void setMontoMN(BigDecimal montoMN) {
		this.montoMN = montoMN;
	}

	public BigDecimal getMontoMN() {
		return montoMN;
	}

	public void setMontoEquiv(BigDecimal montoEquiv) {
		this.montoEquiv = montoEquiv;
	}

	public BigDecimal getMontoEquiv() {
		return montoEquiv;
	}

	public void setDiff(BigDecimal diff) {
		this.diff = diff;
	}

	public BigDecimal getDiff() {
		return diff;
	}

	public void setDebeT(BigDecimal debeT) {
		this.debeT = debeT;
	}

	public BigDecimal getDebeT() {
		return debeT;
	}

	public void setHaberT(BigDecimal haberT) {
		this.haberT = haberT;
	}

	public BigDecimal getHaberT() {
		return haberT;
	}

	public List<Datosmen> getListaCampos() {
		return listaCampos;
	}

	public void setListaCampos(List<Datosmen> listaCampos) {
		this.listaCampos = listaCampos;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public void setMonC(String monC) {
		this.monC = monC;
	}

	public String getMonC() {
		return monC;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setCuentaBC(String cuentaBC) {
		this.cuentaBC = cuentaBC;
	}

	public String getCuentaBC() {
		return cuentaBC;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getNumero() {
		return numero;
	}

	public void setBenef(String benef) {
		this.benef = benef;
	}

	public String getBenef() {
		return benef;
	}

	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	public String getGlosa() {
		return glosa;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getMensaje() {
		return mensaje;
	}

	public Boolean getSwiftVer() {
		return swiftVer;
	}

	public void setSwiftVer(Boolean swiftVer) {
		this.swiftVer = swiftVer;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setNroVer(Boolean nroVer) {
		this.nroVer = nroVer;
	}

	public Boolean getNroVer() {
		return nroVer;
	}

	public void setNroCVer(Boolean nroCVer) {
		this.nroCVer = nroCVer;
	}

	public Boolean getNroCVer() {
		return nroCVer;
	}

	public void setExtVer(Boolean extVer) {
		this.extVer = extVer;
	}

	public Boolean getExtVer() {
		return extVer;
	}

	public void setLocalVer(Boolean localVer) {
		this.localVer = localVer;
	}

	public Boolean getLocalVer() {
		return localVer;
	}

	public void setOpVer(Boolean opVer) {
		this.opVer = opVer;
	}

	public Boolean getOpVer() {
		return opVer;
	}

	public void setSwVer(Boolean swVer) {
		this.swVer = swVer;
	}

	public Boolean getSwVer() {
		return swVer;
	}

	public void setEquiv(Boolean equiv) {
		this.equiv = equiv;
	}

	public Boolean getEquiv() {
		return equiv;
	}

	private static String getRaiz() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = request.getRequestURL().toString();
		String direccionRaiz = null;
		if (url.indexOf("/faces") > 0)
			direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
		else
			direccionRaiz = url;
		return direccionRaiz;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + inst + "&tipo=SW";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	public void setMostrarGenOperacion(Boolean mostrarGenOperacion) {
		this.mostrarGenOperacion = mostrarGenOperacion;
	}

	public Boolean getMostrarGenOperacion() {
		return mostrarGenOperacion;
	}

	public void setTipoOperacionFecValor(String tipoOperacionFecValor) {
		this.tipoOperacionFecValor = tipoOperacionFecValor;
	}

	public String getTipoOperacionFecValor() {
		return tipoOperacionFecValor;
	}

	public void setComprobanteList(List<ComprobanteDet> comprobanteList) {
		this.comprobanteList = comprobanteList;
	}

	public List<ComprobanteDet> getComprobanteList() {
		return comprobanteList;
	}

}
