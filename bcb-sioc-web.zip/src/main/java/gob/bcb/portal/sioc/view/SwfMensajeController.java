package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocValorescla;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.ArchivoSinple;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfDetmensaje;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.service.ReporteSwift;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SwfMensajeController extends BaseBeanController {
	private static Logger log = Logger.getLogger(SwfMensajeController.class);
	private SwfMensaje swfMensajeSelected = new SwfMensaje();
	private SwfDetmensaje swfDetmensajeSelected = new SwfDetmensaje();
	private List<SwfDetmensaje> swfDetmensajeLista = new ArrayList<SwfDetmensaje>();
	private List<SelectItem> cveestswiftItems;
	private Map<String, String> cveestswiftMap;
	private String urlReporte;
	private ReporteSwift reporteSwift = new ReporteSwift();
	public static String FILE_REPORT_SWIFT = "reposwiftsend.docx";
	private boolean canEdit = false;
	
	@PostConstruct
	public void init() {
		try {
			log.info("Iniciando el modulo de adm swift");
			recuperarVisit();
			getCveestswiftItems();
			
			Integer codigomensaje = (Integer) getVisit().getParametro("SIOCWEB_CODMENSWFT");
			if (codigomensaje != null){
				String sIOCWEB_ACTION = (String) getVisit().getParametro("SIOCWEB_ACTION");
				if (!StringUtils.isBlank(sIOCWEB_ACTION)){
					canEdit = sIOCWEB_ACTION.equals("SWFTEDT");
				}
				recuperarDatos(codigomensaje);
				// inicialiar reporte swift
				InputStream in = SwfMensajeController.class.getClassLoader().getResourceAsStream(FILE_REPORT_SWIFT);

				reporteSwift.initArchivoTemplate(in, FILE_REPORT_SWIFT);
				reporteSwift.inicializar();
			}
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		} finally{
			getVisit().removeParametro("SIOCWEB_CODMENSWFT");			
			getVisit().removeParametro("SIOCWEB_ACTION");
			
			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
			// la desesperada!! esto no debería estar aqui
			sesiones.remove("solicitudController");
			sesiones.remove("solicitudSearchPanel");			
		}

	}
	public void inicializar(ActionEvent event) {
		log.info("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOSIIIIIIIIIOOOOOOOOOOOOOOOOO");
		init() ;
	}
	private void recuperarDatos(Integer codigomensaje) {
		log.info("Recuperando mensaje " + codigomensaje);
		swfMensajeSelected = getSolicitudBean().getSwfMensajeBean().findByCodigo(codigomensaje);
		swfDetmensajeLista = getSolicitudBean().getSwfDetmensajeBean().findByCodMen(codigomensaje);
	}

	public void verReporte(ActionEvent event) {
		log.info("XXX: reporte " + swfMensajeSelected.getMenCodmen());
		try {
			SwfMensaje swfMensaje = getSolicitudBean().getSwfMensajeBean().findByCodigo(swfMensajeSelected.getMenCodmen());

			SwiftDatos swiftDatos = getSolicitudBean().getSwfMensajeBean().swiftDatosFromSwfMensaje(swfMensaje);

			ArchivoSinple archivoSinplePDF = generarReporte(swfMensaje.getMenPlano(), swiftDatos);

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("tipo", "reporteSwiftPdf");
			
			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			request.getSession().setAttribute("RPTSwift", swfMensajeSelected.getMenCodmen());
			request.getSession().setAttribute("nombreReporte", "reporteSwiftPdf");			
			request.getSession().setAttribute("archivoSinple", archivoSinplePDF);
			request.getSession().setAttribute("parametros", parametros);
			
			log.info("Ir a ventana reporte swift " + swfMensajeSelected.getMenCodmen());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void preAutorizarSwift() {
		log.info("preAutorizarSwift " + swfMensajeSelected.getMenCodmen());
		try {
			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setSwfMensaje(swfMensajeSelected);
			getSolicitudBean().procesar(solicitudTO, "PREAUTSWFMEN");
			
			recuperarDatos(swfMensajeSelected.getMenCodmen());
			
			log.info("autorizar Mensaje swift hecho: " + swfMensajeSelected.getMenCodmen() + " " + swfMensajeSelected.getMenNrocorr());
			addMessageInfo("Aviso",
					"Mensaje PRE autorizado para " + swfMensajeSelected.getMenCodmen() + " con numero correlativo " + swfMensajeSelected.getMenNrocorr());			
		} catch (Exception e) {
			log.error("error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void autorizarSwift() {
		log.info("autorizarSwift " + swfMensajeSelected.getMenCodmen());
		try {
			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setSwfMensaje(swfMensajeSelected);
			getSolicitudBean().procesar(solicitudTO, "AUTSWIFT");
			
			recuperarDatos(swfMensajeSelected.getMenCodmen());			
			
			log.info("autorizar Mensaje swift hecho: " + swfMensajeSelected.getMenCodmen() + " " + swfMensajeSelected.getMenNrocorr());
			addMessageInfo("Aviso",
					"Mensaje autorizado para " + swfMensajeSelected.getMenCodmen() + " con numero correlativo " + swfMensajeSelected.getMenNrocorr());			
		} catch (Exception e) {
			log.error("error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void rechazarSwift() {
		log.info("rechazarSwift " + swfMensajeSelected.getMenCodmen());
		try {
			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setSwfMensaje(swfMensajeSelected);
			getSolicitudBean().procesar(solicitudTO, "RECHSWIFT");
			
			log.info("rechazado Mensaje swift hecho: " + swfMensajeSelected.getMenCodmen() + " " + swfMensajeSelected.getMenNrocorr());
			addMessageInfo("Aviso",
					"Mensaje anulado para " + swfMensajeSelected.getMenCodmen() + " con numero correlativo " + swfMensajeSelected.getMenNrocorr());
			retornarDeSwift();			
		} catch (Exception e) {
			log.error("error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}
	
	public void retornarDeSwift() {
		if (canEdit){
			irAPagina("/view/Solicitud/solicitud_view.xhtml");			
		} else {
			irAPagina("/view/Solicitud/solicitud_viewha.xhtml");
		}
		getVisit().setParametro("SIOCWEB_SOCCODIGO", swfMensajeSelected.getMenCodoperacion());		
	}
	
	private ArchivoSinple generarReporte(String swiftPlano, SwiftDatos mensajesDatos) {

		try {
			mensajesDatos.setAuditusr(getVisit().getUsuarioSession().getLogin());
			mensajesDatos.setAuditwst(getVisit().getAddress());
			SocParametros param = getSolicitudBean().getSocParametrosDao().getByCodigo("pathswift");
			reporteSwift.setSocBancosDao(getSolicitudBean().getSocBancosDao());
			reporteSwift.populateReport(swiftPlano, mensajesDatos);

			reporteSwift.render();
			String nameFile = "reportSwf_" + mensajesDatos.getSwfMensaje().getMenCodmt() + "_" + mensajesDatos.getSwfMensaje().getMenCodmen()
					+ ".pdf";
			ArchivoSinple archivoSinplePDF = reporteSwift.convertToPDF(reporteSwift.getArchivoSinple(), nameFile);

			archivoSinplePDF.setDirectory(param.getParValor());
			archivoSinplePDF.setName(archivoSinplePDF.getHash() + "." + ArchivoUtil.obtenerExtension(archivoSinplePDF.getNameOriginal()));
			archivoSinplePDF.putPathFile();
			log.info("reporte PDF generado " + archivoSinplePDF.getNameOriginal());
			return archivoSinplePDF;
		} catch (Exception e) {
			log.error("Error al renderizar reporte swift!!!!!! " + e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		} catch (Throwable e) {
			log.error("Throwable: Error al renderizar reporte swift!!!!!! " + e.getMessage(), e);
			throw new SwiftAdminException(e.getMessage(), e);
		}

	}

	public SwfMensaje getSwfMensajeSelected() {
		return swfMensajeSelected;
	}

	public void setSwfMensajeSelected(SwfMensaje swfMensajeSelected) {
		this.swfMensajeSelected = swfMensajeSelected;
	}

	public SwfDetmensaje getSwfDetmensajeSelected() {
		return swfDetmensajeSelected;
	}

	public void setSwfDetmensajeSelected(SwfDetmensaje swfDetmensajeSelected) {
		this.swfDetmensajeSelected = swfDetmensajeSelected;
	}

	public List<SwfDetmensaje> getSwfDetmensajeLista() {
		return swfDetmensajeLista;
	}

	public void setSwfDetmensajeLista(List<SwfDetmensaje> swfDetmensajeLista) {
		this.swfDetmensajeLista = swfDetmensajeLista;
	}

	public List<SelectItem> getCveestswiftItems() {
		if (cveestswiftItems == null) {
			cveestswiftItems = new ArrayList<SelectItem>();
			cveestswiftMap = new HashMap<String, String>();
			List<SocValorescla> ClavesList = getSolicitudBean().getSocValoresclaDao().getValoresByClave(Constants.CLAVE_ESTSWIFT);
			for (SocValorescla claves : ClavesList) {
				cveestswiftItems.add(new SelectItem(claves.getId().getValCodigo().trim(), claves.getValNombre().trim()));
				cveestswiftMap.put(claves.getId().getValCodigo().trim(), claves.getValNombre().trim());
			}
		}
		return cveestswiftItems;
	}

	public void setCveestswiftItems(List<SelectItem> cveestswiftItems) {
		this.cveestswiftItems = cveestswiftItems;
	}

	public Map<String, String> getCveestswiftMap() {
		return cveestswiftMap;
	}

	public void setCveestswiftMap(Map<String, String> cveestswiftMap) {
		this.cveestswiftMap = cveestswiftMap;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?nombreReporte=reporteSwiftPdf";
		return urlReporte;
	}

	public boolean isCanEdit() {
		return canEdit;
	}

	public void setCanEdit(boolean canEdit) {
		this.canEdit = canEdit;
	}

}
