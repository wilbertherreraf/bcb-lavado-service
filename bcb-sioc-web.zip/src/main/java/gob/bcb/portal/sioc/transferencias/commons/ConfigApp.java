package gob.bcb.portal.sioc.transferencias.commons;

public class ConfigApp {

}
