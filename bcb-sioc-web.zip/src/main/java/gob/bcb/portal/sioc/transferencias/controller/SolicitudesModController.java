package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBenefslocal;
import gob.bcb.bpm.pruebaCU.SocBenefslocalId;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.servicioSioc.common.MensSwiftUtiles;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

public class SolicitudesModController extends BaseBeanController {

	private SocSolicitudes solicitud;
	private SolicitudesS solicitudSS;
	private SocDetallessol detalle;
	private SocBenefslocal benef;
	private List<SolicitudesS> solicitudes;
	private List<SocSolicitudes> listaSoli;
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> monedasL = new ArrayList<SelectItem>();
	private List<SelectItem> monedasT = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private List<SelectItem> benefs = new ArrayList<SelectItem>();
	private List<SelectItem> benefsL = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasBL = new ArrayList<SelectItem>();
	private List<SelectItem> conceptos = new ArrayList<SelectItem>();
	private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
	private String idSoli = "-1";
	private String codigo = "";
	private String tipo = "";
	private String idBenef = "-1";
	private String idCuenta = "-1";
	private String idCuentaC = "-1";
	private String idMoneda = "-1";
	private Integer idCuentaB = -1;
	private String idDescuento = "NO";
	private String prioridad = "S";
	private String idConcepto = "-1";
	private String concepto = "";
	private String conc = "-1";
	private String factura = "";
	private String nit = "";
	private String nroCuenta = "";
	private String cuenta = "";
	private String bic = "";
	private String bic1 = "";
	private String banco = "";
	private String plaza = "";
	private String informa = "";
	private String info10 = "";
	private String adicional = "";
	private String mensaje = "";
	private String label1 = "";
	private String label2 = "";
	private BigDecimal montoOrd = BigDecimal.valueOf(0);
	private BigDecimal montoME = BigDecimal.valueOf(0);
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean cuentaVer = true;
	private Boolean botonHab = true;
	private Boolean interVer = false;
	private Boolean fijoVer = false;
	private Boolean facVer = false;
	private Boolean fijo = true;
	private Boolean fijoT = false;
	private Boolean regalIDH = false;

	private String urlReporte;

	private Logger log = Logger.getLogger(SolicitudesModController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	@SuppressWarnings("unchecked")
	public SolicitudesModController() {
		
recuperarVisit();
		String usuario = 
getVisit().getUsuarioSession().getLogin();
		
idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		this.recuperarSolicitudes();

		monedas.add(new SelectItem("USD", "DOLARES ESTADOUNIDENSES"));
		monedas.add(new SelectItem("EUR", "EUROS"));
		monedas.add(new SelectItem("SEK", "CORONAS SUECAS"));
		monedas.add(new SelectItem("CHF", "FRANCOS SUIZOS"));// monedas.add(new
																// SelectItem("GBP",
																// "LIBRAS ESTERLINAS"));

		monedasL.add(new SelectItem("USD", "DOLARES ESTADOUNIDENSES"));
		monedasL.add(new SelectItem("BS", "BOLIVIANOS"));

		conceptos.add(new SelectItem("INV", "PAGO FACTURA"));
		conceptos.add(new SelectItem("OTR", "OTROS"));
	}

	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SolicitudesS>();
		this.listaSoli = new ArrayList<SocSolicitudes>();

		String query = "";

		if (!idSoli.equals("900")) {
			query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
					+ " and s.cla_estado = 'B'" + " and trim(s.sol_codigo) = '" + idSoli + "'";
		} else {
			idSoli = "-1";
			query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
					+ " and s.cla_estado = 'B'" + " and ss.cla_entidad = 'SP'";
		}

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				solicitudSS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'B', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");
				if (solicitudSS.getClaTipo().equals("TE")) {
					solicitudSS.setPanel1(true);
					solicitudSS.setPanel2(false);
					solicitudSS.setPanel3(false);
					solicitudSS.setTipo("TRANSFERENCIA AL EXTERIOR");
				} else {
					if (solicitudSS.getClaTipo().startsWith("TC")) {
						solicitudSS.setPanel1(false);
						solicitudSS.setPanel2(true);
						solicitudSS.setPanel3(false);
						solicitudSS.setTipo("TRANSFERENCIA CUENTA A CUENTA");
					} else {
						solicitudSS.setPanel1(false);
						solicitudSS.setPanel2(false);
						solicitudSS.setPanel3(true);
						solicitudSS.setTipo("VENTA DE DIVISAS");
					}
				}
				solicitudes.add(solicitudSS);

				solicitud = new SocSolicitudes((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_tipo"),
						(Integer) res.get("soc_cuentad"), (String) res.get("soc_nrocuentad"), (String) res.get("moneda"), 'B',
						(Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (Integer) res.get("soc_cuentac"),
						(String) res.get("soc_nrocuentac"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"),
						(BigDecimal) res.get("soc_montomn"), (String) res.get("soc_nropago"), (String) res.get("monedat"));
				listaSoli.add(solicitud);
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudSS = this.solicitudes.get(fila);
		this.solicitud = this.listaSoli.get(fila);
		String query = " select d.* " + " from soc_detallessol d " + " where d.soc_codigo = '" + solicitud.getSocCodigo() + "'"
				+ " and d.det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {

				detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), (String) res.get("moneda"),
						(Integer) res.get("det_ctabenef"), (String) res.get("det_concepto"), (String) res.get("det_info"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("monedat"), (String) res.get("det_facturas"));
			}

			log.info("sol: " + solicitudSS.getSolicitante());
			setIdSoli(solicitud.getSolCodigo());
			setIdCuenta(solicitud.getSocCuentad().toString());

			if (solicitud.getClaTipo().equals("TE")) {
				if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
					idDescuento = "SI";
					setMontoOrd(solicitud.getSocMontoord());
				} else {
					idDescuento = "NO";
				}
				setIdBenef(detalle.getBenCodigo());
				setIdCuentaB(detalle.getDetCtabenef());
				query = "SELECT cc.cta_nrocuenta, bb.bco_nombre, pp.pla_nombre, pp.pla_bic, "
						+ " pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, pp1.pla_nombre as pla1"
						+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
						+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
						+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
						+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + idCuentaB + "'";

				List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
				if (resultado2.size() > 0) {
					interVer = true;
					for (Map<String, Object> res : resultado2) {

						banco = (String) res.get("bco_nombre") + (String) res.get("pla_nombre");
						bic = (String) res.get("pla_nrocuenta");
						if (bic == null)
							bic = (String) res.get("pla_bic");
						bic1 = (String) res.get("pla_intermediario");
						plaza = (String) res.get("bco1") + (String) res.get("pla1");
					}
				} else {
					query = "SELECT cc.cta_nrocuenta, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic, pp.pla_nrocuenta "
							+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
							+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
							+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + idCuentaB + "'";

					List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
					if (resultado3.size() > 0) {
						interVer = false;
						for (Map<String, Object> res : resultado3) {

							banco = (String) res.get("bco_nombre") + (String) res.get("pla_nombre");
							bic = (String) res.get("pla_bic");
							if (bic == null)
								bic = (String) res.get("pla_nrocuenta");
							bic1 = "";
							plaza = "";
						}
					}
				}
				concepto = detalle.getDetConcepto();
				if (concepto.startsWith("/INV/")) {
					conc = "INV";
					idConcepto = "INV";
					concepto = concepto.substring(5);
				} else {
					conc = "OTR";
					idConcepto = "OTR";
				}
				informa = detalle.getDetInfo();
			} else {
				log.info("Lista Nula");
			}
		}
		if (solicitud.getClaTipo().startsWith("TC")) // transferencia local
		{
			idMoneda = solicitud.getMoneda();
			setIdBenef(detalle.getBenCodigo());
			setIdCuentaB(detalle.getDetCtabenef());
			concepto = detalle.getDetConcepto();

			query = " select b.ben_nombre, b.ben_nit, b.ben_factura, c.cta_nrocuenta, c.moneda, c.cta_nrocuenta1, c.moneda1, s.cta_nommovimiento "
					+ " from soc_benefsloc b, soc_cuentasloc c, soc_cuentassol s " + " where b.ben_codigo = '" + idBenef + "'"
					+ " and c.cta_codigo = " + idCuentaB + " " + " and c.cta_ctacodigo = s.cta_codigo";

			List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
			if (resultado2.size() > 0) {
				for (Map<String, Object> res : resultado2) {

					setBenef(new SocBenefslocal(new SocBenefslocalId(detalle.getId().getSocCodigo(), detalle.getId().getDetCodigo()),
							(String) res.get("cta_nommovimiento"), (String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"),
							(String) res.get("ben_factura"), (String) res.get("ben_nit")));
					banco = (String) res.get("cta_nommovimiento");
				}
			} else {
				log.info("Lista Nula");
			}

			if (solicitud.getSocCuentac() != null) {
				setPrioridad("S");
				montoVer = false;
				setCuentaVer(true);
			} else {
				setPrioridad("B");
				montoVer = true;
				setCuentaVer(false);
			}

			// CCUH SIOC V.2
			// R-04 Incluir opciones separadas para IDH, Regalías
			// Se crearon nuevos tipos de operación para registrar solicitudes
			// 02-07-2013
			if (solicitud.getClaTipo().equals("TCRG") || solicitud.getClaTipo().equals("TCID")) {
				regalIDH = true;
			} else {
				regalIDH = false;
			}
		}

	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		if (!idSoli.equals("-1")) {
			cuentasD.clear();

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") != 69) {
						if (res.get("cta_numero") != null) {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD-" + res.get("cta_numero")));
						} else {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD"));
						}
					}
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public List<SelectItem> getBenefs() {
		log.info("enter getbenefs");
		if (idSoli != "-1") {
			benefs.clear();

			String query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '" + idSoli + "' " + "ORDER BY bb.ben_nombre ";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado != null) {
				for (Map<String, Object> res : resultado) {

					benefs.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			benefs.clear();
		}

		return benefs;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getCuentasB() {
		cuentasB.clear();
		String moneda = "";

		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";

		if (idBenef != "-1") {
			String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
					+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
					+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
					+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() > 0) {
				for (Map<String, Object> res : resultado) {
					interVer = true;

					if ((Integer) res.get("moneda") == 34) {
						moneda = "USD";
					} else if ((Integer) res.get("moneda") == 53) {
						moneda = "EUR";
					} else if ((Integer) res.get("moneda") == 31) {
						moneda = "CHF";
					} else if ((Integer) res.get("moneda") == 30) {
						moneda = "SEK";
					} else {
						moneda = "";
					}
					cuentasB.add(new SelectItem(res.get("cta_codigo"), res.get("cta_nrocuenta") + " - " + moneda));
					listaCuentasB.add(new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"),
							(String) res.get("cta_info"), (Integer) res.get("moneda"), (String) res.get("bco_nombre"),
							(String) res.get("pla_nombre"), (String) res.get("pla_bic"), (String) res.get("pla_intermediario"), (String) res
									.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1")));
				}
			} else {
				query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
						+ " pp.pla_nombre, pp.pla_bic, pp.pla_nrocuenta " + " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
						+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
						+ " AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					interVer = false;
					for (Map<String, Object> res : resultado1) {

						if ((Integer) res.get("moneda") == 34) {
							moneda = "USD";
						} else if ((Integer) res.get("moneda") == 53) {
							moneda = "EUR";
						} else if ((Integer) res.get("moneda") == 31) {
							moneda = "CHF";
						} else if ((Integer) res.get("moneda") == 30) {
							moneda = "SEK";
						} else {
							moneda = "";
						}
						cuentasB.add(new SelectItem(res.get("cta_codigo"), res.get("cta_nrocuenta") + " - " + moneda));
						listaCuentasB.add(new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res
								.get("cta_info"), (Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"),
								(String) res.get("pla_bic"), (String) res.get("pla_nrocuenta")));
					}
				} else {
					interVer = false;
					log.info("Lista Nula");
				}
			}
		}

		return cuentasB;
	}

	public List<SelectItem> getBenefsL() {
		benefsL.clear();
		int mon = 0;

		if (!idMoneda.equals("-1")) {
			String query = "";
			if (idMoneda.equals("USD"))
				mon = 34;
			else
				mon = 69;

			query = " select ben_codigo, ben_nombre, ben_nit, ben_factura " + " from soc_benefsloc "
					+ " where cla_vigente = 1 and trim(sol_codigo) = '" + idSoli + "'"
					+ " and ben_codigo in (select ben_codigo from soc_cuentasloc where moneda = " + mon + ")";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado != null) {
				for (Map<String, Object> res : resultado) {

					benefsL.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
				}
			} else {
				log.info("Lista Nula");
			}

		} else {
			benefsL.clear();
		}

		return benefsL;
	}

	public List<SelectItem> getCuentasBL() {
		cuentasBL.clear();

		String moneda = "";
		String moneda1 = "";

		if (idBenef != "-1") {
			String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_ctacodigo, cc.moneda, ss.cta_nommovimiento, "
					+ " cc.cta_nrocuenta1, moneda1, ben_factura, ben_nit " + " FROM soc_cuentasloc cc, soc_cuentassol ss, soc_benefsloc bb "
					+ " WHERE cc.cta_ctacodigo = ss.cta_codigo " + " AND cc.ben_codigo = bb.ben_codigo "
					+ " AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() > 0) {
				for (Map<String, Object> res : resultado) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "USD";
					else
						moneda = "BS";

					cuentasBL.add(new SelectItem(res.get("cta_codigo"), res.get("cta_nrocuenta") + "-" + moneda));
					listaCuentasB.add(new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), res.get("cta_nrocuenta1")
							+ "-" + moneda1, (Integer) res.get("moneda"), (String) res.get("cta_nommovimiento"), (String) res.get("ben_factura"),
							(String) res.get("ben_nit")));
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			banco = "";
		}

		return cuentasBL;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getCuentasC() {
		String idC;
		String moneda = "";

		if (idCuenta != "-1") {
			cuentasC.clear();

			if ("SI".equals(idDescuento)) {
				idC = Integer.toString(0);
			} else {
				idC = idCuenta;
			}

			log.info("idc:" + idC);

			String query = " SELECT sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " FROM soc_solcuentas sc, soc_cuentassol cc "
					+ " WHERE sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					if (res.get("cta_numero") != null) {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda
								+ "-" + res.get("cta_numero")));
					} else {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda));
					}
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			cuentasC.clear();
		}

		return cuentasC;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		idCuentaB = sel;
		log.info("Valor seleccionado: " + sel);

		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";

		if (idCuentaB != -1) {
			for (CuentasBen cuentaB : listaCuentasB) {
				if (cuentaB.getCtaCodigo().compareTo(idCuentaB) == 0) {
					if (!interVer) {
						bic = cuentaB.getPlaBic();
						if (bic != null)
							label2 = "BIC:";
						else {
							bic = cuentaB.getPlaNroCuenta();
							label2 = "Cuenta:";
						}
					} else {
						bic = cuentaB.getPlaNroCuenta();
						if (bic != null)
							label2 = "Cuenta:";
						else {
							bic = cuentaB.getPlaBic();
							label2 = "BIC:";
						}
					}
					cuenta = cuentaB.getCtaNroCuenta();
					banco = cuentaB.getBcoNombre() + " - " + cuentaB.getPlaNombre();
					bic1 = cuentaB.getPlaIntermediario();
					plaza = cuentaB.getBcoNombreI() + " - " + cuentaB.getPlaNombreI();
					informa = cuentaB.getCtaInfo();
				}
			}
		}
	}

	public void seleccion1Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idConcepto = sel;
		log.info("Valor seleccionado: " + sel);

		if ("INV".equals(sel)) {
			label1 = "Ingresar sólo el número de la factura";
		} else {
			label1 = "";
		}
	}

	public void seleccion2Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idDescuento = sel;
		log.info("Valor seleccionado: " + idDescuento);

		if ("SI".equals(idDescuento)) {
			solicitud.setSocCuentac(Integer.parseInt(idCuenta));

			// cargando los parametros
			Date fecha = new Date();
			int monUS = 34;

			int mon = Servicios.getMoneda(solicitud.getMoneda());

			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("fecha", fecha);
			mapaParametros.put("moneda", mon);
			mapaParametros.put("consulta", "tc");

			String iid = new Long(new Date().getTime()).toString();
			BigDecimal tc = BigDecimal.valueOf(0.00);
			BigDecimal tc1 = BigDecimal.valueOf(0.00);

			// Metodo estatico que se encarga de manejar las consultas al
			// servicio
			log.info("Llamando al servicio de coin: factor_conv_mn");
			Map<String, Object> mapaResultado;
			try {
				mapaResultado = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros, iid);
				tc = (BigDecimal) mapaResultado.get("tc");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			BigDecimal monto = BigDecimal.valueOf(0);

			if (mon == monUS) {
				monto = solicitud.getSocMontome();
				tc1 = tc;
			} else {
				Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
				mapaParametros1.put("fecha", fecha);
				mapaParametros1.put("moneda", monUS);
				mapaParametros.put("consulta", "tc");

				String iid1 = new Long(new Date().getTime()).toString();

				// Metodo estatico que se encarga de manejar las consultas al
				// servicio
				log.info("Llamando al servicio de coin: factor_conv_mn");
				Map<String, Object> mapaResultado1;
				try {
					mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros1, iid1);
					tc1 = (BigDecimal) mapaResultado1.get("tc");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				monto = solicitud.getSocMontome().multiply(tc).divide(tc1, 2, RoundingMode.HALF_UP);
			}

			BigDecimal swift = BigDecimal.valueOf(190).divide(tc1, 11, RoundingMode.HALF_UP);
			log.info("sw: " + swift);
			BigDecimal util = BigDecimal.valueOf(37).divide(tc1, 11, RoundingMode.HALF_UP);
			log.info("ut: " + util);
			BigDecimal comi = BigDecimal.valueOf(0.001);
			montoOrd = (monto.subtract(swift)).subtract(util).divide(comi.add(BigDecimal.valueOf(1)), 2, RoundingMode.HALF_UP);
			if (mon != monUS)
				montoOrd = montoOrd.multiply(tc1).divide(tc, 2, RoundingMode.HALF_UP);
			log.info("Monto: " + montoOrd);
			solicitud.setSocMontoord(solicitud.getSocMontome());
			cuentaHab = true;
			montoVer = true;
		} else {
			cuentaHab = false;
			montoVer = false;
			solicitud.setSocMontoord(BigDecimal.valueOf(0));
		}
	}

	public void seleccion3Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		log.info("Valor seleccionado: " + sel);

		if (sel.equals("USD")) {
			solicitud.setMoneda(sel);
			fijoVer = false;
		} else {
			monedasT.add(new SelectItem("USD", "DOLARES AMERICANOS"));
			monedasT.add(new SelectItem("EUR", "EUROS"));
			fijoVer = true;
		}
	}

	public void seleccion4Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idDescuento = sel;
		log.info("Valor seleccionado: " + idDescuento);

		if ("S".equals(idDescuento)) // facturar a solicitante
		{
			cuentaHab = true;
			setFacVer(false);

		} else // facturar a beneficiario
		{
			setFacVer(true);
			cuentaHab = false;
		}

	}

	public String cortarConcepto() {
		String concCortado = "";
		Boolean cortado = false;
		int i = 34;
		int j;
		String texto = "";
		String ln = System.getProperty("line.separator");

		if (concepto.length() > 35) {
			texto = concepto;
			do {
				if (concepto.charAt(i) == ' ' || concepto.charAt(i) == '.' || concepto.charAt(i) == ',') {
					texto = concepto.substring(0, i) + ln + concepto.substring(i + 1);
					cortado = true;
				}
				i--;
			} while (!cortado);

			concCortado = texto;
			log.info("Cortado: " + concCortado);
			j = texto.indexOf(ln);
			texto = concCortado.substring(j + ln.length());
			log.info("texto: " + texto);
			if (texto.length() > 35) {
				cortado = false;
				i = 34;
				do {
					if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
						texto = texto.substring(0, i) + ln + texto.substring(i + 1);
						cortado = true;
					}
					i--;
				} while (!cortado);
				concCortado = concCortado.substring(0, j + ln.length()) + texto;
				log.info("Cortado: " + concCortado);
				j = texto.indexOf(ln);
				texto = texto.substring(j + ln.length());
				log.info("texto: " + texto);
				if (texto.length() > 35) {
					cortado = false;
					i = 34;
					do {
						if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
							texto = texto.substring(0, i) + ln + texto.substring(i + 1);
							cortado = true;
						}
						i--;
					} while (!cortado);
					i = concCortado.indexOf(ln);
					j = concCortado.indexOf(ln, i + 1);
					concCortado = concCortado.substring(0, j + ln.length()) + texto;
					log.info("Cortado: " + concCortado);
					j = texto.indexOf(ln);
					texto = texto.substring(j + ln.length());
					log.info("texto: " + texto);
					if (texto.length() > 35) {
						concCortado = "-1";
					}
				}
			}
		} else {
			concCortado = concepto;
		}

		return concCortado;
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitudTest) {
		this.solicitud = solicitudTest;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudSS = solicitudS;
	}

	public SolicitudesS getSolicitudS() {
		return solicitudSS;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public void setBenef(SocBenefslocal benef) {
		this.benef = benef;
	}

	public SocBenefslocal getBenef() {
		return benef;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public List<SelectItem> getMonedasL() {
		return monedasL;
	}

	public void setMonedasL(List<SelectItem> monedasL) {
		this.monedasL = monedasL;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setMonedasT(List<SelectItem> monedasT) {
		this.monedasT = monedasT;
	}

	public List<SelectItem> getMonedasT() {
		return monedasT;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	/*
	 * public List<SelectItem> getBenefs() { return benefs; }
	 */

	public void setBenefs(List<SelectItem> benefs) {
		this.benefs = benefs;
	}

	public void setBenefsL(List<SelectItem> benefsL) {
		this.benefsL = benefsL;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasB(List<SelectItem> cuentasB) {
		this.cuentasB = cuentasB;
	}

	public void setCuentasBL(List<SelectItem> cuentasBL) {
		this.cuentasBL = cuentasBL;
	}

	public List<CuentasBen> getListaCuentasB() {
		return listaCuentasB;
	}

	public void setListaCuentasB(List<CuentasBen> listaCuentasB) {
		this.listaCuentasB = listaCuentasB;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public void setIdCuentaB(Integer idCuentaB) {
		this.idCuentaB = idCuentaB;
	}

	public Integer getIdCuentaB() {
		return idCuentaB;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public void setIdCuentaC(String idCuentaC) {
		this.idCuentaC = idCuentaC;
	}

	public String getIdCuentaC() {
		return idCuentaC;
	}

	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}

	public String getIdMoneda() {
		return idMoneda;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getBic1() {
		return bic1;
	}

	public void setBic1(String bic1) {
		this.bic1 = bic1;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getPlaza() {
		return plaza;
	}

	public void setPlaza(String plaza) {
		this.plaza = plaza;
	}

	public void setFactura(String factura) {
		this.factura = factura;
	}

	public String getFactura() {
		return factura;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public List<SelectItem> getConceptos() {
		return conceptos;
	}

	public void setConceptos(List<SelectItem> conceptos) {
		this.conceptos = conceptos;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConc() {
		return conc;
	}

	public void setConc(String conc) {
		this.conc = conc;
	}

	public String getInforma() {
		return informa;
	}

	public void setInforma(String informa) {
		this.informa = informa;
	}

	public String getAdicional() {
		return adicional;
	}

	public void setAdicional(String adicional) {
		this.adicional = adicional;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getLabel2() {
		return label2;
	}

	public void setLabel2(String label2) {
		this.label2 = label2;
	}

	public BigDecimal getMontoOrd() {
		return montoOrd;
	}

	public void setMontoOrd(BigDecimal montoOrd) {
		this.montoOrd = montoOrd;
	}

	public void setMontoME(BigDecimal montoME) {
		this.montoME = montoME;
	}

	public BigDecimal getMontoME() {
		return montoME;
	}

	public String getIdDescuento() {
		return idDescuento;
	}

	public void setIdDescuento(String idDescuento) {
		this.idDescuento = idDescuento;
	}

	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}

	public String getPrioridad() {
		return prioridad;
	}

	public String getIdConcepto() {
		return idConcepto;
	}

	public void setIdConcepto(String idConcepto) {
		this.idConcepto = idConcepto;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public void setCuentaVer(Boolean cuentaVer) {
		this.cuentaVer = cuentaVer;
	}

	public Boolean getCuentaVer() {
		return cuentaVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public Boolean getFijoVer() {
		return fijoVer;
	}

	public void setFijoVer(Boolean fijoVer) {
		this.fijoVer = fijoVer;
	}

	public void setFacVer(Boolean facVer) {
		this.facVer = facVer;
	}

	public Boolean getFacVer() {
		return facVer;
	}

	public Boolean getFijo() {
		return fijo;
	}

	public void setFijo(Boolean fijo) {
		this.fijo = fijo;
	}

	public Boolean getFijoT() {
		return fijoT;
	}

	public void setFijoT(Boolean fijoT) {
		this.fijoT = fijoT;
	}

	public Boolean getRegalIDH() {
		return regalIDH;
	}

	public void setRegalIDH(Boolean regalIDH) {
		this.regalIDH = regalIDH;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getTipo() {
		return tipo;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + codigo + "&tipo=" + tipo;
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		codigo = solicitud.getSocCodigo();
		tipo = solicitud.getClaTipo();
		if (idConcepto != "-1") {
			if (MensSwiftUtiles.validarConcepto(concepto) > 0) {
				if ("INV".equals(idConcepto)) {
					concepto = "/INV/" + concepto;
				}

				concepto = this.cortarConcepto();
				if (concepto != "-1") {
					solicitud.setSocCuentad(Integer.parseInt(idCuenta));
					nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentad());
					solicitud.setSocNrocuentad(nroCuenta);
					nroCuenta = "";

					if ("NO".equals(idDescuento)) {
						nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentac());
						solicitud.setSocNrocuentac(nroCuenta);
						solicitud.setSocMontoord(BigDecimal.valueOf(0));
					} else {
						solicitud.setSocMontome(montoOrd);
					}

					detalle.setBenCodigo(idBenef);
					detalle.setDetCtabenef(idCuentaB);
					detalle.setDetMonto(solicitud.getSocMontome());
					detalle.setDetMontoord(solicitud.getSocMontoord());
					detalle.setMoneda(solicitud.getMoneda());
					detalle.setMonedaT(solicitud.getMonedaT());
					detalle.setDetConcepto(concepto.toUpperCase());

					String info1 = "";
					if (!StringUtils.isBlank(informa))
						info1 = informa;
					if (!StringUtils.isBlank(info1) && !StringUtils.isBlank(adicional))
						info1 = info1 + " ";
					if (!StringUtils.isBlank(adicional))
						info1 = info1 + adicional;
					log.info("info1:" + info1);

					String ln = System.getProperty("line.separator");
					int j = info1.lastIndexOf(ln);
					String info2 = "";
					if (j > 0)
						info2 = info1.substring(j + ln.length());
					else
						info2 = info1;
					if (info2.length() > 35) {
						Boolean cortado = false;
						String texto = info2;
						int i = 34;
						do {
							if (info2.charAt(i) == ' ' || info2.charAt(i) == '.' || info2.charAt(i) == ',') {
								texto = info2.substring(0, i) + ln + "//" + info2.substring(i + 1);
								cortado = true;
							}
							i--;
						} while (!cortado);
						if (j > 0)
							info1 = info1.substring(0, j + ln.length()) + texto;
						else
							info1 = texto;
					}
					log.info("informa:" + info1);
					detalle.setDetInfo(info1);

					Date date = new Date();
					long time = date.getTime();
					log.info("Creando el objeto Request para enviar al BPM");

					// parametros para request
					String id = new Long(time).toString();

					// mapa de parametros a enviar a BPM
					Map<String, Object> mapaParametros = new HashMap<String, Object>();
					mapaParametros.put("opcion", "modificar");
					mapaParametros.put("solicitud", solicitud);
					mapaParametros.put("detalle", detalle);

					Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
					if (mapaRespuesta.containsKey("resp_msgerror")) {
						mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
						return;
					}

					String nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
					log.info("Numero de Solicitud: " + nroSolicitud);

					if (!nroSolicitud.equals("-1")) {
						this.mensaje = "La solicitud " + solicitud.getSocCorrelativo() + " se guardó exitosamente.";
						this.botonHab = true;
						this.recuperarSolicitudes();
					} else {
						this.mensaje = "Se produjo un error al guardar la solicitud.";
						this.botonHab = true;
					}
				} else {
					this.mensaje = "El concepto de la transferencia excede la longitud permitida para este campo.";
					this.botonHab = false;
				}
			} else {
				this.mensaje = "Existen caracteres no válidos en el concepto de la transferencia.";
				this.botonHab = false;
			}
		} else {
			this.mensaje = "Se debe seleccionar un concepto para la transferencia.";
			this.botonHab = false;
		}
	}

	public void eventoGuardarBtn1(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		codigo = solicitud.getSocCodigo();
		tipo = solicitud.getClaTipo();

		solicitud.setSocCuentad(Integer.parseInt(idCuenta));
		nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentad());
		solicitud.setSocNrocuentad(nroCuenta);
		solicitud.setMoneda(idMoneda);

		if ("S".equals(idDescuento)) // facturar a solicitante
		{
			nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentac());
			solicitud.setSocNrocuentac(nroCuenta);
		} else {
			solicitud.setSocCuentac(null);
			solicitud.setSocNrocuentac(null);
		}

		detalle.setBenCodigo(idBenef);
		detalle.setDetCtabenef(idCuentaB);
		detalle.setDetMonto(solicitud.getSocMontome());
		detalle.setDetMontoord(solicitud.getSocMontoord());
		detalle.setMoneda(solicitud.getMoneda());
		detalle.setDetConcepto(concepto.toUpperCase());

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "modificar");
		mapaParametros.put("solicitud", solicitud);
		mapaParametros.put("detalle", detalle);

		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
		log.info("Numero de Solicitud: " + nroSolicitud);

		if (!nroSolicitud.equals("-1")) {
			this.mensaje = "La solicitud " + solicitud.getSocCorrelativo() + " se guardó exitosamente.";
			this.botonHab = true;
			this.recuperarSolicitudes();
		} else {
			this.mensaje = "Se produjo un error al guardar la solicitud.";
			this.botonHab = true;
		}
	}

}
