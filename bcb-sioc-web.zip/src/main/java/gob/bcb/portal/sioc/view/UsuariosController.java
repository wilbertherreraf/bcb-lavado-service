package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocUsuariosol;
import gob.bcb.bpm.pruebaCU.SocUsuariosolPK;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.richfaces.component.html.HtmlDataTable;

public class UsuariosController extends BaseBeanController {
	private static final Log log = LogFactory.getLog(UsuariosController.class);
	private SolicitudBean solicitudBean = new SolicitudBean();
	private List<SelectItem> solicitantes = new ArrayList<SelectItem>();
	private List<SocUsuariosol> socUsuariosolLista = new ArrayList<SocUsuariosol>();
	private SocUsuariosol socUsuariosolSearch = new SocUsuariosol();
	private SocUsuariosol socUsuariosolSelected = new SocUsuariosol();
	private String mensaje = "";
	private String sIOCWEB_TIPOPERACION;

	@PostConstruct
	public void init() {
		log.info("PostConstruct ListaBancosController - " + getClass().getName());
		try {
			recuperarVisit();

			solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			recuperarDatos();
			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			getVisit().setParametro("pagretorno", dd.getPagina());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "OcurriÃƒÂ³ un error: " + e.getMessage(), null));
		}

	}

	private void recuperarDatos() {
		SocUsuariosolPK socUsuariosolPK = new SocUsuariosolPK();
		socUsuariosolSelected = new SocUsuariosol();
		socUsuariosolSearch.setSocUsuariosolPK(socUsuariosolPK);

		socUsuariosolLista = solicitudBean.getSocUsuariosolDao().getUsuariosSioc(null, null, null);
		List<SocSolicitante> socSolicitanteLista = solicitudBean.getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			solicitantes.add(new SelectItem(socSolicitante.getSolCodigo().trim() + "", socSolicitante.getSolPersona()));
		}
	}

	public void botonBuscar(ActionEvent actionEvent) {
		buscar();
	}

	public void buscar() {
		socUsuariosolLista.clear();
		socUsuariosolLista = solicitudBean.getSocUsuariosolDao().getUsuariosSioc(socUsuariosolSearch.getSocUsuariosolPK().getSolCodigo(), null, null);
	}

	public void adicionar(ActionEvent event) {
		SocUsuariosolPK socUsuariosolPK = new SocUsuariosolPK();
		socUsuariosolSelected = new SocUsuariosol();
		socUsuariosolSelected.setSocUsuariosolPK(socUsuariosolPK);
	}

	public void editar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocUsuariosol cta0 = (SocUsuariosol) SerializationUtils.clone(socUsuariosolLista.get(fila));
		List<SocUsuariosol> socUsuariosols = solicitudBean.getSocUsuariosolDao().getUsuariosSioc(cta0.getSocUsuariosolPK().getSolCodigo(),
				cta0.getSocUsuariosolPK().getLogin(), null);
		if (socUsuariosols.size() > 0) {
			socUsuariosolSelected = socUsuariosols.get(0);
			socUsuariosolSelected.getSocUsuariosolPK().setSolCodigo(socUsuariosolSelected.getSocUsuariosolPK().getSolCodigo().trim());
		}
	}

	public void guardar(SocUsuariosol socBanco) {
		socBanco.setEstacion(getVisit().getAddress());
		socBanco.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
		socBanco.setFechaHora(new Date());
		solicitudBean.getSocUsuariosolDao().saveOrUpdate(socBanco);
	}

	public void guardarUsuario(ActionEvent event) {
		try {
			log.info("XXX: socUsuariosolSelected " + socUsuariosolSelected.getSocUsuariosolPK().getSolCodigo() + " "
					+ socUsuariosolSelected.getSocUsuariosolPK().getLogin());
			socUsuariosolSelected.setClaVigente(Short.valueOf("1"));
			guardar(socUsuariosolSelected);

			recuperarDatos();

		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void eliminar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();

		SocUsuariosol cta0 = (SocUsuariosol) SerializationUtils.clone(socUsuariosolLista.get(fila));
		try {
			List<SocUsuariosol> socUsuariosols = solicitudBean.getSocUsuariosolDao().getUsuariosSioc(cta0.getSocUsuariosolPK().getSolCodigo(),
					cta0.getSocUsuariosolPK().getLogin(), null);
			if (socUsuariosols.size() > 0) {
				socUsuariosolSelected = socUsuariosols.get(0);
				socUsuariosolSelected.setClaVigente(Short.valueOf("0"));
				guardar(socUsuariosolSelected);
			}

			recuperarDatos();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public List<SelectItem> getSolicitantes() {
		return solicitantes;
	}

	public void setSolicitantes(List<SelectItem> solicitantes) {
		this.solicitantes = solicitantes;
	}

	public List<SocUsuariosol> getSocUsuariosolLista() {
		return socUsuariosolLista;
	}

	public void setSocUsuariosolLista(List<SocUsuariosol> socUsuariosolLista) {
		this.socUsuariosolLista = socUsuariosolLista;
	}

	public SocUsuariosol getSocUsuariosolSearch() {
		return socUsuariosolSearch;
	}

	public void setSocUsuariosolSearch(SocUsuariosol socUsuariosolSearch) {
		this.socUsuariosolSearch = socUsuariosolSearch;
	}

	public SocUsuariosol getSocUsuariosolSelected() {
		return socUsuariosolSelected;
	}

	public void setSocUsuariosolSelected(SocUsuariosol socUsuariosolSelected) {
		this.socUsuariosolSelected = socUsuariosolSelected;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}
