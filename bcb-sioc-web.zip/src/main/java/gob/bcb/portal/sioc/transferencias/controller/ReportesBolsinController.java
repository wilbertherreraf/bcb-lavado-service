package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.web.utils.ConstantesReportes;
import gob.bcb.web.utils.FechaPojo;
import gob.bcb.web.utils.UtilFechas;
import gob.bcb.bpm.pruebaCU.SocEstadistica;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.BeanContextFactory;
import gob.bcb.service.servicioSioc.pojos.Resultado;
import gob.bcb.service.servicioSiocCoin.ServicioCoinDao;
import gob.bcb.web.utils.UtilReporte;


import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

//import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils.Collections;

public class ReportesBolsinController extends BaseBeanController {

	private List<SelectItem> reportes = new ArrayList<SelectItem>();
	private String idRep = "";
	private String f1 = "";
	private String f2 = "";
	private String fff1 = "";
	private String fff2 = "";
	private Date fecha1;
	private Date fecha2;
	private SocEstadistica socEstadisticaBusqueda = new SocEstadistica();
	List<SocSolicitante> socSolicitanteLista = new ArrayList<SocSolicitante>();
	private List<SelectItem> solicitanteItems = new ArrayList<SelectItem>();
	private ServicioCoinDao servicioCoinDao = new ServicioCoinDao();

	private String mensajeValidacion = "";

	private String nombreReporte = "";

	private String tipoPeriodoReporteValidacion = ""; // Diario = 0,Semana = 1,
														// Mensual = 2,Dias = 3,
														// Anual = 4

	private String tipoPeriodo = ""; // Diario = 0,Semana = 1, Mensual = 2,Dias
										// = 3, Anual = 4

	private String urlReporte;

	private String usuario = "";
	
	private List<BigDecimal> bolsin = new ArrayList<BigDecimal>();
	
	private List<BigDecimal> ventaDia = new ArrayList<BigDecimal>();
	
	private Logger log = Logger.getLogger(ReportesBolsinController.class);

	
	// Instancia clase de tipo "UtilReporte".
	UtilReporte vObjReporte = new UtilReporte();
	// Instancia clase de tipo "UtilFechas".						
	UtilFechas vObjUtilFecha = new UtilFechas();	
	
	
	//
	// public ReportesBolsinController() {
	// reportes.add(new SelectItem("R", "VENTA DE DIVISAS - RESUMEN"));
	// reportes.add(new SelectItem("D", "VENTA DE DIVISAS - DETALLE"));
	// reportes.add(new SelectItem("C", "CONSULTA DE LA SUBASTA POR FECHAS"));
	//
	// }

	@PostConstruct
	public void init() {
		try {
			log.info("Iniciando el modulo ");
			recuperarVisit();
			fecha1 = new Date();
			fecha2 = new Date();
			socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");
			servicioCoinDao.setSessionFactory(BeanContextFactory.getInstance().getServicioCoinDao().getHibernateTemplate().getSessionFactory());
			vObjReporte.setFeriadoDao(servicioCoinDao.getFeriadoDao());
			vObjUtilFecha.setFeriadoDao(servicioCoinDao.getFeriadoDao());
			
			
			for (SocSolicitante socSolicitante : socSolicitanteLista) {
				solicitanteItems.add(new SelectItem(socSolicitante.getSolCodigo().trim() + "", socSolicitante.getSolPersona()));
			}

			String usuarioLogin = getVisit().getUsuarioSession().getLogin();
			String direccionIp = getVisit().getAddress();
			usuario = usuarioLogin + " - " + direccionIp;

		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		} finally {
			getVisit().removeParametro("SIOCWEB_CODMENSWFT");
			getVisit().removeParametro("SIOCWEB_ACTION");

			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext()
					.getSessionMap();
			// la desesperada!! esto no debería estar aqui
			sesiones.remove("solicitudController");
			sesiones.remove("solicitudSearchPanel");
		}

	}

	public SocEstadistica getSocEstadisticaBusqueda() {
		return socEstadisticaBusqueda;
	}

	public void setSocEstadisticaBusqueda(SocEstadistica socEstadisticaBusqueda) {
		this.socEstadisticaBusqueda = socEstadisticaBusqueda;
	}

	public List<SelectItem> getSolicitanteItems() {
		return solicitanteItems;
	}

	public void setSolicitanteItems(List<SelectItem> solicitanteItems) {
		this.solicitanteItems = solicitanteItems;
	}

	public void verReporte(String tipoArchivo) {
		try {
			log.info("Fecha desde " + fecha1 + " fecha hasta " + fecha2);
			nombreReporte = "Reporte Bolsin y Venta directa";
						
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
				Map<String, Object> parametros = new HashMap<String, Object>();
				parametros.put("fechaini", fecha1);
				parametros.put("fechafin", fecha2);
				parametros.put("tipo", "bolsinDetCompra");
				parametros.put("reportFormato", tipoArchivo);
				parametros.put("USUARIO", usuario);
							

				HttpServletRequest request = (HttpServletRequest) FacesContext
						.getCurrentInstance().getExternalContext().getRequest();
				request.getSession().setAttribute("tipo", "bolsinDetCompra");
				request.getSession().setAttribute("parametros", parametros);

			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	vObjResultado.getMensaje(), null));
			}
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}		

	public void verReporteExtSFinanciero(String tipoArchivo) {
		try {
			
						
			log.info("verReporteExtSFinanciero: Fecha desde " + fecha1 + " fecha hasta " + fecha2);
			// Validamos las fechas
			nombreReporte = "Reporte de Transferencias al exterior (Sistema Financiero)";
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
				// Parametros para el reporte
				Map<String, Object> parametros = new HashMap<String, Object>();
				// Obtenemos el año anterior de la fecha seleccionada
				
				Calendar cal = Calendar.getInstance();
				cal.setTime(fecha2);
				int anho = cal.get(Calendar.YEAR);
							
				//Obtenemos el mes para el calculo de los meses anterirores
				int mes = cal.get(Calendar.MONTH);
				
				// Gemramos el encabezado del reporte
				List<String> headers = vObjReporte.generarEncabezadoOpcional(anho, mes, fecha2, false, true, false, true);
				// Obtenemos las filas
				
				
				parametros.put("fechaini", fecha1);
				parametros.put("fechafin", fecha2);
				parametros.put("tipo", "transfExtSF");
				parametros.put("reportFormato", tipoArchivo);
				parametros.put("USUARIO", usuario);
				

				HttpServletRequest request = (HttpServletRequest) FacesContext
						.getCurrentInstance().getExternalContext().getRequest();
				request.getSession().setAttribute("tipo", "transfExtSF");
				request.getSession().setAttribute("parametros", parametros);
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verReporteOperacionesCambiarias(String tipoArchivo) {
		try {
			
			log.info("verReporteOperacionesCambiarias: Fecha desde " + fecha1 + " fecha hasta " + fecha2);
			nombreReporte = "Reporte de Operaciones Cambiarias";
			tipoPeriodoReporteValidacion = "4";
								
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
				// Parametros para el reporte
				Map<String, Object> parametros = new HashMap<String, Object>();
				// Obtenemos el año anterior de la fecha seleccionada
				parametros.put("tipoReporteDinamico", "opCambiarias");
				Calendar cal = Calendar.getInstance();
				cal.setTime(fecha2);
				int anho = cal.get(Calendar.YEAR);
							
				//Obtenemos el mes para el calculo de los meses anterirores
				int mes = cal.get(Calendar.MONTH);
				
				// Gemramos el encabezado del reporte
				List<String> headers = vObjReporte.generarEncabezadoOpcional(anho, mes, fecha2, false, false, false, false);
				
				for (Iterator iterator = headers.iterator(); iterator.hasNext();) {
					log.info("Cabecera: " + iterator.next());					
				}
				
				log.debug(">>>>>>>>>>>>>> Numero de Cabeceras " + headers.size() + " >>>>>>>>>>>>>>");
							
				List<List<String>> lists = vObjReporte.generarFilasReporteOperacionesCambiarias(anho, mes);

				log.debug(">>>>>>>>>>>>>> Numero de Filas " + lists.size() + " >>>>>>>>>>>>>>");
				
				
		        parametros.put("reportFormato", tipoArchivo);
		        ////////////////////////////////////////////////////
		        
		        parametros.put("headers",headers);
		        parametros.put("rows",lists);
		        		
				parametros.put("esDinamico", true);
				parametros.put("tipo", ConstantesReportes.cReporteOperacionesCambiarias);
//				parametros.put("tipo", "vOpCamMill");
				parametros.put("USUARIO", this.usuario);
				
				HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
				request.getSession().setAttribute("tipo", "vOpCamMill");
				request.getSession().setAttribute("parametros", parametros);
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,vObjResultado.getMensaje(), null));
			}		

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}
	
	/**
     * Método que genera reporte del venta de dolares estadounidenses.
     * @param pTipoArchivo Tipo de archivo de reporte.
     * @param pNombreReporte Nombre de reporte.
    */
	public void ObtenerReporteVentaDolaresEstadounidenses(String tipoArchivo, String pNombreReporte) 
	{	
		try 
		{
					
			this.nombreReporte = "Reporte de Venta de Dólares Estadounidenses (Presidente)";
			
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", this.nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
												
				// Verifica is el nombre de reporte es válido.
				if(!pNombreReporte.isEmpty())
				{
				// Obtiene titulo de reporte.
				String titulo =  vObjReporte.obtenerTituloReporte(pNombreReporte,fecha2);
				
				// Obtiene fecha completa.
				FechaPojo vObjFecha = vObjUtilFecha.obtenerFechaCompletaPorFecha(fecha2, 0);
				
				// Instancia tipo de objeto "Dictionary".
				Map<String, Object> parametros = new HashMap<String, Object>();
						
				// Genera encabezado opcional para los reportes.
				List<String> headers =  vObjReporte.generarEncabezadoOpcional(vObjFecha.getGestionValor(), vObjFecha.getMesValor(), fecha2, true, true, false, true);
				
				// Genera cuerpo del reporte.
				List<List<String>> lists =  vObjReporte.generarFilasReporteVentaDolares(vObjFecha.getGestionValor(), vObjFecha.getMesValor(), fecha1, fecha2, false, true);			
				
				// Adiciona titulo de reporte.
				parametros.put("titulo",titulo);
				// Adiciona nombre de usuario.
				parametros.put("USUARIO", usuario);
				// Adiciona tipo de reporte	al objeto diccionario.
				parametros.put("reportFormato", tipoArchivo);
				// Adiciona cabecera de reporte.
				parametros.put("headers", headers);
				// Adiciona cuerpo de reporte.
				parametros.put("rows", lists);
				// Adiciona mes pivote.
				parametros.put("mes", vObjFecha.getMesLiteral());
				// Adiciona cantida de semanas.
				parametros.put("nroSemana", vObjFecha.getDiasValidos());
				// Adiciona variable si el reporte es activo.
				parametros.put("esDinamico", true);
				// Almacena el nombre del reporte.
				parametros.put("tipo", pNombreReporte);

				// Instancia servlet para almacenar los parametros de entrada.
				HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();			
				
				// Almacena el nombre del reporte.
				request.getSession().setAttribute("tipo", pNombreReporte);
				// Almacena todos los parametros de entrada.
				request.getSession().setAttribute("parametros", parametros);
				}
				else 
				{
					// Inserta mensaje de validacion.
					mensajeValidacion = "El nombre de reporte no es válido.";
					// Adiciona mensaje de validación.
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeValidacion, null));
				}
			} 
			else 
			{
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}	
		
	}
	
	/**
     * Método que genera reporte del sistema de operaciones cambiarias - sioc.
     * @param pTipoArchivo Tipo de archivo de reporte.
     * @param pNombreReporte Nombre de reporte.
    */
	public void GenerarReporteOperacionesCambiarias(String pTipoArchivo, String pNombreReporte) 
	{		
		try 
		{
			// Verificar Nombre del reporte

			if(ConstantesReportes.cReporteTransferenciasExterior.equalsIgnoreCase(pNombreReporte)){
				this.nombreReporte = "Reporte de Transferencias al exterior Por Gestión";
			} else if(ConstantesReportes.cReporteVentaDolaresBolsinSistemaFinanciero.equalsIgnoreCase(pNombreReporte)){
				this.nombreReporte = "Reporte de Venta de Dólares Estadounidenses a través de Bolsin al Sistema Financiero";
			} else if (ConstantesReportes.cReporteVentaDolaresBolsinClientesSistemaFinanciero.equalsIgnoreCase(pNombreReporte)){
				this.nombreReporte = "Reporte de Venta de Dólares Estadounidenses a través de Bolsin a Clientes del Sistema Financiero";
			} else if (ConstantesReportes.cReporteVentaDolaresDiaSistemaFinanciero.equalsIgnoreCase(pNombreReporte)){
				this.nombreReporte = "Reporte de Venta de Dólares Estadounidenses en el dia al Sistema Financiero";
			} else if(ConstantesReportes.cReporteVentaDolaresDiaClientesSistemaFinanciero.equalsIgnoreCase(pNombreReporte)){
				this.nombreReporte = "Reporte de Venta de Dólares Estadounidenses en el día a Clientes del Sistema Financiero";
			}
				
			
			log.info("---------------------> EBM ---------------------> " + Locale.getDefault().getCountry() + " " + Locale.getDefault().getLanguage());
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
						
				// Verifica is el nombre de reporte es válido.
				if(!pNombreReporte.isEmpty())
				{
					// Obtiene titulo de reporte.
					String titulo =  vObjReporte.obtenerTituloReporte(pNombreReporte,fecha2);
					
					// Instancia tipo de objeto "Diccionary".
					Map<String, Object> parametros = new HashMap<String, Object>();
					
					// Obtiene fecha completa.
					FechaPojo vObjFecha = vObjUtilFecha.obtenerFechaCompletaPorFecha(fecha2, 0);
					// calculamos dias habiles
					int diasValidos = vObjFecha.getDiasValidos();
					// Controlamos que hayan dias habiles
					if(diasValidos < 1){
						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
						String fechaHasta = dateFormat.format(fecha2);
						// Inserta mensaje de validacion.
						mensajeValidacion = "No existen dias validos a la fecha: " +  fechaHasta;
						// Adiciona mensaje de validación.
						FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeValidacion, null));
						return;
					}
					
					// Genera encabezado opcional para los reportes.
					List<String> headers = vObjReporte.generarEncabezadoOpcional(vObjFecha.getGestionValor(), vObjFecha.getMesValor(), fecha2, false, true, false, true);

					// Genera cuerpo del reporte por nombre de reporte.
					List<List<String>> lists =  vObjReporte.generarCuerpoReporte(vObjFecha.getGestionValor(), vObjFecha.getMesValor(), fecha2, pNombreReporte, false, true);

					//	Obtiene sumatoria de filas para los reportes.
					vObjReporte.generarSumaFilasReporte(lists);
								
					// Adiciona titulo de reporte.
					parametros.put("titulo",titulo);
					// Adiciona nombre de usuario.
					parametros.put("USUARIO", usuario);
					// Adiciona tipo de reporte	al objeto diccionario.							
					parametros.put("reportFormato", pTipoArchivo);
					// Adiciona cabecera de reporte.
					parametros.put("headers", headers);
					// Adiciona cuerpo de reporte.
					parametros.put("rows", lists);
					// Adiciona mes pivote.
					parametros.put("mes", vObjFecha.getMesLiteral());
																		
					parametros.put("nroSemana", diasValidos);
					// Adiciona variable si el reporte es activo.
					parametros.put("esDinamico", true);
					// Adiciona nombre de reporte.
					parametros.put("tipo", pNombreReporte);
									
					// Instancia servlet para almacenar los parametros de entrada.
					HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
					
					// Almacena el nombre del reporte.
					request.getSession().setAttribute("tipo", pNombreReporte);
					// Almacena todos los parametros de entrada.
					request.getSession().setAttribute("parametros", parametros);
				}
				else 
				{
					// Inserta mensaje de validacion.
					mensajeValidacion = "El nombre de reporte no es válido.";
					// Adiciona mensaje de validación.
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeValidacion, null));
				}				
			} 
			else 
			{
				// Adiciona mensaje de validación.
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	vObjResultado.getMensaje(), null));
			}
		} 
		catch (Exception e) 
		{
			// Escribe el errole en el log del sistema.
			log.error("Error al cargar " + e.getMessage(), e);
			// Adiciona error del mensaje.
			addMessageError("Error", e.getMessage());
		}
	}
	
	public void verReporteDiarioOpCambiarias(String tipoArchivo, String tipoPeriodo) {
		try {
			log.info("verReporteDiarioOpCambiarias: Fecha desde " + fecha1
					+ " fecha hasta " + fecha2);

			log.info("Tipo Periodo " + tipoPeriodo);
						
			// Validamos las fechas
			Calendar cal = Calendar.getInstance();
			cal.setTime(fecha1);
			int month = cal.get(Calendar.MONTH);
			int idioma = 0; // Español
			String mes = vObjReporte.getNombreMes(idioma, month);

			SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

			String fechaS1 = format.format(this.fecha1);

			String fechaS2 = format.format(this.fecha2);

			int anho = cal.get(Calendar.YEAR);

			int diaAnho = cal.get(Calendar.DAY_OF_YEAR);

			int diaSemana = cal.get(Calendar.DAY_OF_WEEK);

			int diaMes = cal.get(Calendar.DAY_OF_MONTH);

			String dia = vObjReporte.getNombreDia(idioma, diaSemana);

			int numeroSemana = (diaAnho - diaSemana + 10) / 7;		
			

			String fechalarga = "";
			// Calculamos el número de la semana

			String periodo = "";
			if ("0".equalsIgnoreCase(tipoPeriodo)) {
				periodo = "Diario";
				fechalarga = dia + " " + diaMes + " de " + mes + " " + anho;
				this.tipoPeriodo = " del día";
			} else if ("1".equalsIgnoreCase(tipoPeriodo)) {
				periodo = "Semanal";
				fechalarga = "Semana " + numeroSemana + " del " + fechaS1
						+ " al " + fechaS2;
				this.tipoPeriodo = " Semana";
			} else if ("2".equalsIgnoreCase(tipoPeriodo)) {
				periodo = "Mensual";
				fechalarga = mes + " " + anho;
				this.tipoPeriodo = " mes";
			}
			nombreReporte = "Reporte " + periodo + " de Operaciones Cambiarias";
			tipoPeriodoReporteValidacion = tipoPeriodo;
			
			
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, tipoPeriodoReporteValidacion, nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
							
				Map<String, Object> parametros = new HashMap<String, Object>();
				java.sql.Date fechInicio = new java.sql.Date(fecha1.getTime());
				java.sql.Date fechFin = new java.sql.Date(fecha2.getTime());
				vObjReporte.obtenerParametrosOperacionesCambiariasPorPeriodo(fecha1, fecha2, parametros);
				parametros.put("fechaInicio", fechInicio);
				parametros.put("fechaFin", fechFin);
	
				parametros.put("tipoPeriodo", this.tipoPeriodo);
				parametros.put("periodoReporte", periodo);
				parametros.put("periodoReporte", periodo);
				parametros.put("fechaLarga", fechalarga);
				parametros.put("propioDt", true);
				parametros.put("tipo", "vDOpCam");
				parametros.put("reportFormato", tipoArchivo);
				parametros.put("USUARIO", usuario);
				
				HttpServletRequest request = (HttpServletRequest) FacesContext
						.getCurrentInstance().getExternalContext().getRequest();
				request.getSession().setAttribute("tipo", "vDOpCam");
				request.getSession().setAttribute("parametros", parametros);
			} else {
				FacesContext.getCurrentInstance().addMessage(null,	new FacesMessage(FacesMessage.SEVERITY_INFO, vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verReporteDolares(String tipoArchivo) {
		try {
			log.info("verReporteBolsinSistemaFinanciero: Fecha desde " + fecha1
					+ " fecha hasta " + fecha2);

			// Validamos las fechas
			nombreReporte = "Reporte de Transferencias al exterior (Sistema Financiero)";
						
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
				
				Map<String, Object> parametros = new HashMap<String, Object>();
				java.sql.Date fechInicio = new java.sql.Date(fecha1.getTime());
				java.sql.Date fechFin = new java.sql.Date(fecha2.getTime());
				parametros.put("fechaInicio", fechInicio);
				parametros.put("fechaFin", fechFin);

				parametros.put("estacion", " ");
				parametros.put("tipo", "vDol");
				parametros.put("reportFormato", tipoArchivo);
				parametros.put("USUARIO", usuario);
				

				HttpServletRequest request = (HttpServletRequest) FacesContext
						.getCurrentInstance().getExternalContext().getRequest();
				request.getSession().setAttribute("tipo", "vDol");
				request.getSession().setAttribute("parametros", parametros);
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,	vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verReporteGrafVentDolares(String tipoArchivo, String tipoPeriodo) {
		try {
			log.info("verGraficoVentaDiariaSistemaFinanciero: Fecha desde "
					+ fecha1 + " fecha hasta " + fecha2);

			// Validamos las fechas
			nombreReporte = "Grafico de Venta diaria de Dólares (Sistema Financiero)";
			tipoPeriodoReporteValidacion = tipoPeriodo;
			
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, tipoPeriodoReporteValidacion, nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
							
				Map<String, Object> parametros = new HashMap<String, Object>();
								
				java.sql.Date fechInicio = new java.sql.Date(fecha1.getTime());
				java.sql.Date fechFin = new java.sql.Date(fecha2.getTime());
				parametros.put("fechaInicio", fechInicio);
				parametros.put("fechaFin", fechFin);
				parametros.put("tipo", "gVeDiSisFin");
				parametros.put("reportFormato", tipoArchivo);
				int idioma = 0;

				Calendar cal = Calendar.getInstance();
				cal.setTime(fecha1);
				int month = cal.get(Calendar.MONTH);

				int anho = cal.get(Calendar.YEAR);
				String nombreMes = vObjReporte.getNombreMes(idioma, month);
				String mesAnho = nombreMes + " " + anho;
				log.info("Mes año: " + mesAnho);
				parametros.put("mesAnho", mesAnho);
				parametros.put("estacion", " ");
				parametros.put("tipo", "gVeDiSisFin");
				parametros.put("USUARIO", usuario);

				HttpServletRequest request = (HttpServletRequest) FacesContext
						.getCurrentInstance().getExternalContext().getRequest();
				request.getSession().setAttribute("tipo", "gVeDiSisFin");
				request.getSession().setAttribute("parametros", parametros);
			} else {
				FacesContext.getCurrentInstance().addMessage(null,	new FacesMessage(FacesMessage.SEVERITY_INFO, vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}
	
	/**
     * Método que genera el grafico de venta mensual de dolares del sistema financiero.
     * @param pTipoArchivo Tipo de archivo de reporte.
     * @param pNombreReporte Nombre de reporte.
    */
	public void generarGraficoVentaMensualDolaresSistemaFinanciero(String pTipoArchivo, String pTipoPeriodo) {
		
		try {
			
			// Obtiene valor de la gestión para el reporte. 
			String vGestion = "";
			String vDescripcionFecha = "";
						
			// Validamos las fechas.
			tipoPeriodoReporteValidacion = pTipoPeriodo;
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, tipoPeriodoReporteValidacion, nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
				
				// Instancia tipo de objeto "Diccionary".
				Map<String, Object> parametros = new HashMap<String, Object>();
							
				// Obtiene fecha incial completa.
				FechaPojo vObjFechaInicio = vObjUtilFecha.obtenerFechaCompletaPorFecha(fecha1, 2);
				// Obtiene fecha fin completa.
				FechaPojo vObjFechaFin = vObjUtilFecha.obtenerFechaCompletaPorFecha(fecha2, 2);
								
				// Verifica si las gestiones son iguales.
				if(vObjFechaInicio.getGestionValor() == vObjFechaFin.getGestionValor())
					// Obtiene gestion del reporte.
					vGestion =  String.valueOf(vObjFechaInicio.getGestionValor()) ;							
				else
					// Obtiene gestiones correspondientes al reporte.
					vGestion = vObjFechaInicio.getGestionValor() + " - " + vObjFechaFin.getGestionValor();					
				
				vDescripcionFecha = "(*) Al "+vObjFechaFin.getDiaValor() + " de " + vObjFechaFin.getMesLiteral() + " de " + vObjFechaFin.getGestionValor();
				// Adiciona fecha inicial de reporte.
				parametros.put("fechaInicio", fecha1);
				// Adiciona fecha final de reporte.
				parametros.put("fechaFin", fecha2);
				// Adiciona descripcion literal fecha final.
				parametros.put("p_fecha_reporte", vDescripcionFecha);
				// Adiciona gestiones correspondientes.
				parametros.put("mesAnho", vGestion);
				// Adiciona nombre de reporte.
				parametros.put("tipo", "gVeMensualSisFin");
				// Adiciona tipo de archivo.
				parametros.put("reportFormato", pTipoArchivo);
				// Adiciona tipo de estacion.
				parametros.put("estacion", " ");
				// Adiciona nombre de usuario.
				parametros.put("USUARIO", usuario);

				// Instancia servlet para almacenar los parametros de entrada.
				HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
				
				// Almacena todos los parametros de entrada.
				request.getSession().setAttribute("parametros", parametros);
			} 
			else {
				// Adiciona mensaje de validación.
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, vObjResultado.getMensaje(), null));
			}
		} 
		catch (Exception e) {
			
			// Escribe en el log del sistema.
			log.error("Error al cargar " + e.getMessage(), e);
			// Adiciona mensaje de validación.
			addMessageError("Error", e.getMessage());
		}
	}
	
	
	/**
     * Método que genera el grafico de venta mensual de dolares del sistema financiero.
     * @param pTipoArchivo Tipo de archivo de reporte.
     * @param pNombreReporte Nombre de reporte.
    */
	public void generarGraficoTransMensualAlExtSistemaFinanciero(String pTipoArchivo, String pTipoPeriodo) {
		
		try {
			
			// Obtiene valor de la gestión para el reporte. 
			String vGestion = "";
						
			// Validamos las fechas.
			tipoPeriodoReporteValidacion = pTipoPeriodo;
			
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, tipoPeriodoReporteValidacion, nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){
	
				// Instancia tipo de objeto "Diccionary".
				Map<String, Object> parametros = new HashMap<String, Object>();
							
				// Obtiene fecha incial completa.
				FechaPojo vObjFechaInicio = vObjUtilFecha.obtenerFechaCompletaPorFecha(fecha1, 2);
				// Obtiene fecha fin completa.
				FechaPojo vObjFechaFin = vObjUtilFecha.obtenerFechaCompletaPorFecha(fecha2, 2);
								
				// Verifica si las gestiones son iguales.
				if(vObjFechaInicio.getGestionValor() == vObjFechaFin.getGestionValor())
					// Obtiene gestion del reporte.
					vGestion =  "Gestión " + String.valueOf(vObjFechaInicio.getGestionValor()) ;		
				else
					// Obtiene gestiones correspondientes al reporte.
					vGestion = "Gestiones " +vObjFechaInicio.getGestionValor() + " - " + vObjFechaFin.getGestionValor();
				
				// Adiciona fecha inicial de reporte.
				parametros.put("fechaInicio", fecha1);
				// Adiciona fecha final de reporte.
				parametros.put("fechaFin", fecha2);
				// Adiciona descripcion literal fecha final.
				parametros.put("p_fecha_reporte", "(*) Al "+vObjFechaFin.getDiaValor() + " de " + vObjFechaFin.getMesLiteral() + " de " + vObjFechaFin.getGestionValor());
				// Adiciona gestiones correspondientes.
				parametros.put("mesAnho", vGestion);
				// Adiciona nombre de reporte.
				parametros.put("tipo", "gTransMenAlExt");
				// Adiciona tipo de archivo.
				parametros.put("reportFormato", pTipoArchivo);
				// Adiciona tipo de estacion.
				parametros.put("estacion", " ");
				// Adiciona nombre de usuario.
				parametros.put("USUARIO", usuario);

				// Instancia servlet para almacenar los parametros de entrada.
				HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
				
				// Almacena todos los parametros de entrada.
				request.getSession().setAttribute("parametros", parametros);
			} 
			else {
				// Adiciona mensaje de validación.
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, vObjResultado.getMensaje(), null));
			}
		} 
		catch (Exception e) {
			
			// Escribe en el log del sistema.
			log.error("Error al cargar " + e.getMessage(), e);
			// Adiciona mensaje de validación.
			addMessageError("Error", e.getMessage());
		}
	}

	

	public void verReporteBolSFinanciero(String tipoArchivo) {
		try {
			log.info("verReporteBolsinSistemaFinanciero: Fecha desde " + fecha1
					+ " fecha hasta " + fecha2);

			SelectItem selectedItem = new SelectItem();
			String solSeleccionado = socEstadisticaBusqueda.getSolCodigo();
			String itemProcesando = "";
			log.info("Identificador del solicitante " + solSeleccionado);
			
			// Validamos las fechas
			nombreReporte = "Reporte de Venta de USD a través del bolsín (Sistema Financiero)";

			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){	
				
				if (!"".equalsIgnoreCase(solSeleccionado)) {

					// Obtenemos el nombre del solicitante
					for (SelectItem items : solicitanteItems) {
						itemProcesando = items.getValue().toString();
						log.info("Item procesando " + itemProcesando);
						if (solSeleccionado.equalsIgnoreCase(itemProcesando)) {
							log.info("Item seleccionado " + items.getLabel());
							selectedItem = items;
							break;
						}
					}

					log.info("Solicitante seleccionado "
							+ selectedItem.getLabel());
					Map<String, Object> parametros = new HashMap<String, Object>();
					java.sql.Date fechInicio = new java.sql.Date(
							fecha1.getTime());
					java.sql.Date fechFin = new java.sql.Date(fecha2.getTime());
					parametros.put("fechaInicio", fechInicio);
					parametros.put("fechaFin", fechFin);
					parametros.put("sol_codigo", new Integer(socEstadisticaBusqueda.getSolCodigo()));

					parametros.put("nom_solicitante", selectedItem.getLabel());
					parametros.put("estacion", " ");
					parametros.put("tipo", "bolSF");
					parametros.put("reportFormato", tipoArchivo);
					parametros.put("USUARIO", usuario);
					
					HttpServletRequest request = (HttpServletRequest) FacesContext
							.getCurrentInstance().getExternalContext()
							.getRequest();
					request.getSession().setAttribute("tipo", "bolSF");
					request.getSession().setAttribute("parametros", parametros);
				} else {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
									"Debe seleccionar un solcitante para el " + nombreReporte, null));
				}
			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
								vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verReporteBolClientesSFinanciero(String tipoArchivo) {
		try {
			log.info("verReporteBolsinClientesSistemaFinanciero: Fecha desde "
					+ fecha1 + " fecha hasta " + fecha2);
			
			SelectItem selectedItem = new SelectItem();
			String solSeleccionado = socEstadisticaBusqueda.getSolCodigo();
			String itemProcesando = "";
			log.info("Identificador del solicitante " + solSeleccionado);
			// Validamos las fechas
			nombreReporte = "Reporte de Venta de USD a través del bolsín a clientes (Sistema Financiero)";
			
				
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){	
				
				if (!"".equalsIgnoreCase(solSeleccionado)) {
					// Obtenemos el nombre del solicitante
					for (SelectItem items : solicitanteItems) {
						itemProcesando = items.getValue().toString();
						log.info("Item procesando " + itemProcesando);
						if (solSeleccionado.equalsIgnoreCase(itemProcesando)) {
							log.info("Item seleccionado " + items.getLabel());
							selectedItem = items;
							break;
						}
					}

					log.info("Solicitante seleccionado " + selectedItem.getLabel());
					Map<String, Object> parametros = new HashMap<String, Object>();
					java.sql.Date fechInicio = new java.sql.Date(fecha1.getTime());
					java.sql.Date fechFin = new java.sql.Date(fecha2.getTime());
					parametros.put("fechaInicio", fechInicio);
					parametros.put("fechaFin", fechFin);
					parametros.put("sol_codigo", new Integer(socEstadisticaBusqueda.getSolCodigo()));

					parametros.put("nom_solicitante", selectedItem.getLabel());
					parametros.put("estacion", " ");
					parametros.put("tipo", "bolCSF");
					parametros.put("reportFormato", tipoArchivo);
					parametros.put("USUARIO", usuario);
					

					HttpServletRequest request = (HttpServletRequest) FacesContext
							.getCurrentInstance().getExternalContext()
							.getRequest();
					request.getSession().setAttribute("tipo", "bolCSF");
					request.getSession().setAttribute("parametros", parametros);
				} else {
					FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
									"Debe seleccionar un solcitante para el " + nombreReporte, null));
				}

			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
								vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verReporteDiaSFinanciero(String tipoArchivo) {
		try {
			log.info("verReporteDiaSistemaFinanciero: Fecha desde " + fecha1
					+ " fecha hasta " + fecha2);
			SelectItem selectedItem = new SelectItem();
			String solSeleccionado = socEstadisticaBusqueda.getSolCodigo();
			String itemProcesando = "";
			log.info("Identificador del solicitante " + solSeleccionado);
			// Validamos las fechas
			nombreReporte = "Reporte de Venta de USD en el dia (Sistema Financiero)";
							
			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){	
					
				
				if (!"".equalsIgnoreCase(solSeleccionado)) {
					// Obtenemos el nombre del solicitante
					for (SelectItem items : solicitanteItems) {
						itemProcesando = items.getValue().toString();
						log.info("Item procesando " + itemProcesando);
						if (solSeleccionado.equalsIgnoreCase(itemProcesando)) {
							log.info("Item seleccionado " + items.getLabel());
							selectedItem = items;
							break;
						}
					}

					log.info("Solicitante seleccionado " + selectedItem.getLabel());
					Map<String, Object> parametros = new HashMap<String, Object>();
					java.sql.Date fechInicio = new java.sql.Date(fecha1.getTime());
					java.sql.Date fechFin = new java.sql.Date(fecha2.getTime());
					parametros.put("fechaInicio", fechInicio);
					parametros.put("fechaFin", fechFin);
					parametros.put("sol_codigo", socEstadisticaBusqueda.getSolCodigo());

					parametros.put("nom_solicitante", selectedItem.getLabel());
					parametros.put("estacion", " ");
					parametros.put("tipo", "bolDSF");
					parametros.put("reportFormato", tipoArchivo);
					parametros.put("USUARIO", usuario);
					

					HttpServletRequest request = (HttpServletRequest) FacesContext
							.getCurrentInstance().getExternalContext()
							.getRequest();
					request.getSession().setAttribute("tipo", "bolDSF");
					request.getSession().setAttribute("parametros", parametros);
				} else {
					FacesContext.getCurrentInstance().addMessage(
							null,
							new FacesMessage(FacesMessage.SEVERITY_INFO,
									"Debe seleccionar un solcitante para el "
											+ nombreReporte, null));
				}

			} else {
				FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
								vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void verReporteDiaClientesSFinanciero(String tipoArchivo) {
		try {
			log.info("verReporteDiaSistemaFinanciero: Fecha desde " + fecha1
					+ " fecha hasta " + fecha2);
			
			SelectItem selectedItem = new SelectItem();
			String solSeleccionado = socEstadisticaBusqueda.getSolCodigo();
			String itemProcesando = "";
			log.info("Identificador del solicitante " + solSeleccionado);

			// / Validamos las fechas
			nombreReporte = "Reporte de Venta de USD en el dia a clientes (Sistema Financiero)";
			//boolean respuesta = validarFechas(fecha1, fecha2, false);

			// Valida la fechas inicial y fianal del reporte
			Resultado vObjResultado = vObjUtilFecha.validarFechas(fecha1, fecha2, "5", nombreReporte);
			// Valida fecha de reporte.
			if (vObjResultado.getEsValido()){							

				if (!"".equalsIgnoreCase(solSeleccionado)) {
					// Obtenemos el nombre del solicitante
					for (SelectItem items : solicitanteItems) {
						itemProcesando = items.getValue().toString();
						log.info("Item procesando " + itemProcesando);
						if (solSeleccionado.equalsIgnoreCase(itemProcesando)) {
							log.info("Item seleccionado " + items.getLabel());
							selectedItem = items;
							break;
						}
					}

					log.info("Solicitante seleccionado " + selectedItem.getLabel());
					Map<String, Object> parametros = new HashMap<String, Object>();
					java.sql.Date fechInicio = new java.sql.Date(fecha1.getTime());
					java.sql.Date fechFin = new java.sql.Date(fecha2.getTime());
					parametros.put("fechaInicio", fechInicio);
					parametros.put("fechaFin", fechFin);
					parametros.put("sol_codigo", socEstadisticaBusqueda.getSolCodigo());
					parametros.put("nom_solicitante", selectedItem.getLabel());
					parametros.put("estacion", " ");
					parametros.put("tipo", "bolDCSF");
					parametros.put("reportFormato", tipoArchivo);
					parametros.put("USUARIO", usuario);
					

					HttpServletRequest request = (HttpServletRequest) FacesContext
							.getCurrentInstance().getExternalContext()
							.getRequest();
					request.getSession().setAttribute("tipo", "bolDCSF");
					request.getSession().setAttribute("parametros", parametros);
				} else {
					FacesContext.getCurrentInstance().addMessage(
							null,
							new FacesMessage(FacesMessage.SEVERITY_INFO,
									"Debe seleccionar un solcitante para el "
											+ nombreReporte, null));
				}

			} else {
				FacesContext.getCurrentInstance().addMessage(
						null,
						new FacesMessage(FacesMessage.SEVERITY_INFO,
								vObjResultado.getMensaje(), null));
			}

		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	


public void seleccionChanged(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idRep = sel;
		log.info("Valor seleccionado: " + idRep);
	}

	public List<SelectItem> getReportes() {
		return reportes;
	}

	public void setReportes(List<SelectItem> reportes) {
		this.reportes = reportes;
	}

	public void setIdRep(String idRep) {
		this.idRep = idRep;
	}

	public String getIdRep() {
		return idRep;
	}

	public void setFecha1(Date fecha1) {
		this.fecha1 = fecha1;
	}

	public Date getFecha1() {
		return fecha1;
	}

	public void setFecha2(Date fecha2) {
		this.fecha2 = fecha2;
	}

	public Date getFecha2() {
		return fecha2;
	}

	public void setFff1(String fff1) {
		this.fff1 = fff1;
	}

	public String getFff1() {
		return fff1;
	}

	public void setFff2(String fff2) {
		this.fff2 = fff2;
	}

	public String getFff2() {
		return fff2;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	public String getMensajeValidacion() {
		return mensajeValidacion;
	}

	public void setMensajeValidacion(String mensajeValidacion) {
		this.mensajeValidacion = mensajeValidacion;
	}

	public String getNombreReporte() {
		return nombreReporte;
	}

	public void setNombreReporte(String nombreReporte) {
		this.nombreReporte = nombreReporte;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
}