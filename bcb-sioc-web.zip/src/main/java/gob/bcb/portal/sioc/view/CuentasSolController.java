package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.SocBancos;
import gob.bcb.bpm.pruebaCU.SocBenefsloc;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocPlazas;
import gob.bcb.bpm.pruebaCU.SocPlazasId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.richfaces.component.html.HtmlDataTable;

public class CuentasSolController extends BaseBeanController {
	private static final Log log = LogFactory.getLog(CuentasSolController.class);
	private SolicitudBean solicitudBean = new SolicitudBean();
	private List<SelectItem> solicitantes = new ArrayList<SelectItem>();
	private List<SelectItem> monedasItems = new ArrayList<SelectItem>();
	private List<SocCuentassol> socCuentassolLista = new ArrayList<SocCuentassol>();
	private SocCuentassol socCuentassolSearch = new SocCuentassol();
	private SocCuentassol socCuentassolSelected = new SocCuentassol();
	private String mensaje = "";
	private String sIOCWEB_TIPOPERACION;

	@PostConstruct
	public void init() {
		log.info("PostConstruct ListaBancosController - " + getClass().getName());
		try {
			recuperarVisit();

			solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			recuperarDatos();
			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			getVisit().setParametro("pagretorno", dd.getPagina());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrio un error: " + e.getMessage(), null));
		}

	}

	private void recuperarDatos() {
		socCuentassolLista = solicitudBean.getSocCuentassolDao().ctasUnicas(null, null, null, false);
		List<GenMoneda> genMonedaLista = solicitudBean.getGenMonedaDao().getMonedas();
		monedasItems.clear();
		for (GenMoneda genMoneda : genMonedaLista) {
			monedasItems.add(new SelectItem(genMoneda.getCodMoneda() + "", genMoneda.getMonSigla() + ": " + genMoneda.getMonNombre()));
		}

	}

	public void botonBuscar(ActionEvent actionEvent) {
		buscar();
	}

	public void buscar() {
		socCuentassolLista.clear();
		String query = "";
		query = "select b.* from soc_cuentassol b where b.cta_nommovimiento is not null ";

		if (!StringUtils.isBlank(socCuentassolSearch.getCtaNommovimiento())) {
			query = query.concat("and upper(b.cta_nommovimiento) like '%" + socCuentassolSearch.getCtaNommovimiento().toUpperCase() + "%' ");
		}

		query = query.concat("order by b.cta_nommovimiento ");

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			SocCuentassol benefi0 = new SocCuentassol();
			benefi0.setCtaCodigo((Integer) res.get("cta_codigo"));
			benefi0.setCtaMovimiento((String) res.get("cta_movimiento"));
			benefi0.setCtaAfectable((String) res.get("cta_afectable"));
			benefi0.setMoneda((Integer) res.get("moneda"));
			benefi0.setCtaNommovimiento((String) res.get("cta_nommovimiento"));
			benefi0.setCveImptiva((String) res.get("cve_imptiva"));
			benefi0.setCveImptppto((String) res.get("cve_imptppto"));
			benefi0.setCveImptsigma((String) res.get("cve_imptsigma"));
			benefi0.setPartida((String) res.get("partida"));
			benefi0.setGenItf((Integer) res.get("gen_itf"));
			socCuentassolLista.add(benefi0);
		}

	}

	public void adicionar(ActionEvent event) {
		socCuentassolSelected = new SocCuentassol();
	}

	public void editar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocCuentassol cta0 = (SocCuentassol) SerializationUtils.clone(socCuentassolLista.get(fila));
		socCuentassolSelected = solicitudBean.getSocCuentassolDao().getByCodigo(cta0.getCtaCodigo());
	}

	public void guardar(SocCuentassol socBanco) {
		socBanco.setEstacion(getVisit().getAddress());
		socBanco.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
		socBanco.setFechaHora(new Date());
		solicitudBean.getSocCuentassolDao().saveOrUpdate(socBanco);
	}

	public void guardarReg(ActionEvent event) {
		try {
			socCuentassolSelected.setClaVigente(Short.valueOf("1"));
			guardar(socCuentassolSelected);

			recuperarDatos();

		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void guardarRegM(ActionEvent event) {
		try {
			socCuentassolSelected.setClaVigente(Short.valueOf("1"));
			guardar(socCuentassolSelected);

			recuperarDatos();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void eliminar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();

		SocCuentassol cta0 = (SocCuentassol) SerializationUtils.clone(socCuentassolLista.get(fila));
		try {
			socCuentassolSelected = solicitudBean.getSocCuentassolDao().getByCodigo(cta0.getCtaCodigo());
			socCuentassolSelected.setClaVigente(Short.valueOf("0"));
			solicitudBean.getSocCuentassolDao().eliminar(socCuentassolSelected);

			recuperarDatos();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public List<SelectItem> getSolicitantes() {
		return solicitantes;
	}

	public void setSolicitantes(List<SelectItem> solicitantes) {
		this.solicitantes = solicitantes;
	}

	public List<SocCuentassol> getSocCuentassolLista() {
		return socCuentassolLista;
	}

	public void setSocCuentassolLista(List<SocCuentassol> socCuentassolLista) {
		this.socCuentassolLista = socCuentassolLista;
	}

	public SocCuentassol getSocCuentassolSearch() {
		return socCuentassolSearch;
	}

	public void setSocCuentassolSearch(SocCuentassol socCuentassolSearch) {
		this.socCuentassolSearch = socCuentassolSearch;
	}

	public SocCuentassol getSocCuentassolSelected() {
		return socCuentassolSelected;
	}

	public void setSocCuentassolSelected(SocCuentassol socCuentassolSelected) {
		this.socCuentassolSelected = socCuentassolSelected;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public List<SelectItem> getMonedasItems() {
		return monedasItems;
	}

	public void setMonedasItems(List<SelectItem> monedasItems) {
		this.monedasItems = monedasItems;
	}
}
