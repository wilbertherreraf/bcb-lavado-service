package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class SolicitudesASFAutController extends BaseBeanController {
	private SocSolicitudes solicitud = new SocSolicitudes();
	private SolicitudesS solicitudS = new SolicitudesS();
	private SocDetallessol detalle = new SocDetallessol();
	private CuentasBen cuentaBen = new CuentasBen();
	private List<SolicitudesS> solicitudes;
	private List<SocSolicitudes> listaSoli;

	private String prioridad = "NO";
	private String idSoli = "-1";
	private String cuentaD = "";
	private String cuentaC = "";
	private Boolean montoVer = false;
	private Boolean cuentaVer = true;
	private Boolean generada = true;
	private Boolean botonHab = false;
	private String nombre = "";
	private String mensaje = "";

	private Logger log = Logger.getLogger(SolicitudesASFAutController.class);

	public SolicitudesASFAutController() {
		recuperarVisit();
		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		this.recuperarSolicitudes();
	}

	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SolicitudesS>();
		this.listaSoli = new ArrayList<SocSolicitudes>();

		String query = "";

		if (!idSoli.equals("900")) {
			query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
					+ " and s.cla_estado = 'B'" + " and trim(s.sol_codigo) = '" + idSoli + "' and ss.cla_entidad = 'SF' ";
		} else {
			idSoli = "-1";
			query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
					+ " and s.cla_estado = 'V'" + " and ss.cla_entidad = 'SF'";
		}

		DateTime fecha = new DateTime();

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'B', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");

				solicitudS.setTipo("TRANSFERENCIA AL EXTERIOR");

				solicitud = new SocSolicitudes((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_tipo"),
						(Integer) res.get("soc_cuentad"), (String) res.get("soc_nrocuentad"), (String) res.get("moneda"), 'B',
						(Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (Integer) res.get("soc_cuentac"),
						(String) res.get("soc_nrocuentac"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"),
						(BigDecimal) res.get("soc_montomn"), "", (String) res.get("monedat"));

				DateTime fechaV = new DateTime(res.get("fecha"));
				if (fecha.getDayOfMonth() != fechaV.getDayOfMonth()) {
					solicitudes.add(solicitudS);
					listaSoli.add(solicitud);
				}
			}
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudS = this.solicitudes.get(fila);
		this.solicitud = this.listaSoli.get(fila);

		String query = " select s.* " + " from soc_detallessol s " + " where s.soc_codigo = '" + solicitud.getSocCodigo() + "'"
				+ " and s.det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {

				detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), (String) res.get("moneda"),
						(Integer) res.get("det_ctabenef"), (String) res.get("det_concepto"), (String) res.get("det_info"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("monedaT"), (String) res.get("det_facturas"));
			}
		}

		query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
				+ solicitud.getSocCuentad() + "'";

		List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
		if (resultadoD.size() == 1) {
			for (Map<String, Object> res : resultadoD) {

				cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
			}
		}

		query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
				+ solicitud.getSocCuentac() + "'";

		List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
		if (resultadoC.size() == 1) {
			for (Map<String, Object> res : resultadoC) {

				cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-" + res.get("moneda");
			}
		}

		query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
				+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
				+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.ben_codigo) = '" + detalle.getBenCodigo() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {

				nombre = (String) res.get("ben_nombre");
			}
		}

		query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
				+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp " + " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
				+ " AND pp.bco_codigo = bb.bco_codigo " + " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalle.getDetCtabenef() + "'";

		List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
		if (resultado3.size() == 1) {
			for (Map<String, Object> res : resultado3) {

				cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
						(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"));
			}
			// label1 = "BIC:";
			// bic = cuentaBen.getPlaBic();
		}

		/*
		 * if (solicitud.getSocCuentac().equals(solicitud.getSocCuentad())) {
		 * prioridad = "SI"; montoVer = true; cuentaVer = false; } else {
		 * prioridad = "NO"; montoVer = false; cuentaVer = true; }
		 */
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Autorizando la provisi�n: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "provision");

		mapaParametros.put("solicitud", solicitud);
		log.info("XXX: solicitud.getMonedaT()  ===== " + solicitud.getMonedaT());
		mapaParametros.put("detalle", detalle);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		mensaje = "Se envi� la solicitud y se realizó la provisión de fondos satisfactoriamente.";
		botonHab = true;
		this.recuperarSolicitudes();
	}

	public void eventoAnularBtn(ActionEvent action) {
		log.info("Anulando la solicitud: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "anular");

		mapaParametros.put("solicitud", solicitud);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		mensaje = "Se anuló la solicitud registrada.";
		botonHab = true;
		this.recuperarSolicitudes();
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitud) {
		this.solicitud = solicitud;
	}

	public SolicitudesS getSolicitudS() {
		return solicitudS;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudS = solicitudS;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public String getPrioridad() {
		return prioridad;
	}

	public void setPrioridad(String prioridad) {
		this.prioridad = prioridad;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getCuentaVer() {
		return cuentaVer;
	}

	public void setCuentaVer(Boolean cuentaVer) {
		this.cuentaVer = cuentaVer;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
