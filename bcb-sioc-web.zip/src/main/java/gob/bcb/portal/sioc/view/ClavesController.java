package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.SocClaves;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocValorescla;
import gob.bcb.bpm.pruebaCU.SocValoresclaPK;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

public class ClavesController extends BaseBeanController {
	private Logger log = Logger.getLogger(ClavesController.class);
	
	private SocClaves socClaves = new SocClaves();
	private SocValorescla socValorescla = new SocValorescla();
	private List<SocValorescla> socValoresclaLista = new ArrayList<SocValorescla>();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private String mensaje = "";
	private List<SocClaves> socClavesLista = new ArrayList<SocClaves>();
	private String sIOCWEB_TIPOPERACION;

	@PostConstruct
	public void init() {
		log.info("PostConstruct - " + getClass().getName());
		try {
			recuperarVisit();
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			crearObjetosPorDefecto();

			recuperarDatos();
			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			getVisit().setParametro("pagretorno", dd.getPagina());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "OcurriÃƒÂ³ un error: " + e.getMessage(), null));
		}

	}

	private void crearObjetosPorDefecto() {
		monedas.add(new SelectItem(34, "DOLARES ESTADOUNIDENSES"));
		monedas.add(new SelectItem(69, "BOLIVIANOS"));
	}

	private void recuperarDatos() {

		if (sIOCWEB_TIPOPERACION.equals("CLAVESPAR")) {
			SocParametros  socParametros = getSolicitudBean().getSocParametrosDao().getByCodigo("claves-list");
			String listaclaves = socParametros.getParValor();
			
			socClavesLista = getSolicitudBean().getSocValoresclaDao().buscarClavesLista(listaclaves);
		} else if (sIOCWEB_TIPOPERACION.equals("VER_DETCLAVE")) {
			String SIOCWEB_CODBENEF = (String) getVisit().getParametro("SIOCWEB_CODCLAVE");
			log.info("XXX: SIOCWEB_CODBENEF " + SIOCWEB_CODBENEF);
			if (!StringUtils.isBlank(SIOCWEB_CODBENEF)) {
				recuperarBenef(SIOCWEB_CODBENEF);
			}
		}

	}

	public void botonBuscar(ActionEvent actionEvent) {
		buscar();
	}

	public void recuperarBenef(String benCodigo) {
		socClaves = getSolicitudBean().getSocValoresclaDao().claveByCod(benCodigo);

		socValoresclaLista = getSolicitudBean().getSocValoresclaDao().getValoresByClave(benCodigo);
	}

	public void buscar() {
	}

	public void adicionarNuevo(ActionEvent event) {
		SocValoresclaPK socValoresclaPK = new SocValoresclaPK();
		socValorescla = new SocValorescla();
		socValorescla.setId(socValoresclaPK);

	}

	public void editar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		log.info("editando fila: " + fila);
		SocValorescla cta0 = (SocValorescla) SerializationUtils.clone(this.socValoresclaLista.get(fila));
		socValorescla = getSolicitudBean().getSocValoresclaDao().getValoresByCod(cta0.getId().getClaCodigo(), cta0.getId().getValCodigo());
	}

	public void adicionar(ActionEvent event) {
		socClaves = new SocClaves();
	}

	public void guardarValorCla(SocValorescla socValorescla) {
		socValorescla.setEstacion(getVisit().getAddress());
		socValorescla.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
		socValorescla.setFechaHora(new Date());
		getSolicitudBean().getSocValoresclaDao().saveOrUpdate(socValorescla);
		
	}
	public void guardarValorClave(ActionEvent event) {
		try {
			socValorescla.getId().setClaCodigo(socClaves.getClaCodigo());
			socValorescla.setClaVigente(Short.valueOf("1"));

			guardarValorCla(socValorescla);

			recuperarBenef(socClaves.getClaCodigo());
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void guardarValorClaveM(ActionEvent event) {
		try {
			socValorescla.setClaVigente(Short.valueOf("1"));			
			guardarValorCla(socValorescla);
			recuperarBenef(socValorescla.getId().getClaCodigo());
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void eliminar(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();

		SocValorescla cta0 = (SocValorescla) SerializationUtils.clone(this.socValoresclaLista.get(fila));

		try {
			socValorescla = getSolicitudBean().getSocValoresclaDao().getValoresByCod(cta0.getId().getClaCodigo(), cta0.getId().getValCodigo());
			socValorescla.setClaVigente(Short.valueOf("0"));
			guardarValorCla(socValorescla);			
			getSolicitudBean().getSocValoresclaDao().saveOrUpdate(socValorescla);
			log.info("Se dio de baja el registro.");

			recuperarBenef(socClaves.getClaCodigo());
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}
	}

	public void eventoGenerarBtn(ActionEvent action) {
		getSolicitudBean().getSocValoresclaDao().saveOrUpdate(socClaves);		
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getMensaje() {
		return mensaje;
	}

	public SocClaves getSocClaves() {
		return socClaves;
	}

	public void setSocClaves(SocClaves socClaves) {
		this.socClaves = socClaves;
	}

	public SocValorescla getSocValorescla() {
		return socValorescla;
	}

	public void setSocValorescla(SocValorescla socValorescla) {
		this.socValorescla = socValorescla;
	}

	public List<SocValorescla> getSocValoresclaLista() {
		return socValoresclaLista;
	}

	public void setSocValoresclaLista(List<SocValorescla> socValoresclaLista) {
		this.socValoresclaLista = socValoresclaLista;
	}

	public List<SocClaves> getSocClavesLista() {
		return socClavesLista;
	}

	public void setSocClavesLista(List<SocClaves> socClavesLista) {
		this.socClavesLista = socClavesLista;
	}



}
