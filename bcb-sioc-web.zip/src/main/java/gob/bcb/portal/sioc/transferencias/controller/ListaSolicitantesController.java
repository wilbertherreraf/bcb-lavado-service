/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocParticipante;
import gob.bcb.bpm.pruebaCU.SocParticipantePK;
import gob.bcb.bpm.pruebaCU.SocSolcuentas;
import gob.bcb.bpm.pruebaCU.SocSolcuentasPK;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocValorescla;
import gob.bcb.bpm.pruebaCU.SocValoresclaPK;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.view.SolicitudBean;
import gob.bcb.service.servicioSioc.pojos.CuentaS;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaSolicitantesController extends BaseBeanController {
	private final static Logger log = Logger.getLogger(ListaSolicitantesController.class);
	private SocSolicitante socSolicitante = new SocSolicitante();
	private SocSolicitante solicitante = new SocSolicitante();
	private List<SocSolicitante> solicitantes = new ArrayList<SocSolicitante>();
	private SocSolcuentas cta = new SocSolcuentas();
	private List<CuentaS> cuentas = new ArrayList<CuentaS>();
	private List<SelectItem> cuentasMov = new ArrayList<SelectItem>();
	private SocValorescla socValoresclaBolsin = new SocValorescla();
	private SocValorescla socValoresclaVD = new SocValorescla();
	private String mensaje = "";
	private SolicitudBean solicitudBean = new SolicitudBean();
	private String sIOCWEB_TIPOPERACION;

	@PostConstruct
	public void init() {
		log.info("PostConstruct ListaSolicitantesController - " + getClass().getName());
		try {
			recuperarVisit();
			solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			recuperarDatos();
			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			getVisit().setParametro("pagretorno", dd.getPagina());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "OcurriÃƒÂ³ un error: " + e.getMessage(), null));
		}

	}

	private void recuperarDatos() {

		if (sIOCWEB_TIPOPERACION.equals("SOLICITANTES")) {
			// solicitudes a preautorizar en estado P o V
			solicitantes = solicitudBean.getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");
		} else if (sIOCWEB_TIPOPERACION.equals("VER_SOLICITANTE")) {
			String SIOCWEB_CODSOLIC = (String) getVisit().getParametro("SIOCWEB_CODSOLIC");
			if (!StringUtils.isBlank(SIOCWEB_CODSOLIC)) {
				recuperarSolicitante(SIOCWEB_CODSOLIC);
			}
		}

	}

	public void botonBuscar() {
		buscar();
	}

	public void recuperarSolicitante(String solCodigo) {
		solicitante = solicitudBean.getSocSolicitanteDao().solicitanteByCod(solCodigo);
		cuentas = solicitudBean.getSocCuentassolDao().listaCuentasSolicitante(solicitante.getSolCodigo(), null, null, null, null, null, null, false);
	}

	public void buscar() {
		solicitantes.clear();
		String query = "";
		query = "select b.* from soc_solicitante b where b.sol_persona is not null ";

		if (!StringUtils.isBlank(socSolicitante.getSolPersona())) {
			query = query.concat("and upper(b.sol_persona) like '%" + socSolicitante.getSolPersona().toUpperCase() + "%' ");
		}

		if (!StringUtils.isBlank(socSolicitante.getLogin())) {
			query = query.concat("and exists (select 1 from soc_solcuentas c where c.sol_codigo = b.sol_codigo and c.cta_numero like '%" + socSolicitante.getLogin() + "%' ) ");
		}

		if (!StringUtils.isBlank(socSolicitante.getClaEntidad())) {
			query = query.concat("and b.cla_entidad = '" + socSolicitante.getClaEntidad() + "' ");
		}
		query = query.concat("order by b.sol_persona ");

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				SocSolicitante benefi0 = new SocSolicitante();
				benefi0.setSolCodigo((String) res.get("sol_codigo"));
				benefi0.setSolPersona((String) res.get("sol_persona"));
				benefi0.setClaEntidad((String) res.get("cla_entidad"));
				benefi0.setSolDireccion((String) res.get("sol_direccion"));
				benefi0.setClaVigente((Short) res.get("cla_vigente"));
				benefi0.setSolCodsigep((String) res.get("sol_codsigep"));
				solicitantes.add(benefi0);
			}
		}
	}

	public void adicionarCuenta() {
		log.info("XXX: adicionarCuenta" + solicitante.getSolCodigo());
		SocSolcuentasPK id = new SocSolcuentasPK();
		cta = new SocSolcuentas();
		cta.setId(id);

		cuentasMov.clear();
		List<SocCuentassol> socCuentassolList = solicitudBean.getSocCuentassolDao().ctasUnicas(null, null, null, true);
		for (SocCuentassol cuentasS : socCuentassolList) {
			cuentasMov.add(new SelectItem(cuentasS.getCtaCodigo(),
					"[" + cuentasS.getCtaMovimiento() + "] " + cuentasS.getCtaNommovimiento() + " - " + cuentasS.getCtaAfectable() + " " + cuentasS.getMoneda()));
		}
	}

	public void editarCuenta(CuentaS cta0) {
		cta = solicitudBean.getSocSolcuentasDao().getByCodigo(cta0.getSolCodigo(), cta0.getCtaCodigo(), cta0.getCorrCuenta());

		cuentasMov.clear();
		SocCuentassol socCuentassol = solicitudBean.getSocCuentassolDao().getByCodigo(cta.getId().getCtaCodigo());
		cuentasMov.add(new SelectItem(socCuentassol.getCtaCodigo(),
				"[" + socCuentassol.getCtaMovimiento() + "] " + socCuentassol.getCtaNommovimiento() + " - " + socCuentassol.getCtaAfectable() + " " + socCuentassol.getMoneda()));

	}

	public void adicionarSolic() {
		solicitante = new SocSolicitante();
	}

	public void guardarSolic() {
		try {
			solicitante.setClaVigente(Short.valueOf("1"));
			solicitante.setEstacion(getVisit().getAddress());
			solicitante.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			solicitante.setFechaHora(new Date());
			solicitudBean.getSocSolicitanteDao().saveOrUpdate(solicitante);

			solicitantes.clear();
			DropDownBean dropDownBean = getVisit().getMainController();
			log.info("XXX: dropDownBean.getPagina() " + dropDownBean.getPagina());
			dropDownBean.setPagina("/Modulos/Transferencias/listaSolicitantesDet.xhtml");
			getVisit().setParametro("SIOCWEB_CODSOLIC", solicitante.getSolCodigo());
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "VER_SOLICITANTE");

			recuperarSolicitante(solicitante.getSolCodigo());
			addMessageInfo("Aviso", "La operación se actualizó satisfactoriamente ");
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void guardar(SocSolcuentas socSolcuentas) {
		try {
			log.info("nueva cuenta " + socSolcuentas.getId().getCtaCodigo());

			socSolcuentas.setEstacion(getVisit().getAddress());
			socSolcuentas.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			socSolcuentas.setFechaHora(new Date());

			solicitudBean.getSocSolcuentasDao().saveOrUpdate(socSolcuentas);
			log.info("Se inserto el registro correctamente." + socSolcuentas.getId().getCtaCodigo());

			recuperarSolicitante(solicitante.getSolCodigo());
			addMessageInfo("Aviso", "La operación se actualizó satisfactoriamente ");
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void guardarCuenta() {
		log.info("nueva cuenta " + cta.getId().getCtaCodigo());
		Integer cod = solicitudBean.getSocSolcuentasDao().generarCodigo(solicitante.getSolCodigo(), cta.getId().getCtaCodigo());
		cta.getId().setCorrCuenta(cod);
		cta.getId().setSolCodigo(solicitante.getSolCodigo());
		cta.setClaVigente(Short.valueOf("1"));
		guardar(cta);
	}

	public void guardarCuentaM() {
		log.info("guardarCuentaM " + cta.getId().getCtaCodigo());
		cta.setClaVigente(Short.valueOf("1"));
		guardar(cta);

	}

	public void eliminarCuenta(CuentaS cta0) {
		try {
			cta = solicitudBean.getSocSolcuentasDao().getByCodigo(cta0.getSolCodigo(), cta0.getCtaCodigo(), cta0.getCorrCuenta());
			cta.setClaVigente(Short.valueOf("0"));

			cta.setEstacion(getVisit().getAddress());
			cta.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			cta.setFechaHora(new Date());

			solicitudBean.getSocSolcuentasDao().saveOrUpdate(cta);
			log.info("Se dio de baja el registro.");

			recuperarSolicitante(solicitante.getSolCodigo());
			addMessageInfo("Aviso", "La operación se actualizó satisfactoriamente ");
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void eventoGenerarBtn() {
		log.info("Guardando el solicitante: ");
		try {
			solicitante.setEstacion(getVisit().getAddress());
			solicitante.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			solicitante.setFechaHora(new Date());
			solicitudBean.getSocSolicitanteDao().saveOrUpdate(solicitante);

			log.info("Se modifico el registro correctamente.");
			recuperarSolicitante(solicitante.getSolCodigo());
			addMessageInfo("Aviso", "La operación se actualizó satisfactoriamente ");
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void verDatosBolsinVDirecta() {
		socValoresclaBolsin = solicitudBean.getSocValoresclaDao().getValoresByCodigo("cla_afec_b", solicitante.getSolCodigo());
		if (socValoresclaBolsin == null) {
			SocValoresclaPK socValoresclaPK = new SocValoresclaPK();
			socValoresclaPK.setClaCodigo("cla_afec_b");
			socValoresclaPK.setValCodigo(solicitante.getSolCodigo());
			socValoresclaBolsin = new SocValorescla();
			socValoresclaBolsin.setId(socValoresclaPK);
		}
		socValoresclaVD = solicitudBean.getSocValoresclaDao().getValoresByCodigo("cla_afec_vd", solicitante.getSolCodigo());
		if (socValoresclaVD == null) {
			SocValoresclaPK socValoresclaPK = new SocValoresclaPK();
			socValoresclaPK.setClaCodigo("cla_afec_vd");
			socValoresclaPK.setValCodigo(solicitante.getSolCodigo());
			socValoresclaVD = new SocValorescla();
			socValoresclaVD.setId(socValoresclaPK);
		}
	}

	public void guardarDatosBolsinVD() {
		try {
			socValoresclaBolsin.getId().setValCodigo(solicitante.getSolCodigo().trim());
			socValoresclaBolsin.setEstacion(getVisit().getAddress());
			socValoresclaBolsin.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			socValoresclaBolsin.setFechaHora(new Date());
			socValoresclaBolsin.setClaVigente(Short.valueOf("1"));
			solicitudBean.getSocValoresclaDao().saveOrUpdate(socValoresclaBolsin);

			socValoresclaVD.getId().setValCodigo(solicitante.getSolCodigo().trim());
			socValoresclaVD.setClaVigente(Short.valueOf("1"));
			socValoresclaVD.setEstacion(getVisit().getAddress());
			socValoresclaVD.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			socValoresclaVD.setFechaHora(new Date());
			solicitudBean.getSocValoresclaDao().saveOrUpdate(socValoresclaVD);

			List<SocCuentassol> socCuentassolLista = solicitudBean.getSocCuentassolDao().getCtasByCods(solicitante.getSolCodigo(), 69);
			SocCuentassol socCuentassol = null;
			if (socCuentassolLista.size() > 0) {
				socCuentassol = socCuentassolLista.get(0);
			} else {
				throw new RuntimeException("Cuenta en Bs inexistente para solicitante " + solicitante.getSolCodigo());
			}

			SocParticipante socParticipante = solicitudBean.getSocParticipanteDao().getParticipante(solicitante.getSolCodigo());
			if (socParticipante == null) {
				SocParticipantePK socParticipantePK = new SocParticipantePK();
				socParticipantePK.setSolCodigo(solicitante.getSolCodigo().trim());
				socParticipantePK.setCtaCodigo(Integer.valueOf(socCuentassol.getCtaMovimiento()));

				socParticipante = new SocParticipante();
				socParticipante.setId(socParticipantePK);
			}
			socParticipante.setMoneda("69");
			socParticipante.setSaldo(BigDecimal.valueOf(1000000000));
			socParticipante.setSaldop(BigDecimal.valueOf(0));
			socParticipante.setClaEstado("2");
			solicitudBean.getSocParticipanteDao().saveOrUpdate(socParticipante);

			addMessageInfo("Aviso", "La operación se actualizó satisfactoriamente ");
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void setCuentas(List<CuentaS> cuentas) {
		this.cuentas = cuentas;
	}

	public List<CuentaS> getCuentas() {
		return cuentas;
	}

	public void setCuentasMov(List<SelectItem> cuentasMov) {
		this.cuentasMov = cuentasMov;
	}

	public List<SelectItem> getCuentasMov() {
		return cuentasMov;
	}

	public SocSolicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setSocSolicitante(SocSolicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public SocSolicitante getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(SocSolicitante solicitante) {
		this.solicitante = solicitante;
	}

	public List<SocSolicitante> getSolicitantes() {
		return solicitantes;
	}

	public void setSolicitantes(List<SocSolicitante> solicitantes) {
		this.solicitantes = solicitantes;
	}

	public SocSolcuentas getCta() {
		return cta;
	}

	public void setCta(SocSolcuentas cta) {
		this.cta = cta;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public SocValorescla getSocValoresclaBolsin() {
		return socValoresclaBolsin;
	}

	public void setSocValoresclaBolsin(SocValorescla socValoresclaBolsin) {
		this.socValoresclaBolsin = socValoresclaBolsin;
	}

	public SocValorescla getSocValoresclaVD() {
		return socValoresclaVD;
	}

	public void setSocValoresclaVD(SocValorescla socValoresclaVD) {
		this.socValoresclaVD = socValoresclaVD;
	}
}
