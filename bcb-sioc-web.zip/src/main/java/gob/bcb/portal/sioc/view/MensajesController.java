package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.SocDatosmen;
import gob.bcb.bpm.pruebaCU.SocDatosmenId;
import gob.bcb.bpm.pruebaCU.SocMensajes;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class MensajesController extends BaseBeanController {
	private Logger log = Logger.getLogger(MensajesController.class);
	private List<SelectItem> conceptoItems = new ArrayList<SelectItem>();
	private List<SelectItem> esquemasItems = new ArrayList<SelectItem>();

	private String sIOCWEB_TIPOPERACION;
	private List<SocMensajes> socMensajesLista = new ArrayList<SocMensajes>();
	private SocMensajes socMensajesSelected = new SocMensajes();
	private SolicitudBean solicitudBean = new SolicitudBean();

	private List<Datosmen> datosmenLista = new ArrayList<Datosmen>();
	private Datosmen datosmenSelected = new Datosmen();
	private String urlReporte;
	private String swiftPlano;

	@PostConstruct
	public void inicio() {
		log.info("=============ooo00OOO00ooo===================");
		log.info("PostConstruct  " + getClass().getName());
		try {
			recuperarVisit();
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();
			solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);

			crearObjetosPorDefecto();

			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			String pagretorno = (String) getVisit().getParametro("pagretorno");
			log.info("pagretorno " + pagretorno);

			if (sIOCWEB_TIPOPERACION.equals("MENSAJES_VERLIST")) {
				recuperaMensaje(null, null, null, "E");
				getVisit().setParametro("pagretorno", dd.getPagina());
			} else if (sIOCWEB_TIPOPERACION.equals("VER_DETMENSAJE")) {

				if (getVisit().getParametro().containsKey("SIOCWEB_SOCCODIGO") && getVisit().getParametro().containsKey("SIOCWEB_DETCODIGO")) {
					String detc = (String) getVisit().getParametro("SIOCWEB_DETCODIGO");
					recuperaMensaje(null, (String) getVisit().getParametro("SIOCWEB_SOCCODIGO"), Integer.valueOf(detc), null);
				}

			} else if (sIOCWEB_TIPOPERACION.equals("MENSAJES_DETVER")) {

				if (getVisit().getParametro().containsKey("SIOCWEB_MENCODIGO")) {
					recuperaMensaje((String) getVisit().getParametro("SIOCWEB_MENCODIGO"), null, null, null);
				}
			}

		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "OcurriÃ³ un error: " + e.getMessage(), null));
		}

	}

	public void botonGuardarSwift(ActionEvent actionEvent) {
		try {
			log.info("en botonAutorizarSwift " + socMensajesSelected.toString());

			Solicitud solicitudTemp = new Solicitud();
			SocSolicitudes socSolicitudes = new SocSolicitudes();
			socSolicitudes.setSocCodigo(socMensajesSelected.getOpeCodigo());

			solicitudTemp.setSolicitud(socSolicitudes);
			//solicitudTemp.getSocMensajesLista().add(socMensajesSelected);

			// registramos solo los mensajes swifts
			solicitudBean.generarSwifts(solicitudTemp, socMensajesSelected);

			String mensajeError = "La operacion se actualizo " + socMensajesSelected.getOpeCodigo();
			log.info("fin botonGuardarSwift " + mensajeError + " cod " + socMensajesSelected.getOpeCodigo());

			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError, null));
			recuperaMensaje(socMensajesSelected.getInsCodigo(), null, null, null);

		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}

	}

	public String botonAutorizarSwift() {
		try {
			log.info("en botonAutorizarSwift " + socMensajesSelected.toString());

			// guardarDetalle();
			// registramos solo los mensajes swifts
			//solicitudBean.autorizaSwift(socMensajesSelected);

			String mensajeError = "La operaciÃ³n se generÃ³ exitosamente los mensajes swift fueron creados para solicitud "
					+ socMensajesSelected.getOpeCodigo() + " a fecha valor "
					+ UtilsDate.stringFromDate(socMensajesSelected.getMenFechavalor(), "dd/MM/yyyy");

			log.info("fin botonGenerarMensSwiftFValor " + mensajeError);

			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError, null));

			botonRetornar();

			return "";
		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
			return "";
		}

	}

	public String botonAnularSwift() {
		try {
			log.info("en botonAnularSwift " + socMensajesSelected.toString());

			// guardarDetalle();
			// registramos solo los mensajes swifts
			//solicitudBean.anularSwift(socMensajesSelected);

			String mensajeError = "Mensaje swift anulado";

			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, mensajeError, null));

			botonRetornar();

			return "";
		} catch (Exception e) {
			// sessionContext.setRollbackOnly();
			String mensajeError = "La operaciÃ³n generÃ³ ERROR: " + e.getMessage();
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
			return "";
		}

	}

	public String botonRetornar() {

		log.info("en botonRetornar ");

		DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
		log.info("XXX: botonRetornar this.pagina= " + dd.getPagina());

		String pagretorno = (String) getVisit().getParametro("pagretorno");
		log.info("pagretorno " + pagretorno);

		if (sIOCWEB_TIPOPERACION.equals("VER_DETMENSAJE")) {
			dd.setPagina(pagretorno);
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "VER_SOLICITUD");

		} else if (sIOCWEB_TIPOPERACION.equals("MENSAJES_DETVER")) {
			dd.setPagina(pagretorno);
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "MENSAJES_VERLIST");
			recuperaMensaje(null, null, null, "E");
		}

		return "";
	}

	public String cancelarCambios() {
		recuperaMensaje(socMensajesSelected.getInsCodigo(), null, null, null);
		return null;
	}

	public void recuperaMensaje(String insCodigo, String opeCodigo, Integer detCodigo, String claEstadomen) {
		socMensajesLista = getSolicitudBean().getSocMensajesDao().mensajesByParams(insCodigo, opeCodigo, detCodigo, claEstadomen);
		if (socMensajesLista != null && socMensajesLista.size() == 1) {
			socMensajesSelected = socMensajesLista.get(0);
			datosmenLista = recuperarDatosmen(socMensajesSelected.getInsCodigo());
		} else {
			socMensajesSelected = new SocMensajes();
			datosmenLista = new ArrayList<Datosmen>();
		}
	}

	public void swiftFormatoPlano(ActionEvent event) {
		try {
			swiftPlano = "";
			if (socMensajesSelected != null && !StringUtils.isBlank(socMensajesSelected.getInsCodigo())) {
				log.info("Antes de swiftFormatoPlano " + socMensajesSelected.getInsCodigo());
				//swiftPlano = solicitudBean.generarSwiftPlano(socMensajesSelected);
			}
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error!!: " + e.getMessage(), null));
		}

	}

	public List<Datosmen> recuperarDatosmen(String insCodigo) {
		List<Datosmen> datosmenList = new ArrayList<Datosmen>();

		String query1 = "select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
				+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + insCodigo + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
		for (Map<String, Object> res : resultado1) {
			Datosmen datosmen = new Datosmen();
			datosmen.setCamCodigo((String) res.get("cam_codigo"));
			datosmen.setInsCodigo((String) res.get("ins_codigo"));
			datosmen.setDamValor((String) res.get("dam_valor"));
			datosmen.setDesc((String) res.get("cam_nombre"));

			datosmenList.add(datosmen);
		}

		return datosmenList;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + socMensajesSelected.getInsCodigo() + "&tipo=SW";
		return urlReporte;
	}

	private void crearObjetosPorDefecto() {
		conceptoItems.add(new SelectItem("F", "PAGO FACTURA"));
		conceptoItems.add(new SelectItem("O", "OTROS"));
		
		esquemasItems = llenarEsquemas();
	}

	public void mostrarReporte(ActionEvent event) {
		log.info("Antes de reporte " + socMensajesSelected.getInsCodigo());
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("cod", socMensajesSelected.getInsCodigo());
		parametros.put("tipo", "SW");
		parametros.put("TITULO", "EMISION DE INSTRUMENTO");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "repApertura.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}

	public List<SocMensajes> getSocMensajesLista() {
		return socMensajesLista;
	}

	public void setSocMensajesLista(List<SocMensajes> socMensajesLista) {
		this.socMensajesLista = socMensajesLista;
	}

	public SocMensajes getSocMensajesSelected() {
		return socMensajesSelected;
	}

	public void setSocMensajesSelected(SocMensajes socMensajesSelected) {
		this.socMensajesSelected = socMensajesSelected;
	}

	public List<Datosmen> getDatosmenLista() {
		return datosmenLista;
	}

	public void setDatosmenLista(List<Datosmen> datosmenLista) {
		this.datosmenLista = datosmenLista;
	}

	public List<SelectItem> getEsquemasItems() {
		return esquemasItems;
	}

	public void setEsquemasItems(List<SelectItem> esquemasItems) {
		this.esquemasItems = esquemasItems;
	}

	public Datosmen getDatosmenSelected() {
		return datosmenSelected;
	}

	public void setDatosmenSelected(Datosmen datosmenSelected) {
		this.datosmenSelected = datosmenSelected;
	}

	public String getSwiftPlano() {
		return swiftPlano;
	}

	public void setSwiftPlano(String swiftPlano) {
		this.swiftPlano = swiftPlano;
	}

}
