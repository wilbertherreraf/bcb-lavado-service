package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocBenefslocal;
import gob.bcb.bpm.pruebaCU.SocBenefslocalId;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Venta;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class SolicitudesAutController extends BaseBeanController {
	private SocSolicitudes solicitud = new SocSolicitudes();
	private SolicitudesS solicitudS = new SolicitudesS();
	private SocDetallessol detalle = new SocDetallessol();
	private SocBenefslocal benef = new SocBenefslocal();
	private CuentasBen cuentaBen = new CuentasBen();
	private Venta venta = new Venta();
	private List<SolicitudesS> solicitudes;
	private List<SocSolicitudes> listaSoli;
	private List<Venta> ventas;

	private String panel = "";
	private String verP = "";
	private String provision = "NO";
	private String descuento = "NO";
	private String idSoli = "-1";
	private String cuentaD = "";
	private String cuentaC = "";
	private String cuentaB = "";
	private String nroPago = "";
	private String moneda = "";
	private Boolean montoVer = false;
	private Boolean cuentaVer = true;
	private Boolean cuentaCVer = true;
	private Boolean nroVer = false;
	private Boolean generada = true;
	private Boolean interVer = false;
	private Boolean extVer = true;
	private Boolean localVer = false;
	private Boolean sigma = true;
	private Boolean opVer = true;
	private Boolean ccVer = false;
	private Boolean botonHab = false;
	private String nombre = "";
	private String mensaje = "";
	private String label1 = "BIC:";
	private String bic = "";
	private String subtipo = "";
	private Boolean interno = true;

	private Logger log = Logger.getLogger(SolicitudesAutController.class);

	public SolicitudesAutController() {

		recuperarVisit();
		String usuario = getVisit().getUsuarioSession().getLogin();

		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		this.recuperarSolicitudes();
	}

	private void recuperarSolicitudes() {
		Timestamp hora = Servicios.getFechaHora();
		DateTime hora1 = new DateTime(hora);
		Integer horaL2 = Servicios.getHoraLimite("transfextAut");

		this.solicitudes = new ArrayList<SolicitudesS>();
		this.listaSoli = new ArrayList<SocSolicitudes>();

		String query = "";

		if (!idSoli.equals("900")) {
			interno = false;
			if (hora1.getHourOfDay() >= horaL2) {
				// CCUH SIOC V.2
				// R-04 Incluir opciones separadas para IDH, Regalías
				// Se crearon nuevos tipos de operaciones para registrar
				// solicitudes
				// 02-07-2013
				query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
						+ " and s.cla_estado = 'B'" + " and substr(s.cla_tipo,1,2) = 'TC'" + " and trim(s.sol_codigo) = '" + idSoli + "'";
			} else {
				query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
						+ " and s.cla_estado = 'B'" + " and trim(s.sol_codigo) = '" + idSoli + "'";
			}
		} else {
			interno = true;
			idSoli = "-1";
			if (hora1.getHourOfDay() >= horaL2) {
				query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
						+ " and s.cla_estado = 'B'" + " and substr(s.cla_tipo,1,2) = 'TC'" + " and ss.cla_entidad = 'SP'";
			} else {
				query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
						+ " and s.cla_estado = 'B'" + " and ss.cla_entidad = 'SP'";
			}
		}

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'B', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");
				if (solicitudS.getClaTipo().equals("TE")) {
					solicitudS.setPanel1(true);
					solicitudS.setPanel2(false);
					solicitudS.setPanel3(false);
					solicitudS.setTipo("TRANSFERENCIA AL EXTERIOR");
				} else {
					// CCUH SIOC V.2
					// R-04 Incluir opciones separadas para IDH, Regalías
					// Se crearon nuevos tipos de operaciones para registrar
					// solicitudes
					// 02-07-2013
					if (solicitudS.getClaTipo().startsWith("TC")) {
						solicitudS.setPanel1(false);
						solicitudS.setPanel2(true);
						solicitudS.setPanel3(false);
						solicitudS.setTipo("TRANSFERENCIA CUENTA A CUENTA");
					} else {
						solicitudS.setPanel1(false);
						solicitudS.setPanel2(false);
						solicitudS.setPanel3(true);
						solicitudS.setTipo("VENTA DE DIVISAS");
					}
				}
				solicitudes.add(solicitudS);

				solicitud = new SocSolicitudes((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_tipo"),
						(Integer) res.get("soc_cuentad"), (String) res.get("soc_nrocuentad"), (String) res.get("moneda"), 'B',
						(Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (Integer) res.get("soc_cuentac"),
						(String) res.get("soc_nrocuentac"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"),
						(BigDecimal) res.get("soc_montomn"), (String) res.get("soc_nropago"), (String) res.get("monedat"));
				listaSoli.add(solicitud);
			}
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudS = this.solicitudes.get(fila);
		this.solicitud = this.listaSoli.get(fila);
		botonHab = false;
		opVer = true;

		// CCUH SIOC V.2
		// R-04 Incluir opciones separadas para IDH, Regalías
		// Se crearon nuevos tipos de operaciones para registrar solicitudes
		// 02-07-2013
		if (solicitud.getClaTipo().startsWith("TC")) {
			// transferencia local
			nroVer = (StringUtils.isBlank(solicitud.getSocNrocuentad()));

			String query = " select d.*, b.ben_nombre, b.ben_nit, b.ben_factura, c.cta_nrocuenta, c.moneda, c.cta_nrocuenta1, c.moneda1, s.cta_nommovimiento "
					+ " from soc_detallessol d, soc_benefsloc b, soc_cuentasloc c, soc_cuentassol s "
					+ " where d.soc_codigo = '"
					+ solicitud.getSocCodigo()
					+ "'"
					+ " and d.det_codigo = 1"
					+ " and d.ben_codigo = b.ben_codigo "
					+ " and d.det_ctabenef = c.cta_codigo " + " and c.cta_ctacodigo = s.cta_codigo";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					Integer mm = (Integer) res.get("moneda");
					detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
							(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), String.valueOf(mm), (Integer) res.get("det_ctabenef"),
							(String) res.get("det_concepto"), "", (BigDecimal) res.get("det_montoord"), String.valueOf(mm),
							(String) res.get("det_facturas"));
					benef = new SocBenefslocal(new SocBenefslocalId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
							(String) res.get("cta_nommovimiento"), (String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"),
							(String) res.get("ben_factura"), (String) res.get("ben_nit"));
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentad() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {
					cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-USD";
				}
			}

			if (solicitud.getSocCuentac() != null) {
				query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
						+ solicitud.getSocCuentac() + "'";

				List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
				if (resultadoC.size() == 1) {
					for (Map<String, Object> res : resultadoC) {
						if ((Integer) res.get("moneda") == 34)
							moneda = "-USD";
						if ((Integer) res.get("moneda") == 69)
							moneda = "";
						cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
					}
				}

				provision = "SOLICITANTE";
				montoVer = false;
				cuentaVer = true;
			} else {
				provision = "BENEFICIARIO";
				montoVer = true;
				cuentaVer = false;
			}
		} else if (solicitud.getClaTipo().equals("VE")) {
			// venta de divisas
			nroVer = StringUtils.isBlank(solicitud.getSocNrocuentad());

			this.ventas = new ArrayList<Venta>();

			String query = "select ben_codigo from soc_detallessol where soc_codigo = '" + solicitud.getSocCodigo() + "' and det_codigo = 1";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					subtipo = (String) res.get("ben_codigo");
				}
			}
			if (subtipo.equals("999998")) { // orden de pago
				subtipo = "TC";
				interVer = false;
				extVer = false;
				localVer = true;
				opVer = false;
				ccVer = false;
				query = " select s.*, b.*" + " from soc_detallessol s, soc_benefslocal b" + " where s.soc_codigo = '" + solicitud.getSocCodigo()
						+ "'" + " and b.soc_codigo = s.soc_codigo " + " and b.det_codigo = s.det_codigo";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					for (Map<String, Object> res : resultado1) {
						venta = new Venta((String) res.get("beneficiario"), (String) res.get("cta_benef"), "", (BigDecimal) res.get("det_monto"),
								"999998", (String) res.get("moneda"), 0, "", (Integer) res.get("det_codigo"));
						ventas.add(venta);
					}
				}
			} else if (!subtipo.startsWith("0")) {
				// transf. sist. financ.
				subtipo = "TC";
				interVer = false;
				extVer = false;
				localVer = true;
				ccVer = false;

				query = " select d.*, b.ben_nombre, c.cta_nrocuenta, c.moneda, s.cta_nommovimiento "
						+ " from soc_detallessol d, soc_benefsloc b, soc_cuentasloc c, soc_cuentassol s " + " where d.soc_codigo = '"
						+ solicitud.getSocCodigo() + "'" + " and d.ben_codigo = b.ben_codigo " + " and d.det_ctabenef = c.cta_codigo "
						+ " and c.cta_ctacodigo = s.cta_codigo";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					for (Map<String, Object> res : resultado1) {
						Integer mon = (Integer) res.get("moneda");
						venta = new Venta((String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_nommovimiento"),
								(BigDecimal) res.get("det_monto"), "999999", mon.toString(), 0, "", (Integer) res.get("det_codigo"));
						ventas.add(venta);
					}
				}

			} else { // transf. al exterior
				subtipo = "TE";
				extVer = true;
				localVer = false;
				ccVer = false;
				query = "select s.*, b.ben_nombre, c.cta_nrocuenta, bb.bco_nombre, p.pla_nombre "
						+ "from soc_detallessol s, soc_benefs b, soc_plazas p, soc_bancos bb, soc_cuentas c "
						+ "where b.ben_codigo = s.ben_codigo and c.cta_codigo = s.det_ctabenef "
						+ "and c.bco_codigo = bb.bco_codigo and p.bco_codigo = bb.bco_codigo "
						+ "and c.pla_codigo = p.pla_codigo and s.soc_codigo = '" + solicitud.getSocCodigo() + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					for (Map<String, Object> res : resultado1) {
						venta = new Venta((String) res.get("ben_nombre"), (String) res.get("cta_nrocuenta"), (String) res.get("bco_nombre") + " - "
								+ (String) res.get("pla_nombre"), (BigDecimal) res.get("det_monto"), (String) res.get("ben_codigo"),
								(String) res.get("moneda"), (Integer) res.get("det_ctabenef"), (String) res.get("det_info"),
								(Integer) res.get("det_codigo"));
						ventas.add(venta);
					}
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentad() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {
					cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "";
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentac() + "'";

			List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
			if (resultadoC.size() == 1) {
				for (Map<String, Object> res : resultadoC) {
					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
				}
			}

			if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
				setDescuento("SI");
				montoVer = true;
				cuentaCVer = false;
			} else {
				setDescuento("NO");
				montoVer = false;
				cuentaCVer = true;
			}

			if (solicitud.getSocCuentad() == 5) {
				provision = "SIGMA";
				cuentaVer = false;
				sigma = true;
			} else {
				provision = "CUENTA CORRIENTE FISCAL";
				cuentaVer = true;
				sigma = false;
			}

		} else {
			// transferencia al exterior
			nroVer = StringUtils.isBlank(solicitud.getSocNrocuentad());

			String query = " select s.* " + " from soc_detallessol s " + " where s.soc_codigo = '" + solicitud.getSocCodigo() + "'"
					+ " and s.det_codigo = 1";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() > 0) {
				for (Map<String, Object> res : resultado1) {
					detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
							(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), (String) res.get("moneda"),
							(Integer) res.get("det_ctabenef"), (String) res.get("det_concepto"), (String) res.get("det_info"),
							(BigDecimal) res.get("det_montoord"), (String) res.get("monedat"), (String) res.get("det_facturas"));
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentad() + "'";

			List<Map<String, Object>> resultadoD = Servicios.ejecutarQuery(query);
			if (resultadoD.size() == 1) {
				for (Map<String, Object> res : resultadoD) {
					cuentaD = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + "-USD";
				}
			}

			query = " select cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento " + " from soc_cuentassol cc " + " where cc.cta_codigo = '"
					+ solicitud.getSocCuentac() + "'";

			List<Map<String, Object>> resultadoC = Servicios.ejecutarQuery(query);
			if (resultadoC.size() == 1) {
				for (Map<String, Object> res : resultadoC) {
					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					cuentaC = res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda;
				}
			}

			query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.ben_codigo) = '" + detalle.getBenCodigo() + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					nombre = (String) res.get("ben_nombre");
				}
			}

			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
					+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
					+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
					+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalle.getDetCtabenef() + "'";

			List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query);
			if (resultado2.size() == 1) {
				interVer = true;
				for (Map<String, Object> res : resultado2) {
					cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
							(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"),
							(String) res.get("pla_intermediario"), (String) res.get("pla_nrocuenta"), (String) res.get("bco1"),
							(String) res.get("pla1"));
				}
				label1 = "Cuenta:";
				bic = cuentaBen.getPlaNroCuenta();
			} else {
				query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
						+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
						+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
						+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + detalle.getDetCtabenef() + "'";

				List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
				if (resultado3.size() == 1) {
					interVer = false;
					for (Map<String, Object> res : resultado3) {

						cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
								(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"),
								(String) res.get("pla_bic"));
					}
					label1 = "BIC:";
					bic = cuentaBen.getPlaBic();
				} else {
					interVer = false;
				}
			}

			if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
				descuento = "SI";
				montoVer = true;
				cuentaVer = false;
			} else {
				descuento = "NO";
				montoVer = false;
				cuentaVer = true;
			}
		}

	}

	public void verBenef(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		venta = (Venta) SerializationUtils.clone(this.ventas.get(fila));

		String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
				+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
				+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
				+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
				+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
				+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			interVer = true;
			for (Map<String, Object> res : resultado) {

				cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
						(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"),
						(String) res.get("pla_intermediario"), (String) res.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1"));
			}
			label1 = "Cuenta:";
			bic = cuentaBen.getPlaNroCuenta();
		} else {
			query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic "
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
					+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + venta.getDetCtabenef() + "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1.size() == 1) {
				interVer = false;
				for (Map<String, Object> res : resultado1) {

					cuentaBen = new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res.get("cta_info"),
							(Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"), (String) res.get("pla_bic"));
				}
				label1 = "BIC:";
				bic = cuentaBen.getPlaBic();
			} else {
				interVer = false;
			}
		}
	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Autorizando la provisión: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();

		if (solicitud.getClaTipo().equals("VE")) {
			if (sigma) {
				// Provisi�n SIGMA
				if (!interno) {

					mapaParametros.put("opcion", "provisionS");
					mapaParametros.put("solicitud", solicitud);
					mapaParametros.put("subtipo", subtipo);
					/*
					 * } else continuar = false;
					 */
				} else {
					mapaParametros.put("opcion", "provisionS");
					mapaParametros.put("solicitud", solicitud);
					mapaParametros.put("subtipo", subtipo);
				}
			} else {
				// Provisi�n cuenta fiscal
				mapaParametros.put("opcion", "provisionV");
				mapaParametros.put("solicitud", solicitud);
				mapaParametros.put("subtipo", subtipo);
			}
		} else if (solicitud.getClaTipo().equals("TCRG")) { // Pago de Regalías
			// CCUH SIOC V.2
			// R-04 Incluir opciones separadas para IDH, Regalías
			// Se crearon nuevos tipos de operación y opciones separadas para
			// autorizar
			// 01-07-2013

			mapaParametros.put("opcion", "provisionReg");
			mapaParametros.put("solicitud", solicitud);
			mapaParametros.put("detalle", detalle);
		} else if (solicitud.getClaTipo().equals("TCID")) { // Pago de IDH

			mapaParametros.put("opcion", "provisionIDH");
			mapaParametros.put("solicitud", solicitud);
			mapaParametros.put("detalle", detalle);
		} else { // Transferencias locales y Transferencias al exterior
			mapaParametros.put("opcion", "provision");
			mapaParametros.put("solicitud", solicitud);
			mapaParametros.put("detalle", detalle);
		}
		Boolean continuar = true;
		if (solicitud.getClaTipo().equals("TC")) {
			if (solicitud.getSocCuentac() != null && solicitud.getSocCuentac() == -1) {
				continuar = false;
			}
		}

		if (continuar) {
			// Metodo estatico que se encarga de manejar las consultas al BPM
			// parametros
			// nombre BPM, ipRequest, requester, feature, mapaParametros, id
			Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros,
					id);
			if (mapaRespuesta.containsKey("resp_msgerror")) {
				mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
				return;
			}

			String estado = (String) mapaRespuesta.get("estado");
			log.info("Estado asignado desde el BPM: " + estado);

			if (!estado.equals("-1")) {
				if (solicitud.getClaTipo().startsWith("TC"))
					mensaje = "La solicitud " + solicitud.getSocCorrelativo() + " se autorizó correctamente y se realizó la transferencia de fondos.";
				else
					mensaje = "La solicitud " + solicitud.getSocCorrelativo() + " se autorizó correctamente.";
			} else {
				mensaje = "Se produjo un error al autorizar la solicitud.";
			}

			this.recuperarSolicitudes();
		} else {
			this.mensaje = "No se puede autorizar la solicitud, no se ha seleccionado una cuenta para las comisiones.";
		}
		botonHab = true;
	}

	public void eventoAnularBtn(ActionEvent action) {
		log.info("Anulando la solicitud: ");

		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "anular");

		mapaParametros.put("solicitud", solicitud);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");
		log.info("Estado asignado desde el BPM: " + estado);

		mensaje = "Se anuló la solicitud registrada.";
		botonHab = true;
		this.recuperarSolicitudes();
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitud) {
		this.solicitud = solicitud;
	}

	public SolicitudesS getSolicitudS() {
		return solicitudS;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudS = solicitudS;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public Venta getVenta() {
		return venta;
	}

	public void setVenta(Venta venta) {
		this.venta = venta;
	}

	public SocBenefslocal getBenef() {
		return benef;
	}

	public void setBenef(SocBenefslocal benef) {
		this.benef = benef;
	}

	public CuentasBen getCuentaBen() {
		return cuentaBen;
	}

	public void setCuentaBen(CuentasBen cuentaBen) {
		this.cuentaBen = cuentaBen;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public List<Venta> getVentas() {
		return ventas;
	}

	public void setVentas(List<Venta> ventas) {
		this.ventas = ventas;
	}

	public String getPanel() {
		return panel;
	}

	public void setPanel(String panel) {
		this.panel = panel;
	}

	public String getVerP() {
		return verP;
	}

	public void setVerP(String verP) {
		this.verP = verP;
	}

	public String getProvision() {
		return provision;
	}

	public void setProvision(String provision) {
		this.provision = provision;
	}

	public String getDescuento() {
		return descuento;
	}

	public void setDescuento(String descuento) {
		this.descuento = descuento;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getCuentaVer() {
		return cuentaVer;
	}

	public void setCuentaVer(Boolean cuentaVer) {
		this.cuentaVer = cuentaVer;
	}

	public Boolean getCuentaCVer() {
		return cuentaCVer;
	}

	public void setCuentaCVer(Boolean cuentaCVer) {
		this.cuentaCVer = cuentaCVer;
	}

	public void setNroVer(Boolean nroVer) {
		this.nroVer = nroVer;
	}

	public Boolean getNroVer() {
		return nroVer;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public Boolean getSigma() {
		return sigma;
	}

	public void setSigma(Boolean sigma) {
		this.sigma = sigma;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public Boolean getGenerada() {
		return generada;
	}

	public void setGenerada(Boolean generada) {
		this.generada = generada;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getCuentaD() {
		return cuentaD;
	}

	public void setCuentaD(String cuentaD) {
		this.cuentaD = cuentaD;
	}

	public String getCuentaC() {
		return cuentaC;
	}

	public void setCuentaC(String cuentaC) {
		this.cuentaC = cuentaC;
	}

	public String getCuentaB() {
		return cuentaB;
	}

	public void setCuentaB(String cuentaB) {
		this.cuentaB = cuentaB;
	}

	public String getNroPago() {
		return nroPago;
	}

	public void setNroPago(String nroPago) {
		this.nroPago = nroPago;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public void setExtVer(Boolean extVer) {
		this.extVer = extVer;
	}

	public Boolean getExtVer() {
		return extVer;
	}

	public void setLocalVer(Boolean localVer) {
		this.localVer = localVer;
	}

	public Boolean getLocalVer() {
		return localVer;
	}

	public void setOpeVer(Boolean opVer) {
		this.opVer = opVer;
	}

	public Boolean getOpVer() {
		return opVer;
	}

	public void setCcVer(Boolean ccVer) {
		this.ccVer = ccVer;
	}

	public Boolean getCcVer() {
		return ccVer;
	}

}
