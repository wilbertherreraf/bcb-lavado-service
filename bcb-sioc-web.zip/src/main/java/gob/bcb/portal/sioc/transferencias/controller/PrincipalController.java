package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.Opecomi;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;

import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.commons.Visit;
import gob.bcb.portal.sioc.view.SolicitudBean;
import gob.bcb.service.servicioSioc.common.MensSwiftUtiles;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class PrincipalController extends BaseBeanController {

	private SocSolicitudes solicitud = new SocSolicitudes();
	private SocDetallessol detalle = new SocDetallessol();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> monedasT = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private List<SelectItem> benefs = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
	private List<SelectItem> conceptos = new ArrayList<SelectItem>();
	private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
	private CuentasBen cuentaBSelected = new CuentasBen();
	private Opecomi comision = new Opecomi();
	private List<Opecomi> comisiones = new ArrayList<Opecomi>();
	private String[][] comis = new String[3][2];
	private String nroSolicitud = "";
	private String idSoli = "-1";
	private String idBenef = "-1";
	private String idCuenta = "-1";
	private Integer idCuentaB = -1;
	private String idDescuento = "NO";
	private String idFijo = "F";
	private String idConcepto = "-1";
	private String concepto = "";
	private String conceptoO = "";
	private String conc = "-1";
	private String nroCuenta = "";
	private String cuenta = "";
	private String bic = "";
	private String bic1 = "";
	private String banco = "";
	private String plaza = "";
	private String informa = "";
	// private String info1 = "";
	private String adicional = "";
	private String mensaje = "";
	private String label1 = "";
	private String label2 = "";
	private String labelM = "Monto a Transferir:";
	private String labelE = "Equivalente en USD:";
	private BigDecimal montoOrd = BigDecimal.valueOf(0);
	private BigDecimal montoEquiv = BigDecimal.valueOf(0);
	private BigDecimal total = BigDecimal.valueOf(0);
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean comiVer = false;
	private Boolean botonHab = true;
	private Boolean interVer = false;
	private Boolean infoVer = false;
	private Boolean otroVer = false;
	private Boolean fijoVer = false;
	private Boolean fijo = true;
	private Boolean fijoT = false;
	private Boolean continuar;

	private String urlReporte;
	private SolicitudBean solicitudBean = new SolicitudBean();
	private Logger log = Logger.getLogger(PrincipalController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";

	// private static final String ESTACION = "172.29.18.3-curiona";
	// private static final String ESTACION = "";

	/*
	 * private String pagina = ""; public String getPagina() { return pagina; }
	 * public void setPagina(String pagina) { this.pagina = pagina; }
	 * 
	 * @SuppressWarnings("rawtypes") public void listenerMenu(ActionEvent event)
	 * { FacesContext facesContext = FacesContext.getCurrentInstance(); Map map
	 * = facesContext.getExternalContext().getRequestParameterMap();
	 * System.out.println(map.get("pagina").toString()); this.pagina = (String)
	 * map.get("pagina"); }
	 */

	@SuppressWarnings("unchecked")
	public PrincipalController() {
		recuperarVisit();
		solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
		String usuario = getVisit().getUsuarioSession().getLogin();
		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		String query = "";

		if (!idSoli.equals("900")) {

			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SP' "
					+ " and cla_vigente = 1" + " and trim(sol_codigo) = '" + idSoli + "'";
		} else {
			idSoli = "-1";
			query = " select trim(sol_codigo) as cod, sol_persona " + " from soc_solicitante " + " where cla_entidad = 'SP' "
					+ " and cla_vigente = 1" + " order by sol_persona";
		}

		solicitud = new SocSolicitudes();
		solicitud.setMonedaT("-1");
		solicitud.setSocMontome(BigDecimal.valueOf(0));

		monedas.add(new SelectItem("USD", "DOLARES ESTADOUNIDENSES"));
		monedas.add(new SelectItem("EUR", "EUROS"));
		monedas.add(new SelectItem("SEK", "CORONAS SUECAS"));
		monedas.add(new SelectItem("CHF", "FRANCOS SUIZOS"));// monedas.add(new
																// SelectItem("GBP",
																// "LIBRAS ESTERLINAS"));

		conceptos.add(new SelectItem("INV", "PAGO FACTURA"));
		conceptos.add(new SelectItem("OTR", "OTROS"));

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {

				solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
			}
		}

	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		cuentasD.clear();		
		cuentaBSelected = new CuentasBen();		
		if (!idSoli.equals("-1")) {

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") != 69) {
						if (res.get("cta_numero") != null) {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD-" + res.get("cta_numero")));
						} else {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD"));
						}
					}
				}
			}
		} 

		return cuentasD;
	}

	public List<SelectItem> getBenefs() {
		log.info("enter getbenefs");
		log.info("soli: " + idSoli);
		if (!idSoli.equals("-1")) {

			benefs.clear();

			String query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '" + idSoli + "' " + "ORDER BY bb.ben_nombre ";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			for (Map<String, Object> res : resultado) {
					//
				benefs.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
			}
		} else {
			benefs.clear();
		}

		return benefs;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getCuentasB() {
		cuentasB.clear();
		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";
		cuentaBSelected = new CuentasBen();
		Integer codMon = null;
		if (!StringUtils.isBlank(solicitud.getMonedaT())){
		if (solicitud.getMonedaT().equals("USD")) {
			codMon = 34;
		} else if (solicitud.getMonedaT().equals("EUR")) {
			codMon = 53;
		} else if (solicitud.getMonedaT().equals("CHF")) {
			codMon = 31;
		} else if (solicitud.getMonedaT().equals("SEK")) {
			codMon = 30;
		}
		}
		List<CuentasBen> listaCuentasB0 = solicitudBean.getSocBenefsDao().cuentasBenefExterior(null, idBenef, null, codMon, null, null, null, null, null, true);
		for (CuentasBen cuentasBen0 : listaCuentasB0) {
			String moneda = "";
			if (cuentasBen0.getMoneda().compareTo(34) == 0) {
				moneda = "USD";
			} else if (cuentasBen0.getMoneda().compareTo(53) == 0) {
				moneda = "EUR";
			} else if (cuentasBen0.getMoneda().compareTo(31) == 0) {
				moneda = "CHF";
			} else if (cuentasBen0.getMoneda().compareTo(30) == 0) {
				moneda = "SEK";
			} else {
				moneda = "";
			}
			cuentasB.add(new SelectItem(cuentasBen0.getCtaCodigo(), cuentasBen0.getCtaNroCuenta() + " - " + moneda));

			listaCuentasB.add(cuentasBen0);

		}

		return cuentasB;

	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getCuentasC() {
		String idC;
		String moneda = "";

		if (!idCuenta.equals("-1")) {
			cuentasC.clear();

			if ("SI".equals(idDescuento)) {
				idC = Integer.toString(0);
			} else {
				idC = idCuenta;
			}

			log.info("idc:" + idC);

			String query = " SELECT sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " FROM soc_solcuentas sc, soc_cuentassol cc "
					+ " WHERE sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					if (res.get("cta_numero") != null) {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda
								+ "-" + res.get("cta_numero")));
					} else {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda));
					}
				}
			}
		} else {
			cuentasC.clear();
		}

		return cuentasC;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		idCuentaB = sel;
		log.info("Valor seleccionado: " + sel);

		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";
		interVer = false;
		if (idCuentaB != -1) {
			for (CuentasBen cuentaB : listaCuentasB) {
				interVer = (!StringUtils.isBlank(cuentaB.getPlaIntermediario()));				
				if (cuentaB.getCtaCodigo().compareTo(idCuentaB) == 0) {
					cuentaBSelected = cuentaB;
					if (!interVer) {
						bic = cuentaB.getPlaBic();
						if (bic != null)
							label2 = "BIC:";
						else {
							bic = cuentaB.getPlaNroCuenta();
							label2 = "Cuenta:";
						}
					} else {
						bic = cuentaB.getPlaNroCuenta();
						if (bic != null)
							label2 = "Cuenta:";
						else {
							bic = cuentaB.getPlaBic();
							label2 = "BIC:";
						}
					}
					cuenta = cuentaB.getCtaNroCuenta();
					banco = cuentaB.getBcoNombre() + " - " + cuentaB.getPlaNombre();
					bic1 = cuentaB.getPlaIntermediario();
					plaza = cuentaB.getBcoNombreI() + " - " + cuentaB.getPlaNombreI();
					informa = cuentaB.getCtaInfo();
					// if (informa != null) {
					// info1 = informa;
					// log.info("info: " + info1);
					// }
				}
			}
		}
		setInfoVer(!StringUtils.isBlank(informa));
	}

	public void seleccion1Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idConcepto = sel;
		log.info("Valor seleccionado: " + sel);

		label1 = "";
		otroVer = "INV".equals(sel);
		if (otroVer) {
			label1 = "Ingresar sólo el número de la factura";
		}
	}

	public void seleccion2Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idDescuento = sel;
		log.info("Valor seleccionado: " + idDescuento);

		if ("SI".equals(idDescuento)) {
			solicitud.setSocCuentac(Integer.parseInt(idCuenta));

			int monUS = 34;
			int mon = Servicios.getMoneda(solicitud.getMoneda());
			BigDecimal monto = BigDecimal.valueOf(0);
			BigDecimal tc = Servicios.getTipoCambio(mon);
			BigDecimal tc1 = BigDecimal.valueOf(0);

			if (mon == monUS) {
				monto = solicitud.getSocMontome();
				tc1 = tc;
			} else {
				tc1 = Servicios.getTipoCambio(monUS);
				monto = solicitud.getSocMontome().multiply(tc).divide(tc1, 2, RoundingMode.HALF_UP);
			}

			log.info("Monto: " + monto);
			BigDecimal swift = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))).divide(tc1, 11, RoundingMode.HALF_UP);
			BigDecimal util = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL"))).divide(tc1, 11, RoundingMode.HALF_UP);
			BigDecimal comi = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRA"))).divide(BigDecimal.valueOf(100));
			montoOrd = (monto.subtract(swift)).subtract(util).divide(comi.add(BigDecimal.valueOf(1)), 2, RoundingMode.HALF_UP);
			log.info("MontoOrd: " + montoOrd);

			BigDecimal montoC = ((montoOrd.multiply(comi).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP)).multiply(tc1)).divide(
					BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			BigDecimal totC = (montoC.add(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT")))).add(BigDecimal.valueOf(Double
					.valueOf(Servicios.getComision("UTIL"))))).divide(tc1, 2, RoundingMode.HALF_UP);
			BigDecimal tot = montoOrd.add(totC);
			BigDecimal diff = monto.subtract(tot);
			log.info("diff: " + diff);
			if (diff.abs().compareTo(BigDecimal.valueOf(0)) != 0) {
				montoOrd = montoOrd.add(diff).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			}

			if (mon != monUS)
				montoOrd = montoOrd.multiply(tc1).divide(tc, 2, RoundingMode.HALF_UP);
			log.info("MontoOrd: " + montoOrd);
			solicitud.setSocMontoord(solicitud.getSocMontome());
			cuentaHab = true;
			montoVer = true;

			calcularComisiones(montoOrd);
		} else {
			cuentaHab = false;
			montoVer = false;
			solicitud.setSocMontoord(BigDecimal.valueOf(0));
		}
	}

	public void seleccion3Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		log.info("Valor seleccionado: " + sel);

		if (!sel.equals("-1")) {
			solicitud.setMoneda(sel);
			if (sel.equals("USD"))
				fijoVer = false;
			else
				fijoVer = true;
		}
	}

	public void montoChanged(ValueChangeEvent event) {
		log.info("enter changed");
		String montoS = event.getNewValue().toString();
		log.info("montoS:" + montoS);
		Double montoD = Double.parseDouble(montoS);
		log.info("montoD:" + montoD);
		// Double montoD = montoL.doubleValue();
		int monUS = 34;
		setComiVer(true);
		if (solicitud.getMonedaT().equals("USD"))
			calcularComisiones(BigDecimal.valueOf(montoD));
		else {
			BigDecimal tc = Servicios.getTipoCambio(Servicios.getMoneda(solicitud.getMonedaT()));
			BigDecimal tcUS = Servicios.getTipoCambio(monUS);
			if (idFijo.equals("F")) {
				calcularComisiones(BigDecimal.valueOf(montoD).multiply(tc).divide(tcUS, 2, RoundingMode.HALF_UP));
				montoEquiv = BigDecimal.valueOf(montoD).multiply(tc).divide(tcUS, 2, RoundingMode.HALF_UP);
			} else {
				montoEquiv = BigDecimal.valueOf(montoD).multiply(tcUS).divide(tc, 2, RoundingMode.HALF_UP);
				calcularComisiones(BigDecimal.valueOf(montoD));
			}
		}
	}

	public void seleccion5Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idFijo = sel;
		log.info("Valor seleccionado: " + idFijo);
		montoEquiv = BigDecimal.valueOf(0);
		solicitud.setSocMontome(BigDecimal.valueOf(0));
		setComiVer(false);

		if (idFijo.equals("F")) {
			labelM = "Monto a Transferir:";
			labelE = "Equivalente en USD:";
			solicitud.setMoneda(solicitud.getMonedaT());
		} else {
			labelM = "Monto en USD:";
			labelE = "Equivalente en " + solicitud.getMonedaT() + ":";
			solicitud.setMoneda("USD");
		}
	}

	private void calcularComisiones(BigDecimal monto) {
		int monUS = 34;
		comisiones.clear();
		total = BigDecimal.valueOf(0);

		BigDecimal tc1 = Servicios.getTipoCambio(monUS);
		BigDecimal comi = monto.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRA"))).divide(BigDecimal.valueOf(100))).divide(
				BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		comision = new Opecomi();
		comision.setOcoMonto(comi.multiply(tc1).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
		comision.setDescripcion("TRANSFERENCIA AL EXTERIOR");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))));
		comision.setDescripcion("GASTOS DE COMUNICACIÓN");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL"))));
		comision.setDescripcion("EMISIÓN DE COMPROBANTES");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
	}

	private String cortarConcepto() {
		String concCortado = "";
		Boolean cortado = false;
		int i = 34;
		int j;
		String texto = "";
		String ln = "\r\n";

		if (concepto.length() > 35) {
			texto = concepto;
			do {
				if (concepto.charAt(i) == ' ' || concepto.charAt(i) == '.' || concepto.charAt(i) == ',') {
					texto = concepto.substring(0, i) + ln + concepto.substring(i + 1);
					cortado = true;
				}
				i--;
			} while (!cortado);

			concCortado = texto;
			log.info("Cortado: " + concCortado);
			j = texto.indexOf(ln);
			texto = concCortado.substring(j + ln.length());
			log.info("texto: " + texto);
			if (texto.length() > 35) {
				cortado = false;
				i = 34;
				do {
					if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
						texto = texto.substring(0, i) + ln + texto.substring(i + 1);
						cortado = true;
					}
					i--;
				} while (!cortado);
				concCortado = concCortado.substring(0, j + ln.length()) + texto;
				log.info("Cortado: " + concCortado);
				j = texto.indexOf(ln);
				texto = texto.substring(j + ln.length());
				log.info("texto: " + texto);
				if (texto.length() > 35) {
					cortado = false;
					i = 34;
					do {
						if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
							texto = texto.substring(0, i) + ln + texto.substring(i + 1);
							cortado = true;
						}
						i--;
					} while (!cortado);
					i = concCortado.indexOf(ln);
					j = concCortado.indexOf(ln, i + 1);
					concCortado = concCortado.substring(0, j + ln.length()) + texto;
					log.info("Cortado: " + concCortado);
					j = texto.indexOf(ln);
					texto = texto.substring(j + ln.length());
					log.info("texto: " + texto);
					if (texto.length() > 35) {
						concCortado = "-1";
					}
				}
			}
		} else {
			concCortado = concepto;
		}

		return concCortado;
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitudTest) {
		this.solicitud = solicitudTest;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setMonedasT(List<SelectItem> monedasT) {
		this.monedasT = monedasT;
	}

	public List<SelectItem> getMonedasT() {
		return monedasT;
	}

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	/*
	 * public List<SelectItem> getBenefs() { return benefs; }
	 */

	public void setBenefs(List<SelectItem> benefs) {
		this.benefs = benefs;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasB(List<SelectItem> cuentasB) {
		this.cuentasB = cuentasB;
	}

	public List<CuentasBen> getListaCuentasB() {
		return listaCuentasB;
	}

	public void setListaCuentasB(List<CuentasBen> listaCuentasB) {
		this.listaCuentasB = listaCuentasB;
	}

	public void setComision(Opecomi comision) {
		this.comision = comision;
	}

	public Opecomi getComision() {
		return comision;
	}

	public void setComisiones(List<Opecomi> comisiones) {
		this.comisiones = comisiones;
	}

	public List<Opecomi> getComisiones() {
		return comisiones;
	}

	public void setComis(String[][] comis) {
		this.comis = comis;
	}

	public String[][] getComis() {
		return comis;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public void setIdCuentaB(Integer idCuentaB) {
		this.idCuentaB = idCuentaB;
	}

	public Integer getIdCuentaB() {
		return idCuentaB;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getBic1() {
		return bic1;
	}

	public void setBic1(String bic1) {
		this.bic1 = bic1;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getPlaza() {
		return plaza;
	}

	public void setPlaza(String plaza) {
		this.plaza = plaza;
	}

	public List<SelectItem> getConceptos() {
		return conceptos;
	}

	public void setConceptos(List<SelectItem> conceptos) {
		this.conceptos = conceptos;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConceptoO() {
		return conceptoO;
	}

	public void setConceptoO(String conceptoO) {
		this.conceptoO = conceptoO;
	}

	public String getConc() {
		return conc;
	}

	public void setConc(String conc) {
		this.conc = conc;
	}

	public String getInforma() {
		return informa;
	}

	public void setInforma(String informa) {
		this.informa = informa;
	}

	public String getAdicional() {
		return adicional;
	}

	public void setAdicional(String adicional) {
		this.adicional = adicional;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getLabel2() {
		return label2;
	}

	public void setLabel2(String label2) {
		this.label2 = label2;
	}

	public void setLabelM(String labelM) {
		this.labelM = labelM;
	}

	public String getLabelM() {
		return labelM;
	}

	public void setLabelE(String labelE) {
		this.labelE = labelE;
	}

	public String getLabelE() {
		return labelE;
	}

	public BigDecimal getMontoOrd() {
		return montoOrd;
	}

	public void setMontoOrd(BigDecimal montoOrd) {
		this.montoOrd = montoOrd;
	}

	public void setMontoEquiv(BigDecimal montoEquiv) {
		this.montoEquiv = montoEquiv;
	}

	public BigDecimal getMontoEquiv() {
		return montoEquiv;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public String getIdDescuento() {
		return idDescuento;
	}

	public void setIdDescuento(String idDescuento) {
		this.idDescuento = idDescuento;
	}

	public void setIdFijo(String idFijo) {
		this.idFijo = idFijo;
	}

	public String getIdFijo() {
		return idFijo;
	}

	public String getIdConcepto() {
		return idConcepto;
	}

	public void setIdConcepto(String idConcepto) {
		this.idConcepto = idConcepto;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public void setComiVer(Boolean comiVer) {
		this.comiVer = comiVer;
	}

	public Boolean getComiVer() {
		return comiVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setInfoVer(Boolean infoVer) {
		this.infoVer = infoVer;
	}

	public Boolean getInfoVer() {
		return infoVer;
	}

	public Boolean getOtroVer() {
		return otroVer;
	}

	public void setOtroVer(Boolean otroVer) {
		this.otroVer = otroVer;
	}

	public Boolean getFijoVer() {
		return fijoVer;
	}

	public void setFijoVer(Boolean fijoVer) {
		this.fijoVer = fijoVer;
	}

	public Boolean getFijo() {
		return fijo;
	}

	public void setFijo(Boolean fijo) {
		this.fijo = fijo;
	}

	public Boolean getFijoT() {
		return fijoT;
	}

	public void setFijoT(Boolean fijoT) {
		this.fijoT = fijoT;
	}

	public String getUrlReporte() {
		if ("NO".equals(idDescuento)) {
			urlReporte = getRaiz() + "reporte?cod=" + nroSolicitud + "&tipo=TE";
		} else {
			urlReporte = getRaiz() + "reporte?cod=" + nroSolicitud + "&tipo=TED";
		}
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");
		// if (banco != "")
		// {
		if (!idConcepto.equals("-1")) {
			if (MensSwiftUtiles.validarConcepto(concepto) > 0) {
				if ("INV".equals(idConcepto)) {
					concepto = "/INV/" + concepto;
					log.info("enter INV:" + concepto);
				}

				concepto = this.cortarConcepto();
				if (!concepto.equals("-1")) {
					String corrs = Servicios.getCorrelativo(idSoli);

					String sigla = Servicios.getSigla(idSoli);

					solicitud.setSocCuentad(Integer.parseInt(idCuenta));
					nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentad());
					solicitud.setSocNrocuentad(nroCuenta);
					nroCuenta = "";

					if ("NO".equals(idDescuento)) {
						nroCuenta = Servicios.getNroCuenta(idSoli, solicitud.getSocCuentac());
						solicitud.setSocNrocuentac(nroCuenta);
						solicitud.setSocMontoord(BigDecimal.valueOf(0));
					} else {
						solicitud.setSocMontome(montoOrd);
					}
					solicitud.setSolCodigo(idSoli + "   ");
					solicitud.setClaTipo("TE");
					solicitud.setClaEstado('B');
					solicitud.setSocCorrelativo(sigla + "-" + corrs + "-" + Servicios.obtGestion());

					log.info("XXX: enviando ");
					detalle = new SocDetallessol();
					detalle.setBenCodigo(idBenef);
					detalle.setDetCtabenef(idCuentaB);
					detalle.setDetMonto(solicitud.getSocMontome());
					detalle.setDetMontoord(solicitud.getSocMontoord());
					detalle.setMoneda(solicitud.getMoneda());
					detalle.setMonedaT(solicitud.getMonedaT());
					if ("INV".equals(idConcepto)) {
						detalle.setDetConcepto(conceptoO.toUpperCase());
						detalle.setDetFacturas(concepto.toUpperCase());
					} else {
						detalle.setDetConcepto(concepto.toUpperCase());
					}

					String info1 = "";
					if (!StringUtils.isBlank(informa))
						info1 = informa;
					if (!StringUtils.isBlank(info1) && !StringUtils.isBlank(adicional))
						info1 = info1 + " ";
					if (!StringUtils.isBlank(adicional))
						info1 = info1 + adicional;
					log.info("info1:" + info1);

					String ln = "\r\n";
					String ln1 = "\n";
					int j = info1.lastIndexOf(ln1);
					String info2 = "";
					if (j > 0) {
						log.info("con corte");
						info2 = info1.substring(j + ln1.length());
					} else {
						log.info("sin corte");
						info2 = info1;
					}
					if (info2.length() > 35) {

						Boolean cortado = false;
						String texto = info2;
						int i = 34;
						do {
							if (info2.charAt(i) == ' ' || info2.charAt(i) == '.' || info2.charAt(i) == ',') {
								texto = info2.substring(0, i) + ln + "//" + info2.substring(i + 1);
								cortado = true;
							}
							i--;
						} while (!cortado);
						if (j > 0)
							info1 = info1.substring(0, j + ln1.length()) + texto;
						else
							info1 = texto;
					}
					log.info("informa2:" + info1);
					detalle.setDetInfo(info1);

					Date date = new Date();
					long time = date.getTime();
					log.info("Creando el objeto Request para enviar al BPM");

					// parametros para request
					String id = new Long(time).toString();

					// mapa de parametros a enviar a BPM
					Map<String, Object> mapaParametros = new HashMap<String, Object>();
					mapaParametros.put("opcion", "nueva");
					mapaParametros.put("solicitud", solicitud);
					mapaParametros.put("detalle", detalle);
					Visit visit = Visit.getVisit();
					String ESTACION = visit.getAddress();
					Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
					if (mapaRespuesta.containsKey("resp_msgerror")) {
						mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
						return;
					}

					nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
					log.info("Numero de Solicitud: " + nroSolicitud);

					if (!nroSolicitud.equals("-1")) {
						this.mensaje = "La solicitud se registró correctamente con el número " + solicitud.getSocCorrelativo() + ".";
						this.botonHab = true;
					} else {
						this.mensaje = "Se produjo un error al registrar la solicitud.";
						this.botonHab = true;
					}
				} else {
					this.mensaje = "El concepto de la transferencia excede la longitud permitida para este campo.";
					this.botonHab = false;
				}
			} else {
				this.mensaje = "Existen caracteres no válidos en el concepto de la transferencia.";
				this.botonHab = false;
			}
		} else {
			this.mensaje = "Se debe seleccionar un concepto para la transferencia.";
			this.botonHab = false;
		}
		/*
		 * } else { this.mensaje =
		 * "Los datos del beneficiario no son correctos. Comun�quese con el Depto. de Operacions Cambiarias del BCB."
		 * ; this.botonHab = false; }
		 */
	}

	public CuentasBen getCuentaBSelected() {
		return cuentaBSelected;
	}

	public void setCuentaBSelected(CuentasBen cuentaBSelected) {
		this.cuentaBSelected = cuentaBSelected;
	}
}
