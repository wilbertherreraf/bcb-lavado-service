/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.joda.time.DateTime;
import org.richfaces.component.html.HtmlDataTable;

import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import gob.bcb.bpm.pruebaCU.SocMensajes;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.portal.sioc.transferencias.model.Datosmen;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaMensajesController extends BaseBeanController {
	private SocMensajes mens = new SocMensajes();
	private List<SocMensajes> mensajes;
	private List<Datosmen> listaCampos;

	private String codIns;
	private String mensaje = "";
	private boolean generada;
	private boolean botonHab = false;

	private String urlReporte;

	private Logger log = Logger.getLogger(ListaMensajesController.class);

	@PostConstruct
	public void inicio() {
		log.info("=============ooo00OOO00ooo===================");
		log.info("PostConstruct SolicitudController - " + getClass().getName());
		recuperarVisit();
		this.recuperarMensajes();
	}

	private void recuperarMensajes() {
		this.mensajes = new ArrayList<SocMensajes>();
		DateTime fecha = new DateTime();

		String query = " select m.* " + " from soc_mensajes m " + " where m.cla_estadomen = 'E'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				// log.debug("resultado" + res.toString());

				mens = new SocMensajes();
				DateTime fechaV = new DateTime(res.get("men_fechavalor"));

				mens.setInsCodigo((String) res.get("ins_codigo"));
				mens.setMenNroswift((Integer) res.get("men_nroswift"));
				mens.setMenFechavalor((Date) res.get("men_fechavalor"));
				mens.setMenMontoordenado((BigDecimal) res.get("men_montoordenado"));
				mens.setClaEstadomen("E");
				mens.setUsrCodigo((String) res.get("usr_codigo"));
				mens.setClaEsquema((String) res.get("cla_esquema"));

				if ((fechaV.getDayOfMonth() > fecha.getDayOfMonth() && fechaV.getMonthOfYear() == fecha.getMonthOfYear())
						|| (fechaV.getDayOfMonth() < fecha.getDayOfMonth() && fechaV.getMonthOfYear() > fecha.getMonthOfYear())) {
					mensajes.add(mens);
				}
			}
		}
	}

	public void verSwift(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		mens = (SocMensajes) SerializationUtils.clone(this.mensajes.get(fila));

		codIns = mens.getInsCodigo();

		String ln = System.getProperty("line.separator");

		this.listaCampos = new ArrayList<Datosmen>();

		String query1 = " select d.cam_codigo, d.ins_codigo, d.dam_valor, c.cam_nombre " + " from soc_datosmen d, soc_campos c "
				+ " where d.cam_codigo = c.cam_codigo and substr(d.cam_codigo, 1, 1) = ':'" + " and d.ins_codigo = '" + codIns + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1);
		if (resultado1 != null) {
			for (Map<String, Object> res : resultado1) {
				//

				String alto;
				String valor = "";
				String valor1 = (String) res.get("dam_valor");
				if (res.get("cam_codigo").equals(":32A")) {
					valor = valor1;
					valor1 = valor.substring(0, 6) + ln + valor.substring(6, 9) + ln + valor.substring(9);
				}

				if (res.get("cam_codigo").equals(":33B")) {
					valor = valor1;
					valor1 = valor.substring(0, 3) + ln + valor.substring(3);
				}

				int i = StringUtils.countMatches(valor1, ln);
				i = (i + 1) * 16;
				alto = " height : " + i + "px;";

				listaCampos.add(new Datosmen((String) res.get("cam_codigo"), (String) res.get("ins_codigo"), valor1, alto, (String) res
						.get("cam_nombre")));
			}

			botonHab = false;
		}

	}

	public void eventoGenerarBtn(ActionEvent action) {
		log.info("Generando la operaciï¿½n: ");
		try {

			// parametros para request
			String id = new Long(new Date().getTime()).toString();

			// mapa de parametros a enviar a BPM
			Map<String, Object> mapaParametros = new HashMap<String, Object>();
			mapaParametros.put("opcion", "verificar");

			// enviando objeto del formulario
			mapaParametros.put("mensaje", mens);

			// Metodo estatico que se encarga de manejar las consultas al BPM
			// parametros
			// nombre BPM, ipRequest, requester, feature, mapaParametros, id
			Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros,
					id);
			if (mapaRespuesta.containsKey("resp_msgerror")) {
				mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
				return;
			}

			String estado = (String) mapaRespuesta.get("estado");

			this.recuperarMensajes();

			if (estado.equals("V")) {
				log.info("El mensaje swift se verifico correctamente.");
				mensaje = "El mensaje swift se verifico correctamente.";
				botonHab = true;
			} else {
				log.info("No se pudo verificar el mensaje swift.");
				mensaje = "No se pudo verificar el mensaje swift.";
			}
			addMessageInfo("Aviso",mensaje);
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void eventoRechazarBtn(ActionEvent action) {
		log.info("Generando la operacion: ");
		// parametros para request
		String id = new Long(new Date().getTime()).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "rechazarSwift");

		// enviando objeto del formulario
		mapaParametros.put("mensaje", mens);

		// Metodo estatico que se encarga de manejar las consultas al BPM
		// parametros
		// nombre BPM, ipRequest, requester, feature, mapaParametros, id
		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM("bpmPruebaCU", "172.29.18.3", "cliente", "consulta", mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		String estado = (String) mapaRespuesta.get("estado");

		this.recuperarMensajes();

		if (estado.equals("Z")) {
			log.info("El mensaje swift fue rechazado.");
			mensaje = "El mensaje swift fue rechazado.";
			botonHab = true;
		} else {
			log.info("No se pudo rechazar el mensaje swift.");
			mensaje = "No se pudo rechazar el mensaje swift.";
		}

	}

	public SocMensajes getMens() {
		return mens;
	}

	public void setMens(SocMensajes mens) {
		this.mens = mens;
	}

	public List<SocMensajes> getMensajes() {
		return mensajes;
	}

	public void setMensajes(List<SocMensajes> mensajes) {
		this.mensajes = mensajes;
	}

	public String getCodIns() {
		return codIns;
	}

	public void setCodIns(String codIns) {
		this.codIns = codIns;
	}

	public List<Datosmen> getListaCampos() {
		return listaCampos;
	}

	public void setListaCampos(List<Datosmen> listaCampos) {
		this.listaCampos = listaCampos;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + codIns + "&tipo=SW";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	public void setGenerada(boolean generada) {
		this.generada = generada;
	}

	public boolean isGenerada() {
		return generada;
	}

	public boolean isBotonHab() {
		return botonHab;
	}

	public void setBotonHab(boolean botonHab) {
		this.botonHab = botonHab;
	}

}
