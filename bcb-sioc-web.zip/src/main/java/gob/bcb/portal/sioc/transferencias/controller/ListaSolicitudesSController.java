/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-siocweb
 * gob.bcb.portal.sioc.transferencias.controller.ListaSolicitudesController
 * 11/08/2011 - 10:01:25
 * Creado por Cecilia Uriona
 */
package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.commons.Constants;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

/**
 * BackingBean de la vista de solicitudes recibidas.
 * 
 * @author Cecilia Uriona
 * 
 */
public class ListaSolicitudesSController extends BaseBeanController {
	private Logger log = Logger.getLogger(ListaSolicitudesSController.class);
	private SolicitudesS solicitudS = new SolicitudesS();
	private List<SolicitudesS> solicitudes;

	private String codSol = "";
	private String tipo = "";
	private String codParticipante = "";

	private String urlReporte;
	private String urlListado;

	private Date fechaDesde;
	private Date fechaAl;
	private String querySolicitudes;
	private String mensaje = "";

	@PostConstruct
	public void init() {
		log.info("=============ooo00OOO00ooo===================");
		log.info("PostConstruct - " + getClass().getName());
		recuperarVisit();
		this.fechaDesde = new Date();
		this.fechaAl = new Date();

		recuperarSolicitudes();
	}

	private void recuperarSolicitudes() {
		// se arma la consulta si es usuario BCB solo se consulta con estado 'R'
		this.solicitudes = new ArrayList<SolicitudesS>();
		Calendar calFechaDesde = GregorianCalendar.getInstance();
		Calendar calFechaAl = GregorianCalendar.getInstance();
		calFechaDesde.setTime(this.fechaDesde);
		calFechaAl.setTime(this.fechaAl);

		if (calFechaDesde.compareTo(calFechaAl) > 0) {
			FacesContext.getCurrentInstance().addMessage("listaSolicitudes:calendarfechaal",
					new FacesMessage("Fecha inicio debe ser menor o igual a fecha fin"));

			return;
		}

		querySolicitudes = "select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo ";
		querySolicitudes = querySolicitudes + " and (s.esq_codigo is null or s.esq_codigo < 100) ";
		codParticipante = getVisit().getUsuarioSession().getSolicitante().getSolCodigo().trim();

		if (codParticipante.trim().equalsIgnoreCase(gob.bcb.service.servicioSioc.common.Constants.COD_BCB)
				&& getVisit().getParametro("SIOCWEB_TIPOPERACION").equals("SOLICITUDES_RECIBIDAS")) {
			querySolicitudes += "and s.cla_estado = 'R' ";
		}

		if (getVisit().getParametro("SIOCWEB_TIPOPERACION").equals("SOLICITUDES_HISTORICO")) {
			String strFechaDesde = " mdy(" + (calFechaDesde.get(Calendar.MONTH) + 1) + "," + calFechaDesde.get(Calendar.DAY_OF_MONTH) + ","
					+ calFechaDesde.get(Calendar.YEAR) + ") ";
			String strFechaAl = " mdy(" + (calFechaAl.get(Calendar.MONTH) + 1) + "," + calFechaAl.get(Calendar.DAY_OF_MONTH) + ","
					+ calFechaAl.get(Calendar.YEAR) + ") ";
			querySolicitudes += "and (date(s.fecha) between " + strFechaDesde + " AND " + strFechaAl + ") ";
			querySolicitudes += "and s.cla_estado != 'Z' "; 
		}

		if (!codParticipante.equalsIgnoreCase(gob.bcb.service.servicioSioc.common.Constants.COD_BCB)) {
			querySolicitudes += "and trim(s.sol_codigo) = '" + codParticipante + "' ";
		}

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(querySolicitudes);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'R', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");
				String c0 = " ";
				if (c0 != null) {
					c0 = (String) res.get("cla_estado");
				}

				Character c = c0.charAt(0);
				solicitudS.setClaEstado(c);

				if (solicitudS.getClaTipo().equals("TE")) {
					solicitudS.setTipo("TRANSFERENCIA AL EXTERIOR");
				} else if (solicitudS.getClaTipo().equals("TC") || solicitudS.getClaTipo().equals("TCID") || solicitudS.getClaTipo().equals("TCRG")) {
					solicitudS.setTipo("TRANSFERENCIA CUENTA A CUENTA");
				} else if (solicitudS.getClaTipo().equals("TD")) {
					solicitudS.setTipo("TRANSFERENCIA DEL EXTERIOR");
				} else if (solicitudS.getClaTipo().equals("VE")) {
					solicitudS.setTipo("VENTA DE DIVISAS");
				}

				solicitudes.add(solicitudS);
			}
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudS = this.solicitudes.get(fila);
		codSol = solicitudS.getSocCodigo();
		tipo = solicitudS.getClaTipo();
		if (tipo.equals("TE")) {
			if (solicitudS.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
				// tranferencia al exterior con descuento
				tipo = "TED";
			}
		} else {
			if (tipo.equals("VE")) {
				if (solicitudS.getSocMontoord().compareTo(BigDecimal.valueOf(0)) > 0) {
					tipo = "VED";
				} else {
					String query = "select ben_codigo from soc_detallessol where soc_codigo = '" + solicitudS.getSocCodigo() + "' and det_codigo = 1";

					List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
					String benef = "";
					if (resultado.size() == 1) {
						for (Map<String, Object> res : resultado) {
							benef = (String) res.get("ben_codigo");
						}
					}

					if (benef.equals("999998")) {
						tipo = "VEO";
					} else {
						if (!benef.startsWith("0")) {
							tipo = "VEL";
						}
					}
				}
			}
		}
		log.info("cod:" + codSol);
		log.info("tipo:" + tipo);
	}

	public void recuperarOperaciones(ActionEvent event) {
		log.info("XXX: llamando a recuperar operaciones ..............");
		recuperarSolicitudes();
	}

	public void verReporte(ActionEvent event) {
		log.info("XXX: llamando a recuperar ver reporte ..............");

		String strFechaDesde = UtilsDate.stringFromDate(this.fechaDesde, Constants.FORMAT_DATE_DB);
		String strFechaAl = UtilsDate.stringFromDate(this.fechaAl, Constants.FORMAT_DATE_DB);
		log.info("REPORTE ENTRE " + strFechaDesde + " AL " + strFechaAl);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("FECHA_DESDE", this.fechaDesde);
		parametros.put("FECHA_HASTA", this.fechaAl);
		parametros.put("TITULO", "Periodo " + strFechaDesde + " AL " + strFechaAl);

		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("nombreReporte", "EMISXMESCONV");
		request.getSession().setAttribute("parametros", parametros);
	}

	public void botonEliminar(SolicitudesS solicitudesS) {
		try {
			log.info("botonEliminar solic SF : '" + solicitudesS.getSocCodigo() + "'");
			SocSolicitudes socSolicitudesOld = getSolicitudBean().getSocSolicitudesDao().getSolicitud(solicitudesS.getSocCodigo());
			socSolicitudesOld.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			socSolicitudesOld.setEstacion(getVisit().getAddress());
			getSolicitudBean().getSocSolicitudesDao().remove(socSolicitudesOld);
			recuperarSolicitudes();
		} catch (Exception e) {
			log.error("error al verDetalle " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public SolicitudesS getSolicitudS() {
		return solicitudS;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudS = solicitudS;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	public String getUrlReporte() {

		urlReporte = getRaiz() + "reporte?cod=" + codSol + "&tipo=" + tipo;
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	public String getUrlListado() {
		log.info("XXX:En urlelelelele");
		Integer gestion = fechaDesde.getYear() + 1900;
		Integer mes = fechaDesde.getMonth() + 1;
		Integer dia = fechaDesde.getDate();
		String fechaD = gestion + "-" + mes + "-" + dia;
		gestion = fechaAl.getYear() + 1900;
		mes = fechaAl.getMonth() + 1;
		dia = fechaAl.getDate();
		String fechaH = gestion + "-" + mes + "-" + dia;
		urlListado = getRaiz() + "reporte?cod=" + codParticipante + "&tipo=LS" + "&f1=" + fechaD + "&f2=" + fechaH;
		return urlListado;
	}

	public void setUrlListado(String urlListado) {
		this.urlListado = urlListado;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaAl() {
		return fechaAl;
	}

	public void setFechaAl(Date fechaAl) {
		this.fechaAl = fechaAl;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setCodParticipante(String codParticipante) {
		this.codParticipante = codParticipante;
	}

	public String getCodParticipante() {
		return codParticipante;
	}

}
