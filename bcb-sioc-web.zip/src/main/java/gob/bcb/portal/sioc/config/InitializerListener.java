package gob.bcb.portal.sioc.config;

import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.web.utils.UtilsWeb;

import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;

public class InitializerListener implements ServletContextListener {
	private static Logger log = Logger.getLogger(InitializerListener.class);	
	public InitializerListener() {
		log.info("XXX: creado listener seeeee");
	}

	public void contextInitialized(ServletContextEvent event) {
		ServletContext servletContext = event.getServletContext();
		inicializar(servletContext);
	}
	public void contextDestroyed(ServletContextEvent arg0) {
		

	}
	public void inicializar(ServletContext servletContext){
		UtilsWeb.log(servletContext, "Initializing Project SIOC...");
		log.info("Initializing Project SIOC...");
		String homeParam = servletContext.getInitParameter(Constants.INIT_PATH_HOME);
		try{
			UtilsWeb.log(servletContext, "Parametro de directorio home " + Constants.INIT_PATH_HOME + " : " + homeParam + " en web.xml");
			log.info("Parametro de directorio home " + Constants.INIT_PATH_HOME + " : " + homeParam + " en web.xml");
			ConfigurationServ.setHomeProperty(homeParam);
			ConfigurationServ.init(homeParam);
			
			String urlBroker = ConfigurationServ.getConfigProperty("jms.broker.url");
			if (urlBroker == null) {
				throw new RuntimeException("Par�metro [urlBroker] requerido no esta definido en appconfig.properties");
			}			
			
			Constants.setUrlBroker(urlBroker);
			gob.bcb.core.jms.Constants.setUrlBroker(urlBroker);
		}catch (Exception e) {
		      servletContext.log("Errror initializing project", e);
		}
		  UtilsWeb.log(servletContext, "Initialization complete...");		
		  log.info("Initialization complete...");
		
		
	}
}
