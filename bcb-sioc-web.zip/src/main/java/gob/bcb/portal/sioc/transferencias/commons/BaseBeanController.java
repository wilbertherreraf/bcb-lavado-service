package gob.bcb.portal.sioc.transferencias.commons;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.view.SolicitudBean;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.ServicioCoinDao;
import gob.bcb.swift.model.SwfMttransfer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class BaseBeanController {
	private static final Log log = LogFactory.getLog(BaseBeanController.class);	
	private Visit visit;
	private UsuarioSession usuarioSession;
	private Map<String, Boolean> autorizado = new HashMap<String, Boolean>();
	private SolicitudBean solicitudBean = new SolicitudBean();
	private ServicioCoinDao servicioCoinDao = new ServicioCoinDao();
	private Boolean usuarioBCB = false;
	
	public BaseBeanController() {
	}

	public FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

	public javax.faces.application.Application getApplication() {
		return getFacesContext().getApplication();
	}

	public Visit getVisit() {
		return visit;
	}

	public void setVisit(Visit visit) {
		this.usuarioSession = visit.getMainController().getUsuarioSession();
		this.visit = visit;
	}

	public boolean isAuthorized(String codRecurso) {
		return getVisit().getUsuarioSession().getRecursos().contains(codRecurso);
	}

	public void recuperarVisit() {
		try {
			log.info("==== INGRESANDO A " + this.getClass().getName());
			
			HttpSession session = (HttpSession) getFacesContext().getExternalContext().getSession(false);
			Visit visit = Visit.getVisit(session);
			setVisit(visit);

			if (visit.getUsuarioSession() != null) {
				autorizado = visit.getUsuarioSession().getRecAutorizadosMapa();
			}

			Map<String, String> sesiones = getFacesContext().getExternalContext().getRequestParameterMap();
			visit.getParametro().putAll(sesiones);
			
			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			if (dd != null){
				log.info("this.pagina ->> " + dd.getPagina());
				getVisit().setParametro("pagretorno", dd.getPagina());
				getVisit().setParametro("paginaact", dd.getPagina());				
			}
		
			solicitudBean.setSessionFactory(getSiocFactoryDao().getHibernateTemplate().getSessionFactory());
			servicioCoinDao.setSessionFactory(BeanContextFactory.getInstance().getServicioCoinDao().getHibernateTemplate().getSessionFactory());
			
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();
			
			String sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin()
					+ " ==> codEnt: " + codEnt + " ip " + ip);
			
			usuarioBCB = visit.getUsuarioSession().getSolicitante().getSolCodigo().trim().equals(Constants.COD_BCB);
		} catch (Exception e) {
			log.error("Error al recuperar visit " + e.getMessage(), e);
			throw new RuntimeException("Error al recuperar visit " + e.getMessage());
		}
	}

	public Map<String, Boolean> getAutorizado() {
		return autorizado;
	}

	public void setAutorizado(Map<String, Boolean> autorizado) {
		this.autorizado = autorizado;
	}

	public void setUsuarioSession(UsuarioSession usuarioSession) {
		this.usuarioSession = usuarioSession;
	}

	public UsuarioSession getUsuarioSession() {
		return usuarioSession;
	}

	public SiocFactoryDao getSiocFactoryDao() {
		return BeanContextFactory.getInstance().getSiocFactoryDao();
	}

	public SolicitudBean getSolicitudBean() {
		return solicitudBean;
	}

	public void setSolicitudBean(SolicitudBean solicitudBean) {
		this.solicitudBean = solicitudBean;
	}
	
	public void addMessageInfo(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
		getFacesContext().addMessage(null, message);
	}

	public void addMessageError(String summary, String detail) {
		FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, summary, detail);
		getFacesContext().addMessage(null, message);
	}

	public ServicioCoinDao getServicioCoinDao() {
		return servicioCoinDao;
	}

	public void setServicioCoinDao(ServicioCoinDao servicioCoinDao) {
		this.servicioCoinDao = servicioCoinDao;
	}
	public void irAPagina(String pagina) {

		if (StringUtils.isBlank(pagina)){
			pagina = "/index.xhtml";
		}

		DropDownBean dd = (DropDownBean) visit.getParametro("DropDownBean");
		log.info("Ir a pagina==> "  + pagina + " pag retorno: " + dd.getPagina());		
		visit.setParametro("pagretorno", dd.getPagina());		
		//dd.removerSesiones();
		dd.setPagina(pagina);
		
//		try {
//			FacesContext.getCurrentInstance().getExternalContext().redirect(getRaiz());
//			log.info("Ir a pagina(despues de redirect)==>0000000 "  + pagina);			
//		} catch (IOException e) {
//			log.error(e.getMessage(), e);
//		}		
	}
	public void removeSessions() {
		DropDownBean dd = (DropDownBean) visit.getParametro("DropDownBean");
		dd.removerSesiones();
	}
	public String botonRetornar() {
		log.info("en botonRetornar ");

		DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
		log.info("XXX: botonRetornar this.pagina= " + dd.getPagina());

		String pagretorno = (String) getVisit().getParametro("pagretorno");
		log.info("pagretorno " + pagretorno);

		if (StringUtils.isBlank(pagretorno)){
			dd.setPagina(pagretorno);
		}
		return "";
	}

	public Boolean getUsuarioBCB() {
		return usuarioBCB;
	}

	public void setUsuarioBCB(Boolean usuarioBCB) {
		this.usuarioBCB = usuarioBCB;
	}

	public static String getRaiz() {
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String url = request.getRequestURL().toString();
		String direccionRaiz = null;
		if (url.indexOf("/faces") > 0)
			direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
		else
			direccionRaiz = url;
		return direccionRaiz;
	}
	public List<SelectItem>  llenarEsquemas() {
		List<SelectItem> esquemas = new ArrayList<SelectItem>();
		List<SwfMttransfer> swfMttransferLista = getSolicitudBean().getSwfMttransferBean().getMTs();
		for (SwfMttransfer swfMttransfer : swfMttransferLista) {
			esquemas.add(new SelectItem(swfMttransfer.getMttCodttransfer().trim(), swfMttransfer.getMttDescrip().trim()));
		}
		return esquemas;
	}

	public void irReporteSolicitud(String socCodigo) {
		log.info("Antes de irReporteSolicitud " + socCodigo);
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codigo", socCodigo);
		parametros.put("tipo", "soldetalle");
		parametros.put("TITULO", "DETALLE DE OPERACION");
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("nombreReporte", "solicitudresu.jasper");
		request.getSession().setAttribute("parametros", parametros);
	}
	
	public String getUrlAdjunto() {
		return getRaiz() + "ServletAdjunto";
	}
}
