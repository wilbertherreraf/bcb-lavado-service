package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.CharUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SolicitudSearchPanel extends BaseBeanController {
	private Logger log = Logger.getLogger(SolicitudSearchPanel.class);
	public static final int MAX_DIAS_REPORTE_EXTRACTO = 31;
	private Date fechaDesde;
	private Date fechaHasta;

	private SolicitudesS solicitudesSSelected = new SolicitudesS();
	private List<SolicitudesS> solicitudesSLista = new ArrayList<SolicitudesS>();
	private List<SelectItem> solicitanteItems = new ArrayList<SelectItem>();
	private SocSolicitudes socSolicitudes = new SocSolicitudes();
	private SocSolicitudctas socSolicitudctasMovProv = new SocSolicitudctas();
	private String claTipoSolicitud;
	private List<SelectItem> tiposTransaccionesItems = new ArrayList<SelectItem>();
	private List<SelectItem> valoresClavesItems = new ArrayList<SelectItem>();
	private List<SelectItem> socCuentassolItems = new ArrayList<SelectItem>();
	private String actDetalle;
	private String sIOCWEB_TIPOPERACION;
	private String urlReporte;

	@PostConstruct
	public void inicio() {
		log.info("PostConstruct SolicitudSearchPanel - " + getClass().getName());
		try {
			recuperarVisit();
			String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
			String ip = getVisit().getAddress();

			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");

			log.info("Par. sIOCWEB_TIPOPERACION= " + sIOCWEB_TIPOPERACION + " usuario: " + getVisit().getUsuarioSession().getLogin() + " ==> codEnt: "
					+ codEnt + " ip " + ip);

			crearObjetosPorDefecto();
			recuperarSolicitudes();
			actualizarCuentasProvSolicitante();
			getVisit().removeParametro("SIOCWEB_SOCCODIGO");

			DropDownBean dd = (DropDownBean) getVisit().getParametro("DropDownBean");
			log.info("this.pagina ->> " + dd.getPagina());
			getVisit().setParametro("pagretorno", dd.getPagina());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ocurrió un error: " + e.getMessage(), null));
		} finally {
			getVisit().removeParametro("SIOCWEB_SOCCODIGO");
			getVisit().removeParametro("SOL_ACTION");
			getVisit().removeParametro("SOL_ESTADO");
			getVisit().removeParametro("SIOCWEB_TIPOPERACION");
			getVisit().removeParametro("pagretorno");
			getVisit().removeParametro("pagretorno0");

			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
			// la desesperada!! esto no debería estar aqui
			sesiones.remove("solicitudController");
			sesiones.remove("solicitudTDController");
			sesiones.remove("swfMensajeController");

		}

	}

	private void recuperarSolicitudes() {

		String codEnt = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();
		solicitudesSLista.clear();
		// solicitudesSLista = new ArrayList<SolicitudesS>();
		log.info("En recuperarSolicitudes " + sIOCWEB_TIPOPERACION + " codEnt:" + codEnt);
		actDetalle = "view";
		Date fechaHoy = new Date();
		if (sIOCWEB_TIPOPERACION.equals("MODSOL")) {
			// solicitudes pendientes
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				solicitudesSLista = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, null, "P", null, null, codEnt, null,
						null, null, codEnt);
			} else {
				solicitudesSLista = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, null, "P", null, codEnt, codEnt, null,
						null, null, codEnt);
			}

			actDetalle = "edit";

		} else if (sIOCWEB_TIPOPERACION.equals("PREAUT")) {
			// pre autorizar AProbadas por el solicitante en casos de te
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				solicitudesSLista = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TC,TE,CC,OP", "D", null, null, null,
						null, null, null, codEnt);
			}

		} else if (sIOCWEB_TIPOPERACION.equals("APROSOL")) {
			// aprobar solicitudes por el solicitante pre autorizadas en tc, o v
			// verificadas en caso de te
			List<SolicitudesS> solicitudesSListatmp = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TC", "V,1", null,
					codEnt, codEnt, null, null, null, codEnt);
			solicitudesSLista.addAll(solicitudesSListatmp);

			solicitudesSListatmp = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TE", "V", null, codEnt, codEnt, null,
					null, null, codEnt);
			solicitudesSLista.addAll(solicitudesSListatmp);

		} else if (sIOCWEB_TIPOPERACION.equals("AUTSOL")) {
			// solicitudes a autorizar en estado 1
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				// filtro de solicitudes generardos por el bcb
				List<SolicitudesS> solicitudesSListatmp = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TD,TE,TC,OP,CC",
						"1", null, null, codEnt, null, null, null, codEnt);
				solicitudesSLista.addAll(solicitudesSListatmp);

				// filtro de solicitudes generardos por el solicitante
				solicitudesSListatmp = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TD,OP,TC,TE", "1", null, null,
						null, null, null, null, codEnt);
				solicitudesSLista.addAll(solicitudesSListatmp);
			}

		} else if (sIOCWEB_TIPOPERACION.equals("NOTIF")) {
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				solicitudesSLista = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, null, "C", "V", null, null, null, null,
						null, codEnt);
			}

		} else if (sIOCWEB_TIPOPERACION.equals("VERSREC")) {
			// VER SOLICITTUDES RECIBIDAS, SOLICS EN ESTADO DE APROBACION,
			// repote de solicitudes que se procesan en el BCB
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				solicitudesSLista = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TE,TD", "D", null, null, null, null,
						null, null, codEnt);
			}

		} else if (sIOCWEB_TIPOPERACION.equals("VERSAPR")) {
			// pre autorizar AProbadas por el solicitante en casos de te
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				// solicitudes
				List<SolicitudesS> solicitudesSListatmp = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TD,TE", "D",
						null, null, null, null, null, null, codEnt);
				solicitudesSLista.addAll(solicitudesSListatmp);

				// solicittudes contabilizadas de hoy
				solicitudesSListatmp = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(null, null, "TC,OP", "C", null, null, null,
						null, fechaHoy, fechaHoy, codEnt);
				solicitudesSLista.addAll(solicitudesSListatmp);
			}

		} else if (sIOCWEB_TIPOPERACION.equals("VERHA")) {
			// busqueda de solicitudes historicas
			String claEstado = null;

			if (socSolicitudes.getClaEstado() != null && socSolicitudes.getClaEstado().equals(' ')) {
				claEstado = CharUtils.toString(socSolicitudes.getClaEstado());
			}
			if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				solicitudesSLista = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(socSolicitudes.getEsqCodigo(), null, null,
						claEstado, null, socSolicitudes.getSolCodigo(), null, null, fechaDesde, fechaHasta, null);
			} else {
				solicitudesSLista = getSolicitudBean().getSocSolicitudesDao().recuperarSolicitudes(socSolicitudes.getEsqCodigo(), null, null,
						claEstado, null, codEnt, null, null, fechaDesde, fechaHasta, codEnt);
			}

		}

	}

	public void botonNotificar(SolicitudesS solicitudesS) {
		try {
			log.info("botonNotificar : '" + solicitudesS.getSocCodigo() + "' tipoper: " + sIOCWEB_TIPOPERACION);
			SocSolicitudes socSolicitudes = getSolicitudBean().getSocSolicitudesDao().getSolicitud(solicitudesS.getSocCodigo());

			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setSolicitud(socSolicitudes);
			solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);

			getSolicitudBean().procesar(solicitudTO, "NOTIFMEFP");
			String mensajeError = "La operacion se NOTIFICÓ exitosamente al MEFP";

			log.info("fin botonNotificar " + mensajeError);

			addMessageInfo("Aviso",
					(StringUtils.isBlank(getSolicitudBean().getCodRespuesta()) ? mensajeError : getSolicitudBean().getDescRespuesta()));

			recuperarSolicitudes();
		} catch (Exception e) {
			log.error("Operacion con error: " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void solicitanteChanged(ActionEvent event) {
		log.info("solicitanteChanged " + socSolicitudes.getSolCodigo());
		actualizarCuentasProvSolicitante();

	}

	public void botonBuscar() {
		log.info("en botonBuscar " + socSolicitudes.toString());
		recuperarSolicitudes();
	}

	public void verReporteSolicitud(ActionEvent event) {
		log.info("Antes de reporte " + socSolicitudes.getSolCodigo());
		mostrarReporte("pdf");
	}

	public void verDetalle(SolicitudesS solicitudesS) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();

		sesiones.remove("solicitudController");
		sesiones.remove("solicitudTDController");

		getVisit().setParametro("pagretorno0", getVisit().getParametro("paginaact"));
		log.info("XXX: retrono 0 " + getVisit().getParametro("paginaact"));
		irAPagina("/view/Solicitud/solicitud_view.xhtml");
		getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		getVisit().setParametro("SIOCWEB_SOCCODIGO", solicitudesS.getSocCodigo());
	}

	public void verDetalleHa(SolicitudesS solicitudesS) {
		FacesContext facesContext = FacesContext.getCurrentInstance();
		Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
		sesiones.remove("solicitudController");
		sesiones.remove("solicitudTDController");

		irAPagina("/view/Solicitud/solicitud_viewha.xhtml");

		getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
		getVisit().setParametro("SIOCWEB_SOCCODIGO", solicitudesS.getSocCodigo());
	}

	public void modificarDetalle(SolicitudesS solicitudesS) {
		try {
			log.info("modificarDetalle : '" + solicitudesS.getSocCodigo() + "' tipoper: " + sIOCWEB_TIPOPERACION);
			SocSolicitudes socSolicitudes = getSolicitudBean().getSocSolicitudesDao().getSolicitud(solicitudesS.getSocCodigo());

			if (socSolicitudes == null) {
				throw new BusinessException("Solicitud inexistente");
			}
			FacesContext facesContext = FacesContext.getCurrentInstance();
			Map<String, Object> sesiones = facesContext.getExternalContext().getSessionMap();
			sesiones.remove("solicitudController");
			sesiones.remove("solicitudTDController");

			if (actDetalle.equals("edit")) {
				getVisit().setParametro("pagretorno0", getVisit().getParametro("paginaact"));
				if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
					irAPagina("/view/Solicitud/solicitud_newVDD.xhtml");
				}

				if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {
					irAPagina("/view/Solicitud/solicitud_newVETC.xhtml");
				}
				if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
					irAPagina("/view/Solicitud/solicitud_newVEOP.xhtml");
				}
				if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
					if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT)) {
						if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)) {
							irAPagina("/view/Solicitud/solicitud_newTDSF.xhtml");
						} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
							irAPagina("/view/Solicitud/solicitud_newTDCC.xhtml");
						} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ORDPAGO)) {
							irAPagina("/view/Solicitud/solicitud_newTDCC.xhtml");
						}
					} else if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT_REGISACREE)) {
						//regsitro en acreedores
						irAPagina("/view/Solicitud/solicitud_newTDACR.xhtml");
					} else if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT_REGACREE)) {
						//regularizacion de acreedores
						if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)) {
							irAPagina("/view/Solicitud/solicitud_newTDRACRSF.xhtml");
						} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
							irAPagina("/view/Solicitud/solicitud_newTDRACR.xhtml");
						} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ORDPAGO)) {
							irAPagina("/view/Solicitud/solicitud_newTDRACR.xhtml");
						}						
					} else if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT_DEVFONDOSVISTA)) {
						irAPagina("/view/Solicitud/solicitud_newTDDEVFV.xhtml");
					} else {
						irAPagina("/view/Solicitud/solicitud_newTDCC.xhtml");						
					}
				}

				getVisit().setParametro("SIOCWEB_TIPOPERACION", sIOCWEB_TIPOPERACION);
				getVisit().setParametro("SIOCWEB_ACTION", "SOL_EDIT");
				getVisit().setParametro("SIOCWEB_SOCCODIGO", socSolicitudes.getSocCodigo());
			}
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	private void crearObjetosPorDefecto() {
		Calendar cal = GregorianCalendar.getInstance();
		fechaDesde = new Date();
		cal.setTime(fechaDesde);
		fechaDesde = cal.getTime();
		fechaHasta = new Date();

		recuperarListaSolicitantes("SP,SF");
		tiposTransaccionesItems = new ArrayList<SelectItem>();
		valoresClavesItems = Servicios.valoresLista("cla_estsolic");
	}

	private void recuperarListaSolicitantes(String claTipoEntidad) {

		solicitanteItems = new ArrayList<SelectItem>();
		List<SocSolicitante> socSolicitanteLista = new ArrayList<SocSolicitante>();

		if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, claTipoEntidad);
		} else {
			SocSolicitante socSolicitante = getSolicitudBean().getSocSolicitanteDao()
					.solicitanteByCod(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
			if (socSolicitante != null) {
				socSolicitanteLista.add(socSolicitante);
				socSolicitudes.setSolCodigo(socSolicitante.getSolCodigo());
			}
		}
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			solicitanteItems.add(new SelectItem("" + socSolicitante.getSolCodigo().trim() + "",
					socSolicitante.getSolPersona() + " [" + socSolicitante.getSolCodigo() + "]"));
		}

	}

	private void actualizarCuentasProvSolicitante() {
		// actualiza listas segun valores en la solicitud
		socCuentassolItems = new ArrayList<SelectItem>();
		// lista de cuentas de la entidad solicitante

		if (StringUtils.isBlank(socSolicitudes.getSolCodigo()))
			return;

		log.info("actualizarCuentasProvSolicitante codsol: " + socSolicitudes.getSolCodigo());

		List<SocCuentassol> socCuentassolLista = getSolicitudBean().getSocCuentassolDao().ctasSolicitante(socSolicitudes.getSolCodigo(), null, null,
				null, null, null, null);

		for (SocCuentassol socCuentassol : socCuentassolLista) {
			if (!StringUtils.isBlank(socCuentassol.getCtaAfectable())) {
				socCuentassolItems.add(new SelectItem(StringUtils.trim(socCuentassol.getCtaAfectable()),
						socCuentassol.getCtaMovimiento() + " - " + socCuentassol.getCtaNommovimiento() + " " + socCuentassol.getMoneda()));
			}
		}

	}

	public void verReporteSolicitud(SolicitudesS solicitudesS) {
		log.info("Antes de reporte " + solicitudesS.getSocCodigo());
		irReporteSolicitud(solicitudesS.getSocCodigo());
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte";
		return urlReporte;
	}

	public void mostrarReporte(String tipoFormato) {
		log.info("En mostrarReporte...........");
		if (StringUtils.isBlank(socSolicitudes.getSolCodigo()))
			return;

		Date d1 = UtilsDate.addTime(fechaHasta, (MAX_DIAS_REPORTE_EXTRACTO - 1) * (-1), 5);

		int compara = UtilsDate.compara(d1, fechaDesde);
		if (compara > 0) {
			// intervalo entre fechas mayor al permitido
			fechaHasta = UtilsDate.addTime(fechaDesde, (MAX_DIAS_REPORTE_EXTRACTO - 1), 5);
		}
		log.info("En mostrarReporte.compara : " + compara + " :: " + UtilsDate.stringFromDate(d1, "dd/MM/yyyy") + " :::: "
				+ UtilsDate.stringFromDate(fechaHasta, "dd/MM/yyyy"));

		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("tipo", "extractoCtas");
		parametros.put("reportFormato", tipoFormato);
		parametros.put("solCodigo", socSolicitudes.getSolCodigo());
		parametros.put("fechaini", fechaDesde);
		parametros.put("fechafin", fechaHasta);
		parametros.put("parametros", new HashMap<String, Object>());
		parametros.put("nroafectable", socSolicitudctasMovProv.getCtaAfectable());
		parametros.put("TITULO", "EXTRACTO DE CUENTAS");
		parametros.put("USUARIO", getVisit().getUsuarioSession().getLogin() + ":" + getVisit().getAddress());
		HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		request.getSession().setAttribute("pathTranslated", request.getPathTranslated());
		request.getSession().setAttribute("parametros", parametros);
	}

	public List<SolicitudesS> getSolicitudesSLista() {
		return solicitudesSLista;
	}

	public void setSolicitudesSLista(List<SolicitudesS> solicitudesSLista) {
		this.solicitudesSLista = solicitudesSLista;
	}

	public SolicitudesS getSolicitudesSSelected() {
		return solicitudesSSelected;
	}

	public void setSolicitudesSSelected(SolicitudesS solicitudesSSelected) {
		this.solicitudesSSelected = solicitudesSSelected;
	}

	public List<SelectItem> getSolicitanteItems() {
		return solicitanteItems;
	}

	public void setSolicitanteItems(List<SelectItem> solicitanteItems) {
		this.solicitanteItems = solicitanteItems;
	}

	public String getClaTipoSolicitud() {
		return claTipoSolicitud;
	}

	public void setClaTipoSolicitud(String claTipoSolicitud) {
		this.claTipoSolicitud = claTipoSolicitud;
	}

	public List<SelectItem> getTiposTransaccionesItems() {
		return tiposTransaccionesItems;
	}

	public void setTiposTransaccionesItems(List<SelectItem> tiposTransaccionesItems) {
		this.tiposTransaccionesItems = tiposTransaccionesItems;
	}

	public List<SelectItem> getValoresClavesItems() {
		return valoresClavesItems;
	}

	public void setValoresClavesItems(List<SelectItem> valoresClavesItems) {
		this.valoresClavesItems = valoresClavesItems;
	}

	public SocSolicitudes getSocSolicitudes() {
		return socSolicitudes;
	}

	public void setSocSolicitudes(SocSolicitudes socSolicitudes) {
		this.socSolicitudes = socSolicitudes;
	}

	public Date getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(Date fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public Date getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(Date fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

	public List<SelectItem> getSocCuentassolItems() {
		return socCuentassolItems;
	}

	public void setSocCuentassolItems(List<SelectItem> socCuentassolItems) {
		this.socCuentassolItems = socCuentassolItems;
	}

	public SocSolicitudctas getSocSolicitudctasMovProv() {
		return socSolicitudctasMovProv;
	}

	public void setSocSolicitudctasMovProv(SocSolicitudctas socSolicitudctasMovProv) {
		this.socSolicitudctasMovProv = socSolicitudctasMovProv;
	}
}
