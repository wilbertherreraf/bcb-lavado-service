package gob.bcb.portal.sioc.transferencias.controller;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class ReportesEst1Controller {

  private String f1 = "";
  
  private String urlReporte;
  
  private Logger log = Logger.getLogger(ReportesEst1Controller.class);

  public ReportesEst1Controller() 
  {
    
  }

  public String getF1() {
    return f1;
  }

  public void setF1(String f1) {
    this.f1 = f1;
  }

  private static String getRaiz() {
    HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    String url = request.getRequestURL().toString();
    String direccionRaiz = null;
    if (url.indexOf("/faces") > 0)
      direccionRaiz = url.substring(0, url.indexOf("/faces")) + "/";
    else
      direccionRaiz = url;
    return direccionRaiz;
  }
  
  public String getUrlReporte() {
    log.info("rr:" + "DI" + ",f1:" + f1);
    urlReporte = getRaiz() + "reporte?cod=0&tipo=DI" + "&f1=" + f1;
    return urlReporte;
  }

  public void setUrlReporte(String urlReporte) {
    this.urlReporte = urlReporte;
  } 

}
