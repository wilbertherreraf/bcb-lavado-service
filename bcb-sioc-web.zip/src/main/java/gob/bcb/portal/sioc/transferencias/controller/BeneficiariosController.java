package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.SocBenefsreg;

import gob.bcb.portal.menu.DropDownBean;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class BeneficiariosController extends BaseBeanController {

  private SocBenefsreg benefsreg = new SocBenefsreg();
  private List<SelectItem> solics = new ArrayList<SelectItem>();
  private int codBenef = 0;
  private String idSoli = "-1";
  private String idIdent = "BIC";
  private String label2 = "C�digo BIC:";
  private String mensaje = "";
  private Boolean botonHab = true;
  private Boolean intVer = false;
  private String usuario = "";

  private String urlReporte;

  private Logger log = Logger.getLogger(BeneficiariosController.class);
  private static final String CLIENTE = "cliente";
  private static final String CONSULTA = "consulta";
  private static final String BPMSIOC = "bpmPruebaCU";
  //private static final String ESTACION = "172.29.18.3-curiona";
  private static final String ESTACION = "";

  /*private String pagina = "";

  public String getPagina() {
    return pagina;
  }

  public void setPagina(String pagina) {
    this.pagina = pagina;
  }

  @SuppressWarnings("rawtypes")
  public void listenerMenu(ActionEvent event) {
    FacesContext facesContext = FacesContext.getCurrentInstance();
    Map map = facesContext.getExternalContext().getRequestParameterMap();
    System.out.println(map.get("pagina").toString());
    this.pagina = (String) map.get("pagina");
  }*/

  public BeneficiariosController() {
	  recuperarVisit();

    usuario = getVisit().getUsuarioSession().getLogin();
    idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

    String query = "";

    if (!idSoli.equals("900"))
    {

      query = " select trim(sol_codigo) as cod, sol_persona "
        + " from soc_solicitante "
        + " where cla_entidad = 'SP' "
        + " and cla_vigente = 1"
        + " and trim(sol_codigo) = '" + idSoli + "'";
    }
    else
    {
      idSoli = "-1";
      query = " select trim(sol_codigo) as cod, sol_persona "
        + " from soc_solicitante "
        + " where cla_entidad = 'SP' "
        + " and cla_vigente = 1"
        + " order by sol_persona";
    }

    List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
    if (resultado1 != null)
    {
      for (Map<String, Object>res : resultado1)
      {

        solics.add(new SelectItem(res.get("cod"), (String) res.get("sol_persona")));
      }
    }
    else
    {
      log.info("Lista Nula");
    }
  }

  public void seleccionChanged(ValueChangeEvent event)
  {
    String sel = (String) event.getNewValue();
    log.info("Valor seleccionado: " + sel);

    if (sel.equals("BIC"))
    {
      label2 = "C�digo BIC:";
      intVer = false;
    }
    if (sel.equals("ABA"))
    {
      label2 = "N�mero ABA:";
      intVer = false;
    }
    if (sel.equals("INT"))
    {
      label2 = "Cta. en Banco Intermediario:";
      intVer = true;
    }
  }

  public void setBenefsreg(SocBenefsreg benefsreg) {
    this.benefsreg = benefsreg;
  }

  public SocBenefsreg getBenefsreg() {
    return benefsreg;
  }

  public List<SelectItem> getSolics()
  {
    return solics;
  }

  public void setSolics(List<SelectItem> solics)
  {
    this.solics = solics;
  }

  public void setCodBenef(int codBenef) {
    this.codBenef = codBenef;
  }

  public int getCodBenef() {
    return codBenef;
  }

  public String getIdSoli()
  {
    return idSoli;
  }

  public void setIdSoli(String idSoli)
  {
    this.idSoli = idSoli;
  }

  public void setIdIdent(String idIdent) {
    this.idIdent = idIdent;
  }

  public String getIdIdent() {
    return idIdent;
  }

  public void setLabel2(String label2) {
    this.label2 = label2;
  }

  public String getLabel2() {
    return label2;
  }

  public String getMensaje() {
    return mensaje;
  }

  public void setMensaje(String mensaje) {
    this.mensaje = mensaje;
  }

  public void setIntVer(Boolean intVer) {
    this.intVer = intVer;
  }

  public Boolean getIntVer() {
    return intVer;
  }

  public Boolean getBotonHab() {
    return botonHab;
  }

  public void setBotonHab(Boolean botonHab) {
    this.botonHab = botonHab;
  }

  public String getUrlReporte() {
    //urlReporte = "http://10.2.11.93:8180/bcb-web-sioc/reporte?cod=" + nroSolicitud + "&tipo=TE";
    urlReporte = getRaiz() + "reporte?cod=" + codBenef + "&tipo=BB";
    return urlReporte;
  }

  public void setUrlReporte(String urlReporte) {
    this.urlReporte = urlReporte;
  }

  /**
   *
   * Metodo que responde al evento de guardado del formulario
   *
   * @throws Exception
   */
  public void eventoGuardarBtn(ActionEvent action) throws Exception
  {
    log.info("Ingresando al boton Guardar");

        Date date = new Date();

        benefsreg.setSolCodigo(idSoli + "   ");
        benefsreg.setUsrCodigo(usuario);
        benefsreg.setFechaHora(date);
        benefsreg.setEstacion(ESTACION);

        long time = date.getTime();
        log.info("Creando el objeto Request para enviar al BPM");

        // parametros para request
        String id = new Long(time).toString();

        // mapa de parametros a enviar a BPM
        Map<String, Object> mapaParametros = new HashMap<String, Object>();
        mapaParametros.put("opcion", "benefreg");
        mapaParametros.put("benef", benefsreg);

        // Metodo estatico que se encarga de manejar las consultas al BPM
        Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);if (mapaRespuesta.containsKey("resp_msgerror")){mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");return;}

        codBenef = (Integer) mapaRespuesta.get("codBenef");
        log.info("Numero de Benef: " + codBenef);

        if (codBenef != 0)
        {
        	this.mensaje = "Los datos del beneficiario se enviaron correctamente.";
        	this.botonHab = true;
        }
        else
        {
        	this.mensaje = "Se produjo un error al registrar los datos del beneficiario.";
        	this.botonHab = true;
        }
  }

}
