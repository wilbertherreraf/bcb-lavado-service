package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;

import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.servicioSioc.common.MensSwiftUtiles;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class SolicitudesBCBController {

	private SocSolicitudes solicitud = new SocSolicitudes();
	private SocDetallessol detalle = new SocDetallessol();
	private List<SelectItem> monedas = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> benefs = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
	private List<SelectItem> conceptos = new ArrayList<SelectItem>();
	private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
	private String idSoli = "-1";
	private String idBenef = "-1";
	private String idCuenta = "-1";
	private Integer idCuentaB = -1;
	private String idConcepto;
	private String concepto = "";
	private String conc = "-1";
	private String nroCuenta = "";
	private String cuenta = "";
	private String bic = "";
	private String bic1 = "";
	private String banco = "";
	private String plaza = "";
	private String informa = "";
	private String adicional = "";
	private String mensaje = "";
	private String label1 = "";
	private String label2 = "";
	private BigDecimal montoOrd = BigDecimal.valueOf(0);
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean botonHab = true;
	private Boolean interVer = false;

	private Logger log = Logger.getLogger(SolicitudesBCBController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	// private static final String ESTACION = "172.29.18.3-curiona";
	private static final String ESTACION = "";

	/*
	 * private String pagina = ""; public String getPagina() { return pagina; }
	 * public void setPagina(String pagina) { this.pagina = pagina; }
	 *
	 * @SuppressWarnings("rawtypes") public void listenerMenu(ActionEvent event)
	 * { FacesContext facesContext = FacesContext.getCurrentInstance(); Map map
	 * = facesContext.getExternalContext().getRequestParameterMap();
	 * System.out.println(map.get("pagina").toString()); this.pagina = (String)
	 * map.get("pagina"); }
	 */

	@SuppressWarnings("unchecked")
	public SolicitudesBCBController() {
		monedas.add(new SelectItem("USD", "DOLARES AMERICANOS"));
		monedas.add(new SelectItem("EUR", "EUROS"));

		conceptos.add(new SelectItem("INV", "PAGO FACTURA"));
		conceptos.add(new SelectItem("ROC", "REFERENCIA CLIENTE ORDENANTE"));
		conceptos.add(new SelectItem("RBC", "REFERENCIA CLIENTE BENEFICIARIO"));
		conceptos.add(new SelectItem("OTR", "OTROS"));

		solics.add(new SelectItem("ADM", "ADMINISTRACION"));
		solics.add(new SelectItem("RRHH", "RECURSOS HUMANOS"));

	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		if (!idSoli.equals("-1")) {

			cuentasD.clear();

			/*
			 * String query =
			 * " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
			 * +
			 * " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable "
			 * + " from soc_solcuentas sc, soc_cuentassol cc " +
			 * " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " +
			 * " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '900'";
			 * List<Map<String, Object>> resultado1 =
			 * Servicios.ejecutarQuery(query); if (resultado1 != null) { for
			 * (Map<String, Object>res : resultado1) { if ((Integer)
			 * res.get("moneda") != 69) { if (res.get("cta_numero") != null) {
			 * cuentasD.add(new SelectItem(res.get("cta_codigo"),
			 * res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") +
			 * "-USD-" + res.get("cta_numero"))); } else {
			 */
			// cuentasD.add(new SelectItem(res.get("cta_codigo"),
			// res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") +
			// "-USD"));
			cuentasD.add(new SelectItem(33, "1355-ACREEDORES POR COMPRA BIENES Y SERVICIOS-ECONOMATO-USD"));
			/*
			 * } } } } else { log.info("Lista Nula"); }
			 */
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public List<SelectItem> getBenefs() {
		log.info("enter getbenefs");
		log.info("soli: " + idSoli);
		if (idSoli != "-1") {

			benefs.clear();

			String query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '900' " + "ORDER BY bb.ben_nombre ";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado != null) {
				for (Map<String, Object> res : resultado) {

					benefs.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			benefs.clear();
		}

		return benefs;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getCuentasB() {
		cuentasB.clear();
		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";
		String moneda = "";

		if (idBenef != "-1") {
			String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
					+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
					+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
					+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() > 0) {
				for (Map<String, Object> res : resultado) {
					interVer = true;

					if ((Integer) res.get("moneda") == 34)
						moneda = "USD";
					if ((Integer) res.get("moneda") == 53)
						moneda = "EUR";
					if ((Integer) res.get("moneda") == 31)
						moneda = "CHF";
					cuentasB.add(new SelectItem(res.get("cta_codigo"), res.get("cta_nrocuenta") + "-" + moneda));
					listaCuentasB.add(new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"),
							(String) res.get("cta_info"), (Integer) res.get("moneda"), (String) res.get("bco_nombre"),
							(String) res.get("pla_nombre"), (String) res.get("pla_bic"), (String) res.get("pla_intermediario"), (String) res
									.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1")));
				}
			} else {
				query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
						+ " pp.pla_nombre, pp.pla_bic, pp.pla_nrocuenta " + " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
						+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
						+ " AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					interVer = false;
					for (Map<String, Object> res : resultado1) {

						if ((Integer) res.get("moneda") == 34)
							moneda = "USD";
						if ((Integer) res.get("moneda") == 53)
							moneda = "EUR";
						if ((Integer) res.get("moneda") == 31)
							moneda = "CHF";
						cuentasB.add(new SelectItem(res.get("cta_codigo"), res.get("cta_nrocuenta") + "-" + moneda));
						listaCuentasB.add(new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res
								.get("cta_info"), (Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"),
								(String) res.get("pla_bic"), (String) res.get("pla_nrocuenta")));
					}
				} else {
					interVer = false;
					log.info("Lista Nula");
				}
			}
		}

		return cuentasB;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		idCuentaB = sel;
		log.info("Valor seleccionado: " + sel);
		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";
		if (idCuentaB != -1) {
			for (CuentasBen cuentaB : listaCuentasB) {
				if (cuentaB.getCtaCodigo().compareTo(idCuentaB) == 0) {
					if (!interVer) {
						bic = cuentaB.getPlaBic();
						if (bic != null)
							label2 = "BIC:";
						else {
							bic = cuentaB.getPlaNroCuenta();
							label2 = "Cuenta:";
						}
					} else {
						bic = cuentaB.getPlaNroCuenta();
						if (bic != null)
							label2 = "Cuenta:";
						else {
							bic = cuentaB.getPlaBic();
							label2 = "BIC:";
						}
					}
					cuenta = cuentaB.getCtaNroCuenta();
					banco = cuentaB.getBcoNombre() + " - " + cuentaB.getPlaNombre();
					bic1 = cuentaB.getPlaIntermediario();
					plaza = cuentaB.getBcoNombreI() + " - " + cuentaB.getPlaNombreI();
					informa = cuentaB.getCtaInfo();
				}
			}
		} 
	}

	public void seleccion1Changed(ValueChangeEvent event) {
		String sel = (String) event.getNewValue();
		idConcepto = sel;
		log.info("Valor seleccionado: " + sel);

		if ("INV".equals(sel)) {
			label1 = "Ingresar s�lo el n�mero de la factura";
		} else {
			label1 = "";
		}
	}

	public String cortarConcepto() {
		String concCortado = "";
		Boolean cortado = false;
		int i = 34;
		int j;
		String texto = "";
		String ln = System.getProperty("line.separator");

		if (concepto.length() > 35) {
			texto = concepto;
			do {
				if (concepto.charAt(i) == ' ' || concepto.charAt(i) == '.' || concepto.charAt(i) == ',') {
					texto = concepto.substring(0, i) + ln + concepto.substring(i + 1);
					cortado = true;
				}
				i--;
			} while (!cortado);

			concCortado = texto;
			log.info("Cortado: " + concCortado);
			j = texto.indexOf(ln);
			texto = concCortado.substring(j + ln.length());
			log.info("texto: " + texto);
			if (texto.length() > 35) {
				cortado = false;
				i = 34;
				do {
					if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
						texto = texto.substring(0, i) + ln + texto.substring(i + 1);
						cortado = true;
					}
					i--;
				} while (!cortado);
				concCortado = concCortado.substring(0, j + ln.length()) + texto;
				log.info("Cortado: " + concCortado);
				j = texto.indexOf(ln);
				texto = texto.substring(j + ln.length());
				log.info("texto: " + texto);
				if (texto.length() > 35) {
					cortado = false;
					i = 34;
					do {
						if (texto.charAt(i) == ' ' || texto.charAt(i) == '.' || texto.charAt(i) == ',') {
							texto = texto.substring(0, i) + ln + texto.substring(i + 1);
							cortado = true;
						}
						i--;
					} while (!cortado);
					i = concCortado.indexOf(ln);
					j = concCortado.indexOf(ln, i + 1);
					concCortado = concCortado.substring(0, j + ln.length()) + texto;
					log.info("Cortado: " + concCortado);
					j = texto.indexOf(ln);
					texto = texto.substring(j + ln.length());
					log.info("texto: " + texto);
					if (texto.length() > 35) {
						concCortado = "-1";
					}
				}
			}
		} else {
			concCortado = concepto;
		}

		return concCortado;
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitud) {
		this.solicitud = solicitud;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SelectItem> getMonedas() {
		return monedas;
	}

	public void setMonedas(List<SelectItem> monedas) {
		this.monedas = monedas;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	/*
	 * public List<SelectItem> getBenefs() { return benefs; }
	 */

	public void setBenefs(List<SelectItem> benefs) {
		this.benefs = benefs;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasB(List<SelectItem> cuentasB) {
		this.cuentasB = cuentasB;
	}

	public List<CuentasBen> getListaCuentasB() {
		return listaCuentasB;
	}

	public void setListaCuentasB(List<CuentasBen> listaCuentasB) {
		this.listaCuentasB = listaCuentasB;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public void setIdCuentaB(Integer idCuentaB) {
		this.idCuentaB = idCuentaB;
	}

	public Integer getIdCuentaB() {
		return idCuentaB;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getBic1() {
		return bic1;
	}

	public void setBic1(String bic1) {
		this.bic1 = bic1;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getPlaza() {
		return plaza;
	}

	public void setPlaza(String plaza) {
		this.plaza = plaza;
	}

	public List<SelectItem> getConceptos() {
		return conceptos;
	}

	public void setConceptos(List<SelectItem> conceptos) {
		this.conceptos = conceptos;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConc() {
		return conc;
	}

	public void setConc(String conc) {
		this.conc = conc;
	}

	public String getInforma() {
		return informa;
	}

	public void setInforma(String informa) {
		this.informa = informa;
	}

	public String getAdicional() {
		return adicional;
	}

	public void setAdicional(String adicional) {
		this.adicional = adicional;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getLabel2() {
		return label2;
	}

	public void setLabel2(String label2) {
		this.label2 = label2;
	}

	public BigDecimal getMontoOrd() {
		return montoOrd;
	}

	public void setMontoOrd(BigDecimal montoOrd) {
		this.montoOrd = montoOrd;
	}

	public String getIdConcepto() {
		return idConcepto;
	}

	public void setIdConcepto(String idConcepto) {
		this.idConcepto = idConcepto;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	/**
	 *
	 * Metodo que responde al evento de guardado del formulario
	 *
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		if (MensSwiftUtiles.validarConcepto(concepto) > 0) {
			if ("INV".equals(idConcepto))
				concepto = "/INV/" + concepto;
			else if ("ROC".equals(idConcepto))
				concepto = "/ROC/" + concepto;
			else if ("RBC".equals(idConcepto))
				concepto = "/RBC/" + concepto;

			concepto = this.cortarConcepto();
			if (concepto != "-1") {
				String corrs = Servicios.getCorrelativo(idSoli);

				String sigla = idSoli;

				solicitud.setSocCuentad(Integer.parseInt(idCuenta));
				solicitud.setSocMontoord(BigDecimal.valueOf(0));
				solicitud.setSolCodigo("900");
				solicitud.setClaTipo("OB");
				solicitud.setClaEstado('B');
				solicitud.setSocCorrelativo(sigla + "-" + corrs + "-" + Servicios.obtGestion());
				solicitud.setMoneda(solicitud.getMonedaT());
				detalle.setBenCodigo(idBenef);
				detalle.setDetCtabenef(idCuentaB);
				detalle.setDetMonto(solicitud.getSocMontome());
				detalle.setDetMontoord(solicitud.getSocMontoord());
				detalle.setMoneda(solicitud.getMoneda());
				detalle.setMonedaT(solicitud.getMonedaT());

				detalle.setDetConcepto(concepto.toUpperCase());

				String info1 = "";
				if (!StringUtils.isBlank(informa))
					info1 = informa ;
				if (!StringUtils.isBlank(info1) && !StringUtils.isBlank(adicional))
					info1 = info1 + " " ;
				if (!StringUtils.isBlank(adicional))
					info1 = info1 + adicional;
				
				log.info("informa:" + info1);
				detalle.setDetInfo(info1);

				Date date = new Date();
				long time = date.getTime();
				log.info("Creando el objeto Request para enviar al BPM");

				// parametros para request
				String id = new Long(time).toString();

				// mapa de parametros a enviar a BPM
				Map<String, Object> mapaParametros = new HashMap<String, Object>();
				mapaParametros.put("opcion", "nueva");
				mapaParametros.put("solicitud", solicitud);
				mapaParametros.put("detalle", detalle);

				Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
				if (mapaRespuesta.containsKey("resp_msgerror")) {
					mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
					return;
				}

				String nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
				log.info("Numero de Solicitud: " + nroSolicitud);

				if (!nroSolicitud.equals("-1")) {
					this.mensaje = "La solicitud se registró correctamente con el número " + solicitud.getSocCorrelativo() + ".";
					this.botonHab = true;
				} else {
					this.mensaje = "Se produjo un error al registrar la solicitud.";
					this.botonHab = true;
				}
			} else {
				this.mensaje = "El concepto de la transferencia excede la longitud permitida para este campo.";
				this.botonHab = false;
			}
		} else {
			this.mensaje = "Existen caracteres no válidos en el concepto de la transferencia.";
			this.botonHab = false;
		}
	}

}
