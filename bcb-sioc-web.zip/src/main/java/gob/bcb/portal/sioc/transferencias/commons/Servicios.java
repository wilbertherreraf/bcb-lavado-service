/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.commons.Servicios
 * 26/07/2011 - 14:35:05
 * Creado por Gustavo Flores
 */
package gob.bcb.portal.sioc.transferencias.commons;

import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.portal.sioc.transferencias.controller.ManejadorServicioBPM;
import gob.bcb.portal.sioc.transferencias.model.SocBolsinS;
import gob.bcb.portal.sioc.transferencias.model.Solicitante;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioSioc.common.Constants;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.faces.model.SelectItem;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;

/**
 * Clase que contiene los metodos para comunicarse con la capa de bpm y
 * servicios.
 * 
 * @author Gustavo Flores
 * 
 */
public class Servicios {
	// private static final BcbLog log =
	// BcbLogFactory.getLogger(Servicios.class);
	private static Logger log = Logger.getLogger(Servicios.class);
	public static int contador = 0;

	public static List<Map<String, Object>> ejecutarQuery(String query) {

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		List<Map<String, Object>> resultado = new ArrayList<Map<String, Object>>();
		log.info(contador++ + ":: Ejecutando el query: " + query);
		try {

			con = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			int nroColumnas = rs.getMetaData().getColumnCount();
			ResultSetMetaData md = rs.getMetaData();

			while (rs.next()) {
				Map<String, Object> fila = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= nroColumnas; i++)
					fila.put(md.getColumnLabel(i), rs.getObject(i));
				resultado.add(fila);
			}

			log.info("Query ejecutado satisfactoriamente");
		} catch (Exception e) {
			log.error("ERROR en ejecutar query " + e.getMessage(), e);
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e1) {
				log.error("Error al cerrar recordSet: " + e1.getMessage());
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch (Exception e1) {
				log.error("Error al cerrar Statement: " + e1.getMessage());
			}
			try {
				if (con != null)
					con.close();
				contador--;
			} catch (Exception e1) {
				log.error("Error al cerrar la conexion a DB: " + e1.getMessage());
			}
		}
		return resultado;
	}

	public static String getSigla(String codigo) {
		String query = " select sigla" + " from soc_solicitante " + " where trim(sol_codigo) = '" + codigo + "'";

		// por default el correlativo es
		String sigla = "GRAL";

		List<Map<String, Object>> resultado1 = ejecutarQuery(query);
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				//
				sigla = (String) res.get("sigla");
			}
		} else {
			log.info("Error al obtener sigla de entidad");
		}

		return sigla;
	}

	public static String getSolicitante(String codigo) {
		String query = " select sol_persona" + " from soc_solicitante " + " where trim(sol_codigo) = '" + codigo + "'";

		String soli = "";

		List<Map<String, Object>> resultado1 = ejecutarQuery(query);
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				//
				soli = (String) res.get("sol_persona");
			}
		} else {
			log.info("Error al obtener nombre de entidad");
		}

		return soli;
	}

	public static Solicitante getSocSolicitante(String codigo) {
		if (codigo == null || codigo.trim().isEmpty()) {
			return null;
		}
		codigo = codigo.trim();
		Solicitante solicitante = null;
		String query = " select s.* " + " from soc_solicitante s " + " where s.sol_codigo = '" + codigo + "'";
		List<Map<String, Object>> resultado1 = ejecutarQuery(query);
		if (resultado1.size() > 0) {
			for (Map<String, Object> res : resultado1) {
				solicitante = new Solicitante(((String) res.get("sol_codigo")).trim(), (String) res.get("sol_persona"),
						(String) res.get("cla_entidad"), (String) res.get("sol_direccion"), (String) res.get("sol_plaza"),
						(String) res.get("sol_bic"), (Short) res.get("cla_vigente"), (String) res.get("usr_codigo"), (Date) res.get("fecha_hora"),
						(String) res.get("estacion"), (String) res.get("sigla"));
				solicitante.setSolNit((String) res.get("sol_nit"));
				solicitante.setSolFactura((String) res.get("sol_factura"));
			}
		}

		return solicitante;
	}

	public static List<Solicitante> getSocSolicitanteByBenef(String benCodigo) {
		List<Solicitante> solicitantes = new ArrayList<Solicitante>();
		String query = " select s.* " + " from soc_solicitante s, soc_solbenefs b " + " where s.sol_codigo = b.sol_codigo" + " and b.ben_codigo = '"
				+ benCodigo + "' order by s.sol_persona ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				Solicitante solicitante = new Solicitante((String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_entidad"), (String) res.get("sol_direccion"), (String) res.get("sol_plaza"),
						(String) res.get("sol_bic"), (Short) res.get("cla_vigente"), (String) res.get("usr_codigo"), (Date) res.get("fecha_hora"),
						(String) res.get("estacion"), (String) res.get("sigla"));
				solicitante.setSolNit((String) res.get("sol_nit"));
				solicitante.setSolFactura((String) res.get("sol_factura"));
				solicitantes.add(solicitante);
			}
		}
		return solicitantes;
	}

	public static String getSoli(String codigo) {
		String query = " select trim(sol_codigo) as cod" + " from soc_usuariosol " + " where login = '" + codigo + "'";

		String cod = "";

		List<Map<String, Object>> resultado1 = ejecutarQuery(query);
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				//
				cod = (String) res.get("cod");
			}
		} else {
			log.info("Error al obtener codigo de entidad");
		}

		return cod;
	}

	public static String getNroCuenta(String codigo, Integer cta) {
		String query = " select cta_numero" + " from soc_solcuentas" + " where sol_codigo = '" + codigo + "'" + " and cta_codigo = " + cta;

		String sigla = "";

		List<Map<String, Object>> resultado1 = ejecutarQuery(query);
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				//
				sigla = (String) res.get("cta_numero");
			}
		} else {
			log.info("Error al obtener n�mero de cuenta");
		}

		return sigla;
	}

	public static String getNomCuenta(Integer cta) {
		String query = " select cta_nommovimiento" + " from soc_cuentassol" + " where cta_codigo = " + cta;

		String nom = "";

		List<Map<String, Object>> resultado1 = ejecutarQuery(query);
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {
				//
				nom = (String) res.get("cta_nommovimiento");
			}
		} else {
			log.info("Error al obtener nombre de cuenta");
		}

		return nom;
	}

	public static String getCorrelativo(String codigo) {
		Long corr = (long) 0;
		Long actual = (long) 0;
		String corrs = "";

		String query = " select soc_correlativo as corr" + " from soc_solicitudes " + " where trim(sol_codigo) = '" + codigo + "'"
				+ " and year(fecha) = " + Integer.parseInt(obtGestion()) + " and soc_correlativo like '%-" + obtGestion() + "' ";

		List<Map<String, Object>> rrs = ejecutarQuery(query);
		if (rrs.size() > 0) {
			for (Map<String, Object> rr : rrs) {
				String cc = (rr.get("corr")).toString();
				if (!StringUtils.isBlank(cc)) {
					corrs = StringUtils.substringBetween(cc, "-", "-");

					if (!StringUtils.isBlank(corrs)) {
						if (corrs.length() <= 4) {
							if (NumberUtils.isNumber(corrs)) {
								actual = Long.valueOf(corrs);
							}
						}
					}
					if (actual.compareTo(corr) > 0) {
						corr = actual;
					}
				}
			}
		}

		corr++;

		return String.format("%04d", corr);
	}

	public static String getCodigoS(String tabla, String campo) {
		String corrS = "";
		Long corr = (long) 0;

		String query = " select max(" + campo + ") as corr" + " from " + tabla;

		List<Map<String, Object>> rrs = ejecutarQuery(query);
		if (rrs.size() == 1) {
			for (Map<String, Object> rr : rrs) {
				// log.info("resultado" + rr.toString());
				String cc = (rr.get("corr")).toString();
				corr = Long.valueOf(cc) + 1;
				if (corr < 100) {
					corrS = "0000" + corr;
				} else {
					if (corr < 1000) {
						corrS = "000" + corr;
					} else {
						if (corr < 10000) {
							corrS = "00" + corr;
						} else {
							corrS = "0" + corr;
						}
					}
				}
			}
		} else {
			log.info("Error al obtener correlativo");
		}

		return corrS;
	}

	public static Integer getCodigo(String tabla, String campo) {
		int corr = 0;

		StringBuffer query = new StringBuffer();
		query = query.append("select max(to_number(" + campo + ")) as corr ");
		query = query.append("from " + tabla);
		query = query.append("where " + campo + " not matches '*[a-z|A-Z|.|,]*' ");

		BigDecimal maxi = null;
		List<Map<String, Object>> rrs = ejecutarQuery(query.toString());
		for (Map<String, Object> rr : rrs) {
			// log.info("resultado" + rr.toString());
			maxi = (BigDecimal) (rr.get("corr"));
		}

		String codSolicitud = "0";
		Long codigo = Long.valueOf(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
			codigo++;
		} else {
			codigo = Long.valueOf(1);
		}

		codSolicitud = String.format("%06d", codigo);

		log.info("Cod solicitud nuevo: " + codSolicitud);

		return corr;
	}

	public static String getCorrelativoB(String codigo) {
		Long corr = (long) 0;
		Long actual = (long) 0;
		String corrs = "";

		String query = " select corr" + " from soc_bolsin " + " where trim(sol_codigo) = '" + codigo + "' ";
		if (codigo.equals("GRAL")) {
			query = " select corr " + " from soc_bolsin " + " where corr like '" + codigo + "-%'";
		}

		List<Map<String, Object>> rrs = ejecutarQuery(query);
		if (rrs.size() > 0) {
			for (Map<String, Object> rr : rrs) {
				String cc = (rr.get("corr")).toString();
				corrs = StringUtils.substringBetween(cc, "-", "-");
				if (corrs != null) {
					actual = Long.valueOf(corrs);
				}
				if (actual.compareTo(corr) > 0) {
					corr = actual;
				}
			}
		}
		corr++;

		return String.format("%04d", corr);
	}

	// crea el correlativo numeral para solicitantes creados por participantes
	// IFA externos
	public static String getCorrelativoSocSolExternos(String solCodigo) {
		Long corr = (long) 0;
		Long actual = (long) 0;
		String corrs = "";
		String prefijo = (solCodigo == null || solCodigo.trim().isEmpty() ? "E" : solCodigo);

		String query = "select sol_codigo from soc_solicitante where sol_codigo like '" + prefijo + "-%'";

		List<Map<String, Object>> rrs = ejecutarQuery(query);
		if (rrs.size() > 0) {
			for (Map<String, Object> rr : rrs) {
				String cc = (rr.get("sol_codigo")).toString();
				corrs = StringUtils.substring(cc, prefijo.length() + 1);
				if (corrs != null) {
					try {
						actual = Long.valueOf(corrs);
					} catch (Exception e) {
						// no pasa nada
						;
						;
					}
				}
				if (actual.compareTo(corr) > 0) {
					corr = actual;
				}
			}
		}
		corr++;

		return prefijo + "-" + String.format("%06d", corr);
	}

	public static Integer getMoneda(String moneda) {
		int mon = 0;

		String query = " select val_codigo" + " from soc_valorescla " + " where cla_codigo = 'cla_moneda' " + " and val_nombre = '" + moneda + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				//
				mon = Integer.parseInt((res.get("val_codigo")).toString());
			}
		} else {
			log.info("Error al obtener c�digo de moneda");
		}

		return mon;
	}

	public static String getComision(String tipo) {
		String comi = "";

		String query = " select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_comision' " + " and val_codigo = '" + tipo + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				//
				comi = (String) res.get("val_nombre");
			}
		} else {
			log.info("Error al obtener valor de comisi�n");
		}

		return comi;
	}

	public static BigDecimal getTotalP(String soli) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select sum(det_monto) as monto " + "from soc_plantillasol " + "where trim(sol_codigo) = '" + soli + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				//
				monto = (BigDecimal) res.get("monto");
			}
		} else {
			log.info("Lista Nula");
		}

		return monto;
	}

	public static Timestamp getFechaHora() {
		Timestamp fh = null;

		String query = "SELECT current as fh FROM soc_solicitante WHERE sol_codigo = '900   '";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				//
				fh = (Timestamp) res.get("fh");
			}
		} else {
			log.info("Lista Nula");
		}

		return fh;
	}

	public static Integer getHoraLimite(String opcion) {
		Integer hora = 0;

		String query = "select val_nombre " + "from soc_valorescla " + "where cla_codigo = 'cla_horas' " + "and val_codigo = '" + opcion + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				//
				hora = Integer.parseInt((res.get("val_nombre")).toString());
			}
		} else {
			log.info("Lista Nula");
		}

		return hora;
	}

	public static String getParam(String param) {
		String valor = "";

		String query = "SELECT par_valor " + "FROM soc_parametros WHERE par_codigo = '" + param + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				//
				valor = (String) res.get("par_valor");
			}
		}

		return valor;
	}

	public static List<SocBolsin> getSocBolsinList(String claEstado, Date fecha, String codIFASolicitante) {
		return getSocBolsinList(claEstado, fecha, codIFASolicitante, "'G','E'");
	}

	public static List<SocBolsin> getSocBolsinList(String claEstado, Date fecha, String codIFASolicitante, String tipoSolic) {

		List<SocBolsin> solicitudes = new ArrayList<SocBolsin>();
		SocBolsin solicitudB;

		String query = "select s.*, ss.sol_persona, ";
		query = query
				.concat("(select trim(v.val_nombre) from soc_valorescla v where v.cla_codigo = 'cla_tipsolic' and v.val_codigo = s.cla_tipsolic) as cla_tipsolicdesc, ");
		query = query
				.concat("(select trim(v.val_nombre) from soc_valorescla v where v.cla_codigo = 'cla_estado' and v.val_codigo = s.cla_estado) as cla_estadodesc, ");
		query = query.concat("s.origen_fondos, s.destino_fondos, s.motivo_fondos ");		
		query = query.concat("from soc_bolsin s, soc_solicitante ss ");
		query = query.concat("where s.sol_codigo = ss.sol_codigo" + " and s.cla_estado in (" + claEstado + ") ");

		if (fecha != null) {
			Calendar fechaAl = GregorianCalendar.getInstance();
			fechaAl.setTime(fecha);
			String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + ","
					+ fechaAl.get(Calendar.YEAR) + ") ";
			query += " and s.fecha = " + strFecha;
		}
		// whf rq02
		if (!StringUtils.isEmpty(codIFASolicitante)) {
			query += " and s.sol_codigo = '" + codIFASolicitante + "' ";
			if (!StringUtils.isEmpty(tipoSolic)) {
				query += " and s.cla_tipsolic in (" + tipoSolic + ") ";
			}
		} else {
			// whf vd
			// si es nulo viene de un usuario BCB para operaciones bolsin
			if (!StringUtils.isEmpty(tipoSolic))
				query += " and s.cla_tipsolic in (" + tipoSolic + ") ";
		}
		// log.info("Query ejecutado: " + query);
		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				solicitudB = new SocBolsin((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (Date) res.get("fecha"),
						(String) res.get("corr"), (Integer) res.get("seq"), (Integer) res.get("cuentad"), (BigDecimal) res.get("cotiz"),
						(BigDecimal) res.get("montosol"), (BigDecimal) res.get("montoadj"), (BigDecimal) res.get("montomn"),
						((String) res.get("cla_estado")).charAt(0), (String) res.get("benef"), (String) res.get("usr_codigo"),
						(Date) res.get("fecha_hora"), (String) res.get("estacion"));
				solicitudB.setClaTipsolic((String) res.get("cla_tipsolic"));
				solicitudB.setBolCtamn((String) res.get("bol_ctamn"));
				solicitudB.setBolCtame((String) res.get("bol_ctame"));
				solicitudB.setOrigenFondos((String) res.get("origen_fondos"));
				solicitudB.setDestinoFondos((String) res.get("destino_fondos"));
				solicitudB.setMotivoFondos((String) res.get("motivo_fondos"));
				
				solicitudes.add(solicitudB);
			}
		}
		return solicitudes;
	}

	public static List<SocBolsinS> getSocBolsinSList(String claEstado, Date fecha, String codIFASolicitante) {

		return getSocBolsinSList(claEstado, fecha, codIFASolicitante, "'G','E'");
	}

	public static List<SocBolsinS> getSocBolsinSList(String claEstado, Date fecha, String codIFASolicitante, String tipoSolic) {
		List<SocBolsinS> solicitudes = new ArrayList<SocBolsinS>();
		SocBolsinS solicitudBS;

		String query = "select s.*, ss.sol_persona, ";
		query = query
				.concat("(select trim(v.val_nombre) from soc_valorescla v where v.cla_codigo = 'cla_tipsolic' and v.val_codigo = s.cla_tipsolic) as cla_tipsolicdesc, ");
		query = query
				.concat("(select trim(v.val_nombre) from soc_valorescla v where v.cla_codigo = 'cla_estado' and v.val_codigo = s.cla_estado) as cla_estadodesc, ");
		query = query.concat("s.origen_fondos, s.destino_fondos, s.motivo_fondos ");
		query = query.concat("from soc_bolsin s, soc_solicitante ss ");
		query = query.concat("where s.sol_codigo = ss.sol_codigo ");

		if (!StringUtils.isEmpty(claEstado)) {
			query = query.concat(" and s.cla_estado in (" + claEstado + ")");
		}

		if (fecha != null) {
			Calendar fechaAl = GregorianCalendar.getInstance();
			fechaAl.setTime(fecha);
			String strFecha = " mdy(" + (fechaAl.get(Calendar.MONTH) + 1) + "," + fechaAl.get(Calendar.DAY_OF_MONTH) + ","
					+ fechaAl.get(Calendar.YEAR) + ") ";
			query += " and s.fecha = " + strFecha;
		}
		if (!StringUtils.isEmpty(codIFASolicitante)) {
			query += " and s.sol_codigo = '" + codIFASolicitante + "' ";
			// whf rq02
			if (!StringUtils.isEmpty(tipoSolic)) {
				query += " and s.cla_tipsolic in (" + tipoSolic + ") ";
			}
		} else {
			// whf vd
			// si es nulo viene de un usuario BCB para operaciones bolsin
			if (!StringUtils.isEmpty(tipoSolic))
				query += " and s.cla_tipsolic in (" + tipoSolic + ") ";
		}

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				solicitudBS = new SocBolsinS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(Date) res.get("fecha"), (String) res.get("corr"), (Integer) res.get("seq"), (BigDecimal) res.get("cotiz"),
						(BigDecimal) res.get("montosol"), (BigDecimal) res.get("montoadj"), (String) res.get("cla_estado"),
						(String) res.get("benef"), "");

				solicitudBS.setClaTipsolic((String) res.get("cla_tipsolicdesc"));
				solicitudBS.setEstado((String) res.get("cla_estadodesc"));
				solicitudBS.setOrigenFondos((String) res.get("origen_fondos"));
				solicitudBS.setDestinoFondos((String) res.get("destino_fondos"));
				solicitudBS.setMotivoFondos((String) res.get("motivo_fondos"));

				String clatipsolic = (String) (res.get("cla_tipsolic"));
				if (!StringUtils.isEmpty(clatipsolic)) {
					if (clatipsolic.trim().equals("G") || clatipsolic.trim().equals("GD")) {
						// si es el solicitante un tercero o pub general
						Solicitante solicitante = Servicios.getSocSolicitante(solicitudBS.getBenef());
						if (solicitante != null) {
							solicitudBS.setBenef(solicitante.getSolPersona());
							solicitudBS.setSolNit(solicitante.getSolNit());
							solicitudBS.setSolFactura(solicitante.getSolFactura());
						}
					}
				}
				solicitudes.add(solicitudBS);
			}
		}
		return solicitudes;
	}

	public static String obtGestion() {
		String formato = "yyyy";
		SimpleDateFormat dateFormat = new SimpleDateFormat(formato);
		return dateFormat.format(new Date());
	}

	public BigDecimal getDemanda(Date fecha) {
		log.info("Entre a buscar el objeto con el id: " + fecha);
		// whf vd
		BigDecimal tt = BigDecimal.valueOf(0.00);
		BigDecimal totalAdj = BigDecimal.valueOf(0.00);
		try {
			StringBuffer query = new StringBuffer();
			query = query.append(" select montoadj from  Soc_Bolsin cc where cc.fecha = ?  and cc.cla_tipsolic in ('G','E') ");

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query.toString());
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					//
					tt = (BigDecimal) (res.get("montoadj"));
					totalAdj = totalAdj.add(tt);
				}
			} else {
				log.info("Lista Nula");
			}
		} catch (Exception e) {
			log.error("Error en el metodo getDemanda: " + e.getMessage());
			e.printStackTrace();
		}

		return tt;
	}

	// whf rq01
	public static BigDecimal getTipoCambio(int mon) {
		BigDecimal tc = BigDecimal.valueOf(0);
		Date fecha = new Date();

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("fecha", fecha);
		mapaParametros1.put("moneda", mon);
		mapaParametros1.put("consulta", "tc");

		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: factor_conv_mn");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros1, iid1);
			tc = (BigDecimal) mapaResultado1.get("tc");
		} catch (Exception e) {
			log.error("Error al obtener tipo de cambio", e);
		}

		return tc;
	}

	public static List<SelectItem> listaMonedas(String moneda) {
		List<SelectItem> listaSelect = new ArrayList<SelectItem>();
		int mon = 0;

		String query = " select cod_moneda, mon_nombre " + " from gen_moneda ";

		List<Map<String, Object>> resultado = ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			//
			listaSelect.add(new SelectItem(res.get("cod_moneda"), (String) res.get("mon_nombre")));
		}

		return listaSelect;
	}

	public static String getValorNombreClave(String clave, String cod) {
		String ctaS = "";

		String query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = '" + clave + "' " + "AND val_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			ctaS = (String) res.get("val_nombre");
		}

		return ctaS;
	}


	public static List<SelectItem> valoresLista(String claCodigo) {
		List<SelectItem> listaSelect = new ArrayList<SelectItem>();
		int mon = 0;

		String query = " select val_codigo, val_nombre " + " from soc_valorescla where cla_codigo = '" + claCodigo + "' ";

		List<Map<String, Object>> resultado = ejecutarQuery(query);
		for (Map<String, Object> res : resultado) {
			//
			listaSelect.add(new SelectItem(res.get("val_codigo"), (String) res.get("val_nombre")));
		}

		return listaSelect;
	}

	public static void main(String[] args) {
		System.out.println("=========> ");
		// System.out.println(StringUtils.substringBetween("a-  asdf  -sf",
		// "-","-"));
		// System.out.println(StringUtils.substringBetween("asdf  -sf",
		// "-","-"));
		// System.out.println(StringUtils.substringBetween("-asdf", "-","-"));
		// System.out.println(StringUtils.substringBetween("asdf", "-","-"));
		ConfigurationServ.setHomeProperty("e:/opt/aplicaciones/servicios/sioc/config");
		ConfigurationServ.init("e:/opt/aplicaciones/servicios/sioc/config");
		System.out.println(Servicios.getCorrelativo("500"));
		// System.out.println("=========> " + "asdfdd".hashCode());
		// List<SocBolsin> l = Servicios.getSocBolsinList("'1'", null, "901" );
		// System.out.println(l.size());
		// for (SocBolsin socBolsin : l) {
		// System.out.println(socBolsin.getClaEstado());
		// System.out.println(socBolsin.getCuentaD());
		// }

	}
}
