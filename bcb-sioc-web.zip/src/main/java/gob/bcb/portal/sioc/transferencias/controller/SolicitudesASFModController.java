package gob.bcb.portal.sioc.transferencias.controller;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.Opecomi;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.portal.sioc.transferencias.commons.Servicios;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.richfaces.component.html.HtmlDataTable;

public class SolicitudesASFModController extends BaseBeanController {

	private SocSolicitudes solicitud = new SocSolicitudes();
	private SolicitudesS solicitudS = new SolicitudesS();
	private SocDetallessol detalle = new SocDetallessol();
	private List<SolicitudesS> solicitudes;
	private List<SocSolicitudes> listaSoli;
	private List<SelectItem> cuentasD = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasC = new ArrayList<SelectItem>();
	private List<SelectItem> benefs = new ArrayList<SelectItem>();
	private List<SelectItem> solics = new ArrayList<SelectItem>();
	private List<SelectItem> cuentasB = new ArrayList<SelectItem>();
	private List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
	private Opecomi comision;
	private List<Opecomi> comisiones = new ArrayList<Opecomi>();
	private String nroSolicitud = "";
	private String idSoli = "-1";
	private String codigo = "";
	private String idBenef = "-1";
	private String idCuenta = "-1";
	private String idCuentaC = "-1";
	private String idMoneda = "-1";
	private Integer idCuentaB = -1;
	private String idDescuento = "NO";
	private String cuenta = "";
	private String concepto = "";
	private String info = "";
	private String bic = "";
	private String bic1 = "";
	private String banco = "";
	private String plaza = "";
	private String informa = "";
	private String info1 = "";
	private String mensaje = "";
	private String label2 = "";
	private BigDecimal total = BigDecimal.valueOf(0);
	private BigDecimal montoOrd = BigDecimal.valueOf(0);
	private BigDecimal montoME = BigDecimal.valueOf(0);
	private Boolean cuentaHab = false;
	private Boolean montoVer = false;
	private Boolean cuentaVer = true;
	private Boolean botonHab = true;
	private Boolean interVer = false;
	private Boolean comiVer = false;

	private String urlReporte;

	private Logger log = Logger.getLogger(SolicitudesASFModController.class);
	private static final String CLIENTE = "cliente";
	private static final String CONSULTA = "consulta";
	private static final String BPMSIOC = "bpmPruebaCU";
	private static final String ESTACION = "";

	public SolicitudesASFModController() {
		recuperarVisit();
		idSoli = getVisit().getUsuarioSession().getSolicitante().getSolCodigo();

		this.recuperarSolicitudes();
	}

	private void recuperarSolicitudes() {
		this.solicitudes = new ArrayList<SolicitudesS>();
		this.listaSoli = new ArrayList<SocSolicitudes>();

		String query = "";

		if (!idSoli.equals("900")) {
			query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
					+ " and s.cla_estado = 'B'" + " and trim(s.sol_codigo) = '" + idSoli + "' and ss.cla_entidad = 'SF' ";
		} else {
			idSoli = "-1";
			query = " select s.*, ss.sol_persona " + " from soc_solicitudes s, soc_solicitante ss " + " where s.sol_codigo = ss.sol_codigo"
					+ " and s.cla_estado = 'B'" + " and ss.cla_entidad = 'SF'";
		}

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				solicitudS = new SolicitudesS((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("sol_persona"),
						(String) res.get("cla_tipo"), (String) res.get("moneda"), 'B', (Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"),
						(String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"), (BigDecimal) res.get("soc_montomn"), "");
				if (solicitudS.getClaTipo().equals("TE")) {
					solicitudS.setPanel1(true);
					solicitudS.setPanel2(false);
					solicitudS.setPanel3(false);
					solicitudS.setTipo("TRANSFERENCIA AL EXTERIOR");
				}
				solicitudes.add(solicitudS);

				solicitud = new SocSolicitudes((String) res.get("soc_codigo"), (String) res.get("sol_codigo"), (String) res.get("cla_tipo"),
						(Integer) res.get("soc_cuentad"), (String) res.get("soc_nrocuentad"), (String) res.get("moneda"), 'B',
						(Date) res.get("fecha"), (BigDecimal) res.get("soc_montome"), (Integer) res.get("soc_cuentac"),
						(String) res.get("soc_nrocuentac"), (String) res.get("soc_correlativo"), (BigDecimal) res.get("soc_montoord"),
						(BigDecimal) res.get("soc_montomn"), (String) res.get("soc_nropago"), (String) res.get("monedat"));
				listaSoli.add(solicitud);
			}
		} else {
			log.info("Lista Nula");
		}
	}

	public void verSolicitud(ActionEvent event) {
		HtmlDataTable dataTable = (HtmlDataTable) event.getComponent().getParent().getParent();
		int fila = dataTable.getRowIndex();
		this.solicitudS = this.solicitudes.get(fila);
		this.solicitud = this.listaSoli.get(fila);
		String query = " select d.* " + " from soc_detallessol d " + " where d.soc_codigo = '" + solicitud.getSocCodigo() + "'"
				+ " and d.det_codigo = 1";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		if (resultado1.size() == 1) {
			for (Map<String, Object> res : resultado1) {

				detalle = new SocDetallessol(new SocDetallessolId((String) res.get("soc_codigo"), (Integer) res.get("det_codigo")),
						(String) res.get("ben_codigo"), (BigDecimal) res.get("det_monto"), (String) res.get("moneda"),
						(Integer) res.get("det_ctabenef"), (String) res.get("det_concepto"), (String) res.get("det_info"),
						(BigDecimal) res.get("det_montoord"), (String) res.get("monedat"), (String) res.get("det_facturas"));
			}

			log.info("sol: " + solicitudS.getSolicitante());
			setIdSoli(solicitud.getSolCodigo());
			setIdCuenta(solicitud.getSocCuentad().toString());
			setIdCuentaC(solicitud.getSocCuentac().toString());

			setIdBenef(detalle.getBenCodigo());
			setIdCuentaB(detalle.getDetCtabenef());

			query = "SELECT cc.cta_nrocuenta, bb.bco_nombre, " + " pp.pla_nombre, pp.pla_bic, pp.pla_nrocuenta "
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
					+ " AND cc.cla_vigente = 1 AND cc.cta_codigo = '" + idCuentaB + "'";

			List<Map<String, Object>> resultado3 = Servicios.ejecutarQuery(query);
			if (resultado3.size() > 0) {
				interVer = false;
				for (Map<String, Object> res : resultado3) {

					banco = (String) res.get("bco_nombre") + (String) res.get("pla_nombre");
					bic = (String) res.get("pla_bic");
					if (bic == null)
						bic = (String) res.get("pla_nrocuenta");
					bic1 = "";
					plaza = "";
				}
			}
			concepto = detalle.getDetConcepto();
		}

	}

	public List<SelectItem> getCuentasD() {
		log.info("enter getcuentasD");
		if (!idSoli.equals("-1")) {
			cuentasD.clear();

			String query = " select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " from soc_solcuentas sc, soc_cuentassol cc "
					+ " where sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") != 69) {
						if (res.get("cta_numero") != null) {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD-" + res.get("cta_numero")));
						} else {
							cuentasD.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento")
									+ "-USD"));
						}
					}
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			cuentasD.clear();
		}

		return cuentasD;
	}

	public List<SelectItem> getBenefs() {
		log.info("enter getbenefs");
		if (idSoli != "-1") {
			benefs.clear();

			String query = "SELECT ss.ben_codigo, bb.ben_nombre, 1, bb.ben_nit, bb.ben_factura "
					+ "FROM soc_solbenefs ss, soc_benefs bb WHERE ss.ben_codigo = bb.ben_codigo "
					+ "AND ss.cla_vigente = 1 and bb.cla_vigente = 1 AND trim(ss.sol_codigo) = '" + idSoli + "' " + "ORDER BY bb.ben_nombre ";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado != null) {
				for (Map<String, Object> res : resultado) {

					benefs.add(new SelectItem(res.get("ben_codigo"), (String) res.get("ben_nombre")));
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			benefs.clear();
		}

		return benefs;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getCuentasB() {
		cuentasB.clear();
		String moneda = "";

		if (idBenef != "-1") {
			String query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
					+ " pp.pla_nombre, pp.pla_bic, pp.pla_intermediario, pp.pla_nrocuenta, bb1.bco_nombre as bco1, " + " pp1.pla_nombre as pla1"
					+ " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp, soc_plazas pp1, soc_bancos bb1 "
					+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo "
					+ " AND pp.bco_codigo = bb.bco_codigo AND pp.pla_intermediario = pp1.pla_bic "
					+ " AND pp1.bco_codigo = bb1.bco_codigo AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
			if (resultado.size() > 0) {
				for (Map<String, Object> res : resultado) {
					interVer = true;

					if ((Integer) res.get("moneda") == 34)
						moneda = "USD";
					if ((Integer) res.get("moneda") == 53)
						moneda = "EUR";
					if ((Integer) res.get("moneda") == 31)
						moneda = "CHF";
					cuentasB.add(new SelectItem(res.get("cta_codigo"), res.get("cta_nrocuenta") + "-" + moneda));
					listaCuentasB.add(new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"),
							(String) res.get("cta_info"), (Integer) res.get("moneda"), (String) res.get("bco_nombre"),
							(String) res.get("pla_nombre"), (String) res.get("pla_bic"), (String) res.get("pla_intermediario"), (String) res
									.get("pla_nrocuenta"), (String) res.get("bco1"), (String) res.get("pla1")));
				}
			} else {
				query = "SELECT cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_nombre, "
						+ " pp.pla_nombre, pp.pla_bic, pp.pla_nrocuenta " + " FROM soc_cuentas cc, soc_bancos bb, soc_plazas pp "
						+ " WHERE cc.bco_codigo = pp.bco_codigo AND cc.pla_codigo = pp.pla_codigo " + " AND pp.bco_codigo = bb.bco_codigo "
						+ " AND cc.cla_vigente = 1 AND cc.ben_codigo = '" + idBenef + "'";

				List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
				if (resultado1.size() > 0) {
					interVer = false;
					for (Map<String, Object> res : resultado1) {

						if ((Integer) res.get("moneda") == 34)
							moneda = "USD";
						if ((Integer) res.get("moneda") == 53)
							moneda = "EUR";
						if ((Integer) res.get("moneda") == 31)
							moneda = "CHF";
						cuentasB.add(new SelectItem(res.get("cta_codigo"), res.get("cta_nrocuenta") + "-" + moneda));
						listaCuentasB.add(new CuentasBen((Integer) res.get("cta_codigo"), (String) res.get("cta_nrocuenta"), (String) res
								.get("cta_info"), (Integer) res.get("moneda"), (String) res.get("bco_nombre"), (String) res.get("pla_nombre"),
								(String) res.get("pla_bic"), (String) res.get("pla_nrocuenta")));
					}
				} else {
					interVer = false;
					log.info("Lista Nula");
				}
			}
		} else {
			cuenta = "";
			bic = "";
			bic1 = "";
			banco = "";
			plaza = "";
			informa = "";
			info1 = "";
		}

		return cuentasB;
	}

	@SuppressWarnings("unchecked")
	public List<SelectItem> getCuentasC() {
		String idC;
		String moneda = "";

		if (idCuenta != "-1") {
			cuentasC.clear();

			if ("SI".equals(idDescuento)) {
				idC = Integer.toString(0);
			} else {
				idC = idCuenta;
			}

			/*
			 * String query =
			 * " SELECT sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
			 * +
			 * " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable "
			 * + " FROM soc_solcuentas sc, soc_cuentassol cc " +
			 * " WHERE sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " +
			 * " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli +
			 * "' and sc.cta_codigo <> '" + idC + "'";
			 */

			log.info("idc:" + idC);

			String query = " SELECT sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, "
					+ " cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable " + " FROM soc_solcuentas sc, soc_cuentassol cc "
					+ " WHERE sc.cta_codigo = cc.cta_codigo and sc.cla_vigente = 1 " + " and cc.cla_vigente = 1 and trim(sc.sol_codigo) = '" + idSoli
					+ "'";

			List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
			if (resultado1 != null) {
				for (Map<String, Object> res : resultado1) {

					if ((Integer) res.get("moneda") == 34)
						moneda = "-USD";
					if ((Integer) res.get("moneda") == 69)
						moneda = "";
					if (res.get("cta_numero") != null) {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda
								+ "-" + res.get("cta_numero")));
					} else {
						cuentasC.add(new SelectItem(res.get("cta_codigo"), res.get("cta_movimiento") + "-" + res.get("cta_nommovimiento") + moneda));
					}
				}
			} else {
				log.info("Lista Nula");
			}
		} else {
			cuentasC.clear();
		}

		return cuentasC;
	}

	public void seleccionChanged(ValueChangeEvent event) {
		Integer sel = (Integer) event.getNewValue();
		idCuentaB = sel;
		log.info("Valor seleccionado: " + sel);

		cuenta = "";
		bic = "";
		bic1 = "";
		banco = "";
		plaza = "";
		informa = "";
		info1 = "";

		if (idCuentaB != -1) {
			for (CuentasBen cuentaB : listaCuentasB) {
				if (cuentaB.getCtaCodigo().compareTo(idCuentaB) == 0) {
					if (!interVer) {
						bic = cuentaB.getPlaBic();
						if (bic != null)
							label2 = "BIC:";
						else {
							bic = cuentaB.getPlaNroCuenta();
							label2 = "Cuenta:";
						}
					} else {
						bic = cuentaB.getPlaNroCuenta();
						if (bic != null)
							label2 = "Cuenta:";
						else {
							bic = cuentaB.getPlaBic();
							label2 = "BIC:";
						}
					}
					cuenta = cuentaB.getCtaNroCuenta();
					banco = cuentaB.getBcoNombre() + " - " + cuentaB.getPlaNombre();
					bic1 = cuentaB.getPlaIntermediario();
					plaza = cuentaB.getBcoNombreI() + " - " + cuentaB.getPlaNombreI();
					informa = cuentaB.getCtaInfo();
					info1 = informa;
					log.info("info: " + info1);
				}
			}
		}
	}

	public void montoChanged(ValueChangeEvent event) {
		log.info("enter changed");
		Long montoL = (Long) event.getNewValue();
		Double montoD = montoL.doubleValue();
		setComiVer(true);
		calcularComisiones(BigDecimal.valueOf(montoD));
	}

	private void calcularComisiones(BigDecimal monto) {
		Date fecha = new Date();
		int monUS = 34;
		BigDecimal tc1 = BigDecimal.valueOf(0.00);
		comisiones.clear();
		total = BigDecimal.valueOf(0);

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("fecha", fecha);
		mapaParametros1.put("moneda", monUS);
		mapaParametros1.put("consulta", "tc");

		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: factor_conv_mn");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", "172.29.18.3", "cliente", "query", mapaParametros1, iid1);
			tc1 = (BigDecimal) mapaResultado1.get("tc");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BigDecimal comi = monto.multiply(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CTRF"))).divide(BigDecimal.valueOf(100))).divide(
				BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		comision = new Opecomi();
		comision.setOcoMonto(comi.multiply(tc1).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
		comision.setDescripcion("TRANSFERENCIA AL EXTERIOR");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("SWFT"))));
		comision.setDescripcion("GASTOS DE COMUNICACIÓN");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
		comision = new Opecomi();
		comision.setOcoMonto(BigDecimal.valueOf(Double.valueOf(Servicios.getComision("UTIL"))));
		comision.setDescripcion("EMISIÓN DE COMPROBANTES");
		comisiones.add(comision);
		total = total.add(comision.getOcoMonto());
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitudTest) {
		this.solicitud = solicitudTest;
	}

	public void setSolicitudS(SolicitudesS solicitudS) {
		this.solicitudS = solicitudS;
	}

	public SolicitudesS getSolicitudS() {
		return solicitudS;
	}

	public SocDetallessol getDetalle() {
		return detalle;
	}

	public void setDetalle(SocDetallessol detalle) {
		this.detalle = detalle;
	}

	public List<SolicitudesS> getSolicitudes() {
		return solicitudes;
	}

	public void setSolicitudes(List<SolicitudesS> solicitudes) {
		this.solicitudes = solicitudes;
	}

	/*
	 * public List<SelectItem> getCuentasD() { return cuentasD; }
	 */

	public void setCuentasD(List<SelectItem> cuentasD) {
		this.cuentasD = cuentasD;
	}

	/*
	 * public List<SelectItem> getBenefs() { return benefs; }
	 */

	public void setBenefs(List<SelectItem> benefs) {
		this.benefs = benefs;
	}

	public List<SelectItem> getSolics() {
		return solics;
	}

	public void setSolics(List<SelectItem> solics) {
		this.solics = solics;
	}

	public void setCuentasB(List<SelectItem> cuentasB) {
		this.cuentasB = cuentasB;
	}

	public List<CuentasBen> getListaCuentasB() {
		return listaCuentasB;
	}

	public void setListaCuentasB(List<CuentasBen> listaCuentasB) {
		this.listaCuentasB = listaCuentasB;
	}

	public void setComision(Opecomi comision) {
		this.comision = comision;
	}

	public Opecomi getComision() {
		return comision;
	}

	public void setComisiones(List<Opecomi> comisiones) {
		this.comisiones = comisiones;
	}

	public List<Opecomi> getComisiones() {
		return comisiones;
	}

	public String getIdSoli() {
		return idSoli;
	}

	public void setIdSoli(String idSoli) {
		this.idSoli = idSoli;
	}

	public String getIdBenef() {
		return idBenef;
	}

	public void setIdBenef(String idBenef) {
		this.idBenef = idBenef;
	}

	public void setIdCuentaB(Integer idCuentaB) {
		this.idCuentaB = idCuentaB;
	}

	public Integer getIdCuentaB() {
		return idCuentaB;
	}

	public String getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}

	public void setIdCuentaC(String idCuentaC) {
		this.idCuentaC = idCuentaC;
	}

	public String getIdCuentaC() {
		return idCuentaC;
	}

	public void setIdMoneda(String idMoneda) {
		this.idMoneda = idMoneda;
	}

	public String getIdMoneda() {
		return idMoneda;
	}

	public void setCuentasC(List<SelectItem> cuentasC) {
		this.cuentasC = cuentasC;
	}

	public String getCuenta() {
		return cuenta;
	}

	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}

	public String getBic() {
		return bic;
	}

	public void setBic(String bic) {
		this.bic = bic;
	}

	public String getBic1() {
		return bic1;
	}

	public void setBic1(String bic1) {
		this.bic1 = bic1;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getPlaza() {
		return plaza;
	}

	public void setPlaza(String plaza) {
		this.plaza = plaza;
	}

	public String getInforma() {
		return informa;
	}

	public void setInforma(String informa) {
		this.informa = informa;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getLabel2() {
		return label2;
	}

	public void setLabel2(String label2) {
		this.label2 = label2;
	}

	public BigDecimal getMontoOrd() {
		return montoOrd;
	}

	public void setMontoOrd(BigDecimal montoOrd) {
		this.montoOrd = montoOrd;
	}

	public void setMontoME(BigDecimal montoME) {
		this.montoME = montoME;
	}

	public BigDecimal getMontoME() {
		return montoME;
	}

	public String getIdDescuento() {
		return idDescuento;
	}

	public void setIdDescuento(String idDescuento) {
		this.idDescuento = idDescuento;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public void setTotal(BigDecimal total) {
		this.total = total;
	}

	public BigDecimal getTotal() {
		return total;
	}

	public Boolean getCuentaHab() {
		return cuentaHab;
	}

	public void setCuentaHab(Boolean cuentaHab) {
		this.cuentaHab = cuentaHab;
	}

	public Boolean getMontoVer() {
		return montoVer;
	}

	public void setMontoVer(Boolean montoVer) {
		this.montoVer = montoVer;
	}

	public void setCuentaVer(Boolean cuentaVer) {
		this.cuentaVer = cuentaVer;
	}

	public Boolean getCuentaVer() {
		return cuentaVer;
	}

	public Boolean getBotonHab() {
		return botonHab;
	}

	public void setBotonHab(Boolean botonHab) {
		this.botonHab = botonHab;
	}

	public Boolean getInterVer() {
		return interVer;
	}

	public void setInterVer(Boolean interVer) {
		this.interVer = interVer;
	}

	public void setComiVer(Boolean comiVer) {
		this.comiVer = comiVer;
	}

	public Boolean getComiVer() {
		return comiVer;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?cod=" + nroSolicitud + "&tipo=SF";
		return urlReporte;
	}

	public void setUrlReporte(String urlReporte) {
		this.urlReporte = urlReporte;
	}

	/**
	 * 
	 * Metodo que responde al evento de guardado del formulario
	 * 
	 * @throws Exception
	 */
	public void eventoGuardarBtn(ActionEvent action) throws Exception {
		log.info("Ingresando al boton Guardar");

		solicitud.setSocCuentad(Integer.parseInt(idCuenta));
		solicitud.setSocCuentac(Integer.parseInt(idCuentaC));
		solicitud.setSocMontoord(BigDecimal.valueOf(0));
		detalle.setBenCodigo(idBenef);
		detalle.setDetMonto(solicitud.getSocMontome());
		detalle.setDetMontoord(solicitud.getSocMontoord());
		detalle.setMoneda(solicitud.getMoneda());

		detalle.setDetConcepto(concepto.toUpperCase());
		detalle.setDetInfo(info);

		Date date = new Date();
		long time = date.getTime();
		log.info("Creando el objeto Request para enviar al BPM");

		// parametros para request
		String id = new Long(time).toString();

		// mapa de parametros a enviar a BPM
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("opcion", "modificar");
		mapaParametros.put("solicitud", solicitud);
		mapaParametros.put("detalle", detalle);

		Map<String, Object> mapaRespuesta = ManejadorServicioBPM.consultaBPM(BPMSIOC, ESTACION, CLIENTE, CONSULTA, mapaParametros, id);
		if (mapaRespuesta.containsKey("resp_msgerror")) {
			mensaje = "Se produjo un error:: " + mapaRespuesta.get("resp_msgerror");
			return;
		}

		nroSolicitud = (String) mapaRespuesta.get("codSolicitud");
		log.info("Numero de Solicitud: " + nroSolicitud);

		if (!nroSolicitud.equals("-1")) {
			this.mensaje = "La solicitud " + solicitud.getSocCorrelativo() + " se guardó exitosamente.";
			this.botonHab = true;
			this.recuperarSolicitudes();
		} else {
			this.mensaje = "Se produjo un error al guardar la solicitud.";
			this.botonHab = true;
		}
	}

}
