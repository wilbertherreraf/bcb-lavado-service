package gob.bcb.portal.sioc.view;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.SocBancos;
import gob.bcb.bpm.pruebaCU.SocBenefs;
import gob.bcb.bpm.pruebaCU.SocBenefsreg;
import gob.bcb.bpm.pruebaCU.SocCuentas;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocPlazas;
import gob.bcb.bpm.pruebaCU.SocPlazasId;
import gob.bcb.bpm.pruebaCU.SocSolbenefs;
import gob.bcb.bpm.pruebaCU.SocSolbenefsId;
import gob.bcb.bpm.pruebaCU.SocSolicitante;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.ArchivoUtil;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.portal.sioc.transferencias.commons.BaseBeanController;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.service.ArchivoSinpleServiceImpl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.model.SelectItem;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.richfaces.event.UploadEvent;
import org.richfaces.model.UploadItem;

public class SocBenefsController extends BaseBeanController {
	private Logger log = Logger.getLogger(SocBenefsController.class);

	private SocBenefs socBenefsSelected = new SocBenefs();
	private SocBenefsreg socBenefsregSelected = new SocBenefsreg();
	private SocCuentas socCuentasSelected = new SocCuentas();
	private SocSolicitante socSolicitante = new SocSolicitante();
	private SocSolbenefs socSolbenefsSelected = new SocSolbenefs();
	private List<SelectItem> socSolicitanteItems = new ArrayList<SelectItem>();
	private List<SelectItem> monedasExtItems = new ArrayList<SelectItem>();
	private List<SelectItem> esquemas = new ArrayList<SelectItem>();
	private List<SelectItem> swfPersonactaBcoInterItems = new ArrayList<SelectItem>();
	private List<SocCuentas> socCuentasLista = new ArrayList<SocCuentas>();
	private List<SocSolbenefs> socSolbenefsLista = new ArrayList<SocSolbenefs>();
	private List<CuentasBen> cuentasBenLista = new ArrayList<CuentasBen>();
	private SocBancos socBancosSelected = new SocBancos();
	private SocBancos socBancosInterSelected = new SocBancos();
	private SocPlazas socPlazas = new SocPlazas();
	private SocPlazas socPlazasInter = new SocPlazas();
	private BancoPlaza bancoPlazaSearch = new BancoPlaza();
	private BancoPlaza bancoPlazaSelected = new BancoPlaza();
	private BancoPlaza bancoPlazaFound = new BancoPlaza();
	private String sIOCWEB_TIPOPERACION;
	private List<BancoPlaza> bancosSearch = new ArrayList<BancoPlaza>();
	// B: Bando beneficiario, I: intermediario
	private String tipoSearch = "B";

	private ArchivoSinpleServiceImpl archivoSinpleService = new ArchivoSinpleServiceImpl();
	private String urlReporte;

	@PostConstruct
	public void inicio() {
		log.info("=============ooo00OOO00ooo===================");
		log.info("PostConstruct " + getClass().getName());
		try {
			recuperarVisit();
			sIOCWEB_TIPOPERACION = (String) getVisit().getParametro("SIOCWEB_TIPOPERACION");
			log.info("sIOCWEB_TIPOPERACION " + sIOCWEB_TIPOPERACION);
			inicializar();
			esquemas = llenarEsquemas();
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", "Ocurrio un error: " + e.getMessage());
		} finally {
			getVisit().removeParametro("SIOCWEB_TIPOPERACION");
			getVisit().removeParametro("SIOCWEB_CODBEN");
		}
	}

	private void inicializar() {
		String sIOCWEB_ACTION = (String) getVisit().getParametro("SIOCWEB_ACTION");
		String SIOCWEB_CODBENEF = (String) getVisit().getParametro("SIOCWEB_CODBEN");
		log.info("sIOCWEB_ACTION " + sIOCWEB_ACTION + " SIOCWEB_CODBENEF " + SIOCWEB_CODBENEF);

		socBenefsSelected = new SocBenefs();

		if (!StringUtils.isBlank(SIOCWEB_CODBENEF)) {
			if (!StringUtils.isBlank(sIOCWEB_ACTION)) {
				if (sIOCWEB_ACTION.equals("VERBEN")) {
					recuperarCtasBancoInterBen();
					actualizarBeneficiario(SIOCWEB_CODBENEF);

				} else if (sIOCWEB_ACTION.equals("PRAUTBEN")) {
					Integer SIOCWEB_NROREGBEN = (Integer) getVisit().getParametro("SIOCWEB_NROREGBEN");
					actualizarBeneficiario(SIOCWEB_CODBENEF, SIOCWEB_NROREGBEN);

				} else if (sIOCWEB_ACTION.equals("AUTBEN")) {
					Integer SIOCWEB_NROREGBEN = (Integer) getVisit().getParametro("SIOCWEB_NROREGBEN");

					actualizarBeneficiarioreg(SIOCWEB_CODBENEF, SIOCWEB_NROREGBEN);

				} else if (sIOCWEB_ACTION.equals("EDIT_REGBENCTA")) {
					nuevoBeneficiarioregCta(SIOCWEB_CODBENEF);
				}
			}
		} else {
			nuevoBeneficiario();
			recuperarListaSolicitantes();
		}

		listarMonedas();
		getVisit().removeParametro("SIOCWEB_TIPOPERACION");
		getVisit().removeParametro("SIOCWEB_CODBEN");
		getVisit().removeParametro("SIOCWEB_ACTION");

	}

	private void nuevoBeneficiario() {
		log.info("nuevaSolicitud: Creando por defecto");
		socBenefsSelected = new SocBenefs();
		socBenefsSelected.setClaVigente(Short.valueOf("1"));

		socBenefsregSelected = new SocBenefsreg();
		socBenefsregSelected.setIdent(Constants.CVE_TIPOBCOINST_BIC);
		socBenefsregSelected.setBenTipoctainst(Constants.CVE_TIPOCTAINST_SININT);
		socBenefsregSelected.setBenEstcta(Constants.CVE_ESTBENEF_REG);

		if (!getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(
					getVisit().getUsuarioSession().getSolicitante().getSolCodigo());

			socBenefsregSelected.setSolCodigo(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		}
	}

	private void actualizarBeneficiario(String codBenef) {
		socBenefsSelected = getSolicitudBean().getSocBenefsDao().getBenefsByBenCodigo(codBenef);

		if (!getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(
					getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		}

		socCuentasLista = getSolicitudBean().getSocCuentasDao().cuentasBeneficiarioExt(null, codBenef, null, null, null, null, null, null);

		if (getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolbenefsLista = getSolicitudBean().getSocSolbenefsDao().getSocSolbenefsByCodigo(null, codBenef);
			cuentasBenLista = getSolicitudBean().getSocBenefsDao().cuentasBenefExterior(null, codBenef, null, null, null, null, null, null, null,
					false);
		} else {
			cuentasBenLista = getSolicitudBean().getSocBenefsDao().cuentasBenefExterior(null, codBenef, null, null, null, null, null, null,
					getVisit().getUsuarioSession().getSolicitante().getSolCodigo(), false);
			socSolbenefsLista = getSolicitudBean().getSocSolbenefsDao().getSocSolbenefsByCodigo(
					getVisit().getUsuarioSession().getSolicitante().getSolCodigo(), codBenef);
		}

	}

	private void actualizarBeneficiario(String codBenef, Integer nroRegbenef) {
		log.info("Recuperando actualizarBeneficiario " + codBenef + " nroRegbenef " + nroRegbenef);
		socBenefsregSelected = getSolicitudBean().getSocBenefsregDao().getBenefsregByCodigo(nroRegbenef);
		socBenefsSelected = getSolicitudBean().getSocBenefsDao().getBenefsByBenCodigo(socBenefsregSelected.getBenCodigo());
		socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socBenefsregSelected.getSolCodigo());

		socCuentasSelected = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(socBenefsregSelected.getCtaCodigobco());

		if (socCuentasSelected != null) {

			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socCuentasSelected.getSolCodigo());

			BancoPlaza bancoPlazab = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socCuentasSelected.getBcoCodigo());
			if (bancoPlazab != null) {
				socBancosSelected = bancoPlazab.getSocBancos();
				socPlazas = bancoPlazab.getSocPlazas();
			}

			BancoPlaza bancoPlazai = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socCuentasSelected.getBcoCodigointer());
			if (bancoPlazai != null) {
				socBancosInterSelected = bancoPlazai.getSocBancos();
				socPlazasInter = bancoPlazai.getSocPlazas();
			}
		} else {
			socCuentasSelected = new SocCuentas();
		}
		recuperarListaSolicitantes();
		recuperarAdjunto(socBenefsregSelected.getNroRegbenef());
	}

	private void actualizarBeneficiarioreg(String codBenef, Integer nroRegbenef) {
		log.info("Recuperando actualizarBeneficiarioreg " + codBenef + " nroRegbenef " + nroRegbenef);
		socBenefsregSelected = getSolicitudBean().getSocBenefsregDao().getBenefsregByCodigo(nroRegbenef);
		socBenefsSelected = getSolicitudBean().getSocBenefsDao().getBenefsByBenCodigo(socBenefsregSelected.getBenCodigo());
		socCuentasSelected = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(socBenefsregSelected.getCtaCodigobco());

		if (socCuentasSelected != null) {

			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(socCuentasSelected.getSolCodigo());

			BancoPlaza bancoPlazab = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socCuentasSelected.getBcoCodigo());
			socBancosSelected = bancoPlazab.getSocBancos();
			socPlazas = bancoPlazab.getSocPlazas();

			BancoPlaza bancoPlazai = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socCuentasSelected.getBcoCodigointer());
			if (bancoPlazai != null) {
				socBancosInterSelected = bancoPlazai.getSocBancos();
				socPlazasInter = bancoPlazai.getSocPlazas();
			}
		}
		recuperarListaSolicitantes();
		recuperarAdjunto(socBenefsregSelected.getNroRegbenef());
	}

	private void nuevoBeneficiarioregCta(String codBenef) {
		log.info("actualizarBeneficiarioregCta " + codBenef);
		socBenefsSelected = getSolicitudBean().getSocBenefsDao().getBenefsByBenCodigo(codBenef);

		socBenefsregSelected = new SocBenefsreg();
		socBenefsregSelected.setIdent(Constants.CVE_TIPOBCOINST_BIC);
		socBenefsregSelected.setBenTipoctainst(Constants.CVE_TIPOCTAINST_SININT);
		socBenefsregSelected.setBenEstcta(Constants.CVE_ESTBENEF_REG);
		socBenefsregSelected.setBenCodigo(socBenefsSelected.getBenCodigo());

		if (!getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
			socSolicitante = getSolicitudBean().getSocSolicitanteDao().solicitanteByCod(
					getVisit().getUsuarioSession().getSolicitante().getSolCodigo());

			socBenefsregSelected.setSolCodigo(getVisit().getUsuarioSession().getSolicitante().getSolCodigo());
		}

		recuperarListaSolicitantes();
	}

	private void recuperarListaSolicitantes() {
		socSolicitanteItems = new ArrayList<SelectItem>();
		List<SocSolicitante> socSolicitanteLista = new ArrayList<SocSolicitante>();

		if (socBenefsregSelected.getSolCodigo() != null) {
			socSolicitanteLista.add(socSolicitante);
		} else {
			if (socBenefsregSelected.getNroRegbenef() == null
					&& getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");

			} else if (!StringUtils.isBlank(socBenefsregSelected.getSolCodigo())) {
				socSolicitanteLista.add(socSolicitante);
			}
		}
		for (SocSolicitante socSolicitante : socSolicitanteLista) {
			socSolicitanteItems.add(new SelectItem(StringUtils.trimToEmpty(socSolicitante.getSolCodigo()), socSolicitante.getSolPersona() + " ["
					+ socSolicitante.getSolCodigo() + "]"));
		}

	}

	public void identChanged(ActionEvent event) {
		// al cambiar el tipo de banco
		if (!StringUtils.isBlank(socBenefsregSelected.getIdent())) {
			if (socBenefsregSelected.getIdent().equals(Constants.CVE_TIPOBCOINST_INTER)) {
				// con cuenta de banco intermediario
				socBenefsregSelected.setBenTipoctainst(Constants.CVE_TIPOCTAINST_CONINT);
			}
		}
	}

	public void bancoChanged(ActionEvent event) {

		if (!StringUtils.isBlank(bancoPlazaSearch.getBcoNombre()) && bancoPlazaSearch.getBcoNombre().trim().length() >= 3) {
			bancosSearch = getSolicitudBean().getSocBancosDao().buscarBancosPlazas(bancoPlazaSearch.getBcoNombre(), null, null, null, null);
		} else {
			bancosSearch.clear();
		}
	}

	public void bancoBicChanged(ActionEvent event) {

		if (!StringUtils.isBlank(bancoPlazaSearch.getPlaBic()) && bancoPlazaSearch.getPlaBic().trim().length() >= 3) {
			bancosSearch = getSolicitudBean().getSocBancosDao().buscarBancosPlazas(null, null, null, bancoPlazaSearch.getPlaBic(), null);
		} else {
			bancosSearch.clear();
		}
	}

	public void bancoFWNroctaChanged(ActionEvent event) {
		if (!StringUtils.isBlank(bancoPlazaSearch.getPlaNrocuenta()) && bancoPlazaSearch.getPlaNrocuenta().trim().length() >= 3) {
			bancosSearch = getSolicitudBean().getSwfPersonactaBean().buscarBancosByFWNroCta(null, null, bancoPlazaSearch.getPlaNrocuenta(), null,
					null);
		} else {
			bancosSearch.clear();
		}
	}

	public void benTipoctainstChanged(ActionEvent event) {
		// cuando cambia si tiene o no intermediario
		if (!StringUtils.isBlank(socBenefsregSelected.getBenTipoctainst())) {
			if (!socBenefsregSelected.getBenTipoctainst().equals(Constants.CVE_TIPOCTAINST_CONINT)) {
				// si es sin intermediario limpiamos los datos de bis ...
				socBenefsregSelected.setBancoInt(null);
				socBenefsregSelected.setPlazaInt(null);
				socBenefsregSelected.setBicInt(null);
			}
		}
	}

	public void selectBanco(BancoPlaza bancoPlaza) {
		bancoPlazaFound = bancoPlaza;

		BancoPlaza bancoPlazaSel = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(bancoPlazaFound.getBcoCodigo());

		if (tipoSearch.equals("B")) {
			// socBancosSelected.setBcoCodigo(bancoPlazaFound.getBcoCodigo());
			socBancosSelected = bancoPlazaSel.getSocBancos();
			socPlazas = bancoPlazaSel.getSocPlazas();
			// socBenefsregSelected.setBic(bancoPlazaFound.getPlaBic());
			// socBenefsregSelected.setBanco(bancoPlazaFound.getBcoNombre());
			// socBenefsregSelected.setPlaza(bancoPlazaFound.getPlaNombre());
			socBenefsregSelected.setBcoCodigo(bancoPlazaFound.getBcoCodigo());

		} else if (tipoSearch.equals("I")) {
			socBancosInterSelected = bancoPlazaSel.getSocBancos();
			socPlazasInter = bancoPlazaSel.getSocPlazas();
			// socBenefsregSelected.setBicInt(bancoPlazaFound.getPlaBic());
			// socBenefsregSelected.setBancoInt(bancoPlazaFound.getBcoNombre());
			// socBenefsregSelected.setPlazaInt(bancoPlazaFound.getPlaNombre());
			socBenefsregSelected.setBcoCodigointer(bancoPlazaFound.getBcoCodigo());
		}
	}

	public void abrirPanelBuscar(String tipo) {
		tipoSearch = tipo;
		bancosSearch.clear();
		bancoPlazaSearch = new BancoPlaza();

	}

	/**********************************/
	public void botonAbrirPanelDetBanco() {

		log.info("En botonAbrirPanelDetBanco");
		socBancosSelected = new SocBancos();
		// socBancosSelected.setBcoCodigo(socBenefsregSelected.getBcoCodigo());
		socBancosSelected.setBcoNombre(socBenefsregSelected.getBanco());

		SocPlazasId socPlazasId = new SocPlazasId();
		socPlazas = new SocPlazas();
		socPlazas.setId(socPlazasId);

		socPlazas.setPlaNombre(socBenefsregSelected.getPlaza());

		if (socBenefsregSelected.getIdent().equals(Constants.CVE_TIPOBCOINST_BIC)) {
			socPlazas.setPlaBic(socBenefsregSelected.getBic());

		} else if (socBenefsregSelected.getIdent().equals(Constants.CVE_TIPOBCOINST_ABA)) {

		} else if (socBenefsregSelected.getIdent().equals(Constants.CVE_TIPOBCOINST_INTER)) {
		}

	}

	public void botonAbrirPanelDetBancointer() {
		log.info("En botonAbrirPanelDetBancointer");
		socBancosInterSelected = new SocBancos();
		// socBancosSelected.setBcoCodigo(socBenefsregSelected.getBcoCodigo());
		socBancosInterSelected.setBcoNombre(socBenefsregSelected.getBancoInt());

		SocPlazasId socPlazasId = new SocPlazasId();
		socPlazasInter = new SocPlazas();
		socPlazasInter.setId(socPlazasId);

		socPlazasInter.setPlaNombre(socBenefsregSelected.getPlazaInt());

		socPlazasInter.setPlaBic(socBenefsregSelected.getBicInt());
	}

	public void botonGuardarBanco2() {
		log.info("En botonGuardarBanco2");

		try {
			socBancosSelected = getSolicitudBean().getSocBancosDao().saveOrUpdate(socBancosSelected, socPlazas);
			socBenefsregSelected.setBcoCodigo(socBancosSelected.getBcoCodigo());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public String botonGuardarBanco() {
		log.info("En botonGuardarBanco");
		return "";

	}

	public void botonGuardarBancointer() {
		log.info("En botonGuardarBancointer");
		try {
			socBancosInterSelected = getSolicitudBean().getSocBancosDao().saveOrUpdate(socBancosInterSelected, socPlazasInter);
			socBenefsregSelected.setBcoCodigointer(socBancosInterSelected.getBcoCodigo());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonCancelarSelecction() {
		socBenefsregSelected.setBcoCodigo(null);
	}

	public void botonCancelarSelecctioninter() {
		socBenefsregSelected.setBcoCodigointer(null);
	}

	public void botonRegistrarBenef() {
		try {
			log.info("botonRegistrarBenef");
			Beneficiario beneficiario = new Beneficiario();
			beneficiario.setSocBenefs(socBenefsSelected);
			beneficiario.setSocBancos(socBancosSelected);
			beneficiario.setSocBancosInter(socBancosInterSelected);
			beneficiario.setSocPlazas(socPlazas);
			beneficiario.setSocPlazasInter(socPlazasInter);
			beneficiario.setSocBenefsreg(socBenefsregSelected);
			beneficiario.setSocCuentas(socCuentasSelected);

			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);
			solicitudTO.setBeneficiario(beneficiario);

			solicitudTO = getSolicitudBean().procesar(solicitudTO, "REG_BENEFEXT");

			if (archivoSinpleService != null) {
				if (archivoSinpleService.getArchivoSinple() != null) {

					SocParametros socParametros = getSolicitudBean().getSocParametrosDao().getByCodigo("pathadjben");
					String directorio = socParametros.getParValor();

					String nfile = "BE_" + String.format("%06d", solicitudTO.getBeneficiario().getSocBenefsreg().getNroRegbenef());

					archivoSinpleService.settingPathFile(directorio, nfile, archivoSinpleService.getArchivoSinple().getNameOriginal());
					String p = UtilsFile.grabaEnArchivo(archivoSinpleService.getArchivoSinple().getStream(), archivoSinpleService.getArchivoSinple()
							.getPathFile());
					log.info("archivo salvado " + p);
				}
			}

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			actualizarBeneficiario(socBenefsSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAutorizarBenef() {
		try {
			log.info("botonAutorizarBenef");
			Beneficiario beneficiario = new Beneficiario();
			beneficiario.setSocBenefs(socBenefsSelected);
			beneficiario.setSocBancos(socBancosSelected);
			beneficiario.setSocBancosInter(socBancosInterSelected);
			beneficiario.setSocPlazas(socPlazas);
			beneficiario.setSocPlazasInter(socPlazasInter);
			beneficiario.setSocBenefsreg(socBenefsregSelected);
			beneficiario.setSocCuentas(socCuentasSelected);

			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);
			solicitudTO.setBeneficiario(beneficiario);

			solicitudTO = getSolicitudBean().procesar(solicitudTO, "AUT_BENEFEXT");

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			// actualizarBeneficiarioreg(socBenefsSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEnivarAModif() {
		try {
			log.info("botonEnivarAModif");
			Beneficiario beneficiario = new Beneficiario();
			beneficiario.setSocBenefs(socBenefsSelected);
			beneficiario.setSocBancos(socBancosSelected);
			beneficiario.setSocBancosInter(socBancosInterSelected);
			beneficiario.setSocPlazas(socPlazas);
			beneficiario.setSocPlazasInter(socPlazasInter);
			beneficiario.setSocBenefsreg(socBenefsregSelected);
			beneficiario.setSocCuentas(socCuentasSelected);

			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);
			solicitudTO.setBeneficiario(beneficiario);

			solicitudTO = getSolicitudBean().procesar(solicitudTO, "RCH_BENEFEXT");

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			// actualizarBeneficiarioreg(socBenefsSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("error al guardar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonGuardarBenef() {
		try {
			socBenefsSelected.setEstacion(getVisit().getAddress());
			socBenefsSelected.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			socBenefsSelected.setFechaHora(new Date());
			getSolicitudBean().getSocBenefsDao().saveOrUpdate(socBenefsSelected);

			log.info("Se modific� el registro correctamente.");

			actualizarBeneficiario(socBenefsSelected.getBenCodigo());
			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEliminarSolBenef(SocSolbenefs socSolbenefslocSel) {
		try {
			socSolbenefslocSel.setClaVigente(Short.valueOf("0"));
			socSolbenefslocSel.setEstacion(getVisit().getAddress());
			socSolbenefslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocSolbenefsDao().saveOrUpdate(socSolbenefslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			actualizarBeneficiario(socBenefsSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonVigentarSolBenef(SocSolbenefs socSolbenefslocSel) {
		try {
			socSolbenefslocSel.setClaVigente(Short.valueOf("1"));
			socSolbenefslocSel.setEstacion(getVisit().getAddress());
			socSolbenefslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocSolbenefsDao().saveOrUpdate(socSolbenefslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			actualizarBeneficiario(socBenefsSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonAgregarCuenta() {
		try {
			log.info("botonAgregarCuenta ");
			Beneficiario beneficiario = new Beneficiario();
			beneficiario.setSocBenefs(socBenefsSelected);
			beneficiario.setSocBancos(socBancosSelected);
			beneficiario.setSocBancosInter(socBancosInterSelected);
			beneficiario.setSocPlazas(socPlazas);
			beneficiario.setSocPlazasInter(socPlazasInter);
			beneficiario.setSocBenefsreg(socBenefsregSelected);
			beneficiario.setSocCuentas(socCuentasSelected);

			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);
			solicitudTO.setBeneficiario(beneficiario);

			getVisit().setParametro("SIOCWEB_CODBEN", socBenefsSelected.getBenCodigo());
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "EDIT_REGBENCTA");
			getVisit().setParametro("SIOCWEB_ACTION", "EDIT_REGBENCTA");

			irAPagina("/view/Parametros/socBenefsreg_regcta.xhtml");
			inicializar();
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEditarCuenta(CuentasBen cuentasBen) {
		try {

			log.info("botonAgregarCuenta ");
			socCuentasSelected = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());

			if (socCuentasSelected != null) {
				BancoPlaza bancoPlazab = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socCuentasSelected.getBcoCodigo());
				if (bancoPlazab != null) {
					socBancosSelected = bancoPlazab.getSocBancos();
					socPlazas = bancoPlazab.getSocPlazas();
				}

				BancoPlaza bancoPlazai = getSolicitudBean().getSocBancosDao().bancoPlazaByCod(socCuentasSelected.getBcoCodigointer());
				if (bancoPlazai != null) {
					socBancosInterSelected = bancoPlazai.getSocBancos();
					socPlazasInter = bancoPlazai.getSocPlazas();
				}
			} else {
				socCuentasSelected = new SocCuentas();
			}

			socSolicitanteItems = new ArrayList<SelectItem>();
			List<SocSolicitante> socSolicitanteLista = new ArrayList<SocSolicitante>();
			if (StringUtils.isBlank(socCuentasSelected.getSolCodigo())
					&& getVisit().getUsuarioSession().getSolicitante().getSolCodigo().equals(Constants.COD_BCB)) {
				socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(null, "SP,SF");

			} else {
				if (!StringUtils.isBlank(socCuentasSelected.getSolCodigo())) {
					socSolicitanteLista = getSolicitudBean().getSocSolicitanteDao().solicitantesByCod(socCuentasSelected.getSolCodigo(), null);
				}
			}

			for (SocSolicitante socSolicitante : socSolicitanteLista) {
				socSolicitanteItems.add(new SelectItem(StringUtils.trimToEmpty(socSolicitante.getSolCodigo()), socSolicitante.getSolPersona() + " ["
						+ socSolicitante.getSolCodigo() + "]"));
			}

		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEliminarCuenta(CuentasBen cuentasBen) {
		log.info("botonEliminarCuenta ");
		try {
			socCuentasSelected = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());

			if (socCuentasSelected != null) {
				socCuentasSelected.setClaVigente(Short.valueOf("0"));
				socCuentasSelected.setEstacion(getVisit().getAddress());
				socCuentasSelected.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
				socCuentasSelected.setFechaHora(new Date());

				getSolicitudBean().getSocCuentasDao().getHibernateTemplate().saveOrUpdate(socCuentasSelected);
				addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
				
				actualizarBeneficiario(socCuentasSelected.getBenCodigo());				
			}
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}

	}
	public void botonVigentarCuenta(CuentasBen cuentasBen) {
		log.info("botonVigentarCuenta ");
		try {
			socCuentasSelected = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());

			if (socCuentasSelected != null) {
				socCuentasSelected.setClaVigente(Short.valueOf("1"));
				socCuentasSelected.setEstacion(getVisit().getAddress());
				socCuentasSelected.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
				socCuentasSelected.setFechaHora(new Date());

				getSolicitudBean().getSocCuentasDao().getHibernateTemplate().saveOrUpdate(socCuentasSelected);
				addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
				
				actualizarBeneficiario(socCuentasSelected.getBenCodigo());				
			}
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonModificarCuentaSolic() {
		try {
			log.info("botonModificarCuentaSolic " + socCuentasSelected.getCtaNrocuenta());
			socCuentasSelected.setEstacion(getVisit().getAddress());
			socCuentasSelected.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			socCuentasSelected.setFechaHora(new Date());

			socCuentasSelected.setClaVigente(Short.valueOf("1"));

			socCuentasSelected = getSolicitudBean().getSocCuentasDao().saveOrUpdate(socCuentasSelected);
			log.info("Se insert� el registro correctamente." + socCuentasSelected.getCtaCodigo());

			actualizarBeneficiario(socCuentasSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	private void botonEditarCuenta00(CuentasBen cuentasBen) {
		try {

			log.info("botonAgregarCuenta ");
			socCuentasSelected = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());

			socBenefsregSelected = new SocBenefsreg();
			socBenefsregSelected.setBenCodigo(socCuentasSelected.getBenCodigo());
			socBenefsregSelected.setSolCodigo(socCuentasSelected.getSolCodigo());
			socBenefsregSelected.setBcoCodigo(socCuentasSelected.getBcoCodigo());
			socBenefsregSelected.setBanco(socBancosSelected.getBcoNombre());
			socBenefsregSelected.setPlaza(socPlazas.getPlaNombre());
			socBenefsregSelected.setIdent(socCuentasSelected.getCveTipbcoben());
			socBenefsregSelected.setBic(socPlazas.getPlaBic());
			socBenefsregSelected.setBcoNrocuentaben(socCuentasSelected.getBcoNrocuentaben());

			if (!StringUtils.isBlank(socCuentasSelected.getBcoCodigointer())) {
				socBenefsregSelected.setBenTipoctainst(Constants.CVE_TIPOCTAINST_CONINT);
			} else {
				socBenefsregSelected.setBenTipoctainst(Constants.CVE_TIPOCTAINST_SININT);
			}
			socBenefsregSelected.setBcoCodigointer(socCuentasSelected.getBcoCodigointer());
			socBenefsregSelected.setBancoInt(socBancosInterSelected.getBcoNombre());
			socBenefsregSelected.setPlazaInt(socPlazasInter.getPlaNombre());
			socBenefsregSelected.setBicInt(socPlazasInter.getPlaBic());
			socBenefsregSelected.setCuentab(socCuentasSelected.getCtaNrocuenta());
			socBenefsregSelected.setCodMoneda(socCuentasSelected.getMoneda());
			socBenefsregSelected.setCtaCodigobco(socCuentasSelected.getCtaCodigo());

			Beneficiario beneficiario = new Beneficiario();
			beneficiario.setSocBenefs(socBenefsSelected);
			beneficiario.setSocBancos(socBancosSelected);
			beneficiario.setSocBancosInter(socBancosInterSelected);
			beneficiario.setSocPlazas(socPlazas);
			beneficiario.setSocPlazasInter(socPlazasInter);
			beneficiario.setSocBenefsreg(socBenefsregSelected);
			beneficiario.setSocCuentas(socCuentasSelected);

			Solicitud solicitudTO = new Solicitud();
			solicitudTO.setsIOCWEB_TIPOPERACION(sIOCWEB_TIPOPERACION);
			solicitudTO.setBeneficiario(beneficiario);

			getVisit().setParametro("SIOCWEB_CODBEN", socBenefsSelected.getBenCodigo());
			getVisit().setParametro("SIOCWEB_TIPOPERACION", "EDIT_REGBENCTA");
			getVisit().setParametro("SIOCWEB_ACTION", "EDIT_REGBENCTA");

			irAPagina("/view/Parametros/socBenefsreg_regcta.xhtml");
			inicializar();
		} catch (Exception e) {
			addMessageError("Error", e.getMessage());
		}
	}

	public void botonEliminarCtaBenef(CuentasBen cuentasBen) {
		try {
			SocCuentas socCuentaslocSel = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());

			socCuentaslocSel.setClaVigente(Short.valueOf("0"));
			socCuentaslocSel.setEstacion(getVisit().getAddress());
			socCuentaslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocCuentasDao().saveOrUpdate(socCuentaslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			actualizarBeneficiario(socBenefsSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	public void botonVigentarCtaBenef(CuentasBen cuentasBen) {
		try {
			SocCuentas socCuentaslocSel = getSolicitudBean().getSocCuentasDao().getSocCuentasByCodigo(cuentasBen.getCtaCodigo());

			socCuentaslocSel.setClaVigente(Short.valueOf("1"));
			socCuentaslocSel.setEstacion(getVisit().getAddress());
			socCuentaslocSel.setUsrCodigo(getVisit().getUsuarioSession().getLogin());
			getSolicitudBean().getSocCuentasDao().saveOrUpdate(socCuentaslocSel);

			addMessageInfo("Aviso", "La operación se proceso satisfactoriamente ");
			actualizarBeneficiario(socBenefsSelected.getBenCodigo());
		} catch (Exception e) {
			log.error("Error al obtener solicitud " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}

	}

	private void listarMonedas() {
		monedasExtItems = new ArrayList<SelectItem>();
		List<Integer> monedaList = new ArrayList<Integer>();
		monedaList.add(Constants.COD_MONEDA_BS);

		List<GenMoneda> genMonedaLista = getSolicitudBean().getGenMonedaDao().getMonedasLista(monedaList, false);

		if (!StringUtils.isBlank(socBenefsSelected.getBenCodigo())) {
		}
		for (GenMoneda genMoneda : genMonedaLista) {
			monedasExtItems.add(new SelectItem(genMoneda.getCodMoneda(), genMoneda.getMonNombre()));
		}
	}

	public void adjuntar(UploadEvent event) throws IOException {
		log.info("adjuntar handleFileUpload ");
		UploadItem item = event.getUploadItem();
		// ArchivoSinpleServiceImpl archivoSinpleService = new
		// ArchivoSinpleServiceImpl();
		InputStream stream;
		try {
			log.info("XXX: 222 En FileSize " + (item == null));
			log.info("XXX: 222 En FileSize " + (item.getData() == null));
			log.info("XXX: 222 En handleFileUpload " + item.getFileName());
			log.info("XXX: 222 En FileSize " + item.getFileSize());

			stream = new ByteArrayInputStream(item.getData());
			SocParametros socParametros = getSolicitudBean().getSocParametrosDao().getByCodigo("pathadjben");
			String directorio = socParametros.getParValor();

			archivoSinpleService = new ArchivoSinpleServiceImpl();
			archivoSinpleService.fileUpload(stream, item.getFileName());
			archivoSinpleService.getArchivoSinple().setDirectory(directorio);
			// archivoSinpleService.settingPathFile(directorio,
			// item.getFileName(), item.getFileName());
			// archivoSinpleService.getArchivoSinple().getHash(),
			// file.getFileName());

			socBenefsregSelected.setNomArchivo(item.getFileName());

			log.info("XXX: 222 En handleFileUpload " + item.getFileName());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
	}

	public void mostrarAdjunto(ActionEvent event) {
		log.info("XXX: reporte " + socBenefsregSelected.getNroRegbenef());
		try {
			recuperarAdjunto(socBenefsregSelected.getNroRegbenef());

			if (archivoSinpleService == null) {
				if (archivoSinpleService.getArchivoSinple() == null) {
					return;
				}
			}

			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("tipo", "reporteSwiftPdf");

			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			request.getSession().setAttribute("nombreReporte", "reporteSwiftPdf");
			request.getSession().setAttribute("archivoSinple", archivoSinpleService.getArchivoSinple());
			request.getSession().setAttribute("parametros", parametros);

			log.info("Ir a ventana reporte adjunto " + archivoSinpleService.getArchivoSinple().getPathFile());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
		// request.getSession().setAttribute("nroMov",
		// this.apertura.getNroMov());
		// request.getSession().setAttribute("adjunto", this.archivo);
	}

	public void mostrarAdjunto2(ActionEvent event) {
		log.info("XXX: reporte2222222 ");
		try {
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("tipo", "reporteSwiftPdf");

			HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
			request.getSession().setAttribute("nombreReporte", "reporteSwiftPdf");
			request.getSession().setAttribute("archivoSinple", archivoSinpleService.getArchivoSinple());
			request.getSession().setAttribute("parametros", parametros);

			log.info("Ir a ventana reporte adjunto " + archivoSinpleService.getArchivoSinple().getPathFile());
		} catch (Exception e) {
			log.error("Error al cargar " + e.getMessage(), e);
			addMessageError("Error", e.getMessage());
		}
		// request.getSession().setAttribute("nroMov",
		// this.apertura.getNroMov());
		// request.getSession().setAttribute("adjunto", this.archivo);
	}

	private void recuperarAdjunto(Integer nroRegben) {
		if (nroRegben == null) {
			return;
		}

		SocParametros socParametros = getSolicitudBean().getSocParametrosDao().getByCodigo("pathadjben");
		String directorio = socParametros.getParValor();
		String nfile = "BE_" + String.format("%06d", nroRegben);

		if (StringUtils.isBlank(socBenefsregSelected.getNomArchivo())) {
			return;
		}

		String ext = ArchivoUtil.obtenerExtension(socBenefsregSelected.getNomArchivo());
		if (ext == null || ext.length() == 0) {
			ext = "";
		} else {
			ext = "." + ext;
		}
		nfile = nfile + ext;
		nfile = directorio + nfile;
		log.info("nfile " + nfile);
		archivoSinpleService.fromPathfile(nfile, socBenefsregSelected.getNomArchivo());
	}

	private void recuperarCtasBancoInterBen() {
		Map<String, BancoPlaza> bancoPlazaMapaCrtl = new HashMap<String, BancoPlaza>();

		swfPersonactaBcoInterItems = new ArrayList<SelectItem>();

		List<BancoPlaza> bancosLista = getSolicitudBean().getSocBancosDao().getBancosPlazasInter(null, null);
		for (BancoPlaza cuentasS : bancosLista) {
			if (!StringUtils.isBlank(cuentasS.getPlaBic())) {
				if (!bancoPlazaMapaCrtl.containsKey(cuentasS.getPlaBic())) {
					swfPersonactaBcoInterItems.add(new SelectItem(cuentasS.getBcoCodigo(), cuentasS.getPlaBic() + " : " + cuentasS.getBcoNombre()
							+ "(" + cuentasS.getBcoCodigo() + ")"));

					bancoPlazaMapaCrtl.put(cuentasS.getPlaBic(), cuentasS);
				}
			}
		}
	}

	public void borrarAdjunto(ActionEvent event) {
		archivoSinpleService = new ArchivoSinpleServiceImpl();
	}

	public SocBenefs getSocBenefsSelected() {
		return socBenefsSelected;
	}

	public void setSocBenefsSelected(SocBenefs socBenefsSelected) {
		this.socBenefsSelected = socBenefsSelected;
	}

	public List<SocCuentas> getSocCuentasLista() {
		return socCuentasLista;
	}

	public void setSocCuentasLista(List<SocCuentas> socCuentasLista) {
		this.socCuentasLista = socCuentasLista;
	}

	public List<SocSolbenefs> getSocSolbenefsLista() {
		return socSolbenefsLista;
	}

	public void setSocSolbenefsLista(List<SocSolbenefs> socSolbenefsLista) {
		this.socSolbenefsLista = socSolbenefsLista;
	}

	public List<CuentasBen> getCuentasBenLista() {
		return cuentasBenLista;
	}

	public void setCuentasBenLista(List<CuentasBen> cuentasBenLista) {
		this.cuentasBenLista = cuentasBenLista;
	}

	public SocCuentas getSocCuentasSelected() {
		return socCuentasSelected;
	}

	public void setSocCuentasSelected(SocCuentas socCuentasSelected) {
		this.socCuentasSelected = socCuentasSelected;
	}

	public SocBenefsreg getSocBenefsregSelected() {
		return socBenefsregSelected;
	}

	public void setSocBenefsregSelected(SocBenefsreg socBenefsregSelected) {
		this.socBenefsregSelected = socBenefsregSelected;
	}

	public List<SelectItem> getMonedasExtItems() {
		return monedasExtItems;
	}

	public void setMonedasExtItems(List<SelectItem> monedasExtItems) {
		this.monedasExtItems = monedasExtItems;
	}

	public List<SelectItem> getSocSolicitanteItems() {
		return socSolicitanteItems;
	}

	public void setSocSolicitanteItems(List<SelectItem> socSolicitanteItems) {
		this.socSolicitanteItems = socSolicitanteItems;
	}

	public SocSolicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setSocSolicitante(SocSolicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public SocSolbenefs getSocSolbenefsSelected() {
		return socSolbenefsSelected;
	}

	public void setSocSolbenefsSelected(SocSolbenefs socSolbenefsSelected) {
		this.socSolbenefsSelected = socSolbenefsSelected;
	}

	public BancoPlaza getBancoPlazaSelected() {
		return bancoPlazaSelected;
	}

	public void setBancoPlazaSelected(BancoPlaza bancoPlazaSelected) {
		this.bancoPlazaSelected = bancoPlazaSelected;
	}

	public List<BancoPlaza> getBancosSearch() {
		return bancosSearch;
	}

	public void setBancosSearch(List<BancoPlaza> bancosSearch) {
		this.bancosSearch = bancosSearch;
	}

	public BancoPlaza getBancoPlazaFound() {
		return bancoPlazaFound;
	}

	public void setBancoPlazaFound(BancoPlaza bancoPlazaFound) {
		this.bancoPlazaFound = bancoPlazaFound;
	}

	public BancoPlaza getBancoPlazaSearch() {
		return bancoPlazaSearch;
	}

	public void setBancoPlazaSearch(BancoPlaza bancoPlazaSearch) {
		this.bancoPlazaSearch = bancoPlazaSearch;
	}

	public List<SelectItem> getEsquemas() {
		return esquemas;
	}

	public void setEsquemas(List<SelectItem> esquemas) {
		this.esquemas = esquemas;
	}

	public SocPlazas getSocPlazas() {
		return socPlazas;
	}

	public void setSocPlazas(SocPlazas socPlazas) {
		this.socPlazas = socPlazas;
	}

	public SocBancos getSocBancosSelected() {
		return socBancosSelected;
	}

	public void setSocBancosSelected(SocBancos socBancosSelected) {
		this.socBancosSelected = socBancosSelected;
	}

	public SocPlazas getSocPlazasInter() {
		return socPlazasInter;
	}

	public void setSocPlazasInter(SocPlazas socPlazasInter) {
		this.socPlazasInter = socPlazasInter;
	}

	public SocBancos getSocBancosInterSelected() {
		return socBancosInterSelected;
	}

	public void setSocBancosInterSelected(SocBancos socBancosInterSelected) {
		this.socBancosInterSelected = socBancosInterSelected;
	}

	public ArchivoSinpleServiceImpl getArchivoSinpleService() {
		return archivoSinpleService;
	}

	public void setArchivoSinpleService(ArchivoSinpleServiceImpl archivoSinpleService) {
		this.archivoSinpleService = archivoSinpleService;
	}

	public String getUrlReporte() {
		urlReporte = getRaiz() + "reporte?nombreReporte=reporteSwiftPdf";
		return urlReporte;
	}

	public List<SelectItem> getSwfPersonactaBcoInterItems() {
		return swfPersonactaBcoInterItems;
	}

	public void setSwfPersonactaBcoInterItems(List<SelectItem> swfPersonactaBcoInterItems) {
		this.swfPersonactaBcoInterItems = swfPersonactaBcoInterItems;
	}

}
