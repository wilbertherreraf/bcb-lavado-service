package gob.bcb.portal.sioc.transferencias.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;

public class Consulta1Controller {

	private String mensaje = "";

	private Logger log = Logger.getLogger(Consulta1Controller.class);
	private static final String ESTACION = "";

	@SuppressWarnings("unchecked")
	public Consulta1Controller() {
		mensaje = "El d a abierto de la aplicaci n es " + this.getDiaAbierto() + ".";
	}

	private Date getDiaAbierto() {
		Date dia = null;

		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("consulta", "dia");
		mapaParametros1.put("opcion", "DiaAbierto");
		
		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: DiaAbierto");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", ESTACION, "cliente", "query", mapaParametros1, iid1);
			dia = (Date) mapaResultado1.get("dia");
		} catch (Exception e) {
			log.error("Error en Consulta", e);
		}

		return dia;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public void eventoMensajeBpm(ActionEvent action) {
		Map<String, Object> mapaParametros1 = new HashMap<String, Object>();
		mapaParametros1.put("consulta", "dia");
		Date dia = null;
		String iid1 = new Long(new Date().getTime()).toString();

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: dia");
		Map<String, Object> mapaResultado1;
		try {
			mapaResultado1 = ManejadorServicioBPM.consultaServidor("sioc", ESTACION, "cliente", "query", mapaParametros1, iid1);
			dia = (Date) mapaResultado1.get("dia");
		} catch (Exception e) {
			log.error("Error en Consulta", e);
		}
		this.mensaje = "El dia abierto de la aplicacion es " + dia + ".";
	}

}
