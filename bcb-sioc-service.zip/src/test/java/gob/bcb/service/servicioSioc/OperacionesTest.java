package gob.bcb.service.servicioSioc;

import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.common.Constants;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class OperacionesTest {

	public String brokerUrl = "tcp://10.2.11.91:61616";
	// private String brokerUrl = "tcp://localhost:61616";
	public String requestQueue = "BCB.SUSTANTIVO.BPM.SIOC.QUEUE";

	Connection connection;
	Map<String, Object> parametrosMsg = new HashMap<String, Object>();
	MessageObjectBean messageObjectBean = new MessageObjectBean();
	public SessionFactory sessionFactorySioc;
	Map<String, Object> parametros = new HashMap<String, Object>();

	public void enviar() throws JMSException, IOException {
		messageObjectBean.setTransformedMessage(parametrosMsg);

		StatusResponse statusResponse = null;

		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(brokerUrl);
		String usuarioTask = Servicios.getParam("usuarioTask");
		try {
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWS");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", usuarioTask);
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOCWS");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					null, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			bcbRequestImpl.setDisableReplyTo(true);
			// bcbRequestImpl.send();
			// Thread.sleep(500);
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();
			// if (statusResponse.getResponse() instanceof MessageObjectBean){
			// MessageObjectBean messageObjectBean1 = (MessageObjectBean)
			// statusResponse.getResponse();
			// Map<String, Object> resultado = (Map<String, Object>)
			// messageObjectBean1.getTransformedMessage();
			// System.out.println(resultado);
			// }else
			// System.out.println(statusResponse.getDescrip());

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			// jMSConnectionHandler.close();
		}
		System.out.println("==========================FIN RECIBIDO==========================");
	}
	public BcbRequestImpl enviar2() throws JMSException, IOException {
		messageObjectBean.setTransformedMessage(parametrosMsg);
		BcbRequestImpl bcbRequestImpl = null;
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(brokerUrl);
		String usuarioTask = Servicios.getParam("usuarioTask");
		try {
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWS");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", usuarioTask);
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOCWS");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					null, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			bcbRequestImpl.setDisableReplyTo(true);
			//bcbRequestImpl.sendMessage();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			// jMSConnectionHandler.close();
		}

		return bcbRequestImpl; 
	}

	// *************************************/
	// *************************************/

	public void requestSolicitud(String codSolicitud, String opcion) throws JMSException, IOException {
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(sessionFactorySioc);

		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud(codSolicitud);
		socSolicitudes.setFecha(new Date());
		System.out.println(socSolicitudes.toString());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(sessionFactorySioc);

		Solicitud solicitud = new Solicitud();
		solicitud.setSolicitud(socSolicitudes);
		solicitud.setSocDetallessolLista(socDetallessolDao.getDetalles(codSolicitud));
		parametrosMsg.put("opcion", opcion);
		parametrosMsg.put(Constants.OBJ_NAME_SOLICITUDTO, solicitud);

		enviar();

	}

	public void requestSolicitudWS(String archFirmado) throws JMSException, IOException {
		String mensajeXML = UtilsFile.readFileAsString2(archFirmado);

		parametrosMsg.put("opcion", "procesarXMLWS");
		parametrosMsg.put("mensajeXML", mensajeXML);

		enviar();

	}

	public void bolsin2(String socCodigo, String solCodigo, Integer cuentaD, BigDecimal montoSol, BigDecimal montoMN, String benef)
			throws JMSException, IOException {
		SocBolsin solicitudB = new SocBolsin();
		solicitudB.setSocCodigo(socCodigo+(Math.random() + 100));
		solicitudB.setSolCodigo(solCodigo);
		solicitudB.setFecha(new Date());
		solicitudB.setCorr(socCodigo);
		solicitudB.setSeq(1);
		solicitudB.setCuentaD(12);
		solicitudB.setCotiz(BigDecimal.valueOf(6.96));
		solicitudB.setMontoSol(BigDecimal.valueOf(100000));
		solicitudB.setMontoAdj(BigDecimal.valueOf(100000));
		solicitudB.setMontoMN(BigDecimal.valueOf(696000));
		solicitudB.setClaEstado('9');
		solicitudB.setBenef(benef);
		solicitudB.setClaTipsolic("ED");
		solicitudB.setBolCtamn(null);
		solicitudB.setBolCtame(null);
		solicitudB.setUsrCodigo("YOP");
		solicitudB.setFechaHora(new Date());
		solicitudB.setEstacion("ricochango");

		SocBolsin solicitudB2 = new SocBolsin();
		solicitudB2.setSocCodigo(socCodigo+(Math.random() + 100));
		solicitudB2.setSolCodigo(solCodigo);
		solicitudB2.setFecha(new Date());
		solicitudB2.setCorr(socCodigo);
		solicitudB2.setSeq(1);
		solicitudB2.setCuentaD(12);
		solicitudB2.setCotiz(BigDecimal.valueOf(6.96));
		solicitudB2.setMontoSol(BigDecimal.valueOf(100000));
		solicitudB2.setMontoAdj(BigDecimal.valueOf(100000));
		solicitudB2.setMontoMN(BigDecimal.valueOf(696000));
		solicitudB2.setClaEstado('9');
		solicitudB2.setBenef(benef);
		solicitudB2.setClaTipsolic("ED");
		solicitudB2.setBolCtamn(null);
		solicitudB2.setBolCtame(null);
		solicitudB2.setUsrCodigo("YOP");
		solicitudB2.setFechaHora(new Date());
		solicitudB2.setEstacion("ricochango");
		
		SocBolsin solicitudB3 = new SocBolsin();
		solicitudB3.setSocCodigo(socCodigo+(Math.random() + 100));
		solicitudB3.setSolCodigo(solCodigo);
		solicitudB3.setFecha(new Date());
		solicitudB3.setCorr(socCodigo);
		solicitudB3.setSeq(1);
		solicitudB3.setCuentaD(12);
		solicitudB3.setCotiz(BigDecimal.valueOf(6.96));
		solicitudB3.setMontoSol(BigDecimal.valueOf(100000));
		solicitudB3.setMontoAdj(BigDecimal.valueOf(100000));
		solicitudB3.setMontoMN(BigDecimal.valueOf(696000));
		solicitudB3.setClaEstado('9');
		solicitudB3.setBenef(benef);
		solicitudB3.setClaTipsolic("ED");
		solicitudB3.setBolCtamn(null);
		solicitudB3.setBolCtame(null);
		solicitudB3.setUsrCodigo("YOP");
		solicitudB3.setFechaHora(new Date());
		solicitudB3.setEstacion("ricochango");
		
		parametrosMsg.put("opcion", "nuevaBolsin");
		parametrosMsg.put("solicitud", solicitudB);

		BcbRequestImpl bcbRequestImpl = enviar2();
		parametrosMsg.put("opcion", "nuevaBolsin");
		parametrosMsg.put("solicitud", solicitudB2);

		BcbRequestImpl bcbRequestImpl2 = enviar2();		
		parametrosMsg.put("opcion", "nuevaBolsin");
		parametrosMsg.put("solicitud", solicitudB3);

		BcbRequestImpl bcbRequestImpl3 = enviar2();
		
		bcbRequestImpl.sendMessage();
		bcbRequestImpl2.sendMessage();
		bcbRequestImpl3.sendMessage();
	}

	public static void bolsin() {
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		if (!pathHome.startsWith("e:")) {
			pathHome = "e:".concat(pathHome);
		}

		ConfigurationServ.setServiceName(properties.getProperty("service.name"));

		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);

		String urlBroker = ConfigurationServ.getConfigProperty("jms.broker.url");
		gob.bcb.core.jms.Constants.setUrlBroker(urlBroker);

		OperacionesTest client = new OperacionesTest();
		client.brokerUrl = urlBroker;
		String[] appContextList = { "classpath:applicationcontextSioc.xml", "classpath:applicationcontextSiocCoin.xml",
				"classpath:applicationcontextPortia.xml" };

		try {
			FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(appContextList);
			ApplicationContext applicationContext = appContext;
			SessionFactory sessionFactorySioc = (SessionFactory) applicationContext.getBean("sessionFactoryBean");

			client.sessionFactorySioc = sessionFactorySioc;
			client.bolsin2("0000001", "902", 14, BigDecimal.valueOf(100000), BigDecimal.valueOf(100000), "");

			sessionFactorySioc.close();
			appContext.stop();
			appContext.close();
			System.out.println("==========================FIN MENSAJE RECIBIDO==========================");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);

	}

	public static void siocsigep() {
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		if (!pathHome.startsWith("e:")) {
			pathHome = "e:".concat(pathHome);
		}

		ConfigurationServ.setServiceName(properties.getProperty("service.name"));

		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);

		String urlBroker = ConfigurationServ.getConfigProperty("jms.broker.url");
		gob.bcb.core.jms.Constants.setUrlBroker(urlBroker);

		OperacionesTest client = new OperacionesTest();
		client.brokerUrl = urlBroker;
		String[] appContextList = { "classpath:applicationcontextSioc.xml", "classpath:applicationcontextBolsin.xml",
				"classpath:applicationcontextSiocCoin.xml", "classpath:applicationcontextBdweb.xml", "classpath:applicationcontextPortia.xml" };

		try {
			// FileSystemXmlApplicationContext appContext = new
			// FileSystemXmlApplicationContext(appContextList);
			// ApplicationContext applicationContext =appContext;
			// SessionFactory sessionFactorySioc = (SessionFactory)
			// applicationContext.getBean("sessionFactoryBean");
			//
			// client.sessionFactorySioc = sessionFactorySioc;

			// client.requestSolicitud("00000007", "generaopcontable");
			// client.requestSolicitudWS("e:/V01_1509012015180755_I.xml");
			 client.requestSolicitudWS("e:/V01_1509012015180756_I.xml");
			// client.requestSolicitudWS("e:/V01_1509012015180757_I.xml");
//			client.requestSolicitudWS("e:/V01_1509012015180758_I.xml");
//			client.requestSolicitudWS("e:/V02.xml");
//			client.requestSolicitudWS("e:/V0102.xml");
//			client.requestSolicitudWS("e:/V0103.xml");
//			client.requestSolicitudWS("e:/V0105.xml");
//			client.requestSolicitudWS("e:/V0106.xml");
//			client.requestSolicitudWS("e:/V0107.xml");
//			client.requestSolicitudWS("e:/V0108.xml");

			// sessionFactorySioc.close();
			// appContext.stop();
			// appContext.close();
			System.out.println("==========================FIN MENSAJE RECIBIDO==========================");
		} catch (JMSException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.exit(0);
		// Thread.sleep(20000);
		// client.stop();
	}

	public static void main(String[] args) {
		siocsigep();		
	}
}
