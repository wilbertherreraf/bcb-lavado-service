package gob.bcb.service.servicioSioc;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocCuentassol;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolcuentas;
import gob.bcb.bpm.pruebaCU.SocSolcuentasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.service.config.BaseDaoTest;
import gob.bcb.service.servicioSioc.pojos.ComprobanteDet;
import gob.bcb.service.servicioSioc.pojos.Detallesol;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;

public class SocSolicitudesDaoTest extends BaseDaoTest {
	private static final Log log = LogFactory.getLog(SocSolicitudesDaoTest.class);

	public void SocSolicitudesDaoQuery(String codSoli) {
		SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud(codSoli);

		log.info("solicitud " + socSolicitudes.toString());
		SocCuentassolDao socCuentassolDao = (SocCuentassolDao) factoryDao.getDao("socCuentassolDao");
		SocCuentassol socCuentassol = socCuentassolDao.getByCtaMovMoneda("3987", 69);
		log.info("solicitud " + socCuentassol.toString());
	}

	public void cuentasEnCuentaSolicitante(String solCodigo, String ctaMovimiento, String ctaAfectable, Integer codMoneda, Integer claVigente) {
		SocSolcuentasDao socSolicitudesDao = (SocSolcuentasDao) factoryDao.getDao("socSolcuentasDao");
		List<SocSolcuentas> lista = socSolicitudesDao.cuentasEnCuentaSolicitante(solCodigo, ctaMovimiento, ctaAfectable, codMoneda, "00990201001",
				claVigente);
		for (SocSolcuentas socSolcuentas : lista) {
			log.info("socSolcuentas " + socSolcuentas.toString());
		}
	}

	public void consultasolicitudes() {
		SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
		List<SolicitudesS> solicitudesSLista = socSolicitudesDao.recuperarSolicitudes(null, null, "TE,TC", null, null, null, null, null, null, null,null );
		for (SolicitudesS solicitudesS : solicitudesSLista) {
			log.info("solicitudesSLista " + solicitudesS.getSocCodigo() + " " + solicitudesS.getClaEstado());
		}

	}

	public void consultaDetsolicitudes() {
		SocDetallessolDao socSolicitudesDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
		Date de = UtilsDate.dateFromString("01/01/2016", "dd/MM/yyyy");
		SocSolicitudes socSolicitudes = new SocSolicitudes();
		socSolicitudes.setSocCodigo("000063");
		SocDetallessol socDetallessol = new SocDetallessol();
		SocDetallessolId socDetallessolid = new SocDetallessolId();
		socDetallessolid.setDetCodigo(1);
		socDetallessol.setId(socDetallessolid);

		List<Detallesol> solicitudesSLista = socSolicitudesDao.recuperarListaDetallessol(socSolicitudes);
		for (Detallesol solicitudesS : solicitudesSLista) {
			log.info("solicitudesSLista " + solicitudesS.getSocCodigo() + " " + solicitudesS.getBenNombre());
		}
		Detallesol Detallesol = socSolicitudesDao.recuperarDetallesol(socSolicitudes, socDetallessol);
		log.info("Detallesol " + Detallesol.getSocCodigo() + " " + Detallesol.getBenNombre());

	}

	public void comprobsRengs() {
		SocComprobanteDao socComprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
		List<ComprobanteDet> comprobanteList = socComprobanteDao.recuperarComprobReng("0000652971613");
		for (ComprobanteDet comprobanteDet : comprobanteList) {
			log.info("==S" + comprobanteDet.getCpbTipocambio());
			log.info("==S" + comprobanteDet.getRenAfectable() + " " + comprobanteDet.getRenAfectable() + " " + comprobanteDet.getMovi() + " tc: "
					+ comprobanteDet.getRenTipocambio() + " " + comprobanteDet.getClaDebehaber() + " " + comprobanteDet.getRenMontomn() + " "
					+ comprobanteDet.getRenMontomo());
		}

	}

	public void obtenerNroEsquemaContbcbTest(String codSoli) {
		SocComprobanteDao socComprobanteDao = new SocComprobanteDao();
		socComprobanteDao.setSessionFactory(sessionFactorySioc);
		SocComprobante socComprobante = new SocComprobante();
		socComprobante.setCpbCodigo("0052724382131");
		String nroEsq = socComprobanteDao.obtenerNroEsquemaContbcb(socComprobante);
		log.info("Esquema " + nroEsq);
	}
	
	public static void main(String[] args) {
		log.info("inicio testing");
		SocSolicitudesDaoTest socSolicitudesDaoTest = new SocSolicitudesDaoTest();
		try {
			socSolicitudesDaoTest.initContext();
			 socSolicitudesDaoTest.obtenerNroEsquemaContbcbTest("");
			socSolicitudesDaoTest.applicationContext.stop();
			log.info("cerrando");
		} catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		} finally {
			log.info("cerrando");
			socSolicitudesDaoTest.applicationContext.close();
		}

		String itf = "0.15";
		BigDecimal val = UtilsGeneric.bigDecimalFromString(itf);
		log.info("val " + val);

		BigDecimal comiPagoIVA = val.divide(BigDecimal.valueOf(100));
		log.info("comiPagoIVA " + comiPagoIVA);

		BigDecimal valor = UtilsGeneric.bigDecimalFromString("72.28");
		log.info("comiPagoIVA " + valor.multiply(comiPagoIVA).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP));
	}
}
