package gob.bcb.service.servicioSioc;

import gob.bcb.core.utils.UtilsFile;
import gob.bcb.service.config.BaseClientColas;

import java.io.IOException;

import javax.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ClientColas extends BaseClientColas {
	private static final Log log = LogFactory.getLog(ClientColas.class);

	public void enviarArchFirmado(String archFirmado) throws JMSException, IOException {
		String mensajeXML = UtilsFile.readFileAsString2(archFirmado);

		parametrosMsg.put("opcion", "REG_SOLWS");
		parametrosMsg.put(gob.bcb.service.servicioSioc.common.Constants.COD_IFA_REQUEST, gob.bcb.service.servicioSioc.common.Constants.COD_IFA_MEFP);
		parametrosMsg.put("mensajeXML", mensajeXML);

		enviar();
	}

	public static void main(String[] args) {
		ClientColas clientColas = new ClientColas();
		clientColas.init();
		try {
			log.info("===============oo000OOinicioOOO000oo===============");			
			//clientColas.enviarArchFirmado("e:/V01_1509012015180756_I.xml");
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V01001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V02001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V02002.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V03001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V04001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V05001.xml");			
			clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V06001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/V08001.xml");			
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/T01001.xml");
			//clientColas.enviarArchFirmado("e:/opt/testsiocmsgsigep/T02001.xml");
			log.info("===============oo000OFIIIIIIIIIINOOO000oo===============");			
		} catch (JMSException e) {
			log.error("Error " + e.getMessage());
		} catch (IOException e) {
			log.error("Error 2 " + e.getMessage());
		}
		System.exit(0);
	}
}
