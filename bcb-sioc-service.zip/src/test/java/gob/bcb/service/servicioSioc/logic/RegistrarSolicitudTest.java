package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
//import org.junit.Test;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolId;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasPK;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.service.config.BaseDaoTest;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class RegistrarSolicitudTest  extends BaseDaoTest {
	private Logger log = Logger.getLogger(RegistrarSolicitudTest.class);
	//@Test
	public void registrarTDSF(){
		log.info("============== registrarTDSF ===============");
		SocSolicitudes socSolicitudes = new SocSolicitudes();
		socSolicitudes.setSolEntsolic("903");
		socSolicitudes.setSolCodigo("903");
		socSolicitudes.setSocMontome(BigDecimal.valueOf(171017.25));
		socSolicitudes.setSocMontomn(BigDecimal.ZERO);
		socSolicitudes.setSocMontoord(BigDecimal.ZERO);
		socSolicitudes.setCodMoneda(Constants.COD_MONEDA_USD);
		socSolicitudes.setCodMonedat(Constants.COD_MONEDA_USD);

		socSolicitudes.setClaTipo(Constants.CLAVE_TIPOOPER_DELEXT);
		socSolicitudes.setCveSubtipooper(Constants.CLAVE_SUBTIPOOPER_TRADELEXT);
		socSolicitudes.setTipoRetencion(Constants.CLAVE_TIPORETENCION_SINDESC);
		socSolicitudes.setSocTipnegociacion(Constants.CLAVE_TIPNEGOCIA_NORMAL);
		socSolicitudes.setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
		socSolicitudes.setFecha(new Date());
		socSolicitudes.setEsqCodigo(262);
		socSolicitudes.setDetConcepto("test glosa");
		socSolicitudes.setDetFacturas("NRO DE SWIFT TEST 0000");
		socSolicitudes.setUsrCodreg("190");
		
		List<SocDetallessol> socDetallessolLista = completarCtaCTra(socSolicitudes);
		Solicitud solicitudTO = populateSolicitudTO(socSolicitudes,socDetallessolLista);
		
		initContext();
		applicationContext.stop();
		
		QueryProcessor.setSessionFactory(sessionFactoryBeanSiocCoin);
		SiocCoinService.setSessionFactory(sessionFactoryBeanSiocCoin);
		log.info("solicitud " + socSolicitudes.toString());		

		RegistrarSolicitud registrarSolicitud = new RegistrarSolicitud();
		registrarSolicitud.setSessionFactory(sessionFactory);
		ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(sessionFactory);
		
		solicitudTO = registrarSolicitud.registrarSolicitud(solicitudTO);
		procesosSolicitud.preAutorizar(solicitudTO);
	}
	
	public List<SocDetallessol> completarCtaCTra(SocSolicitudes socSolicitudes) {
		List<SocDetallessol> socDetallessolLista = new ArrayList<SocDetallessol>();
		SocDetallessolId socDetallessolId = new SocDetallessolId();
		socDetallessolId.setDetCodigo(1);
		
		SocDetallessol socDetallessolSelected = new SocDetallessol();
		socDetallessolSelected.setId(socDetallessolId);
		socDetallessolSelected.setCodBanco(null);
		socDetallessolSelected.setNroCuentabco("3908");
		socDetallessolSelected.setDetInfo(null);
		socDetallessolSelected.setCtaCodigo(null);
		socDetallessolSelected.setDetFacturas(null);
		socDetallessolSelected.setBeneficiario(null);
		socDetallessolSelected.setBenCodigo("903");		
		socDetallessolSelected.setCodBancointer(null);
		socDetallessolSelected.setNroCuentabcointer(null);
		socDetallessolSelected.setDetCodttransfer(null);
		socDetallessolSelected.setDetMonto(socSolicitudes.getSocMontome());
		socDetallessolSelected.setCodMoneda(socSolicitudes.getCodMoneda());		
		socDetallessolLista.add(socDetallessolSelected);
		
		return socDetallessolLista;
	}
	
	public Solicitud populateSolicitudTO(SocSolicitudes socSolicitudes,List<SocDetallessol> socDetallessolLista) {
		Solicitud solicitudTO = new Solicitud();
		solicitudTO.setsIOCWEB_TIPOPERACION("SOL_AVISO_TRANS_DEL_EXT");
		solicitudTO.setSolicitud(socSolicitudes);
		solicitudTO.setSocDetallessolLista(socDetallessolLista);

		SocSolicitudctasPK socSolicitudctasPK = new SocSolicitudctasPK();
		SocSolicitudctas socSolicitudctasMovProv = new SocSolicitudctas();
		socSolicitudctasMovProv.setId(socSolicitudctasPK);
		socSolicitudctasMovProv.getId().setTipoCuenta(Constants.COD_CLAVE_MOVPROVISION);
		socSolicitudctasMovProv.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);		
		socSolicitudctasMovProv.setCodMoneda(Constants.COD_MONEDA_USD);
		socSolicitudctasMovProv.setNroCuenta("5896");		
		
		SocSolicitudctasPK socSolicitudctasPKga = new SocSolicitudctasPK();
		SocSolicitudctas socSolicitudctasComGAdm = new SocSolicitudctas();
		socSolicitudctasComGAdm.setId(socSolicitudctasPKga);
		socSolicitudctasComGAdm.getId().setTipoCuenta(Constants.COD_CLAVE_COMGADM);
		socSolicitudctasComGAdm.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);		
		socSolicitudctasComGAdm.setCodMoneda(Constants.COD_MONEDA_BS);
		socSolicitudctasComGAdm.setNroCuenta("3908");

		SocSolicitudctasPK socSolicitudctasPKDest = new SocSolicitudctasPK();
		SocSolicitudctas socSolicitudctasDestino = new SocSolicitudctas();
		socSolicitudctasDestino.setId(socSolicitudctasPKDest);
		socSolicitudctasDestino.getId().setTipoCuenta(Constants.COD_CLAVE_MOVDESTINO);
		socSolicitudctasDestino.setCveTipocomis(Constants.CLAVE_TIPOCOMIS_SOLIC);
		socSolicitudctasDestino.setCodMoneda(Constants.COD_MONEDA_USD);
		socSolicitudctasDestino.setNroCuenta("3908");
		
		List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();
		socSolicitudctasLista.add(socSolicitudctasMovProv);
		socSolicitudctasLista.add(socSolicitudctasComGAdm);
		socSolicitudctasLista.add(socSolicitudctasDestino);		
		solicitudTO.setSocSolicitudctasLista(socSolicitudctasLista);

		solicitudTO.setCodEstacionAudit("wherrera");
		solicitudTO.setCodUsuarioAudit("wherrera");
		solicitudTO.setCodPersonaAudit("903");
		solicitudTO.setCodUsuarioCont("wherrera");
		solicitudTO.setCodTipoOperacion("102");
		
		return solicitudTO;
	}
	
}
