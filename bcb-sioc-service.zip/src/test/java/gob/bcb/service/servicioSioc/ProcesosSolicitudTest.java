package gob.bcb.service.servicioSioc;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.service.config.BaseDaoTest;
import gob.bcb.service.servicioPortiaSwift.PortiaService;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.ActualizarAFecha;
import gob.bcb.service.servicioSioc.logic.ProcesosSolicitud;
import gob.bcb.service.servicioSioc.logic.RegistrarSolicitud;
import gob.bcb.service.servicioSioc.logic.SwiftSiocService;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class ProcesosSolicitudTest extends BaseDaoTest {
	private static final Log log = LogFactory.getLog(ProcesosSolicitudTest.class);

	public void registrarSolicitudTest() {
		log.info("registrarSolicitudTest .........");

		ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(sessionFactorySioc);
		SwiftSiocService swiftSiocService = new SwiftSiocService();
		swiftSiocService.setSessionFactory(sessionFactorySioc);

		Solicitud solicitudTO = procesosSolicitud.recuperarSolicitudSimple("005268");

		QueryProcessor.setSessionFactory(sessionFactorySioc);
		QueryProcessor.setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
		SiocCoinService.setSessionFactory(sessionFactoryBeanSiocCoin);
		SiocCoinService.setNameSessionFactory(Constants.PROP_ALIAS_COIN);
		PortiaService.setSessionFactory(sessionFactoryPortia);
		PortiaService.setNameSessionFactory(Constants.PROP_ALIAS_PORTIA);

		// QueryProcessor.begin();

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(sessionFactorySioc);

		solicitudTO.setSocSolicitudctasLista(socSolicitudctasDao.getCuentas(solicitudTO.getSolicitud().getSocCodigo()));
		solicitudTO.getSolicitud().setSocCodigo(null);
		solicitudTO.getSolicitud().setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
		solicitudTO.getSolicitud().setSolEntsolic(Constants.COD_BCB);
		//solicitudTO.setSocOpecomiLista(new ArrayList<SocOpecomi>());
		solicitudTO.getSolicitud().setFechaCont(new Date());

		log.info("solicitud " + solicitudTO.getSolicitud().toString() + " nro detalle " + solicitudTO.getSocDetallessolLista().size());

		RegistrarSolicitud registrarSolicitud = new RegistrarSolicitud();
		registrarSolicitud.setSessionFactory(sessionFactorySioc);

		solicitudTO.setCodEstacionAudit("1653");
		solicitudTO.setCodUsuarioAudit("1653");
		solicitudTO.setCodPersonaAudit(Constants.COD_BCB);
		solicitudTO.setCodUsuarioCont("1653");
		solicitudTO.setCodTipoOperacion("102");

		solicitudTO = registrarSolicitud.registrarSolicitud(solicitudTO);
		solicitudTO.getSolicitud().setFechaCont(new Date());
		solicitudTO.setCodEstacionAudit("1653");
		solicitudTO.setCodUsuarioAudit("1653");
		solicitudTO.setCodPersonaAudit(Constants.COD_BCB);
		solicitudTO.setCodUsuarioCont("1653");
		solicitudTO = procesosSolicitud.preAutorizar(solicitudTO);

		solicitudTO.setCodEstacionAudit("1653");
		solicitudTO.setCodUsuarioAudit("1653");
		solicitudTO.setCodPersonaAudit(Constants.COD_BCB);
		solicitudTO = swiftSiocService.autorizarSwift(solicitudTO);

		solicitudTO.setCodEstacionAudit("1653");
		solicitudTO.setCodUsuarioAudit("1653");
		solicitudTO.setCodPersonaAudit(Constants.COD_BCB);
		solicitudTO.setCodUsuarioCont("1653");
		solicitudTO = procesosSolicitud.autorizar(solicitudTO);
	}

	public void registrarSolicitudConColasTest() {
		log.info("registrarSolicitudConColasTest .........");

		ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(sessionFactorySioc);
		SwiftSiocService swiftSiocService = new SwiftSiocService();
		swiftSiocService.setSessionFactory(sessionFactorySioc);

		// rree 003391		003653		003432
		Solicitud solicitudTO = procesosSolicitud.recuperarSolicitudSimple("003391");

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(sessionFactorySioc);

		solicitudTO.setSocSolicitudctasLista(socSolicitudctasDao.getCuentas(solicitudTO.getSolicitud().getSocCodigo()));
		solicitudTO.getSolicitud().setSocCodigo(null);
		solicitudTO.getSolicitud().setCveTipctasolic(Constants.CLAVE_GENERADOPOR_SISTEMA);
		solicitudTO.getSolicitud().setSolEntsolic(Constants.COD_BCB);
		//solicitudTO.setSocOpecomiLista(new ArrayList<SocOpecomi>());
		solicitudTO.getSolicitud().setFechaCont(new Date());

		log.info("solicitud " + solicitudTO.getSolicitud().toString() + " nro detalle " + solicitudTO.getSocDetallessolLista().size());

		getParametrosMsg().put("opcion", "REG_SOLICITUD");
		getParametrosMsg().put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
		BcbRequestImpl bcbRequestImpl = crearObjetoMensaje((String) getParametrosMsg().get("opcion"), getParametrosMsg());
		bcbRequestImpl.setDisableReplyTo(false);
		StatusResponse statusResponse = bcbRequestImpl.sendMessage();
		
		MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
		Map<String, Object> respuesta = (Map<String, Object>) messageObjectBean1.getTransformedMessage();
		solicitudTO = (Solicitud) respuesta.get(Constants.OBJ_NAME_SOLICITUDTO);
		log.info("solicitud Respuesta " + solicitudTO.getSolicitud().toString());
		
		getParametrosMsg().put("opcion", "PREAUT");
		getParametrosMsg().put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
		bcbRequestImpl = crearObjetoMensaje((String) getParametrosMsg().get("opcion"), getParametrosMsg());
		bcbRequestImpl.setDisableReplyTo(false);
		statusResponse = bcbRequestImpl.sendMessage();		
		
		getParametrosMsg().put("opcion", "AUTSWFT");
		getParametrosMsg().put(Constants.OBJ_NAME_SOLICITUDTO, solicitudTO);
		bcbRequestImpl = crearObjetoMensaje((String) getParametrosMsg().get("opcion"), getParametrosMsg());
		bcbRequestImpl.setDisableReplyTo(false);
		statusResponse = bcbRequestImpl.sendMessage();		
	}

	public void crearSolicitudTCTest() {
		log.info("crearSolicitudTCTest .........");
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(sessionFactory);
		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud("000048");
		socSolicitudes.setFechaCont(new Date());

		Solicitud solicitudTO = new Solicitud();
		solicitudTO.setSolicitud(socSolicitudes);

		QueryProcessor.setSessionFactory(sessionFactoryBeanSiocCoin);
		QueryProcessor.setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
		SiocCoinService.setSessionFactory(sessionFactoryBeanSiocCoin);
		SiocCoinService.setNameSessionFactory(Constants.PROP_ALIAS_COIN);
		log.info("solicitud " + socSolicitudes.toString());

		ProcesosSolicitud procesosSolicitud = new ProcesosSolicitud();
		procesosSolicitud.setSessionFactory(sessionFactory);
		solicitudTO.setCodEstacionAudit("1653");
		solicitudTO.setCodUsuarioAudit("1653");
		solicitudTO.setCodPersonaAudit("900");
		solicitudTO.setCodUsuarioCont("1653");
		solicitudTO.setCodTipoOperacion("102");

		ActualizarAFecha actualizarAFecha = new ActualizarAFecha();
		actualizarAFecha.setSessionFactory(sessionFactory);

		actualizarAFecha.actualizarAFecha(solicitudTO);

		log.info("solicitud ........." + socSolicitudes.toString());
	}

	public static void main(String[] args) {
		log.info("inicio testing");
		ProcesosSolicitudTest socSolicitudesDaoTest = new ProcesosSolicitudTest();
		SeverMainSioc.main(null);
		log.info("registrarSolicitudTest .........");
		try {
			socSolicitudesDaoTest.initContext();
			socSolicitudesDaoTest.registrarSolicitudConColasTest();
		} catch (Exception e) {
			log.error("XXX: " + e.getMessage(), e);
		} finally {
			log.info("cerrandoooooooooooooooo");
			socSolicitudesDaoTest.applicationContext.close();
		}
		// ProcesosSolicitudTest socSolicitudesDaoTest = new
		// ProcesosSolicitudTest();
		// try {
		// socSolicitudesDaoTest.initContext();
		// socSolicitudesDaoTest.registrarSolicitudTest();
		// socSolicitudesDaoTest.applicationContext.stop();
		// log.info("cerrando");
		// log.info("===============oo000OOOOO000oo===============");
		// QueryProcessor.commit();
		// } catch (Exception e) {
		// QueryProcessor.rollbackTransaction();
		// log.error("XXX: " + e.getMessage(), e);
		// } finally {
		// log.info("cerrando");
		// socSolicitudesDaoTest.applicationContext.close();
		//
		// }
	}
}
