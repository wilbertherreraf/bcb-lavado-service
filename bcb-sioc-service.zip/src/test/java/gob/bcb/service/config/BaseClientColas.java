package gob.bcb.service.config;

import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class BaseClientColas {
	private static final Log log = LogFactory.getLog(BaseClientColas.class);
	public String brokerUrl = "tcp://10.2.11.91:61616";
	// private String brokerUrl = "tcp://localhost:61616";
	public String requestQueue = "BCB.SUSTANTIVO.BPM.SIOC.QUEUE";
	protected Map<String, Object> parametrosMsg = new HashMap<String, Object>();
	protected MessageObjectBean messageObjectBean = new MessageObjectBean();
	protected Map<String, Object> parametros = new HashMap<String, Object>();

	public void enviar() throws JMSException, IOException {
		messageObjectBean.setTransformedMessage(parametrosMsg);

		StatusResponse statusResponse = null;

		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(brokerUrl);
		//String usuarioTask = Servicios.getParam("usuarioTask");
		try {
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWS");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", "central");
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOCWS");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					null, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			bcbRequestImpl.setDisableReplyTo(false);
			
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();
			if (statusResponse.getResponse() instanceof MessageObjectBean) {
				MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
				Map<String, Object> respuesta = (Map<String, Object>) messageObjectBean1.getTransformedMessage();
				if (respuesta.containsKey("resp_msgerror")) {
					throw new RuntimeException((String) respuesta.get("resp_msgerror"));
				}
				if (respuesta.containsKey("resp_codmsg")) {
					String codRespuesta = (String) respuesta.get("resp_codmsg");
					String descRespuesta = (String) respuesta.get("resp_descripmsg");
					System.out.println("OOOOOOOOOOOOOOOOOOOOOOOOO");					
					System.out.println(descRespuesta);				
					System.out.println("OOOOOOOOOOOOOOOOOOOOOOOOO");					
				}
				
				System.out.println(respuesta);
			} else
				System.out.println(statusResponse.getDescrip());
			
		} catch (Exception e) {
			log.error("error " + e.getMessage(), e);
			throw new RuntimeException(e);
		} finally {
			// jMSConnectionHandler.close();
		}
		System.out.println("==========================FIN RECIBIDO==========================");
	}

	public void init() {
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		if (!pathHome.startsWith("e:")) {
			pathHome = "e:".concat(pathHome);
		}

		ConfigurationServ.setServiceName(properties.getProperty("service.name"));

		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);

		brokerUrl = ConfigurationServ.getConfigProperty("jms.broker.url");
		gob.bcb.core.jms.Constants.setUrlBroker(brokerUrl);
	}

}
