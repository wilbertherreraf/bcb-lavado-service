/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsQNatives;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.pojos.ComprobanteDet;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.joda.time.DateTime;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author parenas
 * 
 */
public class SocRengscompDao extends HibernateDaoSupport {

	private static final Log log = LogFactory.getLog(SocRengscompDao.class);
	private BigDecimal tcUS = BigDecimal.valueOf(0);
	private BigDecimal tcBS = BigDecimal.valueOf(1);

	public void saveOrUpdate(SocRengscomp pm) {
		// log.info("Saving or updating " + pm);
		this.getHibernateTemplate().merge(pm);
	}

	public void eliminar(SocRengscomp pm) {
		this.getHibernateTemplate().delete(pm);
	}

	public void eliminarRegs(String codigo) {
		List<SocRengscomp> facts = getRenglones(codigo);
		this.getHibernateTemplate().deleteAll(facts);
		int i = 0;
		log.info("Eliminados reng comp [ " + i + " ] regs.");
	}

	public List<SocRengscomp> getRenglones(String id) {
		List<SocRengscomp> lista = new ArrayList<SocRengscomp>();

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocRengscomp re ");
		query = query.append("where re.id.cpbCodigo = :codigo ");
		query = query.append("order by re.id.renCodigo ");

		Query consulta = getSession().createQuery(query.toString());
		log.info("Renglones getRenglones [cpbCodigo= " + id + "]" + query.toString());
		consulta.setParameter("codigo", id);

		lista = consulta.list();

		return lista;
	}

	public List<SocRengscomp> rengloesByCodOpeDHCtaMov(String cpbCodigo, String opeCodigo, Character claDebehaber, String ctaMovimiento,
			String cveEstadocpb, String cveDettipocomp, Integer detCodigo, String cpbCodigoref, String tipoTransfer, String ctaDestorig) {
		List<SocRengscomp> lista = new ArrayList<SocRengscomp>();

		if (!StringUtils.isBlank(cveDettipocomp)) {
			// para consultas que vienen con un solo caracter
			cveDettipocomp = (!cveDettipocomp.startsWith("'") ? "'" : "") + cveDettipocomp + (!cveDettipocomp.endsWith("'") ? "'" : "");
		}

		if (!StringUtils.isBlank(ctaMovimiento)) {
			// para consultas que vienen con un solo caracter
			ctaMovimiento = (!ctaMovimiento.startsWith("'") ? "'" : "") + ctaMovimiento + (!ctaMovimiento.endsWith("'") ? "'" : "");
		}

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocComprobante cp, SocRengscomp re ");
		query = query.append("where cp.cpbCodigo = re.id.cpbCodigo ");

		if (!StringUtils.isBlank(cpbCodigo))
			query = query.append("and cp.cpbCodigo = :cpbCodigo ");

		if (!StringUtils.isBlank(opeCodigo))
			query = query.append("and cp.opeCodigo = :opeCodigo ");

		if (claDebehaber != null) {
			query = query.append("and re.claDebehaber = :claDebehaber ");
		}

		if (!StringUtils.isBlank(ctaMovimiento)) {
			query = query.append("and re.ctaMovimiento in (" + ctaMovimiento + ") ");
		}

		if (!StringUtils.isBlank(cveEstadocpb)) {
			query = query.append("and cp.cveEstadocpb = :cveEstadocpb ");
		} else {
			query = query.append("and cp.cveEstadocpb != 'Z' ");
		}

		if (!StringUtils.isBlank(cveDettipocomp)) {
			query = query.append("and cp.cveDettipocomp in (" + cveDettipocomp + ") ");
		}
		if (detCodigo != null) {
			query = query.append("and cp.codTransac = :detCodigo ");
		}
		if (!StringUtils.isBlank(cpbCodigoref)) {
			query = query.append("and cp.cpbCodigoref = :cpbCodigoref ");
		}
		if (!StringUtils.isBlank(tipoTransfer)) {
			query = query.append("and re.tipoTransfer = :tipoTransfer ");
		}
		if (!StringUtils.isBlank(ctaDestorig)) {
			query = query.append("and re.ctaDestorig = :ctaDestorig ");
		}
		query = query.append("order by re.id.renCodigo ");

		Query consulta = getSession().createQuery(query.toString());
		log.info("Renglones rengloesByCodOpeDHCtaMov [opeCodigo " + opeCodigo + "]" + query.toString());

		if (!StringUtils.isBlank(cpbCodigo))
			consulta.setParameter("cpbCodigo", cpbCodigo);

		if (!StringUtils.isBlank(opeCodigo))
			consulta.setParameter("opeCodigo", opeCodigo);

		if (claDebehaber != null)
			consulta.setCharacter("claDebehaber", claDebehaber);

		if (!StringUtils.isBlank(cveEstadocpb)) {
			consulta.setParameter("cveEstadocpb", cveEstadocpb);
		}

		if (detCodigo != null) {
			consulta.setParameter("detCodigo", detCodigo);
		}
		if (!StringUtils.isBlank(cpbCodigoref)) {
			consulta.setParameter("cpbCodigoref", cpbCodigoref);
		}
		if (!StringUtils.isBlank(tipoTransfer)) {
			consulta.setParameter("tipoTransfer", tipoTransfer);
		}
		if (!StringUtils.isBlank(ctaDestorig)) {
			consulta.setParameter("ctaDestorig", ctaDestorig);
		}
		lista = consulta.list();

		return lista;
	}

	public SocRengscomp getRenglon(String id, Integer reng) {
		SocRengscomp renglon = null;

		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SocRengscomp re ");
		query = query.append("where re.id.cpbCodigo = :codigo ");
		query = query.append("and re.id.renCodigo = :reng ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setString("codigo", id);
		consulta.setInteger("reng", reng);

		log.info("Renglones getRenglon [cpbCodigo= " + id + ", renCodigo= " + reng + "]" + query.toString());

		List lista = consulta.list();

		if (lista.size() > 0) {
			renglon = (SocRengscomp) lista.get(0);
		}
		return renglon;
	}

	public List<SocRengscomp> CrearRenglones(String idC, List<Map<String, Object>> rengs, SocSolicitudes solicitud, List<SocDetallessol> detalles) {
		log.info("Entrando CrearRenglones Solicitud: " + solicitud.getSocCodigo());
		QueryProcessor.flush();

		if (idC == null || idC.trim().isEmpty()) {
			log.error("Codigo de comprobante nulo, el comprobante en SIOC no fue generado, comunique a sistemas. " + solicitud.getSocCodigo());
			throw new RuntimeException("Codigo de comprobante nulo, el comprobante en SIOC no fue generado, comunique a sistemas. "
					+ solicitud.getSocCodigo());
		}

		Boolean creado = true;
		int reng = 0;
		tcUS = getTipoCambio(34);

		SocDetallessol detalle = detalles.get(0);

		for (Map<String, Object> res : rengs) {
			if (detalles.size() == 1) {
				// un beneficiario
				reng = this.CrearRenglon(idC, res, solicitud, detalle, reng);
			} else {
				// varios beneficiarios
				if ((Integer) res.get("repetible") == 0) {
					// no repetible
					reng = this.CrearRenglon(idC, res, solicitud, detalle, reng);
				} else {
					// repetible
					for (SocDetallessol det : detalles) {
						reng = this.CrearRenglonR(idC, res, solicitud, det, reng);
						if (reng == 0)
							creado = false;
					}
				}
			}

		}
		// se realiza el flush para asegurar el guardado de datos

		QueryProcessor.flush();
		List<SocRengscomp> renglones = getRenglones(idC);
		if (renglones == null || renglones.size() == 0) {
			log.error("No se registraron ningun renglon sobre la solicitud " + solicitud.getSocCodigo());
			throw new RuntimeException("No se registraron ningun renglon sobre la solicitud " + solicitud.getSocCodigo());
		}

		log.info("Renglones creados para solicitud [SocCodigo= " + solicitud.getSocCodigo() + ", socComprobante= " + idC + "]" + renglones.size());

		renglones = getRenglones(idC);
		this.crearAjuste(renglones, idC, rengs);
		QueryProcessor.flush();
		renglones = getRenglones(idC);
		return renglones;
	}

	public List<SocRengscomp> CrearRenglones(String idC, List<Map<String, Object>> rengs, SocOperaciones operacion, List<SocDetallesope> detalles) {
		QueryProcessor.flush();

		if (idC == null || idC.trim().isEmpty()) {
			log.error("Codigo de comprobante nulo, el comprobante en SIOC no fue generado, comunique a sistemas. " + operacion.getOpeCodigo());
			throw new RuntimeException("Codigo de comprobante nulo, el comprobante en SIOC no fue generado, comunique a sistemas. "
					+ operacion.getOpeCodigo());
		}
		log.info("Ejecutando CrearRenglones(String idC, List): " + idC + ", " + operacion.getSocCorrelativo());

		Boolean creado = true;
		int reng = 0;
		tcUS = getTipoCambio(34);

		SocDetallesope detalle = detalles.get(0);
		for (Map<String, Object> res : rengs) {
			if (detalles.size() == 1) {
				// un beneficiario
				reng = this.CrearRenglon(idC, res, operacion, detalle, reng);
			}
			if (reng == 0)
				creado = false;
		}
		QueryProcessor.flush();
		List<SocRengscomp> renglones = getRenglones(idC);
		if (renglones == null || renglones.size() == 0) {
			log.error("No se registraron ningun renglon sobre la operacion " + operacion.getOpeCodigo());
			throw new RuntimeException("No se registraron ningun renglon sobre la operacion " + operacion.getOpeCodigo());
		}

		this.crearAjuste(renglones, idC, rengs);
		QueryProcessor.flush();

		renglones = getRenglones(idC);
		return renglones;
	}

	public Integer CrearRenglon(String idC, Map<String, Object> def, SocSolicitudes solicitud, SocDetallessol detalle, int cod) {
		String defCta = (String) def.get("cla_cuenta");
		char dh = (Character) def.get("esq_dh");
		String defMonto = (String) def.get("esq_definicion");
		String defGlosa = (String) def.get("cla_glosa_r");

		log.info(def.get("esq_codigo") + "-" + def.get("cla_cuenta") + " => Entrando a CrearRenglon Solicitud [" + (cod + 1) + "] getSocCodigo: "
				+ solicitud.getSocCodigo() + "; codComprob: " + idC + "; detalleCod " + detalle.getId().getDetCodigo() + "; Definicion: " + def);

		int mon = 0;
		BigDecimal tc = BigDecimal.valueOf(0.00);
		BigDecimal montoMN;
		BigDecimal montoME;
		// cod = cod + 1;

		Map<String, Object> datos;
		if (defCta.charAt(0) == '@') {
			datos = getCuentaP(defCta);
		} else {
			if (defCta.equalsIgnoreCase("BANC")) {
				datos = getCuenta(getDefCuenta(defCta, solicitud.getSocCodigo(), detalle.getId().getDetCodigo()));
			} else {
				datos = getCuenta(getDefCuenta(defCta, solicitud));
			}
		}

		mon = (Integer) datos.get("mon");
		if (mon == 34)
			tc = tcUS;
		else {
			if (mon == 69)
				tc = tcBS;
			else
				tc = getTipoCambio((Integer) datos.get("mon"));
		}
		montoME = getDefMonto(mon, defMonto, solicitud);
		if (defMonto.equalsIgnoreCase("DCMB")) {
			if (montoME.compareTo(BigDecimal.valueOf(0)) < 0) {
				dh = 'D';
				montoME = montoME.abs();
			} else {
				dh = 'H';
			}
		}

		if (!defMonto.equalsIgnoreCase("montoMEO"))
			montoMN = montoME.multiply(tc);
		else {
			montoMN = getMontoMN(solicitud.getSocCodigo());
			tc = montoMN.divide(montoME, 5, RoundingMode.HALF_UP);
		}

		// para ajuste a dos digitos
		montoME = montoME.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		montoMN = montoMN.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

		if (montoME.compareTo(BigDecimal.valueOf(0.009)) > 0) {
			cod = cod + 1;
			SocRengscomp renglon = new SocRengscomp(new SocRengscompId(idC, cod), mon, dh, tc, montoME, montoMN, (String) datos.get("mayor"),
					(String) datos.get("afec"), GlosaRenglon.crearGlosa(defGlosa, detalle));
			this.saveOrUpdate(renglon);
			log.info("Renglon creado [" + cod + "] socCodigo: " + solicitud.getSocCodigo() + " => " + renglon.toString());
		} else {
			// cod = cod - 1;
			log.info("renglon NO creado por importe menor o igual a CERO " + def.toString() + ", SOLICTUD: " + solicitud.toString());
		}

		return cod;
	}

	public Integer CrearRenglon(String idC, Map<String, Object> def, SocOperaciones operacion, SocDetallesope detalle, int cod) {
		String defCta = (String) def.get("cla_cuenta");
		char dh = (Character) def.get("esq_dh");
		String defMonto = (String) def.get("esq_definicion");
		String defGlosa = (String) def.get("cla_glosa_r");

		log.info(def.get("esq_codigo") + "-" + def.get("cla_cuenta") + " => Entrando a CrearRenglon Operacion [" + (cod + 1) + "] getSocCodigo: "
				+ operacion.getOpeCodigo() + "; codComprob: " + idC + "; detalleCod " + detalle.getId().getDetCodigo() + "; Definicion: " + def);

		BigDecimal tc = BigDecimal.valueOf(0.00);
		BigDecimal montoMN;
		BigDecimal montoME;
		// cod = cod + 1;

		Map<String, Object> datos;
		if (defCta.charAt(0) == '@') {
			datos = getCuentaP(defCta);
		} else {
			datos = getCuenta(getDefCuenta(defCta, operacion));
		}

		int mon = (Integer) datos.get("mon");

		if (mon == 34)
			tc = tcUS;
		else {
			if (mon == 69)
				tc = tcBS;
			else
				tc = getTipoCambio((Integer) datos.get("mon"));
		}
		montoME = getDefMonto(mon, defMonto, operacion);
		if (mon == 69 && defMonto.equalsIgnoreCase("montoME"))
			montoME = montoME.multiply(tcUS);
		montoMN = montoME.multiply(tc);

		// para ajuste a dos digitos
		montoME = montoME.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		montoMN = montoMN.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

		if (montoME.compareTo(BigDecimal.valueOf(0.00999)) > 0) {
			cod = cod + 1;
			SocRengscomp renglon = new SocRengscomp(new SocRengscompId(idC, cod), mon, dh, tc, montoME, montoMN, (String) datos.get("mayor"),
					(String) datos.get("afec"), GlosaRenglon.crearGlosa(defGlosa, detalle));
			this.saveOrUpdate(renglon);
			log.info("Renglon creado [" + cod + "] OpeCodigo: " + operacion.getOpeCodigo() + " => " + renglon.toString());
		} else {
			// cod = cod - 1;
			log.info("renglon NO creado por importe menor o igual a CERO " + def.toString() + ", OPERACION: " + operacion.getOpeCodigo());
		}

		return cod;
	}

	public Integer CrearRenglonR(String idC, Map<String, Object> def, SocSolicitudes solicitud, SocDetallessol detalle, int cod) {
		log.info("Entrando a CrearRenglonR Solicitud Repetible [" + (cod + 1) + "] getSocCodigo: " + solicitud.getSocCodigo() + "; codComprob: "
				+ idC + "; detalleCod " + detalle.getId().getDetCodigo() + "; Definicion: " + def);

		String defCta = (String) def.get("cla_cuenta");
		char dh = (Character) def.get("esq_dh");
		String defGlosa = (String) def.get("cla_glosa_r");
		int mon = 0;
		BigDecimal tc = BigDecimal.valueOf(0.00);
		BigDecimal montoMN;
		BigDecimal montoME;
		// cod = cod + 1;

		Map<String, Object> datos;
		if (defCta.charAt(0) == '@') {
			datos = getCuentaP(defCta);
		} else {
			if (defCta.equalsIgnoreCase("BANC")) {
				datos = getCuenta(getDefCuenta(defCta, solicitud.getSocCodigo(), detalle.getId().getDetCodigo()));
			} else {
				datos = getCuenta(getDefCuenta(defCta, solicitud));
			}
		}

		mon = (Integer) datos.get("mon");
		if (mon == 34)
			tc = tcUS;
		else {
			if (mon == 69)
				tc = tcBS;
			else
				tc = getTipoCambio((Integer) datos.get("mon"));
		}
		montoME = detalle.getDetMonto();
		montoMN = montoME.multiply(tc);
		// para ajuste a dos digitos
		montoMN = montoMN.divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

		if (montoME.compareTo(BigDecimal.valueOf(0.00999)) > 0) {
			cod = cod + 1;
			SocRengscomp renglon = new SocRengscomp(new SocRengscompId(idC, cod), mon, dh, tc, montoME, montoMN, (String) datos.get("mayor"),
					(String) datos.get("afec"), GlosaRenglon.crearGlosa(defGlosa, detalle));
			this.saveOrUpdate(renglon);
			log.info("Renglon creado [" + cod + "] socCodigo: " + solicitud.getSocCodigo() + " => " + renglon.toString());
		} else {
			log.info("renglon NO creado por importe menor o igual a CERO " + def.toString() + ", SOLICTUD: " + solicitud.toString());
		}

		return cod;
	}

	public String CrearRenglonesITF(String codComprobOperacion, String opeCodigo, Date fechaOper, SocSolicitudes solicitud, SocDetallessol detalle) {
		log.info("Entrando a nuevo ITF " + codComprobOperacion + " getSocCodigo: " + solicitud.getSocCodigo() + "; detalleCod "
				+ detalle.getId().getDetCodigo());
		Boolean creado = true;

		int reng = 0;
		int monUS = 34;
		int monCoin = 0;
		BigDecimal sobreITF = BigDecimal.valueOf(0.00);
		Map<String, Object> datos;

		String tipoOperacion = "ITF";
		String subTipo = "TT";

		// ** PARCHE 20140719: se reporta que los comprobantes generan itf
		// incorrectos ***////
		// // ** se realiza una verificacion de los comprobantes y de los montos
		// barriendo todos los renglones

		List<SocRengscomp> socRengscompList = getRenglones(codComprobOperacion);

		boolean generaITF = false;
		BigDecimal sumaITF = BigDecimal.ZERO;

		for (SocRengscomp socRengscomp : socRengscompList) {
			log.info("XXX: control de ITF: " + socRengscomp.toString());

			int genITF = Servicios.afectablePorITF(socRengscomp.getRenAfectable());

			if (genITF > 0 && socRengscomp.getClaDebehaber() == 'D') {
				sumaITF = sumaITF.add(socRengscomp.getRenMontomo());
				generaITF = true;
				log.info("El comprobantito genera ITF: " + socRengscomp.toString());
			}
		}

		sumaITF = sumaITF.setScale(2, BigDecimal.ROUND_HALF_UP);
		String codComprobanteT = null;
		if (generaITF) {
			SocComprobanteDao comprobanteDao = new SocComprobanteDao();
			comprobanteDao.setSessionFactory(getSessionFactory());

			Date hoy3 = new Date();
			DateTime hoyT = new DateTime(fechaOper);

			String porcITF = Servicios.getParam("@itf");
			String glosa = "COBRO POR RETENCION DE ITF " + porcITF + "% S/USD " + UtilsGeneric.formatearMonto(sumaITF);

			codComprobanteT = Long.toString(hoy3.getTime());
			SocComprobante comprobanteT = new SocComprobante(codComprobanteT, opeCodigo, hoyT.getYear(), hoyT.getMonthOfYear(), hoyT.getDayOfMonth(),
					tcUS, glosa);

			comprobanteDao.saveOrUpdate(comprobanteT);
			log.info("Comprobante guardado: " + comprobanteT.getCpbCodigo());

			log.info("Ahora va el comprobante de la solicitud [" + solicitud.getSocCodigo() + "] ITF por monto de: " + sumaITF);

			List<Map<String, Object>> renglonesITF = Servicios.obtenerEsquema(tipoOperacion, subTipo);

			tcUS = getTipoCambio(34);

			sobreITF = sumaITF;
			BigDecimal porcITFConvert = UtilsGeneric.bigDecimalFromString(porcITF.trim());
			log.info("porcITFConvert " + porcITFConvert);

			BigDecimal porcentajeITF = porcITFConvert.divide(BigDecimal.valueOf(100));

			BigDecimal montoITF = sobreITF.multiply(porcentajeITF).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
			BigDecimal montoMN = montoITF.multiply(tcUS).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

			if (montoMN.compareTo(BigDecimal.valueOf(0.10)) > 0) {
				BigDecimal redITF = montoMN.divide(BigDecimal.valueOf(1), 0, RoundingMode.HALF_UP);
				if (redITF.equals(BigDecimal.ZERO)) {
					redITF = BigDecimal.ONE;
				}
				BigDecimal redondeo = montoMN.subtract(redITF);

				for (Map<String, Object> res : renglonesITF) {
					SocRengscomp renglon = null;
					log.info("Creando renglon para datos esquema " + res.toString());
					reng = (Integer) res.get("det_codigo");

					if (reng == 1) {
						datos = getCuenta(getDefCuenta((String) res.get("cla_cuenta"), solicitud));
						renglon = new SocRengscomp(new SocRengscompId(codComprobanteT, reng), (Integer) datos.get("mon"), 'D', tcUS, montoITF,
								montoMN, (String) datos.get("mayor"), (String) datos.get("afec"));
						this.saveOrUpdate(renglon);
					}
					if (reng == 2) {
						datos = getCuentaP((String) res.get("cla_cuenta"));
						renglon = new SocRengscomp(new SocRengscompId(codComprobanteT, reng), (Integer) datos.get("mon"), 'H', tcBS, redITF, redITF,
								(String) datos.get("mayor"), (String) datos.get("afec"), GlosaRenglon.crearGlosa("ITF", detalle));
						this.saveOrUpdate(renglon);
					}
					if (reng == 3) {
						datos = getCuentaP((String) res.get("cla_cuenta"));
						if (montoMN.compareTo(redITF) > 0) {
							renglon = new SocRengscomp(new SocRengscompId(codComprobanteT, reng), (Integer) datos.get("mon"), 'H', tcBS, redondeo,
									redondeo, (String) datos.get("mayor"), (String) datos.get("afec"));
							this.saveOrUpdate(renglon);
						} else {
							if (montoMN.compareTo(redITF) < 0) {
								renglon = new SocRengscomp(new SocRengscompId(codComprobanteT, reng), (Integer) datos.get("mon"), 'D', tcBS,
										redondeo.abs(), redondeo.abs(), (String) datos.get("mayor"), (String) datos.get("afec"));
								this.saveOrUpdate(renglon);
							}
						}
					}
					if (renglon != null)
						log.info("Renglon creado ITF [" + renglon.getId().getRenCodigo() + "] socCodigo: " + solicitud.getSocCodigo() + " => "
								+ renglon.toString());
				}
			} else {
				creado = false;
			} // if (montoMN.compareTo(BigDecimal.valueOf(0.10)) > 0)
		} // if (generaITF)
		return codComprobanteT;
	}

	private static Integer getDefCuenta(String defCta, String codigo, Integer det) {
		Integer cuenta = 0;

		if (defCta.equalsIgnoreCase("BANC")) {
			cuenta = Integer.valueOf(getBanco(codigo, det));
		}

		return cuenta;
	}

	private static Integer getDefCuenta(String defCta, SocSolicitudes solicitud) {
		Integer cuenta = 0;

		if (defCta.equalsIgnoreCase("SOLI")) {
			cuenta = solicitud.getSocCuentad();
		} else if (defCta.equalsIgnoreCase("SOLC")) {
			cuenta = solicitud.getSocCuentac();
		} else if (defCta.equalsIgnoreCase("PROV")) {
			String valor = Servicios.getParam("@cprov");
			cuenta = Integer.valueOf(valor);
		} else if (defCta.equalsIgnoreCase("PROB")) {
			String valor = Servicios.getParam("@cprovb");
			cuenta = Integer.valueOf(valor);
		} else if (defCta.equalsIgnoreCase("PRSP")) {
			String valor = Servicios.getParam("@cprsp");
			cuenta = Integer.valueOf(valor);
		} else if (defCta.equalsIgnoreCase("PRPB")) {
			String valor = Servicios.getParam("@cprspb");
			cuenta = Integer.valueOf(valor);
		} else if (defCta.equalsIgnoreCase("PROVSISFINSUS")) {
			String valor = Servicios.getParam("@cprsf");
			cuenta = Integer.valueOf(valor);
		} else if (defCta.equalsIgnoreCase("BANQ")) {
			cuenta = getValor("cla_af_banq", getMonedaCoin(solicitud.getMonedaT()));
		} else if (defCta.equalsIgnoreCase("BANL")) {
			cuenta = getBancoL(solicitud.getSocCodigo());
		} else if (defCta.equalsIgnoreCase("BALC")) {
			cuenta = getBancoLC(solicitud.getSocCodigo());
		} else if (defCta.equalsIgnoreCase("ORPA")) {
			String valor = Servicios.getParam("@op");
			cuenta = Integer.valueOf(valor);
		} else if (defCta.equalsIgnoreCase("BOLS")) {
			String valor = Servicios.getParam("@bolsin");
			cuenta = Integer.valueOf(valor);
		}
		return cuenta;
	}

	private Integer getDefCuenta(String defCta, SocOperaciones operacion) {
		Integer cuenta = 0;

		if (defCta.equalsIgnoreCase("SOLI")) {
			cuenta = operacion.getOpeCtaoperacion();
		} else if (defCta.equalsIgnoreCase("SOLC")) {
			cuenta = operacion.getOpeCtacomision();
		} else if (defCta.equalsIgnoreCase("BANQ")) {
			cuenta = getValor("cla_af_banq", operacion.getMoneda());
		} else if (defCta.equalsIgnoreCase("BAEX")) {
			cuenta = getBancoE(operacion.getOpeCodigo());
		} else if (defCta.equalsIgnoreCase("BEXC")) {
			cuenta = getBancoEC(operacion.getOpeCodigo());
		} else if (defCta.equalsIgnoreCase("ACSP")) {
			cuenta = getCuentaSP(operacion.getOpeCodigo());
		}

		return cuenta;
	}

	private BigDecimal getDefMonto(Integer mon, String defMonto, SocSolicitudes solicitud) {
		log.info("XXX: getDefMontogetDefMontogetDefMonto " + mon + ", defMonto:" + defMonto + ", solicitud: " + solicitud);
		BigDecimal monto = BigDecimal.valueOf(0.00);
		int monUS = 34;
		int monCoin = 0;
		if (defMonto.equalsIgnoreCase("montoME")) {
			monCoin = getMonedaCoin(solicitud.getMoneda());
			if (solicitud.getClaTipo().equalsIgnoreCase("TC") || solicitud.getClaTipo().equalsIgnoreCase("TCID")
					|| solicitud.getClaTipo().equalsIgnoreCase("TCRG"))
				monto = solicitud.getSocMontome();
			else {
				log.info("XXX: monCoin == monUS " + monCoin + " " + monUS + " " + (monCoin == monUS));
				if (monCoin == monUS)
					monto = solicitud.getSocMontome();
				else
					monto = solicitud.getSocMontome().multiply(getTipoCambio(monCoin)).divide(tcUS, 2, RoundingMode.HALF_UP);
			}
		} else if (defMonto.equalsIgnoreCase("montoMEB")) {
			monto = solicitud.getSocMontome();
		} else if (defMonto.equalsIgnoreCase("montoD")) {
			monto = solicitud.getSocMontome();
		} else if (defMonto.equalsIgnoreCase("montoMEO")) {
			monCoin = getMonedaCoin(solicitud.getMonedaT());
			if (monCoin == monUS)
				monto = solicitud.getSocMontome();
			else
				// monto =
				// solicitud.getSocMontome().multiply(getTipoCambio(monUS)).divide(getTipoCambio(monCoin),
				// 2, RoundingMode.HALF_UP);
				monto = getMontoOp(solicitud.getSocCodigo());
		} else if (defMonto.equalsIgnoreCase("montoMN")) {
			// el nuevo calculo es que primero se debita el monto a vender y
			// despues se hace las operaciones de transaferecia
			monto = solicitud.getSocMontomn();
		} else if (defMonto.equalsIgnoreCase("montoMNL")) {
			monto = solicitud.getSocMontome().multiply(tcUS);
		} else if (defMonto.equalsIgnoreCase("montoOrd")) {
			monto = solicitud.getSocMontoord();
		} else if (defMonto.equalsIgnoreCase("montoComi")) {
			String tipoO = solicitud.getClaTipo();

			if (!tipoO.equalsIgnoreCase("VE")) {
				SocSolicitante socSolicitante = Servicios.getSocSolicitante(solicitud.getSolCodigo());
				if (socSolicitante == null) {
					throw new RuntimeException("Solicitante " + solicitud.getSolCodigo() + " inexistente en soc_solicitante");
				}
				if (socSolicitante.getClaEntidad() != null && socSolicitante.getClaEntidad().trim().equalsIgnoreCase("SF"))
					tipoO = tipoO + "F";

				monCoin = getMonedaCoin(solicitud.getMoneda());
				if (monCoin == monUS) {
					if (!tipoO.equalsIgnoreCase("TDF"))
						monto = Servicios.getComisiones(solicitud.getSocMontome(), tipoO, 1);
					else
						monto = getTotComi(solicitud.getSocCodigo());
				} else
					monto = Servicios.getComisiones(solicitud.getSocMontome().multiply(getTipoCambio(monCoin)).divide(tcUS, 2, RoundingMode.HALF_UP),
							tipoO, 1);
			} else {
				if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0.00)) == 0)
					monto = getTotComi(solicitud.getSocCodigo());
				else
					monto = solicitud.getSocMontomn().subtract(solicitud.getSocMontome().multiply(getTipoCambio(35)));
			}

			if (mon == monUS)
				monto = monto.divide(tcUS, 2, RoundingMode.HALF_UP);
		} else if (defMonto.equalsIgnoreCase("montoComiP")) {
			BigDecimal nro = BigDecimal.valueOf(0);
			int nn = 0;

			String query = "select count(det_codigo) as nro " + "from soc_detallessol " + "where soc_codigo = '" + solicitud.getSocCodigo() + "' ";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "nro".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					// log.info("resultado" + res.toString());
					nro = (BigDecimal) res.get("nro");
				}
				nn = nro.intValue();
			}

			monCoin = getMonedaCoin(solicitud.getMoneda());
			if (monCoin == monUS)
				monto = Servicios.getComisiones(solicitud.getSocMontome(), "TE", nn);
			else
				monto = Servicios.getComisiones(solicitud.getSocMontome().multiply(getTipoCambio(monCoin)).divide(tcUS, 2, RoundingMode.HALF_UP),
						"TE", nn);

			if (mon == monUS)
				monto = monto.divide(tcUS, 2, RoundingMode.HALF_UP);
		} else if (defMonto.equalsIgnoreCase("montoComiTC")) {
			monCoin = getMonedaCoin(solicitud.getMoneda());
			if (monCoin == monUS)
				monto = Servicios.getComisiones(solicitud.getSocMontome(), "TC", 1);
			else
				monto = Servicios.getComisiones(solicitud.getSocMontome().multiply(getTipoCambio(monCoin)).divide(tcUS, 2, RoundingMode.HALF_UP),
						"TC", 1);

			if (mon == monUS)
				monto = monto.divide(tcUS, 2, RoundingMode.HALF_UP);
		} else if (defMonto.equalsIgnoreCase("montoME + montoComi")) {
			monto = getDefMonto(mon, "montoME", solicitud).add(getDefMonto(mon, "montoComi", solicitud));
		} else if (defMonto.equalsIgnoreCase("montoMN + montoComi")) {
			monto = getDefMonto(mon, "montoMN", solicitud).add(getDefMonto(mon, "montoComi", solicitud));
		} else if (defMonto.equalsIgnoreCase("montoMN + montoComiP")) {
			monto = getDefMonto(mon, "montoMN", solicitud).add(getDefMonto(mon, "montoComiP", solicitud));
		} else if (defMonto.equalsIgnoreCase("montoMN + montoComiTC")) {
			monto = getDefMonto(mon, "montoMN", solicitud).add(getDefMonto(mon, "montoComiTC", solicitud));
		} else if (defMonto.equalsIgnoreCase("montoComi1")) {
			monto = getMonto1(solicitud.getSocCodigo(), 5);
		} else if (defMonto.equalsIgnoreCase("montoComi2")) {
			monto = getMonto1(solicitud.getSocCodigo(), 3);
		} else if (defMonto.equalsIgnoreCase("CTRA")) {
			monto = getMonto(solicitud.getSocCodigo(), 1);
		} else if (defMonto.equalsIgnoreCase("SWFT")) {
			monto = getMonto(solicitud.getSocCodigo(), 2);
		} else if (defMonto.equalsIgnoreCase("UTIL")) {
			monto = getMonto(solicitud.getSocCodigo(), 3);
		} else if (defMonto.equalsIgnoreCase("CVTA")) {
			monto = getMonto(solicitud.getSocCodigo(), 4);
		} else if (defMonto.equalsIgnoreCase("CDEX")) {
			monto = getMonto(solicitud.getSocCodigo(), 5);
		} else if (defMonto.equalsIgnoreCase("CDOP")) {
			monto = getMonto(solicitud.getSocCodigo(), 7);
		} else if (defMonto.equalsIgnoreCase("IVA")) {
			monto = getMonto(solicitud.getSocCodigo());
		} else if (defMonto.equalsIgnoreCase("DCMB")) {
			if (solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0.00)) == 0) {
				if (mon == monUS) {
					monto = solicitud.getSocMontomn().subtract(solicitud.getSocMontome().multiply(getTipoCambio(35)));
				} else {
					monCoin = getMonedaCoin(solicitud.getMoneda());
					/*
					 * monto = solicitud.getSocMontomn().subtract(
					 * ((solicitud.getSocMontome
					 * ().multiply(getTipoCambio(monCoin
					 * ))).multiply(getTipoCambio
					 * (35))).divide(getTipoCambio(monUS), 2,
					 * RoundingMode.HALF_UP));
					 */
					monto = solicitud.getSocMontomn().subtract(
							((solicitud.getSocMontome().multiply(getTipoCambio(monCoin)).divide(BigDecimal.ONE, 2, RoundingMode.HALF_UP)).divide(
									getTipoCambio(monUS), 2, RoundingMode.HALF_UP)).multiply(getTipoCambio(35)).divide(BigDecimal.ONE, 2,
									RoundingMode.HALF_UP));
				}
			} else {
				if (mon == monUS) {
					monto = solicitud.getSocMontomn().subtract(solicitud.getSocMontoord().multiply(getTipoCambio(35)));
				} else {
					monCoin = getMonedaCoin(solicitud.getMoneda());
					/*
					 * monto = solicitud.getSocMontomn().subtract(
					 * ((solicitud.getSocMontoord
					 * ().multiply(getTipoCambio(monCoin
					 * ))).multiply(getTipoCambio
					 * (35))).divide(getTipoCambio(monUS), 2,
					 * RoundingMode.HALF_UP));
					 */
					monto = solicitud.getSocMontomn().subtract(
							((solicitud.getSocMontoord().multiply(getTipoCambio(monCoin)).divide(BigDecimal.ONE, 2, RoundingMode.HALF_UP)).divide(
									getTipoCambio(monUS), 2, RoundingMode.HALF_UP)).multiply(getTipoCambio(35)).divide(BigDecimal.ONE, 2,
									RoundingMode.HALF_UP));
				}
			}
		}
		if (monto == null || monto.compareTo(BigDecimal.ZERO) <= 0)
			log.warn("Atenciï¿½n: monto ordenado en solicitud CERO " + mon + ", defMonto:" + defMonto + ", solicitud: " + solicitud);
		return monto;
	}

	private BigDecimal getDefMonto(Integer mon, String defMonto, SocOperaciones operacion) {
		BigDecimal monto = BigDecimal.valueOf(0.00);
		int monUS = 34;
		int monCoin = 0;

		if (defMonto.equalsIgnoreCase("montoME")) {
			monCoin = operacion.getMoneda();
			if (monCoin == monUS)
				monto = operacion.getOpeMontome();
			else
				monto = operacion.getOpeMontome().multiply(getTipoCambio(monCoin)).divide(tcUS, 2, RoundingMode.HALF_UP);
		} else if (defMonto.equalsIgnoreCase("montoComi")) {
			monto = getTotComiO(operacion.getOpeCodigo());
			if (mon == monUS)
				monto = monto.divide(tcUS, 2, RoundingMode.HALF_UP);
		} else if (defMonto.equalsIgnoreCase("montoComi1")) {
			// monto = getMontoO1(operacion.getOpeCodigo(), 5);
			BigDecimal porc = BigDecimal.valueOf(Double.valueOf(Servicios.getComision("CDEX"))).divide(BigDecimal.valueOf(100));
			BigDecimal montoComi1 = operacion.getOpeMontome().multiply(porc);
			// log.info("XXX: $$$$$$$$$$$##$$$ getMontoO1 " + montoComi1);
			// log.info("XXX: $$$$$$$$$$$##$$$ getMontoO1 " + tcUS);
			// montoComi1 = montoComi1.multiply(tcUS);
			// log.info("XXX: $$$$$$$$$$$$$$ getMontoO1 " + montoComi1);
			// monto =
			// montoComi1.subtract((montoComi1.multiply(BigDecimal.valueOf(13))).divide(BigDecimal.valueOf(100),
			// 2, RoundingMode.HALF_UP));
			// log.info("XXX: $$$$$$$$$$$$$$ getMontoO1 " + monto);
			monto = montoComi1;

		} else if (defMonto.equalsIgnoreCase("montoComi2")) {
			monto = getMontoO1(operacion.getOpeCodigo(), 3);
		} else if (defMonto.equalsIgnoreCase("UTIL")) {
			monto = getMontoO(operacion.getOpeCodigo(), 3);
		} else if (defMonto.equalsIgnoreCase("SWFT")) {
			monto = getMontoO(operacion.getOpeCodigo(), 2);
		} else if (defMonto.equalsIgnoreCase("CDEX")) {
			monto = getMontoO(operacion.getOpeCodigo(), 5);
		} else if (defMonto.equalsIgnoreCase("CDOP")) {
			monto = getMontoO(operacion.getOpeCodigo(), 7);
		} else if (defMonto.equalsIgnoreCase("IVA")) {
			monto = getMontoIVA(operacion.getOpeCodigo());
		}

		return monto;
	}

	private static BigDecimal getTotComi(String cod) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select sum(c.oco_monto) as monto " + "from soc_opecomi c, soc_operaciones o " + "where c.ope_codigo = o.ope_codigo "
				+ "and o.soc_codigo = '" + cod + "' " + "and c.det_codigo = 1 " + "and c.cla_comision <> '4' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "monto".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				monto = (BigDecimal) res.get("monto");
			}
		}

		return monto;
	}

	private static BigDecimal getTotComiO(String codigo) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select sum(oco_monto) as monto " + "from soc_opecomi " + "where ope_codigo = '" + codigo + "' " + "and det_codigo = 1 ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "monto".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				monto = (BigDecimal) res.get("monto");
			}
		}

		return monto;
	}

	private static BigDecimal getMontoOp(String cod) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select o.ope_montome " + "from soc_operaciones o " + "where o.soc_codigo = '" + cod + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ope_montome".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				monto = (BigDecimal) res.get("ope_montome");
			}
		}

		return monto;
	}

	private static BigDecimal getMontoMN(String cod) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select o.ope_montomn " + "from soc_operaciones o " + "where o.soc_codigo = '" + cod + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ope_montomn".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				monto = (BigDecimal) res.get("ope_montomn");
			}
		}

		return monto;
	}

	private static BigDecimal getMonto(String cod, Integer comi) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select c.oco_monto " + "from soc_opecomi c, soc_operaciones o " + "where c.ope_codigo = o.ope_codigo "
				+ "and o.soc_codigo = '" + cod + "' " + "and c.det_codigo = 1 " + "and c.cla_comision = '" + comi + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "oco_monto".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				monto = (BigDecimal) res.get("oco_monto");
				if (comi != 4) {
					monto = monto.subtract((monto.multiply(BigDecimal.valueOf(13))).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
				}
			}
		}

		return monto;
	}

	private static BigDecimal getMonto1(String cod, Integer comi) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select c.oco_monto " + "from soc_opecomi c, soc_operaciones o " + "where c.ope_codigo = o.ope_codigo "
				+ "and o.soc_codigo = '" + cod + "' " + "and c.det_codigo = 1 " + "and c.cla_comision = '" + comi + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "oco_monto".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				monto = (BigDecimal) res.get("oco_monto");
				if (comi == 5) {
					BigDecimal tcCompra = getTipoCambio(34);
					monto = monto.divide(tcCompra, 2, RoundingMode.HALF_UP);
				}
			}
		}

		return monto;
	}

	private static BigDecimal getMontoO(String codigo, Integer comi) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select oco_monto " + "from soc_opecomi " + "where ope_codigo = '" + codigo + "' " + "and det_codigo = 1 "
				+ "and cla_comision = '" + comi + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "oco_monto".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.info("XXX: resultado " + res.toString());
				monto = (BigDecimal) res.get("oco_monto");
				monto = monto.subtract((monto.multiply(BigDecimal.valueOf(13))).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
			}
		}

		return monto;
	}

	private static BigDecimal getMontoO1(String codigo, Integer comi) {
		BigDecimal monto = BigDecimal.valueOf(0.00);

		String query = "select oco_monto " + "from soc_opecomi " + "where ope_codigo = '" + codigo + "' " + "and det_codigo = 1 "
				+ "and cla_comision = '" + comi + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "oco_monto".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.info("resultado" + res.toString());
				monto = (BigDecimal) res.get("oco_monto");
			}
		}

		return monto;
	}

	private static BigDecimal getMonto(String cod) {
		BigDecimal monto = BigDecimal.valueOf(0.00);
		BigDecimal monto1 = BigDecimal.valueOf(0.00);

		String query = "select c.oco_monto as monto " + "from soc_opecomi c, soc_operaciones o " + "where c.ope_codigo = o.ope_codigo "
				+ "and o.soc_codigo = '" + cod + "' " + "and c.det_codigo = 1 " + "and c.cla_comision <> '4' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "monto".split(","));
		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				monto1 = (BigDecimal) res.get("monto");
				monto1 = (monto1.multiply(BigDecimal.valueOf(13))).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
				monto = monto.add(monto1);
			}
		}

		return monto;
	}

	private static BigDecimal getMontoIVA(String codigo) {
		BigDecimal monto = BigDecimal.valueOf(0.00);
		BigDecimal monto1 = BigDecimal.valueOf(0.00);
		String query = "select oco_monto as monto " + "from soc_opecomi " + "where ope_codigo = '" + codigo + "' " + "and det_codigo = 1 "
				+ "and cla_comision <> '4' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "monto".split(","));

		for (Map<String, Object> res : resultado) {
			monto1 = (BigDecimal) res.get("monto");
			monto1 = monto1.multiply(BigDecimal.valueOf(13).divide(BigDecimal.valueOf(100)));
			monto1 = monto1.setScale(2, BigDecimal.ROUND_HALF_UP);
			monto = monto.add(monto1);
		}
		return monto;
	}

	private static Integer getBancoL(String codigo) {
		Integer cuenta = 0;

		String query = " select c.cta_ctacodigo, c.moneda " + " from soc_cuentasloc c, soc_detallessol d " + " where d.soc_codigo = '" + codigo + "'"
				+ " and det_codigo = 1" + " and d.det_ctabenef = c.cta_codigo";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_ctacodigo, c.moneda".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				cuenta = (Integer) res.get("cta_ctacodigo");
			}
		}

		return cuenta;
	}

	private static Integer getBancoLC(String codigo) {
		Integer cuenta = 0;

		String query = " select c.cta_ctacodigo, c.cta_ctacodigo1" + " from soc_cuentasloc c, soc_detallessol d " + " where d.soc_codigo = '"
				+ codigo + "'" + " and det_codigo = 1" + " and d.det_ctabenef = c.cta_codigo";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_ctacodigo, cta_ctacodigo1".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				cuenta = (Integer) res.get("cta_ctacodigo1");
				if (cuenta == null)
					cuenta = (Integer) res.get("cta_ctacodigo");
			}
		}

		return cuenta;
	}

	private static String getBanco(String codigo, Integer det) {
		String cta = "";
		Integer cuenta = 0;

		String query = " select c.cta_ctacodigo" + " from soc_cuentasloc c, soc_detallessol d " + " where d.soc_codigo = '" + codigo + "'"
				+ " and det_codigo = " + det + " and d.det_ctabenef = c.cta_codigo";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_ctacodigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				cuenta = (Integer) res.get("cta_ctacodigo");
			}
		}

		cta = cuenta.toString();
		return cta;
	}

	public Integer getBancoE(String codigo) {
		QueryProcessor.flush();
		Integer cuenta = 0;

		String query = " select s.cta_codigo" + " from soc_cuentasexp e, soc_solcuentas s, soc_cuentassol c, soc_detallesope o"
				+ " where e.bco_codigo = s.sol_codigo" + " and s.cta_codigo = c.cta_codigo" + " and e.moneda = c.moneda"
				+ " and e.cta_codigo = o.det_ctabenef" + " and o.ope_codigo = '" + codigo + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				cuenta = (Integer) res.get("cta_codigo");
			}
		}

		return cuenta;
	}

	private Integer getBancoEC(String codigo) {
		Integer cuenta = 0;

		String query = " select s.cta_codigo" + " from soc_cuentasexp e, soc_solcuentas s, soc_cuentassol c, soc_detallesope o"
				+ " where e.bco_codigo1 = s.sol_codigo" + " and s.cta_codigo = c.cta_codigo" + " and e.moneda1 = c.moneda"
				+ " and e.cta_codigo = o.det_ctabenef" + " and o.ope_codigo = '" + codigo + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				cuenta = (Integer) res.get("cta_codigo");
			}
		} else {
			log.info("No se encontro valor getBancoEC " + codigo);
			cuenta = getBancoE(codigo);
		}

		return cuenta;
	}

	public static Integer getCuentaSP(String codigo) {
		Integer cuenta = 0;

		String query = " select c.cta_codigo" + " from soc_cuentasexp e, soc_cuentassol c, soc_detallesope o"
				+ " where e.cta_nrocuenta = c.cta_movimiento" + " and e.cta_codigo = o.det_ctabenef" + " and o.ope_codigo = '" + codigo + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				cuenta = (Integer) res.get("cta_codigo");
			}
		}

		return cuenta;
	}

	public Map<String, Object> getCuenta(Integer cta) {
		Map<String, Object> datos = new HashMap<String, Object>();
		String movi = "";
		String afec = "";
		Integer mon = 0;

		String query = "SELECT cta_movimiento, cta_afectable, moneda " + "FROM soc_cuentassol WHERE cta_codigo = " + cta;

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cta_movimiento, cta_afectable, moneda".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				movi = (String) res.get("cta_movimiento");
				afec = (String) res.get("cta_afectable");
				mon = (Integer) res.get("moneda");
			}
		}

		Map<String, Object> mapaParametros3 = new HashMap<String, Object>();
		mapaParametros3.put("consulta", "mayor");
		mapaParametros3.put("movi", movi);

		String mayor = "";

		// Metodo estatico que se encarga de manejar las consultas al servicio
		log.info("Llamando al servicio de coin: mayor");

		SiocCoinService siocCoinService = new SiocCoinService();
		Map<String, Object> mapaResultado3 = siocCoinService.executeTask(mapaParametros3);
		mayor = (String) mapaResultado3.get("mayor");

		datos.put("mayor", mayor);
		datos.put("afec", afec);
		datos.put("mon", mon);

		return datos;
	}

	private static Map<String, Object> getCuentaP(String ctaD) {
		Map<String, Object> datos = new HashMap<String, Object>();
		String mayor = "";
		String afec = "";
		Integer mon = 69;

		if (ctaD.equalsIgnoreCase("@uti")) {
			mayor = "000135";
			afec = "001712";
		} else if (ctaD.equalsIgnoreCase("@swf")) {
			mayor = "000135";
			afec = "001708";
		} else if (ctaD.equalsIgnoreCase("@tra")) {
			mayor = "000149";
			afec = "001761";
		} else if (ctaD.equalsIgnoreCase("@vta")) {
			mayor = Servicios.getParam("@mventaBolsin");
			afec = Servicios.getParam("@cventa");
		} else if (ctaD.equalsIgnoreCase("@iva")) {
			mayor = "000117";
			afec = "001564";
		} else if (ctaD.equalsIgnoreCase("@aju")) {
			mayor = "000065";
			afec = "000516";
		} else if (ctaD.equalsIgnoreCase("@rtf")) {
			mayor = "000117";
			// afec = "012597";
			afec = Servicios.getParam("@citf");
		} else if (ctaD.equalsIgnoreCase("@dtf")) {
			mayor = "000065";
			afec = "011578";
		} else if (ctaD.equalsIgnoreCase("@op")) {
			mayor = "000117";
			afec = "006618";
			mon = 34;
		} else if (ctaD.equalsIgnoreCase("@dex")) {
			mayor = "000149";
			afec = "007795";
		} else if (ctaD.equalsIgnoreCase("@dop")) {
			mayor = "000149";
			afec = "010159";
		} else if (ctaD.equalsIgnoreCase("@acr")) {
			mayor = "000129";
			afec = "001665";
			mon = 34;
		} else if (ctaD.equalsIgnoreCase("@bch")) {
			mayor = "000004";
			afec = "000025";
			mon = 34;
		} else if (ctaD.equalsIgnoreCase("@fv")) {
			mayor = "000004";
			afec = "011058";
			mon = 34;
		} else if (ctaD.equalsIgnoreCase("@otr")) {
			mayor = "000149";
			afec = "010159";
		}

		datos.put("mayor", mayor);
		datos.put("afec", afec);
		datos.put("mon", mon);

		return datos;
	}

	private static Integer getValor(String clave, int cod) {
		Integer cta = 0;
		String ctaS = "";

		String query = "SELECT val_nombre " + "FROM soc_valorescla WHERE cla_codigo = '" + clave + "' " + "AND val_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				ctaS = (String) res.get("val_nombre");
				cta = Integer.valueOf(ctaS);
			}
		}

		return cta;
	}

	private static BigDecimal getTipoCambio(int mon) {
		if (mon <= 0) {
			// este error se genera ya que se probï¿½ que en algunos procesos se
			// enviaba un cï¿½digo de 0 para obtener tipo de cambio
			// si se reporta este error se debe realizar un seguimiento al error
			// y corregirlo
			throw new RuntimeException("Error al obtener tipo de cambio codigo de moneda invalida, comunique a sistemas");
		}
		return QueryProcessor.getTipoCambio(mon, new Date());
	}

	private static int getMonedaCoin(String mon) {
		int monC = 0;

		String query = " select val_codigo" + " from soc_valorescla " + " where cla_codigo = 'cla_moneda' " + " and val_nombre = '" + mon + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				String codMon = (res.get("val_codigo")).toString();
				codMon = codMon.trim();

				monC = Integer.valueOf(codMon);
			}
		}

		return monC;
	}

	private void crearAjuste(List<SocRengscomp> renglones, String idC, List<Map<String, Object>> rengs) {
		log.info("Entrando a crear Ajuste comprobante [" + idC + "]");
		BigDecimal debe = BigDecimal.valueOf(0);
		BigDecimal haber = BigDecimal.valueOf(0);
		Integer esqCodigo = 0;
		for (Map<String, Object> res : rengs) {
			esqCodigo = (Integer) res.get("esq_codigo");
			break;
		}

		for (SocRengscomp reng : renglones) {
			log.info(esqCodigo + ":: {" + reng.getId().getRenCodigo() + "} :[" + reng.getClaDebehaber() + "] MO:(" + reng.getMoneda() + ", "
					+ reng.getRenTipocambio() + ") \t\t\t" + reng.getRenMontomo() + " \t\t:" + reng.getRenMontomn() + " \t\t["
					+ reng.getCtaMovimiento() + "]");
			if (reng.getClaDebehaber() == 'D') {
				debe = debe.add(reng.getRenMontomn());
			} else {
				haber = haber.add(reng.getRenMontomn());
			}
		}

		BigDecimal diff = debe.subtract(haber).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		log.info("Crear Ajuste comprobante [" + idC + "] DEBE: " + debe.toPlainString() + ", HABER: " + haber.toPlainString() + " Diferencia: "
				+ diff.toPlainString());

		if (diff.compareTo(BigDecimal.valueOf(0.00)) != 0) {
			if (diff.abs().compareTo(BigDecimal.valueOf(0.04)) < 1) {
				SocRengscompId id = new SocRengscompId(idC, renglones.size() + 1);
				SocRengscomp renglon;
				Map<String, Object> datos;
				datos = getCuentaP("@aju");
				if (diff.compareTo(BigDecimal.valueOf(0)) > 0) {
					renglon = new SocRengscomp(id, (Integer) datos.get("mon"), 'H', BigDecimal.valueOf(1), diff, diff, (String) datos.get("mayor"),
							(String) datos.get("afec"));
				} else {
					renglon = new SocRengscomp(id, (Integer) datos.get("mon"), 'D', BigDecimal.valueOf(1), diff.abs(), diff.abs(),
							(String) datos.get("mayor"), (String) datos.get("afec"));
				}
				saveOrUpdate(renglon);
				log.info("Renglon creado [" + id.getRenCodigo() + "] Comprob: " + idC + " => " + renglon.toString());
			} else {
				if (diff.abs().compareTo(BigDecimal.valueOf(0.08)) < 1) {
					BigDecimal diff1 = diff.abs().subtract(BigDecimal.valueOf(0.04));
					for (SocRengscomp reng : renglones) {
						if (reng.getRenAfectable().equalsIgnoreCase("001761")) {
							SocRengscompId id = new SocRengscompId(idC, renglones.size() + 1);
							SocRengscomp renglon;
							Map<String, Object> datos;
							datos = getCuentaP("@aju");
							if (diff.compareTo(BigDecimal.valueOf(0)) > 0) {
								// si es positivo la diferencia
								reng.setRenMontomo(reng.getRenMontomn().add(diff1));
								reng.setRenMontomn(reng.getRenMontomo());
								renglon = new SocRengscomp(id, (Integer) datos.get("mon"), 'H', BigDecimal.valueOf(1), BigDecimal.valueOf(0.04),
										BigDecimal.valueOf(0.04), (String) datos.get("mayor"), (String) datos.get("afec"));
							} else {
								// si es negativo la diferencia
								reng.setRenMontomo(reng.getRenMontomn().subtract(diff1));
								reng.setRenMontomn(reng.getRenMontomo());
								renglon = new SocRengscomp(id, (Integer) datos.get("mon"), 'D', BigDecimal.valueOf(1), BigDecimal.valueOf(0.04),
										BigDecimal.valueOf(0.04), (String) datos.get("mayor"), (String) datos.get("afec"));
							}
							saveOrUpdate(reng);
							saveOrUpdate(renglon);
							log.info("Renglon Ajuste creado [" + id.getRenCodigo() + "] Comprob: " + idC + " => " + renglon.toString());
							QueryProcessor.flush();
						}
					}
				} else {
					log.info("Diferencia " + diff + " mayor al ajuste permitido ");
					throw new RuntimeException("Diferencia " + diff + " mayor al ajuste permitido ");
				}
			}
		}
		QueryProcessor.flush();
		// nuevamente se comprueba si no existe diferencias
		renglones = getRenglones(idC);
		debe = BigDecimal.valueOf(0);
		haber = BigDecimal.valueOf(0);

		for (SocRengscomp reng : renglones) {
			if (reng.getClaDebehaber() == 'D') {
				debe = debe.add(reng.getRenMontomn());
			} else {
				haber = haber.add(reng.getRenMontomn());
			}
		}
		diff = debe.subtract(haber).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
		if (diff.compareTo(BigDecimal.valueOf(0.00)) != 0) {
			log.info("Diferencia " + diff + " mayor al ajuste permitido ");
			throw new RuntimeException("Error en comprobante Diferencia " + diff + " entre el DEBE[" + debe.toPlainString() + "] y HABER ["
					+ haber.toPlainString() + "]");
		}
	}

	public void controlTransferenciasRetiro(Solicitud solicitud, String ctaMovimiento) {

		StringBuffer query = new StringBuffer();
		query = query.append("select ope_codigo, cta_movimiento, moneda, sum(suma) suma ");
		query = query.append("from ( ");
		query = query.append("select c.ope_codigo, r.cta_movimiento, r.moneda, SUM( r.ren_montomo *( - 1 )  ) suma ");
		query = query.append("from soc_comprobante c, soc_rengscomp r ");
		query = query.append("where c.cpb_codigo = r.cpb_codigo ");
		query = query.append("and c.ope_codigo = :opeCodigo ");
		query = query.append("and c.cve_dettipocomp in ('R','P') ");
		query = query.append("AND r.cla_debehaber = 'D' ");
		query = query.append("and c.cve_estadocpb != 'Z' ");

		if (!StringUtils.isBlank(ctaMovimiento)) {
			query = query.append("and r.cta_movimiento = :ctaMovimiento ");
		}

		query = query.append("group by c.ope_codigo, r.cta_movimiento, r.moneda ");

		query = query.append("union  ");

		query = query.append("select c.ope_codigo, r.cta_movimiento, r.moneda, SUM( r.ren_montomo) suma ");
		query = query.append("from soc_comprobante c, soc_rengscomp r ");
		query = query.append("where c.cpb_codigo = r.cpb_codigo ");
		query = query.append("and c.ope_codigo = :opeCodigo ");
		query = query.append("and c.cve_dettipocomp in ('R','P') ");
		query = query.append("AND r.cla_debehaber = 'H' ");
		query = query.append("and c.cve_estadocpb != 'Z' ");

		if (!StringUtils.isBlank(ctaMovimiento)) {
			query = query.append("and r.cta_movimiento = :ctaMovimiento ");
		}

		query = query.append("group by c.ope_codigo, r.cta_movimiento, r.moneda ");
		query = query.append(") t ");

		query = query.append("where exists (select 1 from soc_comprobante c0, soc_rengscomp r0  ");
		query = query.append("where c0.cpb_codigo = r0.cpb_codigo  ");
		query = query.append("and c0.ope_codigo = t.ope_codigo  ");
		query = query.append("and r0.cla_debehaber = 'H'  ");
		query = query.append("AND r0.cta_movimiento = t.cta_movimiento) ");
		query = query.append("and exists (select 1 from soc_comprobante c0, soc_rengscomp r0  ");
		query = query.append("where c0.cpb_codigo = r0.cpb_codigo  ");
		query = query.append("and c0.ope_codigo = t.ope_codigo  ");
		query = query.append("and r0.cla_debehaber = 'D'  ");
		query = query.append("AND r0.cta_movimiento = t.cta_movimiento) ");

		query = query.append("group by ope_codigo, cta_movimiento, moneda ");

		log.info("Renglones controlTransferenciasRetiro [opeCodigo= " + solicitud.getSolicitud().getSocCodigo() + "] " + query.toString());

		Query consulta = getSession().createSQLQuery(query.toString());

		consulta.setParameter("opeCodigo", solicitud.getSolicitud().getSocCodigo());

		if (!StringUtils.isBlank(ctaMovimiento)) {
			consulta.setParameter("ctaMovimiento", ctaMovimiento);
		}

		List lista = consulta.list();
		List<Map<String, Object>> resultado = UtilsQNatives.convertListToMap(lista, "ope_codigo,cta_movimiento, moneda, suma".split(","));

		for (Map<String, Object> res : resultado) {
			String cta = (String) res.get("cta_movimiento");
			Integer moneda = (Integer) res.get("moneda");
			BigDecimal montoSuma = (BigDecimal) res.get("suma");

			String neteoCta = "NETEO-" + cta + "-" + moneda;

			if (montoSuma.abs().compareTo(BigDecimal.valueOf(0.04)) > 0) {
				log.error("ERROR de NETEO: solicitud con diferencia [" + montoSuma + "] entre transferencias y monto a retirar [" + neteoCta
						+ "]no puede pre autorizar " + solicitud.getSolicitud().getSocCodigo());
				throw new BusinessException("NETEO: solicitud con diferencia [" + montoSuma + "] entre transferencias y monto a retirar [" + neteoCta
						+ "]no puede pre autorizar " + solicitud.getSolicitud().getSocCodigo());
			}

		}
	}

	public void controlCtasTransitorias(Solicitud solicitud) {
//		
//		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
//		socEsquemasDao.setSessionFactory(getSessionFactory());
//
//		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());
//
//		if (socEsquemas.getTipoTransfer().equals(Constants.CLAVE_TIPOTRANSFER_CONPROV)) {
//			// la operacion es con provision a la 4088 gralmente en opers de tgn goi
//			controlTransferenciasRetiro(solicitud, Constants.CTA_TRANSIT_PROV);
//		}
//
//		controlTransferenciasRetiro(solicitud, Constants.CTA_TRANSIT_SECPUBGOI);
	}

	public ComprobanteDet sumasDebeHaber(SocComprobante socComprobante, SocEsquemas socEsquemas) {
		String query = "";
		query = query.concat("select sumdebe, sumhaber, (sumdebe - sumhaber) diferencia ");
		query = query.concat("from ( ");
		query = query.concat("(select  ");
		query = query.concat("(SELECT SUM( r.ren_montomn)  ");
		query = query.concat("FROM soc_comprobante c, soc_rengscomp r ");
		query = query.concat("WHERE c.cpb_codigo = r.cpb_codigo ");
		query = query.concat("AND c.cpb_codigo = co.cpb_codigo ");
		query = query.concat("AND r.cla_debehaber = 'D') sumdebe, ");
		query = query.concat("(SELECT SUM( r.ren_montomn)  ");
		query = query.concat("FROM soc_comprobante c, soc_rengscomp r ");
		query = query.concat("WHERE c.cpb_codigo = r.cpb_codigo ");
		query = query.concat("AND c.cpb_codigo = co.cpb_codigo ");
		query = query.concat("AND r.cla_debehaber = 'H') sumhaber ");
		query = query.concat("FROM soc_comprobante co ");
		query = query.concat("where co.cpb_codigo = :cpbCodigo)) ");

		Query consulta = getSession().createSQLQuery(query);

		consulta.setParameter("cpbCodigo", socComprobante.getCpbCodigo());

		List lista = consulta.list();
		List<Map<String, Object>> resultado = UtilsQNatives.convertListToMap(lista, "sumdebe,sumhaber,diferencia".split(","));

		ComprobanteDet comprobante = new ComprobanteDet();
		comprobante.setCpbCodigo(socComprobante.getCpbCodigo());		
		comprobante.setDebe(BigDecimal.ZERO);
		comprobante.setHaber(BigDecimal.ZERO);
		comprobante.setRenMontomn(BigDecimal.ZERO);
		
		for (Map<String, Object> res : resultado) {
			BigDecimal sumdebe = (BigDecimal) res.get("sumdebe");
			BigDecimal sumhaber = (BigDecimal) res.get("sumhaber");
			BigDecimal diferencia = (BigDecimal) res.get("diferencia");

			comprobante.setDebe(sumdebe);
			comprobante.setHaber(sumhaber);			
			comprobante.setRenMontomn(diferencia);
		}
		return comprobante;
	}

	public void controlDebeHaber(SocComprobante socComprobante, SocEsquemas socEsquemas) {
			ComprobanteDet comprobante = sumasDebeHaber(socComprobante, socEsquemas) ;

			if (comprobante.getRenMontomn().compareTo(BigDecimal.ZERO) != 0) {
				log.error("Comprobante [" + socComprobante.getCpbCodigo() + "] con diferencia [" + comprobante.getRenMontomn() + "] entre DEBE [" + comprobante.getDebe()
						+ "] y HABER " + comprobante.getHaber() + " esq: " + socComprobante.getEsqCodigo());
				throw new BusinessException("Comprobante [" + socComprobante.getCpbCodigo() + "] con diferencia [" + comprobante.getRenMontomn() + "] entre DEBE [" + comprobante.getDebe()
						+ "] y HABER " + comprobante.getHaber() + " esq: " + socComprobante.getEsqCodigo());
			}
	}
	
}
