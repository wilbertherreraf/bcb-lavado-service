/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class SocCambioDao extends HibernateDaoSupport implements BcbDao {
	private static final Log log = LogFactory.getLog(SocCambioDao.class);
	private JdbcTemplate jdbcTemplate;
	private static FactoryDao factoryDao;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	/**
	 * @param jdbcTemplate
	 *            the jdbcTemplate to set
	 */
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.service.pruebaCU.model.SolicitudDao#saveOrUpdate(gob.bcb.service
	 * .pruebaCU .model.Solicitud)
	 */
	
	public void saveOrUpdate(BcbEntity pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void saveOrUpdate(SocCambio pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.datastore.BcbDao#find(java.lang.Long)
	 */
	
	public BcbEntity find(Long id) {
		return null;
	}

	public SocCambio getCambio(Date fecha) {
		log.info("Entre a buscar el objeto con el id: " + fecha);

		SocCambio cambio = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from SocCambio cc ");
		query = query.append("where cc.fecha = ? ");

		@SuppressWarnings("unchecked")
		List<SocCambio> lista = (List<SocCambio>) getHibernateTemplate().find(query.toString(), fecha);

		if (lista != null) {
			for (SocCambio cc : lista) {
				cambio = cc;
			}
		}

		return cambio;
	}

}
