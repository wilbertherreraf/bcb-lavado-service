package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_opecomi database table.
 * 
 */
@Embeddable
public class SocOpecomiId implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "cla_comision")
	private String claComision;

	@Column(name = "ope_codigo")
	private String opeCodigo;

	@Column(name = "det_codigo")
	private Integer detCodigo;

	public SocOpecomiId() {
	}

	public SocOpecomiId(String claComision, String opeCodigo, Integer detCodigo) {
		this.claComision = claComision;
		this.opeCodigo = opeCodigo;
		this.detCodigo = detCodigo;
	}

	public String getClaComision() {
		return this.claComision;
	}

	public void setClaComision(String claComision) {
		this.claComision = claComision;
	}

	public String getOpeCodigo() {
		return this.opeCodigo;
	}

	public void setOpeCodigo(String opeCodigo) {
		this.opeCodigo = opeCodigo;
	}

	public Integer getDetCodigo() {
		return this.detCodigo;
	}

	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}

	
	public String toString() {
		return "SocOpecomiId [claComision=" + claComision + ", opeCodigo=" + opeCodigo + ", detCodigo=" + detCodigo + "]";
	}

	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((claComision == null) ? 0 : claComision.hashCode());
		result = prime * result + ((detCodigo == null) ? 0 : detCodigo.hashCode());
		result = prime * result + ((opeCodigo == null) ? 0 : opeCodigo.hashCode());
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocOpecomiId other = (SocOpecomiId) obj;
		if (claComision == null) {
			if (other.claComision != null)
				return false;
		} else if (!claComision.equals(other.claComision))
			return false;
		if (detCodigo == null) {
			if (other.detCodigo != null)
				return false;
		} else if (!detCodigo.equals(other.detCodigo))
			return false;
		if (opeCodigo == null) {
			if (other.opeCodigo != null)
				return false;
		} else if (!opeCodigo.equals(other.opeCodigo))
			return false;
		return true;
	}

}
