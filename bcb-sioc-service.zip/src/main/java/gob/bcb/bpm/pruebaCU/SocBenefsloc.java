package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the soc_benefsloc database table.
 * 
 */
@Entity
@Table(name="soc_benefsloc")
public class SocBenefsloc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ben_codigo")
	private String benCodigo;

	@Column(name="ben_factura")
	private String benFactura;

	@Column(name="ben_nit")
	private String benNit;

	@Column(name="ben_nombre")
	private String benNombre;

	@Column(name="cla_vigente")
	private Short claVigente;

	@Column(name="cve_tipobenl")
	private String cveTipobenl;
	
	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="sol_codigo")
	private String solCodigo;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocBenefsloc() {
    }

	public String getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getBenFactura() {
		return this.benFactura;
	}

	public void setBenFactura(String benFactura) {
		this.benFactura = benFactura;
	}

	public String getBenNit() {
		return this.benNit;
	}

	public void setBenNit(String benNit) {
		this.benNit = benNit;
	}

	public String getBenNombre() {
		return this.benNombre;
	}

	public void setBenNombre(String benNombre) {
		this.benNombre = benNombre;
	}

	public Short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getSolCodigo() {
		return this.solCodigo;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getCveTipobenl() {
		return cveTipobenl;
	}

	public void setCveTipobenl(String cveTipobenl) {
		this.cveTipobenl = cveTipobenl;
	}

}