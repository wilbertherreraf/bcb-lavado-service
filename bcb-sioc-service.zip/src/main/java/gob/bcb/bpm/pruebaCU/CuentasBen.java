package gob.bcb.bpm.pruebaCU;

public class CuentasBen implements java.io.Serializable {

	private String benCodigo;	
	private String benNombre;	
	private Integer ctaCodigo;
	private String ctaNroCuenta;
	private String ctaInfo;
	private String claEsquema;
	private Integer moneda;
	private String monedaLit;
	private String ctaNroCuenta1;
	private String bcoCodigo;	
	private String bcoNombre;
	private String plaNombre;
	private String plaBic;
	private String bcoCodigoI;	
	private String plaIntermediario;
	private String plaNroCuenta;
	private String bcoNombreI;
	private String plaNombreI;
	private String ctaNombre;	
	private Integer ctaCodigoCont;
	private String ctaMovimiento;
	private String ctaNommovimiento;	
	private Integer ctaCodmoneda;	
	private String ctaAfectable;	
	
	private String codBancoSigep;
	private String labelBICNroCTA;
	private String bICNroCTA;
	private Integer moneda1;
	private String monedaLit1;	
	private String nit;	
	private String factura;	
	private String benDireccion;	
	private String benPlaza;
	private Short ctaVigente;
	private Short benVigente;
	
	public CuentasBen() {

	}

	public CuentasBen(Integer ctaCodigo, String ctaNroCuenta, String ctaInfo, Integer moneda, String bcoNombre, String plaNombre, String plaBic,
			String plaIntermediario, String plaNroCuenta, String bcoNombreI, String plaNombreI) {
		this.ctaCodigo = ctaCodigo;
		this.ctaNroCuenta = ctaNroCuenta;
		this.ctaInfo = ctaInfo;
		this.moneda = moneda;
		this.bcoNombre = bcoNombre;
		this.plaNombre = plaNombre;
		this.plaBic = plaBic;
		this.plaIntermediario = plaIntermediario;
		this.plaNroCuenta = plaNroCuenta;
		this.bcoNombreI = bcoNombreI;
		this.plaNombreI = plaNombreI;
	}

	public CuentasBen(Integer ctaCodigo, String ctaNroCuenta, String ctaInfo, Integer moneda, String bcoNombre, String plaNombre, String plaBic,
			String plaIntermediario, String plaNroCuenta) {
		this.ctaCodigo = ctaCodigo;
		this.ctaNroCuenta = ctaNroCuenta;
		this.ctaInfo = ctaInfo;
		this.moneda = moneda;
		this.bcoNombre = bcoNombre;
		this.plaNombre = plaNombre;
		this.plaBic = plaBic;
		this.plaIntermediario = plaIntermediario;
		this.plaNroCuenta = plaNroCuenta;
	}

	public CuentasBen(Integer ctaCodigo, String ctaNroCuenta, String ctaInfo, Integer moneda, String bcoNombre, String plaNombre, String plaBic) {
		this.ctaCodigo = ctaCodigo;
		this.ctaNroCuenta = ctaNroCuenta;
		this.ctaInfo = ctaInfo;
		this.moneda = moneda;
		this.bcoNombre = bcoNombre;
		this.plaNombre = plaNombre;
		this.plaBic = plaBic;
	}

	public CuentasBen(Integer ctaCodigo, String ctaNroCuenta, String ctaInfo, Integer moneda, String bcoNombre, String plaNombre, String plaBic,
			String plaNroCuenta) {
		this.ctaCodigo = ctaCodigo;
		this.ctaNroCuenta = ctaNroCuenta;
		this.ctaInfo = ctaInfo;
		this.moneda = moneda;
		this.bcoNombre = bcoNombre;
		this.plaNombre = plaNombre;
		this.plaBic = plaBic;
		this.plaNroCuenta = plaNroCuenta;
	}

	public CuentasBen(Integer ctaCodigo, String ctaNroCuenta, String ctaInfo, Integer moneda, String bcoNombre, String plaBic) {
		this.ctaCodigo = ctaCodigo;
		this.ctaNroCuenta = ctaNroCuenta;
		this.ctaInfo = ctaInfo;
		this.moneda = moneda;
		this.bcoNombre = bcoNombre;
		this.plaBic = plaBic;
	}

	public Integer getCtaCodigo() {
		return ctaCodigo;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public String getCtaNroCuenta() {
		return ctaNroCuenta;
	}

	public void setCtaNroCuenta(String ctaNroCuenta) {
		this.ctaNroCuenta = ctaNroCuenta;
	}

	public String getCtaInfo() {
		return ctaInfo;
	}

	public void setCtaInfo(String ctaInfo) {
		this.ctaInfo = ctaInfo;
	}

	public Integer getMoneda() {
		return moneda;
	}

	public void setMoneda(Integer moneda) {
		this.moneda = moneda;
	}

	public String getBcoNombre() {
		return bcoNombre;
	}

	public void setBcoNombre(String bcoNombre) {
		this.bcoNombre = bcoNombre;
	}

	public String getPlaNombre() {
		return plaNombre;
	}

	public void setPlaNombre(String plaNombre) {
		this.plaNombre = plaNombre;
	}

	public String getPlaBic() {
		return plaBic;
	}

	public void setPlaBic(String plaBic) {
		this.plaBic = plaBic;
	}

	public String getPlaIntermediario() {
		return plaIntermediario;
	}

	public void setPlaIntermediario(String plaIntermediario) {
		this.plaIntermediario = plaIntermediario;
	}

	public String getPlaNroCuenta() {
		return plaNroCuenta;
	}

	public void setPlaNroCuenta(String plaNroCuenta) {
		this.plaNroCuenta = plaNroCuenta;
	}

	public String getBcoNombreI() {
		return bcoNombreI;
	}

	public void setBcoNombreI(String bcoNombreI) {
		this.bcoNombreI = bcoNombreI;
	}

	public String getPlaNombreI() {
		return plaNombreI;
	}

	public void setPlaNombreI(String plaNombreI) {
		this.plaNombreI = plaNombreI;
	}

	public void setCtaCodigoCont(Integer ctaCodigoCont) {
		this.ctaCodigoCont = ctaCodigoCont;
	}

	public Integer getCtaCodigoCont() {
		return ctaCodigoCont;
	}

	public void setBcoCodigo(String bcoCodigo) {
		this.bcoCodigo = bcoCodigo;
	}

	public String getBcoCodigo() {
		return bcoCodigo;
	}

	public void setMonedaLit(String monedaLit) {
		this.monedaLit = monedaLit;
	}

	public String getMonedaLit() {
		return monedaLit;
	}

	public void setMoneda1(Integer moneda1) {
		this.moneda1 = moneda1;
	}

	public Integer getMoneda1() {
		return moneda1;
	}

	
	public String toString() {
		return "CuentasBen [ctaCodigo=" + ctaCodigo + ", ctaNroCuenta=" + ctaNroCuenta + ", ctaInfo=" + ctaInfo + ", moneda=" + moneda
				+ ", monedaLit=" + monedaLit + ", bcoCodigo=" + bcoCodigo + ", bcoNombre=" + bcoNombre + ", plaNombre=" + plaNombre + ", plaBic="
				+ plaBic + ", plaIntermediario=" + plaIntermediario + ", plaNroCuenta=" + plaNroCuenta + ", bcoNombreI=" + bcoNombreI
				+ ", plaNombreI=" + plaNombreI + ", ctaCodigoCont=" + ctaCodigoCont + ", labelBICNroCTA="
				+ labelBICNroCTA + ", bICNroCTA=" + bICNroCTA + ", moneda1=" + moneda1 + "]";
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public void setFactura(String factura) {
		this.factura = factura;
	}

	public String getFactura() {
		return factura;
	}

	public void setCtaNroCuenta1(String ctaNroCuenta1) {
		this.ctaNroCuenta1 = ctaNroCuenta1;
	}

	public String getCtaNroCuenta1() {
		return ctaNroCuenta1;
	}

	public void setMonedaLit1(String monedaLit1) {
		this.monedaLit1 = monedaLit1;
	}

	public String getMonedaLit1() {
		return monedaLit1;
	}

	public void setCtaNombre(String ctaNombre) {
		this.ctaNombre = ctaNombre;
	}

	public String getCtaNombre() {
		return ctaNombre;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getBenCodigo() {
		return benCodigo;
	}

	public void setBenNombre(String benNombre) {
		this.benNombre = benNombre;
	}

	public String getBenNombre() {
		return benNombre;
	}

	public String getClaEsquema() {
		return claEsquema;
	}

	public void setClaEsquema(String claEsquema) {
		this.claEsquema = claEsquema;
	}

	public String getBenDireccion() {
		return benDireccion;
	}

	public void setBenDireccion(String benDireccion) {
		this.benDireccion = benDireccion;
	}

	public String getBenPlaza() {
		return benPlaza;
	}

	public void setBenPlaza(String benPlaza) {
		this.benPlaza = benPlaza;
	}

	public Short getCtaVigente() {
		return ctaVigente;
	}

	public void setCtaVigente(Short ctaVigente) {
		this.ctaVigente = ctaVigente;
	}

	public Short getBenVigente() {
		return benVigente;
	}

	public void setBenVigente(Short benVigente) {
		this.benVigente = benVigente;
	}

	public String getCodBancoSigep() {
		return codBancoSigep;
	}

	public void setCodBancoSigep(String codBancoSigep) {
		this.codBancoSigep = codBancoSigep;
	}

	public String getBcoCodigoI() {
		return bcoCodigoI;
	}

	public void setBcoCodigoI(String bcoCodigoI) {
		this.bcoCodigoI = bcoCodigoI;
	}

	public String getCtaMovimiento() {
		return ctaMovimiento;
	}

	public void setCtaMovimiento(String ctaMovimiento) {
		this.ctaMovimiento = ctaMovimiento;
	}

	public Integer getCtaCodmoneda() {
		return ctaCodmoneda;
	}

	public void setCtaCodmoneda(Integer ctaCodmoneda) {
		this.ctaCodmoneda = ctaCodmoneda;
	}

	public String getCtaAfectable() {
		return ctaAfectable;
	}

	public void setCtaAfectable(String ctaAfectable) {
		this.ctaAfectable = ctaAfectable;
	}

	public String getCtaNommovimiento() {
		return ctaNommovimiento;
	}

	public void setCtaNommovimiento(String ctaNommovimiento) {
		this.ctaNommovimiento = ctaNommovimiento;
	}

}
