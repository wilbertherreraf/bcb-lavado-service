/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;

//import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class SocDetallesopeDao extends HibernateDaoSupport implements BcbDao {
	private static final Log log = LogFactory.getLog(SocDetallesopeDao.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.service.pruebaCU.model.SolicitudDao#saveOrUpdate(gob.bcb.service
	 * .pruebaCU .model.Solicitud)
	 */
	
	public void saveOrUpdate(BcbEntity pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void saveOrUpdate(SocDetallesope pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminarDetalle(BcbEntity pm) {
		log.info("Eliminando detalle... " + pm);
		this.getHibernateTemplate().delete(pm);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.datastore.BcbDao#find(java.lang.Long)
	 */
	
	public BcbEntity find(Long id) {

		return null;
	}

	public List<SocDetallesope> getDetalles(String opeCodigo) {
		List<SocDetallesope> lista = new ArrayList<SocDetallesope>();

		StringBuffer query = new StringBuffer();
		query = query.append(" select de ");
		query = query.append(" from SocDetallesope de ");
		query = query.append(" where de.id.opeCodigo = ? ");

		lista = (List<SocDetallesope>) getHibernateTemplate().find(query.toString(), opeCodigo);

		log.info("Entre a buscar el objeto con el id: " + opeCodigo + " --> " + query.toString());

		return lista;
	}

	@SuppressWarnings("unchecked")
	public SocDetallesope getDetalle(String opeCodigo, int detCodigo) {
		List<SocDetallesope> lista = new ArrayList<SocDetallesope>();
		SocDetallesope detalle = null;

		StringBuffer query = new StringBuffer();

		query = query.append(" select de");
		query = query.append(" from SocDetallesope de");
		query = query.append(" where de.id.opeCodigo = :opeCodigo ");
		query = query.append(" and de.id.detCodigo = :detCodigo ");

		log.info("Entre a buscar el objeto con el id: {" + opeCodigo + ", " + detCodigo + "} --> " + query.toString());

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("opeCodigo", opeCodigo);
		consulta.setParameter("detCodigo", detCodigo);

		lista = consulta.list();
		if (lista.size() > 0) {
			detalle = lista.get(0);
		}

		return detalle;
	}

}
