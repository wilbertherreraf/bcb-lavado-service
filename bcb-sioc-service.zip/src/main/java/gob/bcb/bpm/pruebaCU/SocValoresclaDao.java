package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocValoresclaDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocValoresclaDao.class);

	public void saveOrUpdate(SocValorescla socValorescla) {
		this.getHibernateTemplate().saveOrUpdate(socValorescla);
	}

	public void saveOrUpdate(SocClaves socClaves) {
		this.getHibernateTemplate().saveOrUpdate(socClaves);
	}

	public SocValorescla getValoresByCod(String claCodigo, String valCodigo) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM SocValorescla h ");
		query = query.append("where h.id.claCodigo = :claCodigo ");
		query = query.append("and h.id.valCodigo = :valCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("claCodigo", claCodigo);
		consulta.setParameter("valCodigo", valCodigo);
		List lista = consulta.list();

		if (lista.size() != 1) {
			log.error("Clave [" + claCodigo + "] con parametro " + valCodigo + " no parametrizado en SocValorescla, comunique al administrador.");
			throw new BusinessException("Clave [" + claCodigo + "] con parametro " + valCodigo
					+ " no parametrizado en SocValorescla, comunique al administrador.");
		}
		return (SocValorescla) lista.get(0);
	}
	public SocValorescla getValoresByCodigo(String claCodigo, String valCodigo) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM SocValorescla h ");
		query = query.append("where h.id.claCodigo = :claCodigo ");
		query = query.append("and h.id.valCodigo = :valCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("claCodigo", claCodigo);
		consulta.setParameter("valCodigo", valCodigo);
		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocValorescla) lista.get(0);
		}
		return null;
	}

	public List<SocValorescla> getValoresByClave(String claCodigo) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM SocValorescla h ");
		query = query.append("where h.id.claCodigo = :claCodigo ");
		query = query.append("order by h.id.valCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("claCodigo", claCodigo);

		return consulta.list();
	}

	public List<SocClaves> claves() {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM SocClaves h ");
		query = query.append("order by h.claCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		return consulta.list();
	}

	public List<SocClaves> buscarClavesLista(String claCodigos) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM SocClaves h ");
		query = query.append("where h.claCodigo in (:claCodigos) ");
		query = query.append("order by h.claCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		List estadosList = new ArrayList();
		estadosList.addAll(Arrays.asList(claCodigos.split(",")));
		
		consulta.setParameterList("claCodigos", estadosList);
		
		return consulta.list();
	}

	public SocClaves claveByCod(String claCodigo) {
		StringBuffer query = new StringBuffer();

		query = query.append("SELECT h ");
		query = query.append("FROM SocClaves h ");
		query = query.append("where h.claCodigo = :claCodigo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("claCodigo", claCodigo);
		List lista = consulta.list();
		if (lista.size() > 0) {
			return (SocClaves) lista.get(0);
		}

		return null;
	}

}
