package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the soc_mensajes database table.
 * 
 */
@Entity
@Table(name = "soc_mensajes")
public class SocMensajes implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ins_codigo")
	private String insCodigo;

	@Column(name = "cla_esquema")
	private String claEsquema;

	@Column(name = "cla_estadomen")
	private String claEstadomen;

	@Column(name = "det_codigo")
	private Integer detCodigo;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	@Temporal(TemporalType.DATE)
	@Column(name = "men_fechavalor")
	private Date menFechavalor;

	@Column(name = "men_montoordenado")
	private BigDecimal menMontoordenado;

	@Column(name = "men_nroswift")
	private Integer menNroswift;

	@Column(name = "mon_swift")
	private String monSwift;

	@Column(name = "ope_codigo")
	private String opeCodigo;

	@Column(name = "cod_usrswift")
	private String codUsrswift;
	
	@Column(name = "usr_codigo")
	private String usrCodigo;

	public SocMensajes() {
	}

	public SocMensajes(String insCodigo, String claEstadomen) {
		this.insCodigo = insCodigo;
		this.claEstadomen = claEstadomen;
	}

	public SocMensajes(String insCodigo, Integer menNroswift, Date menFechavalor, BigDecimal menMontoordenado, String claEstadomen, String usrCodigo,
			String claEsquema) {
		this.insCodigo = insCodigo;
		this.menNroswift = menNroswift;
		this.menFechavalor = menFechavalor;
		this.menMontoordenado = menMontoordenado;
		this.claEstadomen = claEstadomen;
		this.usrCodigo = usrCodigo;
		this.claEsquema = claEsquema;
	}

	public String getInsCodigo() {
		return this.insCodigo;
	}

	public void setInsCodigo(String insCodigo) {
		this.insCodigo = insCodigo;
	}

	public String getClaEsquema() {
		return this.claEsquema;
	}

	public void setClaEsquema(String claEsquema) {
		this.claEsquema = claEsquema;
	}

	public String getClaEstadomen() {
		return this.claEstadomen;
	}

	public void setClaEstadomen(String claEstadomen) {
		this.claEstadomen = claEstadomen;
	}

	public Integer getDetCodigo() {
		return this.detCodigo;
	}

	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getMenFechavalor() {
		return this.menFechavalor;
	}

	public void setMenFechavalor(Date menFechavalor) {
		this.menFechavalor = menFechavalor;
	}

	public BigDecimal getMenMontoordenado() {
		return this.menMontoordenado;
	}

	public void setMenMontoordenado(BigDecimal menMontoordenado) {
		this.menMontoordenado = menMontoordenado;
	}

	public Integer getMenNroswift() {
		return this.menNroswift;
	}

	public void setMenNroswift(Integer menNroswift) {
		this.menNroswift = menNroswift;
	}

	public String getMonSwift() {
		return this.monSwift;
	}

	public void setMonSwift(String monSwift) {
		this.monSwift = monSwift;
	}

	public String getOpeCodigo() {
		return this.opeCodigo;
	}

	public void setOpeCodigo(String opeCodigo) {
		this.opeCodigo = opeCodigo;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	
	public String toString() {
		return "SocMensajes [insCodigo=" + insCodigo + ", claEsquema=" + claEsquema + ", claEstadomen=" + claEstadomen + ", detCodigo=" + detCodigo
				+ ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", menFechavalor=" + menFechavalor + ", menMontoordenado="
				+ menMontoordenado + ", menNroswift=" + menNroswift + ", monSwift=" + monSwift + ", opeCodigo=" + opeCodigo + ", usrCodigo="
				+ usrCodigo + "]";
	}

	public String getCodUsrswift() {
		return codUsrswift;
	}

	public void setCodUsrswift(String codUsrswift) {
		this.codUsrswift = codUsrswift;
	}

}
