package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

import java.util.Date;

/**
 * The persistent class for the soc_solicitante database table.
 * 
 */
@Entity
@Table(name = "soc_solicitante")
public class SocSolicitante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sol_codigo")
	private String solCodigo;

	@Column(name = "sol_codsigep")
	private String solCodsigep;

	@Column(name = "cla_entidad")
	private String claEntidad;

	@Column(name = "cla_vigente")
	private Short claVigente;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	private String login;

	private String sigla;

	@Column(name = "sol_bic")
	private String solBic;

	@Column(name = "sol_direccion")
	private String solDireccion;

	@Column(name = "sol_factura")
	private String solFactura;

	@Column(name = "sol_fax")
	private String solFax;

	@Column(name = "sol_nit")
	private String solNit;

	@Column(name = "sol_persona")
	private String solPersona;

	@Column(name = "sol_plaza")
	private String solPlaza;

	@Column(name = "sol_telefono")
	private String solTelefono;

	@Column(name = "usr_codigo")
	private String usrCodigo;

	public SocSolicitante() {
	}

	public SocSolicitante(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public SocSolicitante(String solCodigo, String solPersona, String claEntidad, String solDireccion, String solPlaza, String solBic,
			Short claVigente, String usrCodigo, Date fechaHora, String estacion, String sigla) {
		this.solCodigo = solCodigo;
		this.solPersona = solPersona;
		this.claEntidad = claEntidad;
		this.solDireccion = solDireccion;
		this.solPlaza = solPlaza;
		this.solBic = solBic;
		this.claVigente = claVigente;
		this.usrCodigo = usrCodigo;
		this.fechaHora = fechaHora;
		this.estacion = estacion;
		this.sigla = sigla;
	}

	public String getSolCodigo() {
		return this.solCodigo;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getClaEntidad() {
		return this.claEntidad;
	}

	public void setClaEntidad(String claEntidad) {
		this.claEntidad = claEntidad;
	}

	public Short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getLogin() {
		return this.login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSigla() {
		return this.sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getSolBic() {
		return this.solBic;
	}

	public void setSolBic(String solBic) {
		this.solBic = solBic;
	}

	public String getSolDireccion() {
		return this.solDireccion;
	}

	public void setSolDireccion(String solDireccion) {
		this.solDireccion = solDireccion;
	}

	public String getSolFactura() {
		return this.solFactura;
	}

	public void setSolFactura(String solFactura) {
		this.solFactura = solFactura;
	}

	public String getSolFax() {
		return this.solFax;
	}

	public void setSolFax(String solFax) {
		this.solFax = solFax;
	}

	public String getSolNit() {
		return this.solNit;
	}

	public void setSolNit(String solNit) {
		this.solNit = solNit;
	}

	public String getSolPersona() {
		return this.solPersona;
	}

	public void setSolPersona(String solPersona) {
		this.solPersona = solPersona;
	}

	public String getSolPlaza() {
		return this.solPlaza;
	}

	public void setSolPlaza(String solPlaza) {
		this.solPlaza = solPlaza;
	}

	public String getSolTelefono() {
		return this.solTelefono;
	}

	public void setSolTelefono(String solTelefono) {
		this.solTelefono = solTelefono;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getSolCodsigep() {
		return solCodsigep;
	}

	public void setSolCodsigep(String solCodsigep) {
		this.solCodsigep = solCodsigep;
	}
}
