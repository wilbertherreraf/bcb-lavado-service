package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;


/**
 * The persistent class for the soc_detallesope database table.
 * 
 */
@Entity
@Table(name="soc_detallesope")
public class SocDetallesope implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocDetallesopeId id;

	@Column(name="ben_codigo")
	private String benCodigo;

	@Column(name="det_concepto")
	private String detConcepto;

	@Column(name="det_ctabenef")
	private String detCtabenef;

	@Column(name="det_info")
	private String detInfo;

	@Column(name="det_monto")
	private BigDecimal detMonto;

	@Column(name="det_montoord")
	private BigDecimal detMontoOrd;

	@Column(name="ins_codigo")
	private String insCodigo;

	private Integer moneda;
	
	@Column(name="det_facturas")
	private String detFacturas;
    public SocDetallesope() {
    }

    public SocDetallesope(SocDetallesopeId id, String benCodigo) {
        this.id = id;
        this.benCodigo = benCodigo;
      }

      public SocDetallesope(SocDetallesopeId id, String insCodigo,
          String benCodigo, BigDecimal detMonto, int moneda,
          String detCtabenef, String detConcepto, BigDecimal detMontoOrd,
          String detInfo, String detFacturas) {
        this.id = id;
        this.insCodigo = insCodigo;
        this.benCodigo = benCodigo;
        this.detMonto = detMonto;
        this.moneda = moneda;
        this.detCtabenef = detCtabenef;
        this.detConcepto = detConcepto;
        this.detMontoOrd = detMontoOrd;
        this.detInfo = detInfo;
        this.setDetFacturas(detFacturas);
      }    
	public SocDetallesopeId getId() {
		return this.id;
	}

	public void setId(SocDetallesopeId id) {
		this.id = id;
	}
	
	public String getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getDetConcepto() {
		return this.detConcepto;
	}

	public void setDetConcepto(String detConcepto) {
		this.detConcepto = detConcepto;
	}

	public String getDetCtabenef() {
		return this.detCtabenef;
	}

	public void setDetCtabenef(String detCtabenef) {
		this.detCtabenef = detCtabenef;
	}

	public String getDetInfo() {
		return this.detInfo;
	}

	public void setDetInfo(String detInfo) {
		this.detInfo = detInfo;
	}

	public BigDecimal getDetMonto() {
		return this.detMonto;
	}

	public void setDetMonto(BigDecimal detMonto) {
		this.detMonto = detMonto;
	}

	public BigDecimal getDetMontoOrd() {
		return this.detMontoOrd;
	}

	public void setDetMontoOrd(BigDecimal detMontoord) {
		this.detMontoOrd = detMontoord;
	}

	public String getInsCodigo() {
		return this.insCodigo;
	}

	public void setInsCodigo(String insCodigo) {
		this.insCodigo = insCodigo;
	}

	public Integer getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Integer moneda) {
		this.moneda = moneda;
	}

	public String getDetFacturas() {
		return detFacturas;
	}

	public void setDetFacturas(String detFacturas) {
		this.detFacturas = detFacturas;
	}

	
	public String toString() {
		return "SocDetallesope [id=" + id + ", benCodigo=" + benCodigo + ", detConcepto=" + detConcepto + ", detCtabenef=" + detCtabenef
				+ ", detInfo=" + detInfo + ", detMonto=" + detMonto + ", detMontoOrd=" + detMontoOrd + ", insCodigo=" + insCodigo + ", moneda="
				+ moneda + ", detFacturas=" + detFacturas + "]";
	}

}
