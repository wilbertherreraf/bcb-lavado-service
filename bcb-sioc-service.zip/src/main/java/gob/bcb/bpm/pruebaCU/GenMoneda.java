package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the gen_moneda database table.
 * 
 */
@Entity
@Table(name="gen_moneda")
public class GenMoneda implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cod_moneda")
	private Integer codMoneda;

	@Column(name="des_swift")
	private String desSwift;

	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="mon_nombre")
	private String monNombre;

	@Column(name="mon_sigla")
	private String monSigla;

	@Column(name="usr_codigo")
	private String usrCodigo;

    public GenMoneda() {
    }

	public Integer getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getDesSwift() {
		return this.desSwift;
	}

	public void setDesSwift(String desSwift) {
		this.desSwift = desSwift;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getMonNombre() {
		return this.monNombre;
	}

	public void setMonNombre(String monNombre) {
		this.monNombre = monNombre;
	}

	public String getMonSigla() {
		return this.monSigla;
	}

	public void setMonSigla(String monSigla) {
		this.monSigla = monSigla;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	
	public String toString() {
		return "GenMoneda [codMoneda=" + codMoneda + ", desSwift=" + desSwift + ", estacion=" + estacion + ", fechaHora=" + fechaHora
				+ ", monNombre=" + monNombre + ", monSigla=" + monSigla + ", usrCodigo=" + usrCodigo + "]";
	}

	
}
