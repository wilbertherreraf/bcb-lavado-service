package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;

/**
 * The persistent class for the soc_facturas database table.
 * 
 */
@Entity
@Table(name = "soc_facturas")
public class SocFacturas implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocFacturasId id;

	@Column(name = "cve_ruc")
	private Character cveRuc;

	@Column(name = "fac_concepto")
	private String facConcepto;

	@Column(name = "fac_montoexcento")
	private BigDecimal facMontoexcento;

	@Column(name = "fac_montoiva")
	private BigDecimal facMontoiva;

	@Column(name = "fac_montomn")
	private BigDecimal facMontomn;

	@Column(name = "fac_nit")
	private String facNit;

	@Column(name = "fac_nombre")
	private String facNombre;
	@Column(name = "cla_Tipofact")
	private String claTipofact;

	@Column(name = "fac_preciounitario")
	private BigDecimal facPreciounitario;

	public SocFacturas() {
	}

	public SocFacturas(SocFacturasId id, String facNit, String facNombre, BigDecimal facMontomn, BigDecimal facMontoiva, BigDecimal facMontoexcento,
			BigDecimal facPreciounitario, String facConcepto, char cveRuc) {
		this.id = id;
		this.facNit = facNit;
		this.facNombre = facNombre;
		this.facMontomn = facMontomn;
		this.facMontoiva = facMontoiva;
		this.facMontoexcento = facMontoexcento;
		this.facPreciounitario = facPreciounitario;
		this.facConcepto = facConcepto;
		this.cveRuc = cveRuc;
	}

	public SocFacturasId getId() {
		return this.id;
	}

	public void setId(SocFacturasId id) {
		this.id = id;
	}

	public String getFacNit() {
		return facNit;
	}

	public void setFacNit(String facNit) {
		this.facNit = facNit;
	}

	public String getFacNombre() {
		return facNombre;
	}

	public void setFacNombre(String facNombre) {
		this.facNombre = facNombre;
	}

	public BigDecimal getFacMontomn() {
		return facMontomn;
	}

	public void setFacMontomn(BigDecimal facMontomn) {
		this.facMontomn = facMontomn;
	}

	public BigDecimal getFacMontoiva() {
		return facMontoiva;
	}

	public void setFacMontoiva(BigDecimal facMontoiva) {
		this.facMontoiva = facMontoiva;
	}

	/**
	 * @return the facMontoexcento
	 */
	public BigDecimal getFacMontoexcento() {
		return facMontoexcento;
	}

	/**
	 * @param facMontoexcento
	 *            the facMontoexcento to set
	 */
	public void setFacMontoexcento(BigDecimal facMontoexcento) {
		this.facMontoexcento = facMontoexcento;
	}

	/**
	 * @return the facPreciounitario
	 */
	public BigDecimal getFacPreciounitario() {
		return facPreciounitario;
	}

	/**
	 * @param facPreciounitario
	 *            the facPreciounitario to set
	 */
	public void setFacPreciounitario(BigDecimal facPreciounitario) {
		this.facPreciounitario = facPreciounitario;
	}

	public String getFacConcepto() {
		return facConcepto;
	}

	public void setFacConcepto(String facConcepto) {
		this.facConcepto = facConcepto;
	}

	public void setCveRuc(Character cveRuc) {
		this.cveRuc = cveRuc;
	}

	public Character getCveRuc() {
		return cveRuc;
	}

	public String getClaTipofact() {
		return claTipofact;
	}

	public void setClaTipofact(String claTipofact) {
		this.claTipofact = claTipofact;
	}

}
