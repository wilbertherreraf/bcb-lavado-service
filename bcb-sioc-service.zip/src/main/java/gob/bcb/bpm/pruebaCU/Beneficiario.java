package gob.bcb.bpm.pruebaCU;

import gob.bcb.swift.model.SwfPersonacta;

import java.util.Date;
import java.util.List;

public class Beneficiario implements java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer benCodigoI;
	private String benCodigo;
	private String solCodigo;
	private String benNombre;
	private String benNit;
	private String benFactura;
	private String benDireccion;
	private String benPlaza;	
	private Integer claEntidad;
	private Short claVigente;
	private String usrCodigo;
	private Date fechaHora;
	private String estacion;
	private List<CuentasBen> cuentasBenLista;
	private SocBenefs socBenefs;
	private SocBenefsreg socBenefsreg;
	private SocBenefsexp socBenefsregexp;	
	private SocCuentas socCuentas;
	private SocBancos socBancos;
	private SocBancos socBancosInter;	
	private SocPlazas socPlazas;
	private SocPlazas socPlazasInter;
	private SwfPersonacta swfPersonacta; 

	public Beneficiario() {
	}

	public String getBenCodigo() {
		return benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getBenNombre() {
		return benNombre;
	}

	public void setBenNombre(String benNombre) {
		this.benNombre = benNombre;
	}

	public String getBenNit() {
		return benNit;
	}

	public void setBenNit(String benNit) {
		this.benNit = benNit;
	}

	public String getBenFactura() {
		return benFactura;
	}

	public void setBenFactura(String benFactura) {
		this.benFactura = benFactura;
	}

	public Short getClaVigente() {
		return claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getSolCodigo() {
		return solCodigo;
	}

	public void setBenCodigoI(Integer benCodigoI) {
		this.benCodigoI = benCodigoI;
	}

	public Integer getBenCodigoI() {
		return benCodigoI;
	}

	public Integer getClaEntidad() {
		return claEntidad;
	}

	public void setClaEntidad(Integer claEntidad) {
		this.claEntidad = claEntidad;
	}

	public List<CuentasBen> getCuentasBenLista() {
		return cuentasBenLista;
	}

	public void setCuentasBenLista(List<CuentasBen> cuentasBenLista) {
		this.cuentasBenLista = cuentasBenLista;
	}

	public String getBenDireccion() {
		return benDireccion;
	}

	public void setBenDireccion(String benDireccion) {
		this.benDireccion = benDireccion;
	}

	public String getBenPlaza() {
		return benPlaza;
	}

	public void setBenPlaza(String benPlaza) {
		this.benPlaza = benPlaza;
	}

	public SocBenefs getSocBenefs() {
		return socBenefs;
	}

	public void setSocBenefs(SocBenefs socBenefs) {
		this.socBenefs = socBenefs;
	}

	public SocBenefsreg getSocBenefsreg() {
		return socBenefsreg;
	}

	public void setSocBenefsreg(SocBenefsreg socBenefsreg) {
		this.socBenefsreg = socBenefsreg;
	}

	public SocCuentas getSocCuentas() {
		return socCuentas;
	}

	public void setSocCuentas(SocCuentas socCuentas) {
		this.socCuentas = socCuentas;
	}

	public SocBancos getSocBancos() {
		return socBancos;
	}

	public void setSocBancos(SocBancos socBancos) {
		this.socBancos = socBancos;
	}

	public SocBancos getSocBancosInter() {
		return socBancosInter;
	}

	public void setSocBancosInter(SocBancos socBancosInter) {
		this.socBancosInter = socBancosInter;
	}

	public SocPlazas getSocPlazas() {
		return socPlazas;
	}

	public void setSocPlazas(SocPlazas socPlazas) {
		this.socPlazas = socPlazas;
	}

	public SocPlazas getSocPlazasInter() {
		return socPlazasInter;
	}

	public void setSocPlazasInter(SocPlazas socPlazasInter) {
		this.socPlazasInter = socPlazasInter;
	}

	public SwfPersonacta getSwfPersonacta() {
		return swfPersonacta;
	}

	public void setSwfPersonacta(SwfPersonacta swfPersonacta) {
		this.swfPersonacta = swfPersonacta;
	}

	public SocBenefsexp getSocBenefsregexp() {
		return socBenefsregexp;
	}

	public void setSocBenefsregexp(SocBenefsexp socBenefsregexp) {
		this.socBenefsregexp = socBenefsregexp;
	}
	
}
