package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocParametrosDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocParametrosDao.class);

	public void saveOrUpdate(SocParametros pm) {
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public SocParametros getByCodigo(String parCodigo) {
		log.debug("Entre a buscar getSocCuentasByCodigo id: " + parCodigo);

		SocParametros benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocParametros be ");
		query = query.append("where be.parCodigo = :parCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("parCodigo", parCodigo);

		List lista = consulta.list();

		if (lista.size() != 1) {
			throw new BusinessException("Parametro [" + parCodigo + "] inexistente en soc_parametros, avise a sistemas");
		}

		return (SocParametros) lista.get(0);
	}

	public List<SocParametros> getParams() {
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocParametros be ");

		Query consulta = getSession().createQuery(query.toString());

		List lista = consulta.list();

		return lista;
	}

}
