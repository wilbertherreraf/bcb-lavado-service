package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the soc_rengesq database table.
 * 
 */
@Entity
@Table(name="soc_rengesq")
public class SocRengesq implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocRengesqPK id;

	@Column(name="cla_cuenta")
	private String claCuenta;

	@Column(name="cla_glosa_r")
	private String claGlosaR;

	@Column(name="cod_moneda")
	private String codMoneda;

	@Column(name="esq_definicion")
	private String esqDefinicion;

	@Column(name="esq_descrip")
	private String esqDescrip;

	@Column(name="tipo_cuenta")
	private String tipoCuenta;
	
	@Column(name="esq_dh")
	private Character esqDh;

	private Integer repetible;

	@Column(name="cta_destorig")
	private String ctaDestorig;
	
	@Column(name="nom_datoadic")
	private String nomDatoadic;
	
    public SocRengesq() {
    }

	public SocRengesqPK getId() {
		return this.id;
	}

	public void setId(SocRengesqPK id) {
		this.id = id;
	}
	
	public String getClaCuenta() {
		return this.claCuenta;
	}

	public void setClaCuenta(String claCuenta) {
		this.claCuenta = claCuenta;
	}

	public String getClaGlosaR() {
		return this.claGlosaR;
	}

	public void setClaGlosaR(String claGlosaR) {
		this.claGlosaR = claGlosaR;
	}

	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getEsqDefinicion() {
		return this.esqDefinicion;
	}

	public void setEsqDefinicion(String esqDefinicion) {
		this.esqDefinicion = esqDefinicion;
	}

	public String getEsqDescrip() {
		return this.esqDescrip;
	}

	public void setEsqDescrip(String esqDescrip) {
		this.esqDescrip = esqDescrip;
	}

	public Character getEsqDh() {
		return this.esqDh;
	}

	public void setEsqDh(Character esqDh) {
		this.esqDh = esqDh;
	}

	public Integer getRepetible() {
		return this.repetible;
	}

	public void setRepetible(Integer repetible) {
		this.repetible = repetible;
	}

	public String getTipoCuenta() {
		return tipoCuenta;
	}

	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}

	public String getCtaDestorig() {
		return ctaDestorig;
	}

	public void setCtaDestorig(String ctaDestorig) {
		this.ctaDestorig = ctaDestorig;
	}

	
	public String toString() {
		return "SocRengesq [id=" + id + ", claCuenta=" + claCuenta + ", claGlosaR=" + claGlosaR + ", codMoneda=" + codMoneda + ", esqDefinicion="
				+ esqDefinicion + ", esqDescrip=" + esqDescrip + ", tipoCuenta=" + tipoCuenta + ", esqDh=" + esqDh + ", repetible=" + repetible
				+ ", ctaDestorig=" + ctaDestorig + "]";
	}

	public String getNomDatoadic() {
		return nomDatoadic;
	}

	public void setNomDatoadic(String nomDatoadic) {
		this.nomDatoadic = nomDatoadic;
	}

}
