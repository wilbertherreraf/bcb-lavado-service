/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.joda.time.DateTime;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsQNatives;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.logic.RenglonesComprobantes;
import gob.bcb.service.servicioSioc.pojos.ComprobanteDet;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioTres.model.ComprobanteDao;

//import org.hibernate.Query;

/**
 * @author wherrera
 * 
 */
public class SocComprobanteDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocComprobanteDao.class);

	public void saveOrUpdate(SocComprobante pm) {
		pm.setFechaHora(new Date());
		pm.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
		pm.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));

		this.getHibernateTemplate().merge(pm);
	}

	public void saveOrUpdateSinAud(SocComprobante pm) {
		pm.setFechaHora(new Date());
		this.getHibernateTemplate().merge(pm);
	}

	public void eliminarComprobante(SocComprobante pm) {
		SocFacturasDao socFacturasDao = new SocFacturasDao();
		socFacturasDao.setSessionFactory(getSessionFactory());

		socFacturasDao.eliminarRegs(pm.getCpbCodigo());

		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		socRengscompDao.eliminarRegs(pm.getCpbCodigo());

		this.getHibernateTemplate().delete(pm);
	}

	public void eliminarComprobante(String opeCodigo, String cveEstadocpb, String cveDettipocomp) {
		int i = 0;
		SocFacturasDao socFacturasDao = new SocFacturasDao();
		socFacturasDao.setSessionFactory(getSessionFactory());

		SocOrdenesPagoDao socOrdenesPagoDao = new SocOrdenesPagoDao();
		socOrdenesPagoDao.setSessionFactory(getSessionFactory());

		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		List<SocComprobante> facts = comprobantesByOpeCodigo(opeCodigo, null, null, cveEstadocpb, cveDettipocomp, null, null);
		List<SocComprobante> factsElim = new ArrayList<SocComprobante>();
		for (SocComprobante socComprobante : facts) {

			if (StringUtils.isBlank(socComprobante.getCveEstadocpb()) || (!socComprobante.getCveEstadocpb().trim().equals(Constants.CLAVE_ESTCOMP_CONTAB)
					&& StringUtils.isBlank(socComprobante.getCpbNrocpbte()))) {

				socOrdenesPagoDao.eliminarCbp(socComprobante.getCpbCodigo());
				socFacturasDao.eliminarRegs(socComprobante.getCpbCodigo());
				socRengscompDao.eliminarRegs(socComprobante.getCpbCodigo());
				factsElim.add(socComprobante);
				i++;
			}
		}

		if (factsElim.size() > 0) {
			this.getHibernateTemplate().deleteAll(factsElim);
		}
		log.info(opeCodigo + ":: Eliminados comps [ " + i + " ] regs.");
	}

	public List<SocComprobante> comprobantesByOpeCodigo(String opeCodigo) {
		List<SocComprobante> lista = new ArrayList<SocComprobante>();
		log.info("Entre a buscar el objeto con el id: " + opeCodigo);

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from SocComprobante cp ");
		query = query.append("where cp.opeCodigo = :opeCodigo ");

		log.debug("Consulta " + opeCodigo + " -> " + query.toString());
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		lista = consulta.list();

		return lista;
	}

	public List<SocComprobante> comprobantesByOpeCodigo(String opeCodigo, Integer detCodigo, String cpbCodigoref, String cveEstadocpb,
			String inCveDettipocomp, String noInCveDettipocomp, Integer esqCodigo) {
		List<SocComprobante> lista = new ArrayList<SocComprobante>();

		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select cp ");
		consulta = consulta.append("from SocComprobante cp ");
		consulta = consulta.append("where cp.opeCodigo = :opeCodigo ");

		if (!StringUtils.isBlank(cveEstadocpb)) {
			consulta = consulta.append("and cp.cveEstadocpb in (:cveEstadocpb ) ");
		}

		if (!StringUtils.isBlank(inCveDettipocomp)) {
			consulta = consulta.append("and cp.cveDettipocomp in (:cveDettipocomp ) ");
		}

		if (!StringUtils.isBlank(noInCveDettipocomp)) {
			consulta = consulta.append("and cp.cveDettipocomp not in (:noInCveDettipocomp ) ");
		}
		if (detCodigo != null) {
			consulta = consulta.append("and cp.codTransac = :detCodigo ");
		}
		if (!StringUtils.isBlank(cpbCodigoref)) {
			consulta = consulta.append("and cp.cpbCodigoref = :cpbCodigoref ");
		}

		if (esqCodigo != null) {
			consulta = consulta.append("and cp.esqCodigo = :esqCodigo ");
		}

		consulta = consulta.append("order by cp.cpbCodigo ");

		Query query = getSession().createQuery(consulta.toString());

		query.setParameter("opeCodigo", opeCodigo);

		if (!StringUtils.isBlank(cveEstadocpb)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(cveEstadocpb.split(",")));
			query.setParameterList("cveEstadocpb", estadosList);
		}

		if (!StringUtils.isBlank(inCveDettipocomp)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(inCveDettipocomp.split(",")));
			query.setParameterList("cveDettipocomp", estadosList);
		}

		if (!StringUtils.isBlank(noInCveDettipocomp)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(noInCveDettipocomp.split(",")));
			query.setParameterList("noInCveDettipocomp", estadosList);

		}

		if (detCodigo != null) {
			query.setParameter("detCodigo", detCodigo);
		}
		if (!StringUtils.isBlank(cpbCodigoref)) {
			query.setParameter("cpbCodigoref", cpbCodigoref);
		}
		if (esqCodigo != null) {
			query.setParameter("esqCodigo", esqCodigo);
		}

		log.info("Entre a buscar comprobantesByOpeCodigo : [opeCodigo: " + opeCodigo + "; cveEstadocpb: " + cveEstadocpb + " detCodigo: " + detCodigo
				+ " ;cveDettipocomp: " + inCveDettipocomp + "; esqCodigo: " + esqCodigo + "] noInCveDettipocomp " + noInCveDettipocomp + "::::"
				+ consulta.toString());

		lista = query.list();

		return lista;
	}

	public SocComprobante getComprobante(String id) {
		log.info("Entre a buscar el objeto con el id: " + id);

		SocComprobante comprobante = null;

		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select cp ");
		consulta = consulta.append("from SocComprobante cp ");
		consulta = consulta.append("where cp.cpbCodigo = :cpbCodigo ");

		Query query = getSession().createQuery(consulta.toString());

		query.setParameter("cpbCodigo", id);

		List lista = query.list();

		if (lista.size() > 0) {
			comprobante = (SocComprobante) lista.get(0);
		}

		return comprobante;
	}

	public SocComprobante getComprobanteByNroComprob(String cpbNrocpbte, Integer cpbGestion) {
		log.debug("Entre a buscar el NroComprob: " + cpbNrocpbte);

		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select cp ");
		consulta = consulta.append("from SocComprobante cp ");
		consulta = consulta.append("where cp.cpbNrocpbte = :cpbNrocpbte ");
		consulta = consulta.append("and cp.cveEstadocpb = :cveEstadocpb ");
		consulta = consulta.append("and cp.cpbGestion = :cpbGestion ");
		Query query = getSession().createQuery(consulta.toString());

		String cveEstadocpb = Constants.CLAVE_ESTCOMP_CONTAB;
		query.setParameter("cpbNrocpbte", cpbNrocpbte);
		query.setParameter("cveEstadocpb", cveEstadocpb);
		query.setParameter("cpbGestion", cpbGestion);

		List lista = query.list();
		if (lista.size() > 0) {
			return (SocComprobante) lista.get(0);
		}

		return null;
	}

	public String CrearComprobante(String tipo, SocSolicitudes solicitud, List<SocDetallessol> detalles) {
		String codComprobante = "";
		int monUS = Constants.COD_MONEDA_USD;
		SocDetallessol detalle = detalles.get(0);

		log.info("Creando el comprobante: " + solicitud.getSocCorrelativo() + " para tipo " + tipo);

		DateTime hoy = new DateTime();
		Date hoy1 = new Date();

		BigDecimal tc = QueryProcessor.getTipoCambio(monUS, hoy1);

		codComprobante = Long.toString(hoy1.getTime());

		SocComprobante comprobante = new SocComprobante(codComprobante, solicitud.getSocCodigo(), hoy.getYear(), hoy.getMonthOfYear(), hoy.getDayOfMonth(),
				tc, Glosa.crearGlosa(tipo, solicitud, detalle.getDetConcepto()));

		this.saveOrUpdate(comprobante);
		log.info("Comprobante guardado: " + comprobante.getCpbCodigo());
		return comprobante.getCpbCodigo();

	}

	private SocComprobante nuevoComprobante(String socCodigo, String glosa, Integer esqCodigo, String cveDettipocomp, Integer detCodigo, String cpbCodigoref,
			String genera) {

		// cveDettipocomp : O Operacion principal; P:provision, U: utiles, I:itf
		Date fecha = new Date();
		DateTime fechaComprob = new DateTime(fecha);

		BigDecimal tc = QueryProcessor.getTipoCambio(Constants.COD_MONEDA_USD, fecha);

		SocComprobante comprobante = null;

		List<SocComprobante> lista = comprobantesByOpeCodigo(socCodigo, detCodigo, cpbCodigoref, null, cveDettipocomp, null, esqCodigo);

		if (lista == null || lista.size() == 0) {
			Date hoy = new Date();
			String codComprobante = Long.toString(hoy.getTime());
			codComprobante = socCodigo.substring((socCodigo.length() - 6)).concat(codComprobante.substring(6));
			comprobante = new SocComprobante(codComprobante, socCodigo, fechaComprob.getYear(), fechaComprob.getMonthOfYear(), fechaComprob.getDayOfMonth(),
					tc, glosa);

			comprobante.setCveDettipocomp(cveDettipocomp);
			comprobante.setCpbFecha(fecha);
			comprobante.setEsqCodigo(esqCodigo);
			comprobante.setCveEstadocpb(Constants.CLAVE_ESTCOMP_PEND);
			comprobante.setCpbCodigoref(cpbCodigoref);
			comprobante.setCodTransac(detCodigo);
			comprobante.setGenera(genera);

			comprobante.setFechaHora(new Date());
			comprobante.setEstacion("Esta");
			comprobante.setUsrCodigo("user");

			// saveOrUpdate(comprobante);

			log.info("comprobante creado: " + comprobante.toString());
		} else {
			if (lista.size() > 1) {
				throw new BusinessException("Existe mas de una operacion contable para [solicitud= " + socCodigo + ", dettipocomprob= " + cveDettipocomp
						+ "] no puede continuar comunique al administrador");
			}
			// el comprobante existe
			comprobante = lista.get(0);

			if (StringUtils.isBlank(comprobante.getCveEstadocpb()) || comprobante.getCveEstadocpb().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
				throw new BusinessException("La operacion contable con estado [" + comprobante.getCveEstadocpb() + "] invalido no puede modificar");
			}

			comprobante.setCpbGestion(fechaComprob.getYear());
			comprobante.setCpbPeriodo(fechaComprob.getMonthOfYear());
			comprobante.setCpbDia(fechaComprob.getDayOfMonth());
			comprobante.setCpbTipocambio(tc);
			comprobante.setCpbGlosa(glosa);
			comprobante.setCpbFecha(fecha);
			comprobante.setEsqCodigo(esqCodigo);
			comprobante.setCpbCodigoref(cpbCodigoref);
			comprobante.setCodTransac(detCodigo);
			comprobante.setGenera(genera);
			comprobante.setFechaHora(new Date());
			comprobante.setEstacion("Esta");
			comprobante.setUsrCodigo("user");

			// saveOrUpdate(comprobante);
			log.info("comprobante modificado: " + comprobante.toString());
		}

		// QueryProcessor.flush();

		return comprobante;
	}

	public List<ComprobanteDet> comprobantesGenerados(String opeCodigo) {
		SocFacturasDao socFacturasDao = new SocFacturasDao();
		socFacturasDao.setSessionFactory(getSessionFactory());

		List<ComprobanteDet> comprobanteList = new ArrayList<ComprobanteDet>();

		List<SocComprobante> lista = comprobantesByOpeCodigo(opeCodigo, null, null, null, null, Constants.CLAVE_TIPOESQ_OPER, null);

		for (SocComprobante res : lista) {
			ComprobanteDet comprobante = new ComprobanteDet();

			comprobante.setCpbCodigo(res.getCpbCodigo());
			comprobante.setCpbFecha(res.getCpbFecha());
			comprobante.setCpbGlosa(res.getCpbGlosa());
			comprobante.setCveEstado(res.getCveEstadocpb());
			comprobante.setCpbNrocpbte(res.getCpbNrocpbte());
			comprobante.setCpbTipocambio(res.getCpbTipocambio());
			comprobante.setCveDettipocomp(res.getCveDettipocomp());
			comprobante.setCodTransac(res.getCodTransac());
			comprobante.setEsqCodigo(res.getEsqCodigo());
			comprobante.setCodUsuario(res.getUsrCodauto());

			List<SocFacturas> socFacturasLista = socFacturasDao.getFacturas(comprobante.getCpbCodigo());
			comprobante.setSocFacturasLista(socFacturasLista);

			comprobanteList.add(comprobante);
		}
		return comprobanteList;
	}

	public List<ComprobanteDet> recuperarComprobReng(String cpbCodigo) {
		List<ComprobanteDet> comprobanteList = new ArrayList<ComprobanteDet>();
		String query = "select c.cpb_codigo,c.cpb_fecha,r.ren_codigo,r.cta_movimiento,r.cla_debehaber,r.ren_tipocambio,r.ren_montomo,r.ren_montomn,r.ren_afectable,r.ren_glosa,r.moneda,r.cla_debehaber,c.cpb_glosa, ";
		query = query.concat("(select s.cta_nommovimiento from soc_cuentassol s where s.cta_afectable = r.ren_afectable and s.moneda = r.moneda "
				+ "and s.cta_codigo = (select min(s0.cta_codigo) from soc_cuentassol s0 where s0.cta_movimiento = s.cta_movimiento AND s0.moneda = s.moneda)) cta_nommovimiento ");
		query = query.concat("from soc_rengscomp r, soc_comprobante c ");
		query = query.concat("where c.cpb_codigo = r.cpb_codigo ");
		query = query.concat("and c.cpb_codigo = :cpbCodigo ");
		query = query.concat("order by r.ren_codigo ");

		try {
			log.info("Consulta comprobantes reng " + query);
			Query consulta = getSession().createSQLQuery(query);

			consulta.setParameter("cpbCodigo", cpbCodigo);

			List lista = consulta.list();
			List<Map<String, Object>> resultado = UtilsQNatives.convertListToMap(lista,
					"cpb_codigo,cpb_fecha,ren_codigo,cta_movimiento,cla_debehaber,ren_tipocambio,ren_montomo,ren_montomn,ren_afectable,ren_glosa,moneda,cla_debehaber,cpb_glosa,cta_nommovimiento"
							.split(","));

			for (Map<String, Object> res : resultado) {
				ComprobanteDet comprobante = new ComprobanteDet();

				comprobante.setCpbCodigo((String) res.get("cpb_codigo"));
				comprobante.setCpbFecha((Date) res.get("cpb_fecha"));
				comprobante.setRenCodigo((Integer) res.get("ren_codigo"));
				comprobante.setCtaMovimiento((String) res.get("cta_movimiento"));
				comprobante.setMovi((String) res.get("cta_nommovimiento"));
				comprobante.setClaDebehaber(String.valueOf(((Character) res.get("cla_debehaber"))));
				comprobante.setRenTipocambio((BigDecimal) res.get("ren_tipocambio"));
				comprobante.setRenMontomo((BigDecimal) res.get("ren_montomo"));
				comprobante.setRenMontomn((BigDecimal) res.get("ren_montomn"));
				comprobante.setRenAfectable((String) res.get("ren_afectable"));
				comprobante.setRenGlosa((String) res.get("ren_glosa"));
				comprobante.setCodMoneda((Integer) res.get("moneda"));
				comprobante.setDebe(BigDecimal.ZERO);
				comprobante.setHaber(BigDecimal.ZERO);

				if (comprobante.getClaDebehaber().equals("D")) {
					comprobante.setDebe(comprobante.getRenMontomn());
				} else {
					comprobante.setHaber(comprobante.getRenMontomn());
				}
				comprobanteList.add(comprobante);
			}
		} catch (Exception e) {
			log.error("Error al recuperar comprobante: " + e.getMessage(), e);
			throw new BusinessException("Error al recuperar comprobante: " + e.getMessage(), e);
		}
		return comprobanteList;
	}

	private SocComprobante creaComprobante(Solicitud solicitud, SocEsquemas socEsquemas, Integer detCodigo, String cveDettipocomp, String cpbCodigoref,
			String genera, Map<String, Object> paramsGlosa) {

		log.info("+++En generar COMPROBANTE SOLO : " + solicitud.getSolicitud().toString() + " cveDettipocomp " + cveDettipocomp + " tipoComprob ==> "
				+ socEsquemas.getEsqCodigo() + " [" + solicitud.getCodEstacionAudit() + ":" + solicitud.getCodUsuarioAudit() + " - "
				+ solicitud.getCodUsuarioCont() + "]");

		RenglonesComprobantes renglonesComprobantes = new RenglonesComprobantes();
		renglonesComprobantes.setSessionFactory(getSessionFactory());
		// /////////////////////////////

		String glosaComprob = renglonesComprobantes.generarGlosa(solicitud, socEsquemas.getGlosaComp(), null, paramsGlosa);
		// ahora se hace el comprobante total
		SocComprobante socComprobante = nuevoComprobante(solicitud.getSolicitud().getSocCodigo(), glosaComprob, socEsquemas.getEsqCodigo(), cveDettipocomp,
				detCodigo, cpbCodigoref, genera);

		socComprobante.setFechaHora(new Date());
		socComprobante.setEstacion(solicitud.getCodEstacionAudit());
		socComprobante.setUsrCodigo(solicitud.getCodUsuarioAudit());
		socComprobante.setUsrCodauto(solicitud.getCodUsuarioCont());

		socComprobante = this.getHibernateTemplate().merge(socComprobante);

		socComprobante = getComprobante(socComprobante.getCpbCodigo());
		log.info("Comprobante creado:: " + socComprobante.toString());

		List<SocRengscomp> socRengscompLista = renglonesComprobantes.crearRengscomp(solicitud, detCodigo, socComprobante, socEsquemas, paramsGlosa);

		if (socRengscompLista.size() == 0) {
			log.info("Eliminando comprobante por no tener renglones " + socEsquemas.getEsqCodigo());
			this.getHibernateTemplate().delete(socComprobante);
			return null;
		}

		return socComprobante;
	}

	public SocComprobante generaComprobante(Solicitud solicitud, SocEsquemas socEsquemas, Integer detCodigo, String cveDettipocomp, String cpbCodigoref,
			Map<String, Object> paramsGlosa) {

		SocComprobante socComprobante = creaComprobante(solicitud, socEsquemas, detCodigo, cveDettipocomp, cpbCodigoref, null, paramsGlosa);
		if (socComprobante == null) {
			return null;
		}
		generaComprobanteITF(solicitud, socComprobante);
		return socComprobante;
	}

	private void generaComprobanteITF(Solicitud solicitud, SocComprobante socComprobante) {
		if (socComprobante.getCveDettipocomp().equals(Constants.CLAVE_TIPOESQ_ITF)
				|| socComprobante.getCveDettipocomp().equals(Constants.CLAVE_TIPOESQ_OPER)) {
			return;
		}
		log.info("Ingresando a calculo vars. itf cbp: " + socComprobante.getCpbCodigo());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());

		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		BigDecimal sumaITF = BigDecimal.ZERO;
		BigDecimal sumaITFMN = BigDecimal.ZERO;

		Map<String, BigDecimal> mapaITF = new HashMap<String, BigDecimal>();

		List<SocRengscomp> socRengscompLista = socRengscompDao.getRenglones(socComprobante.getCpbCodigo());
		boolean ctaBenefConITF = true;
		// el itf se cobra a la transferencia no asi a la comision
		for (SocRengscomp socRengscomp : socRengscompLista) {
			if (socRengscomp.getClaDebehaber().equals('D') && socRengscomp.getMoneda().equals(Constants.COD_MONEDA_USD)) {
				// se cobra itf o no
				SocCuentassol socCuentassol = socCuentassolDao.getCtaITF(socRengscomp.getRenAfectable());

				if (socCuentassol != null) {
					// genera itf
					log.info("Renglon cobra itf " + socRengscomp.getId().getCpbCodigo() + ":" + socRengscomp.getId().getRenCodigo() + "=>"
							+ socRengscomp.getRenMontomo());

					if (!mapaITF.containsKey(socRengscomp.getRenAfectable())) {
						mapaITF.put(socRengscomp.getRenAfectable(), BigDecimal.ZERO);
					}

					sumaITF = mapaITF.get(socRengscomp.getRenAfectable()).add(socRengscomp.getRenMontomo()).setScale(2, BigDecimal.ROUND_HALF_UP);
					mapaITF.put(socRengscomp.getRenAfectable(), sumaITF);
				}
			}

			if (socRengscomp.getClaDebehaber().equals('H')) {
				if (!StringUtils.isBlank(socRengscomp.getTipoTransfer())) {
					if (socRengscomp.getTipoTransfer().equals(Constants.CVE_TCONCEPTO_REGALIAS)) {
						ctaBenefConITF = false;
					} else if (socRengscomp.getTipoTransfer().equals(Constants.CVE_TCONCEPTO_IDH)) {
						ctaBenefConITF = false;
					}
				}
			}
		}

		if (mapaITF.size() > 0 && ctaBenefConITF) {
			log.info("Control de cobro de ITF por IDH o REegalias");
			SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
			socDetallessolDao.setSessionFactory(getSessionFactory());

			List<SocDetallessol> socDetallessolLista = socDetallessolDao.getDetalles(solicitud.getSolicitud().getSocCodigo());

			for (SocDetallessol socDetallessol : socDetallessolLista) {
				SocCuentassol socCuentassol = socCuentassolDao.getByAfectable(socDetallessol.getNroCuentabcointer());
				if (socCuentassol != null) {
					if (solicitud.getSolicitud().getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {

						SocCuentaslocDao socCuentaslocDao = new SocCuentaslocDao();
						socCuentaslocDao.setSessionFactory(getSessionFactory());

						List<SocCuentasloc> socCuentaslocLista = socCuentaslocDao.cuentasBeneficiarioLoc(null, null, socDetallessol.getBenCodigo(),
								socDetallessol.getNroCuentabco(), null, socCuentassol.getCtaAfectable(), null);

						if (socCuentaslocLista.size() > 0) {
							// si existe la cuenta se verifica el concepto si es
							// regalias o idh
							SocCuentasloc socCuentasloc = socCuentaslocLista.get(0);
							if (!StringUtils.isBlank(socCuentasloc.getCveTconcepto())) {
								if (socCuentasloc.getCveTconcepto().equals(Constants.CVE_TCONCEPTO_REGALIAS)
										|| socCuentasloc.getCveTconcepto().equals(Constants.CVE_TCONCEPTO_IDH)) {
									// regalias or idh
									log.info("Comprobante de ITF SIN efecto!!! por tipo concepto: " + socCuentasloc.getCveTconcepto());
									ctaBenefConITF = false;
									break;
								}

							}
						}
					}
				}
			}
		}

		if (mapaITF.size() > 0 && ctaBenefConITF) {
			// si la cuenta es afectable para cobro de itf
			// se verifica si la cta del beneficiario tiene concepto de idh o
			// regalias

			log.info("=============" + socComprobante.getEsqCodigo() + "============" + mapaITF.size());
			SocParametrosDao socParametrosDao = new SocParametrosDao();
			socParametrosDao.setSessionFactory(getSessionFactory());

			SocParametros socParametros = socParametrosDao.getByCodigo("@itf");

			String porcITF = socParametros.getParValor();
			BigDecimal porcITFConvert = UtilsGeneric.bigDecimalFromString(porcITF.trim());

			BigDecimal porcentajeITF = porcITFConvert.divide(BigDecimal.valueOf(100));
			Integer detcodigo = 0;

			for (Map.Entry<?, ?> entry : mapaITF.entrySet()) {
				sumaITF = (BigDecimal) entry.getValue();
				String ctaAfectable = (String) entry.getKey();

				log.info("sumaITFsumaITFsumaITF" + sumaITF);
				BigDecimal montoITF = sumaITF.multiply(porcentajeITF).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

				Map<String, Object> montoConvertido = UtilsSioc.conversion(montoITF, Constants.COD_MONEDA_USD, Constants.COD_MONEDA_BS,
						socComprobante.getCpbFecha(), null, "C");

				BigDecimal montoMN = (BigDecimal) montoConvertido.get("montobs");
				BigDecimal tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomoxbs");

				if (montoMN.compareTo(BigDecimal.valueOf(0.10)) > 0) {
					log.info("Generando comprobante de ITF de padre: " + socComprobante.getCpbCodigo());
					socOpecomiDao.crearRegistro(solicitud.getSolicitud(), solicitud.getSolicitud().getSocCodigo(), detcodigo, "ITFMO-" + ctaAfectable,
							sumaITFMN, sumaITF, Constants.COD_MONEDA_USD, null, null, null, ctaAfectable, "V", tipocambiomoxbs);

					socOpecomiDao.crearRegistro(solicitud.getSolicitud(), solicitud.getSolicitud().getSocCodigo(), detcodigo, "PORCITF-" + ctaAfectable,
							porcITFConvert, porcITFConvert, Constants.COD_MONEDA_BS, null, null, null, ctaAfectable, "V", tipocambiomoxbs);

					socOpecomiDao.crearRegistro(solicitud.getSolicitud(), solicitud.getSolicitud().getSocCodigo(), detcodigo, "ITF-" + ctaAfectable, montoMN,
							montoITF, Constants.COD_MONEDA_USD, null, null, null, socComprobante.getEsqCodigo() + ctaAfectable, "V", tipocambiomoxbs);

					// redondeto de decimales
					BigDecimal redITF = montoMN.divide(BigDecimal.valueOf(1), 0, RoundingMode.HALF_UP);

					if (redITF.compareTo(BigDecimal.ZERO) == 0) {
						// el monto es menor a 0.50 bs
						redITF = BigDecimal.ONE;
					}
					// monto entero redondeado
					socOpecomiDao.crearRegistro(solicitud.getSolicitud(), solicitud.getSolicitud().getSocCodigo(), detcodigo, "ITFENT-" + ctaAfectable,
							redITF, redITF, Constants.COD_MONEDA_BS, null, null, null, ctaAfectable, "V", BigDecimal.ONE);

					BigDecimal difCentavos = montoMN.subtract(redITF);

					socOpecomiDao.crearRegistro(solicitud.getSolicitud(), solicitud.getSolicitud().getSocCodigo(), detcodigo, "ITFDIF-" + ctaAfectable,
							difCentavos, difCentavos.abs(), Constants.COD_MONEDA_BS, null, null, null, ctaAfectable, "V", BigDecimal.ONE);

					/**************/
					SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
					socEsquemasDao.setSessionFactory(getSessionFactory());

					SocEsquemas socEsquemasIFT = socEsquemasDao.esquemaByCodTipooperacion(Constants.CLAVE_TIPOOPER_ITF);

					Map<String, Object> mapaParametros = new HashMap<String, Object>();
					mapaParametros.put("@ITFMO", sumaITF);
					mapaParametros.put("@PORCITF", porcITFConvert);
					mapaParametros.put("@ITF", montoITF);

					creaComprobante(solicitud, socEsquemasIFT, 0, Constants.CLAVE_TIPOESQ_ITF, socComprobante.getCpbCodigo(), ctaAfectable, mapaParametros);
				}
			}
		}
	}

	/**
	 * Genera comprobantes de la solicitud
	 * 
	 * @param solicitudTO
	 */
	public void procesarSolicitud(Solicitud solicitudTO) {
		// /////////////////////////////
		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());

		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud(solicitudTO.getSolicitud().getSocCodigo());
		solicitudTO.setSolicitud(socSolicitudes);

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitudTO.getSolicitud().getEsqCodigo());

		log.info("===> inicio registro COMPROBANTES " + socSolicitudes.getSocCodigo());
		// eliminamos todos los comprobantes en estado P pendiente
		eliminarComprobante(socSolicitudes.getSocCodigo(), null, null);

		/*****/
		// / comomprobante de provision para operacoines con cta fiscal///****/

		Integer ordenComprob = 0;
		List<SocComprobante> socComprobanteLista = comprobantesByOpeCodigo(socSolicitudes.getSocCodigo());

		for (SocComprobante socComprobante : socComprobanteLista) {
			// en teoria solo deberian estar compros contabilizados
			if (StringUtils.isBlank(socComprobante.getCpbNrocpbte())) {
				// error
				log.error("Comprobante " + socComprobante.getCpbCodigo() + " con estado " + socComprobante.getCveEstadocpb()
						+ " sin numero de NRO COMPROB coin");
				throw new BusinessException("Comprobante " + socComprobante.getCpbCodigo() + " con estado " + socComprobante.getCveEstadocpb()
						+ " sin numero de NRO COMPROB coin");
			}
			if (socComprobante.getCodTransac() != null && socComprobante.getCodTransac().compareTo(ordenComprob) >= 0) {
				ordenComprob = socComprobante.getCodTransac();
			}
		}
		/*****/
		// / comomprobante de provision para operacoines con cta fiscal o que la
		// provision no se haya realizado///****/

		if (socEsquemas.getCodEsqref() != null) {
			SocEsquemas socEsquemasPROVISION = socEsquemasDao.esquemaByCod(socEsquemas.getCodEsqref());
			List<SocComprobante> comprosProvision = comprobantesByOpeCodigo(socSolicitudes.getSocCodigo(), 0, null, Constants.CLAVE_ESTCOMP_CONTAB,
					Constants.CLAVE_TIPOESQ_PROV, null, socEsquemasPROVISION.getEsqCodigo());

			if (comprosProvision.size() == 0) {
				log.info("Operacion [" + socEsquemas.getEsqCodigo() + "]con provision [" + socEsquemasPROVISION.getEsqCodigo()
						+ "]pero el mismo no fue generado, se genera el comprobante ");

				generaComprobante(solicitudTO, socEsquemasPROVISION, 0, Constants.CLAVE_TIPOESQ_PROV, null, null);

				if (socSolicitudes.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_WS)) {
					socSolicitudesDao.cambiarEstadoSolicitud(socSolicitudes, null, Constants.CLAVE_ESTWS_PROV);
				}
			}
		}

		// generamos el cpb general de la solicitud
		SocComprobante socComprobante = generaComprobante(solicitudTO, socEsquemas, 0, Constants.CLAVE_TIPOESQ_OPER, null, null);

		if (socComprobante == null) {
			throw new BusinessException("Comprobante base de solicitud no creado !!!!");
		}

		// recuperamos los codigos de esquema inscritos en el esquema principal
		List<SocRengesq> socRengesqLista = socRengesqDao.getRengsEsquema(socEsquemas.getEsqCodigo());

		Map<Integer, SocEsquemas> mapaEsq = new HashMap<Integer, SocEsquemas>();
		Integer posi = 0;
		Integer codEsquema = 0;

		for (SocRengesq socRengesq : socRengesqLista) {
			if (!StringUtils.isBlank(socRengesq.getTipoCuenta()) && NumberUtils.isNumber(socRengesq.getTipoCuenta())) {
				codEsquema = Integer.valueOf(socRengesq.getTipoCuenta());
				log.info("Esq TipoCuenta " + codEsquema);
				if (socSolicitudes.getFechaCont() != null) {
					if (UtilsDate.compara(socSolicitudes.getFechaCont(), new Date()) != 0) {
						// si la fecha contable NO es igual a la fecha de hoy
						// se verifica si el esq es de provision
						SocEsquemas socEsquemasPROV = socEsquemasDao.esquemaByCod(codEsquema);

						mapaEsq.put(posi, socEsquemasPROV);
						posi++;
					}
				}
			}
		}

		for (SocRengesq socRengesq : socRengesqLista) {
			if (socSolicitudes.getFechaCont() != null) {
				if (!StringUtils.isBlank(socRengesq.getCtaDestorig()) && NumberUtils.isNumber(socRengesq.getCtaDestorig())) {
					codEsquema = Integer.valueOf(socRengesq.getCtaDestorig());

					log.info("Esq CtaDestorig " + codEsquema);
					if (UtilsDate.compara(socSolicitudes.getFechaCont(), new Date()) == 0) {
						// si la fecha contable NO es igual a la fecha de hoy
						// se verifica si el esq es de provision
						SocEsquemas socEsquemasPROV = socEsquemasDao.esquemaByCod(codEsquema);

						mapaEsq.put(posi, socEsquemasPROV);
						posi++;
					}
				}
			}
		}

		for (int i = 0; i < mapaEsq.size(); i++) {
			SocEsquemas socEsquemasCmp = mapaEsq.get(i);
			log.info("Armando compros [" + socEsquemasCmp.getEsqCodigo() + "]:");

			List<SocComprobante> lista = comprobantesByOpeCodigo(solicitudTO.getSolicitud().getSocCodigo(), 0, null, Constants.CLAVE_ESTCOMP_CONTAB, null,
					null, socEsquemasCmp.getEsqCodigo());

			if (lista.size() > 0) {
				// el esquema ya fue creado y contabilizado
				log.info("Comprob " + solicitudTO.getSolicitud().getSocCodigo() + " esq " + socEsquemasCmp.getEsqCodigo() + " ya fue contabilizado ");
				continue;
			}
			generaComprobante(solicitudTO, socEsquemasCmp, 0, Constants.CLAVE_TIPOESQ_PROV, socComprobante.getCpbCodigo(), null);
		}

		log.info("solicitud actualizada para fecha operacion " + socSolicitudes.getSocCodigo());
	}

	public void controlComprobantes(Solicitud solicitud) {

		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());

		List<SocComprobante> lista = comprobantesByOpeCodigo(solicitud.getSolicitud().getSocCodigo(), null, null, null, null, Constants.CLAVE_TIPOESQ_OPER,
				null);

		List<SocComprobante> lista0 = comprobantesByOpeCodigo(solicitud.getSolicitud().getSocCodigo(), null, null, null, Constants.CLAVE_TIPOESQ_OPER, null,
				null);
		log.info("Control de comprobantes " + solicitud.getSolicitud().getSocCodigo() + " compros.: " + lista.size());

		if (lista0.size() > 0)
			lista.add(lista0.get(0));

		for (SocComprobante socComprobante : lista) {
			if (socComprobante.getCveEstadocpb().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
				continue;
			}

			List<SocRengscomp> renglones = socRengscompDao.getRenglones(socComprobante.getCpbCodigo());

			if (renglones == null || renglones.size() == 0) {
				log.error("No se registraron ningun renglon sobre la solicitud " + solicitud.getSolicitud().getSocCodigo());
				throw new BusinessException("No se registraron ningun renglon sobre la solicitud " + solicitud.getSolicitud().getSocCodigo() + " EsqCodigo:"
						+ socComprobante.getEsqCodigo());
			}

			BigDecimal debe = BigDecimal.valueOf(0);
			BigDecimal haber = BigDecimal.valueOf(0);

			for (SocRengscomp reng : renglones) {
				if (reng.getClaDebehaber() == 'D') {
					debe = debe.add(reng.getRenMontomn());
				} else if (reng.getClaDebehaber() == 'H') {
					haber = haber.add(reng.getRenMontomn());
				}
			}

			BigDecimal diff = debe.subtract(haber).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

			log.info(socComprobante.getCpbCodigo() + ": Control en comprobante[" + socComprobante.getEsqCodigo() + ": "
					+ solicitud.getSolicitud().getClaTipo() + "-" + solicitud.getSolicitud().getCveSubtipooper() + "] monto dif.:" + diff + " entre el DEBE["
					+ debe.toPlainString() + "] y HABER [" + haber.toPlainString() + "]");

			if (diff.compareTo(BigDecimal.valueOf(0.00)) != 0) {
				throw new BusinessException(socComprobante.getCpbCodigo() + ": Diferencia en comprobante[" + socComprobante.getEsqCodigo() + ": "
						+ solicitud.getSolicitud().getClaTipo() + "-" + solicitud.getSolicitud().getCveSubtipooper() + "] monto dif.:" + diff
						+ " entre el DEBE[" + debe.toPlainString() + "] y HABER [" + haber.toPlainString() + "]");
			}
		}
	}

	public String obtenerNroEsquemaContbcb(SocComprobante socComprobante) {
		StringBuffer query = new StringBuffer();
		query.append("Select f_findesqcomprob(cpb_codigo) ");
		query.append("from soc_comprobante ");
		query.append("where cpb_codigo = :cpbCodigo ");

		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("cpbCodigo", socComprobante.getCpbCodigo());

		log.info("Entre a obtenerNroEsquemaContbcb [" + socComprobante.getCpbCodigo() + "] " + consulta.toString());

		String nroEsquema = null;
		List result = consulta.list();
		if (result.size() > 0)
			nroEsquema = (String) result.get(0);

		log.info("Comprobante " + socComprobante.getCpbCodigo() + " con Esquema : " + nroEsquema);
		return nroEsquema;
	}

	public List<SocRengscomp> completarCodigosMayores(String cpbCodigo) {
		ComprobanteDao comprobanteDao = new ComprobanteDao();
		comprobanteDao.setSessionFactory(SiocCoinService.getSessionFactory());
		
		SocRengscompDao socRengscompDao = new SocRengscompDao();
		socRengscompDao.setSessionFactory(getSessionFactory());
		
		List<SocRengscomp> socRengscompLista = socRengscompDao.getRenglones(cpbCodigo);
		log.info("Inicio actuali mayores para " + cpbCodigo);		
		for (SocRengscomp socRengscomp : socRengscompLista) {
			if (StringUtils.isBlank(socRengscomp.getSolCoddestorig()) && !StringUtils.isBlank(socRengscomp.getRenMayor())){
				String codmayor = comprobanteDao.getCodMayorFromNroMayor(socRengscomp.getRenMayor());
				socRengscomp.setSolCoddestorig(codmayor);
				socRengscompDao.saveOrUpdate(socRengscomp);
				log.info("Actualizado mayor " + codmayor + " para: " + socRengscomp.getId().getCpbCodigo() + "." + socRengscomp.getId().getRenCodigo() + " "  + socRengscomp.getRenMayor());
			}
		}
		
		socRengscompLista = socRengscompDao.getRenglones(cpbCodigo);
		return socRengscompLista;
		
//		query = query.append("update soc_rengscomp ");
//		query = query.append("set sol_coddestorig = ");
//		query = query.append("	(select cm.cod_mayor ");
//		query = query.append("	from contbcb:cuenta_mayor cm, contbcb:concepto_mayor com ");
//		query = query.append("	where cm.cod_mayor = com.cod_mayor ");
//		query = query.append("	and cm.nro_mayor = ren_mayor)  ");
//		query = query.append("where cpb_codigo = " +cpbCodigo+ " ");
//		query = query.append("and sol_coddestorig is null ");
//		
//		log.info("update sql " + query.toString());
//		Query consulta = getSession().createSQLQuery(query.toString());

		
		
	}

}
