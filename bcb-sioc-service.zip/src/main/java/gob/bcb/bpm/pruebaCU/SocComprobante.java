package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the soc_comprobante database table.
 * 
 */
@Entity
@Table(name="soc_comprobante")
public class SocComprobante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cpb_codigo")
	private String cpbCodigo;

	@Column(name="cod_transac")
	private Integer codTransac;

	@Column(name="cpb_dia")
	private Integer cpbDia;

    @Temporal( TemporalType.DATE)
	@Column(name="cpb_fecha")
	private Date cpbFecha;

	@Column(name="cpb_gestion")
	private Integer cpbGestion;

	@Column(name="cpb_glosa")
	private String cpbGlosa;

	@Column(name="cpb_nrocpbte")
	private String cpbNrocpbte;

	@Column(name="cpb_periodo")
	private Integer cpbPeriodo;

	@Column(name="cpb_tipocambio")
	private BigDecimal cpbTipocambio;

	@Column(name="cve_estadocpb")
	private String cveEstadocpb;

	@Column(name="cve_dettipocomp")
	private String cveDettipocomp;
	
	@Column(name="esq_codigo")
	private Integer esqCodigo;

	private String estacion;

	@Column(name="genera")
	private String genera;
	
	@Column(name="cpb_codigoref")
	private String cpbCodigoref;
	
    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="ope_codigo")
	private String opeCodigo;

	@Column(name="usr_codauto")
	private String usrCodauto;

	@Column(name="esq_cvetipocomprob")
	private String esqCvetipocomprob;
	
	@Column(name="esq_codesqcont")
	private String esqCodesqcont;	
	
	@Column(name="usr_codigo")
	private String usrCodigo;

    public SocComprobante() {
    }
    public SocComprobante(String cpbCodigo, String opeCodigo) {
        this.cpbCodigo = cpbCodigo;
        this.opeCodigo = opeCodigo;
      }

      public SocComprobante(String cpbCodigo, String opeCodigo, Integer cpbGestion,
          Integer cpbPeriodo, Integer cpbDia, 
          BigDecimal cpbTipocambio, String cpbGlosa) {
        this.cpbCodigo = cpbCodigo;
        this.opeCodigo = opeCodigo;
        this.cpbGestion = cpbGestion;
        this.cpbPeriodo = cpbPeriodo;
        this.cpbDia = cpbDia;
        this.cpbTipocambio = cpbTipocambio;
        this.cpbGlosa = cpbGlosa;
      }
      
      public SocComprobante(String cpbCodigo, String opeCodigo, Integer cpbGestion,
          Integer cpbPeriodo, Integer cpbDia, String cpbNrocpbte,
          BigDecimal cpbTipocambio, String cpbGlosa) {
        this.cpbCodigo = cpbCodigo;
        this.opeCodigo = opeCodigo;
        this.cpbGestion = cpbGestion;
        this.cpbPeriodo = cpbPeriodo;
        this.cpbDia = cpbDia;
        this.cpbNrocpbte = cpbNrocpbte;
        this.cpbTipocambio = cpbTipocambio;
        this.cpbGlosa = cpbGlosa;
      }

	public String getCpbCodigo() {
		return this.cpbCodigo;
	}

	public void setCpbCodigo(String cpbCodigo) {
		this.cpbCodigo = cpbCodigo;
	}

	public Integer getCodTransac() {
		return this.codTransac;
	}

	public void setCodTransac(Integer codTransac) {
		this.codTransac = codTransac;
	}

	public Integer getCpbDia() {
		return this.cpbDia;
	}

	public void setCpbDia(Integer cpbDia) {
		this.cpbDia = cpbDia;
	}

	public Date getCpbFecha() {
		return this.cpbFecha;
	}

	public void setCpbFecha(Date cpbFecha) {
		this.cpbFecha = cpbFecha;
	}

	public Integer getCpbGestion() {
		return this.cpbGestion;
	}

	public void setCpbGestion(Integer cpbGestion) {
		this.cpbGestion = cpbGestion;
	}

	public String getCpbGlosa() {
		return this.cpbGlosa;
	}

	public void setCpbGlosa(String cpbGlosa) {
		this.cpbGlosa = cpbGlosa;
	}

	public String getCpbNrocpbte() {
		return this.cpbNrocpbte;
	}

	public void setCpbNrocpbte(String cpbNrocpbte) {
		this.cpbNrocpbte = cpbNrocpbte;
	}

	public Integer getCpbPeriodo() {
		return this.cpbPeriodo;
	}

	public void setCpbPeriodo(Integer cpbPeriodo) {
		this.cpbPeriodo = cpbPeriodo;
	}

	public BigDecimal getCpbTipocambio() {
		return this.cpbTipocambio;
	}

	public void setCpbTipocambio(BigDecimal cpbTipocambio) {
		this.cpbTipocambio = cpbTipocambio;
	}

	public String getCveEstadocpb() {
		return this.cveEstadocpb;
	}

	public void setCveEstadocpb(String cveEstadocpb) {
		this.cveEstadocpb = cveEstadocpb;
	}

	public Integer getEsqCodigo() {
		return this.esqCodigo;
	}

	public void setEsqCodigo(Integer esqCodigo) {
		this.esqCodigo = esqCodigo;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getOpeCodigo() {
		return this.opeCodigo;
	}

	public void setOpeCodigo(String opeCodigo) {
		this.opeCodigo = opeCodigo;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public void setCveDettipocomp(String cveDettipocomp) {
		this.cveDettipocomp = cveDettipocomp;
	}
	public String getCveDettipocomp() {
		return cveDettipocomp;
	}
	public void setCpbCodigoref(String cpbCodigoref) {
		this.cpbCodigoref = cpbCodigoref;
	}
	public String getCpbCodigoref() {
		return cpbCodigoref;
	}
	
	public String getGenera() {
		return genera;
	}
	public void setGenera(String genera) {
		this.genera = genera;
	}
	public String getUsrCodauto() {
		return usrCodauto;
	}
	public void setUsrCodauto(String usrCodauto) {
		this.usrCodauto = usrCodauto;
	}
	public String getEsqCvetipocomprob() {
		return esqCvetipocomprob;
	}
	public void setEsqCvetipocomprob(String esqCvetipocomprob) {
		this.esqCvetipocomprob = esqCvetipocomprob;
	}
	public String getEsqCodesqcont() {
		return esqCodesqcont;
	}
	public void setEsqCodesqcont(String esqCodesqcont) {
		this.esqCodesqcont = esqCodesqcont;
	}
	@Override
	public String toString() {
		return "SocComprobante [cpbCodigo=" + cpbCodigo + ", codTransac=" + codTransac + ", cpbDia=" + cpbDia + ", cpbFecha=" + cpbFecha
				+ ", cpbGestion=" + cpbGestion + ", cpbGlosa=" + cpbGlosa + ", cpbNrocpbte=" + cpbNrocpbte + ", cpbPeriodo=" + cpbPeriodo
				+ ", cpbTipocambio=" + cpbTipocambio + ", cveEstadocpb=" + cveEstadocpb + ", cveDettipocomp=" + cveDettipocomp + ", esqCodigo="
				+ esqCodigo + ", estacion=" + estacion + ", genera=" + genera + ", cpbCodigoref=" + cpbCodigoref + ", fechaHora=" + fechaHora
				+ ", opeCodigo=" + opeCodigo + ", usrCodauto=" + usrCodauto + ", esqCvetipocomprob=" + esqCvetipocomprob + ", esqCodesqcont="
				+ esqCodesqcont + ", usrCodigo=" + usrCodigo + "]";
	}

	
}
