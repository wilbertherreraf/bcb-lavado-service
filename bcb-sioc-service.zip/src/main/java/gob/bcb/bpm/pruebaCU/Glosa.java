/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-bpm-pruebaCU
 * gob.bcb.bpm.pruebaCU
 * 21/09/2011 - 10:21:05
 * Creado por Cecilia Uriona
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Clase que contiene los metodos para crear los campos de un mensaje swift.
 * 
 * @author C. Cecilia Uriona
 * 
 */
public class Glosa {
	private static final Log log = LogFactory.getLog(Glosa.class);

	public static String crearGlosa(String tipo, SocSolicitudes sol, String ref) {
		String glosa = "";
		String query = "select val_nombre" + " from soc_valorescla " + " where cla_codigo = 'cla_glosa' " + " and val_codigo = '" + tipo + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "val_nombre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				log.info("resultado" + res.toString());
				String definicion = (String) res.get("val_nombre");
				glosa = getVars(definicion, sol,null, ref, null);
			}
		}
		log.info("Glosa de REF: " + ref + " GLOSA: " + glosa);
		return glosa;
	}
	public static String crearGlosa(SocSolicitudes sol, SocOperaciones operacion, Integer esqCodigo, String glosaComprob, String ref, Map<String, Object> paramsGlosa) {
		// whf: parche temporal se modifica glosas para TD por tipo de esquema
		String glosa = "";
		if (operacion.getClaOperacion().equalsIgnoreCase("TD")){
			log.info("Creando glosa crearGlosa por tipo Esq: " + esqCodigo + " GLOSA ANT: " + glosaComprob);			
			// 20140430 solo se aplica por ahora a Transgferencias del exterior
			SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
			socEsquemasDao.setSessionFactory(QueryProcessor.getSessionFactory());
			SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(esqCodigo);
			if (socEsquemas != null){
				String glosaComp = socEsquemas.getGlosaComp();
				
				if (!StringUtils.isBlank(glosaComp)){
					glosa = getVars(glosaComp, sol, operacion, ref, paramsGlosa);
				} else {
					glosa = glosaComprob;
				}
			} else {
				glosa = glosaComprob;
			}
			log.info("Glosa TD tipo Esq: " + esqCodigo + " GLOSA: " + glosa);			
		} else {
			glosa = glosaComprob;
			
		}
		
		return glosa;		
	}
	
	private static String getVars(String definicion, SocSolicitudes sol,SocOperaciones operacion,  String ref, Map<String, Object> paramsGlosa) {
		String var = "";
		String valor = "";
		int longitud = 0;

		int j = definicion.indexOf("@");
		if (j >= 0) {
			longitud = definicion.indexOf(" ", j);
			if (longitud > 0) {
				var = definicion.substring(j, longitud);
				valor = definicion.substring(0, j) + reemplazarVar(var, sol, operacion, ref, paramsGlosa) + getVars(definicion.substring(longitud), sol,operacion, ref, paramsGlosa);
			} else {
				var = definicion.substring(j);
				valor = definicion.substring(0, j) + reemplazarVar(var, sol, operacion, ref, paramsGlosa);
			}
		} else {
			valor = definicion;
		}

		return valor;
	}

	private static String reemplazarVar(String var, SocSolicitudes sol, SocOperaciones operacion, String ref, Map<String, Object> paramsGlosa) {
		String valor = "";

		if (var.equalsIgnoreCase("@corr")) {
			valor = sol.getSocCorrelativo();
		} else if (var.equalsIgnoreCase("@sol")) {
			valor = getSoli(sol.getSolCodigo());
		} else if (var.equalsIgnoreCase("@itf")) {
			valor = Servicios.getParam(var) + "%";
		} else if (var.equalsIgnoreCase("@sitf")) {
			valor = getSobreITF(sol, ref);
		} else if (var.equalsIgnoreCase("@sitfc")) {
			valor = getSobreITFComi(sol);

		} else if (var.equalsIgnoreCase("@ref")) {
			if (!StringUtils.isBlank(ref) && ref.charAt(0) == '/')
				if (ref.charAt(1) == 'I')
					valor = "PAGO FACTURA " + quitarLinea(ref.substring(5));
				else
					valor = ref.substring(5);
			else
				valor = quitarLinea(ref);
		} else if (var.equalsIgnoreCase("@swift")) {
			valor = "EXTRACTO BANCARIO";
		} else if (var.equalsIgnoreCase("@fechaoper")) {
			if (paramsGlosa != null && paramsGlosa.containsKey("fechaoper"))
				valor = UtilsDate.stringFromDate((Date) paramsGlosa.get("fechaoper"), "dd/MM/yyyy");
		} else if (var.equalsIgnoreCase("@nrocomprob")) {
			if (paramsGlosa != null && paramsGlosa.containsKey("@nrocomprob"))			
				valor = (String) paramsGlosa.get("@nrocomprob");			
		} else if (var.equalsIgnoreCase("@fecha")) {			
			Date fecha = new Date();
			valor = UtilsDate.stringFromDate(fecha, "dd/MM/yyyy");
		} else if (var.equalsIgnoreCase("@glosaref")) {		
			if (!StringUtils.isBlank(operacion.getGlosaRefencia())){
				valor = operacion.getGlosaRefencia();				
			}
		} else if (var.equalsIgnoreCase("@menswift")) {
			SocDetallesopeDao socDetallesopeDao = new SocDetallesopeDao();
			socDetallesopeDao.setSessionFactory(QueryProcessor.getSessionFactory());
			SocDetallesope socDetallesope =  socDetallesopeDao.getDetalle(operacion.getOpeCodigo(), 1);
			
			valor = socDetallesope.getDetInfo();
		}

		return valor;
	}

	private static String quitarLinea(String glosa) {
		String glosaCor = "";
		String glosa1 = "";
		String ln = "\r\n";

		int j = glosa.indexOf(ln);
		if (j > 0) {
			glosa1 = glosa.substring(0, j) + " " + glosa.substring(j + 2);
			j = glosa1.indexOf(ln);
			if (j > 0) {
				glosa1 = glosa1.substring(0, j) + " " + glosa1.substring(j + 2);
			}
			glosaCor = glosa1;
		} else
			glosaCor = glosa;

		return glosaCor;
	}

	private static String getSoli(String soli) {
		String valor = "";

		String query = " select sol_persona" + " from soc_solicitante " + " where sol_codigo = '" + soli + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "sol_persona".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				// log.info("resultado" + res.toString());
				valor = (String) res.get("sol_persona");
			}
		} else {
			log.info("Error al obtener solicitante");
		}

		return valor;
	}

	public static String getSobreITF(SocSolicitudes sol, String ref) {
		int monUS = 34;
		BigDecimal monto = BigDecimal.valueOf(0);
		String moneda = "";
		BigDecimal valor = BigDecimal.ZERO;
		String valorLit = "";
		
		if (sol.getClaTipo().equalsIgnoreCase("TC"))
			moneda = "USD";
		else
			moneda = sol.getMoneda();

		monto = sol.getSocMontome().divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

		if (!StringUtils.isBlank(ref) && ref.equalsIgnoreCase("OP")) {
			if (moneda.equalsIgnoreCase("USD")) {
				valor = monto;
			}
		} else {
			if (sol.getSocCuentad().equals(sol.getSocCuentac())) {
				if (moneda.equalsIgnoreCase("USD"))
					valor = (monto.add(Servicios.getComisiones(monto, sol.getClaTipo(), 1).divide(QueryProcessor.getTipoCambio(monUS, new Date()), 2,
							RoundingMode.HALF_UP)));
				else {
					BigDecimal montoUS = monto.multiply(QueryProcessor.getTipoCambio(Servicios.getMoneda(moneda), new Date())).divide(
							QueryProcessor.getTipoCambio(monUS, new Date()), 2, RoundingMode.HALF_UP);
					valor = (montoUS.add(Servicios.getComisiones(montoUS, sol.getClaTipo(), 1).divide(
							QueryProcessor.getTipoCambio(monUS, new Date()), 2, RoundingMode.HALF_UP)));
				}
			} else {
				if (moneda.equalsIgnoreCase("USD")) {
					valor = monto;
				} else {
					valor = (monto.multiply(QueryProcessor.getTipoCambio(Servicios.getMoneda(moneda), new Date())).divide(
							QueryProcessor.getTipoCambio(monUS, new Date()), 2, RoundingMode.HALF_UP));
				}
			}
		}

		valorLit = UtilsGeneric.formatearMonto(valor);

		return valorLit;
	}

	public static String getSobreITFComi(SocSolicitudes sol) {
		int monUS = 34;

		BigDecimal monto = sol.getSocMontome().divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);

		BigDecimal valor = (Servicios.getComisiones(monto, sol.getClaTipo(), 1).divide(QueryProcessor.getTipoCambio(monUS, new Date()), 2, RoundingMode.HALF_UP));

		String valorLit = UtilsGeneric.formatearMonto(valor);		
		return valorLit;
	}
}

