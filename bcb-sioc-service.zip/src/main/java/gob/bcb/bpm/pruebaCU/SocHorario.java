package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the soc_horario database table.
 * 
 */
@Entity
@Table(name="soc_horario")
public class SocHorario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="cod_operacion")
	private String codOperacion;

	@Column(name="cod_usuario")
	private String codUsuario;

	@Column(name="cve_estado_hor")
	private String cveEstadoHor;

	@Column(name="cla_tiporestricc")
	private String claTiporestricc;
	
	private String descrip;

	private String estacion;
	
	@Temporal(TemporalType.TIMESTAMP)	
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Temporal(TemporalType.TIME)
	@Column(name="hora_fin")
	private Date horaFin;

	@Temporal(TemporalType.TIME)	
	@Column(name="hora_ini")
	private Date horaIni;

    public SocHorario() {
    }

	public String getCodOperacion() {
		return this.codOperacion;
	}

	public void setCodOperacion(String codOperacion) {
		this.codOperacion = codOperacion;
	}

	public String getCodUsuario() {
		return this.codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public String getCveEstadoHor() {
		return this.cveEstadoHor;
	}

	public void setCveEstadoHor(String cveEstadoHor) {
		this.cveEstadoHor = cveEstadoHor;
	}

	public String getDescrip() {
		return this.descrip;
	}

	public void setDescrip(String descrip) {
		this.descrip = descrip;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getHoraFin() {
		return this.horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public Date getHoraIni() {
		return this.horaIni;
	}

	public void setHoraIni(Date horaIni) {
		this.horaIni = horaIni;
	}

	
	public String toString() {
		return "SocHorario [codOperacion=" + codOperacion + ", codUsuario=" + codUsuario + ", cveEstadoHor=" + cveEstadoHor + ", descrip=" + descrip
				+ ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", horaFin=" + horaFin + ", horaIni=" + horaIni + "]";
	}

	public String getClaTiporestricc() {
		return claTiporestricc;
	}

	public void setClaTiporestricc(String claTiporestricc) {
		this.claTiporestricc = claTiporestricc;
	}

}
