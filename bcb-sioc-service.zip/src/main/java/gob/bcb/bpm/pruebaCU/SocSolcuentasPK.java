package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_solcuentas database table.
 * 
 */
@Embeddable
public class SocSolcuentasPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "sol_codigo")
	private String solCodigo;

	@Column(name = "cta_codigo")
	private Integer ctaCodigo;

	@Column(name = "corr_cuenta")
	private Integer corrCuenta;
	
	public SocSolcuentasPK() {
	}

	public String getSolCodigo() {
		return this.solCodigo;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public Integer getCtaCodigo() {
		return this.ctaCodigo;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public Integer getCorrCuenta() {
		return corrCuenta;
	}

	public void setCorrCuenta(Integer corrCuenta) {
		this.corrCuenta = corrCuenta;
	}

	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((corrCuenta == null) ? 0 : corrCuenta.hashCode());
		result = prime * result + ((ctaCodigo == null) ? 0 : ctaCodigo.hashCode());
		result = prime * result + ((solCodigo == null) ? 0 : solCodigo.hashCode());
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocSolcuentasPK other = (SocSolcuentasPK) obj;
		if (corrCuenta == null) {
			if (other.corrCuenta != null)
				return false;
		} else if (!corrCuenta.equals(other.corrCuenta))
			return false;
		if (ctaCodigo == null) {
			if (other.ctaCodigo != null)
				return false;
		} else if (!ctaCodigo.equals(other.ctaCodigo))
			return false;
		if (solCodigo == null) {
			if (other.solCodigo != null)
				return false;
		} else if (!solCodigo.equals(other.solCodigo))
			return false;
		return true;
	}

	
	public String toString() {
		return "SocSolcuentasPK [solCodigo=" + solCodigo + ", ctaCodigo=" + ctaCodigo + ", corrCuenta=" + corrCuenta + "]";
	}

	
}
