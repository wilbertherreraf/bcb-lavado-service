package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_comitipoope database table.
 * 
 */
@Embeddable
public class SocComitipoopePK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cod_cargo")
	private Integer codCargo;

	@Column(name="cla_comision")
	private String claComision;

    public SocComitipoopePK() {
    }
	public Integer getCodCargo() {
		return this.codCargo;
	}
	public void setCodCargo(Integer codCargo) {
		this.codCargo = codCargo;
	}
	public void setClaComision(String claComision) {
		this.claComision = claComision;
	}
	public String getClaComision() {
		return claComision;
	}
	
	public String toString() {
		return "SocComitipoopePK [codCargo=" + codCargo + ", claComision=" + claComision + "]";
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((claComision == null) ? 0 : claComision.hashCode());
		result = prime * result + ((codCargo == null) ? 0 : codCargo.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocComitipoopePK other = (SocComitipoopePK) obj;
		if (claComision == null) {
			if (other.claComision != null)
				return false;
		} else if (!claComision.equals(other.claComision))
			return false;
		if (codCargo == null) {
			if (other.codCargo != null)
				return false;
		} else if (!codCargo.equals(other.codCargo))
			return false;
		return true;
	}
	
}
