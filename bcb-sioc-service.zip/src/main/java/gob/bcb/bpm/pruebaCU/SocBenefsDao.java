/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.utils.UtilsQNatives;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioTres.model.CuentaMovimiento;
import gob.bcb.service.servicioTres.model.CuentaMovimientoDao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author wherrera
 * 
 */
public class SocBenefsDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBenefsDao.class);

	public SocBenefs saveOrUpdate(SocBenefs socBenefs) {
		log.info("guardando benef exterior " + socBenefs.toString());

		SocBenefs socBenefsOld = getBenefsByBenCodigo(socBenefs.getBenCodigo());
		if (socBenefsOld == null) {
			String cod = generarCodigo();

			socBenefs.setBenCodigo(cod);
			socBenefs.setClaVigente(Short.valueOf("1"));
			socBenefs.setFechaHora(new Date());
		} else {
			socBenefs.setFechaHora(new Date());
		}

		validarDato(socBenefs);

		this.getHibernateTemplate().merge(socBenefs);
		socBenefsOld = getBenefsByBenCodigo(socBenefs.getBenCodigo());
		log.info("Salvado benef exterior " + socBenefs.toString());
		return socBenefsOld;
	}

	public void validarDato(SocBenefs socBenefs) {
		if (StringUtils.isBlank(socBenefs.getBenNombre())) {
			throw new BusinessException("Beneficiario con nombre invalido");
		}
		if (StringUtils.isBlank(socBenefs.getBenDireccion())) {
			throw new BusinessException("Beneficiario con direcciÃ³n invalida");
		}
		if (StringUtils.isBlank(socBenefs.getBenPlaza())) {
			throw new BusinessException("Beneficiario con plaza invalida");
		}
	}

	public SocBenefs getBenefsByBenCodigo(String benCodigo) {
		log.debug("Entre a buscar getBenefsByBenCodigo id: " + benCodigo);

		SocBenefs benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefs be ");
		query = query.append("where be.benCodigo = :benCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("benCodigo", benCodigo);

		List lista = consulta.list();

		if (lista.size() > 0) {
			benefs = (SocBenefs) lista.get(0);
		}

		return benefs;
	}

	public String generarCodigo() {
		StringBuffer query = new StringBuffer();
		query = query.append("select max(to_number(ben_codigo)) ");
		query = query.append("from soc_benefs ");
		query = query.append("where ben_codigo not matches '*[a-z|A-Z|.|,]*' ");

		Query consulta = getSession().createSQLQuery(query.toString());

		log.debug("Entre a generarCod " + consulta.toString());

		String codSolicitud = "0";
		Long codigo = Long.valueOf(0);

		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
			codigo++;
		} else {
			codigo = Long.valueOf(1);
		}

		codSolicitud = String.format("%06d", codigo);

		log.info("Cod solicitud nuevo: " + codSolicitud);
		return codSolicitud;
	}

	public List<SocBenefs> getBenefsBySolCodigo(String benCodigo, String solCodigo) {
		log.debug("Entre a buscar getBenefsBySolCodigo id: " + benCodigo);
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocBenefs be  ");
		query = query.append("where be.benNombre is not null ");

		if (!StringUtils.isBlank(benCodigo)) {
			query = query.append("and be.benCodigo = :benCodigo ");
		}
		if (!StringUtils.isBlank(solCodigo)) {
			query = query.append(
					"and exists (select 1 from SocSolbenefs sb where be.benCodigo = sb.id.benCodigo and trim(sb.id.solCodigo) = :solCodigo) ");
		}

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);
		}

		if (!StringUtils.isBlank(solCodigo)) {
			consulta.setParameter("solCodigo", solCodigo.trim());
		}

		List lista = consulta.list();

		return lista;
	}

	public List<CuentasBen> cuentasBenefLocal(String codSolicitante, String codBeneficiario, Integer detCtabenef, Integer codMoneda,
			String ctaNrocuenta, Integer ctaCodigocont, String ctaAfectable) {
		List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();
		String query = "SELECT bb.ben_codigo, bb.ben_nombre, cc.cta_codigo, cc.cta_nrocuenta, cc.cta_ctacodigo, ss.cta_movimiento, ";

		query = query.concat(
				"ss.moneda, ss.cta_nommovimiento, cc.cta_nombre, ben_factura, ben_nit, cc.cla_vigente cta_vigente, bb.cla_vigente ben_vigente,ss.cta_afectable ");
		query = query.concat("FROM soc_benefsloc bb, soc_cuentasloc cc, soc_cuentassol ss ");
		query = query.concat("WHERE bb.ben_codigo = cc.ben_codigo ");
		query = query.concat("AND cc.cta_ctacodigo = ss.cta_codigo ");

		if (!StringUtils.isBlank(codSolicitante)) {
			query = query
					+ "AND exists (select 1 from soc_solbenefsloc sb where sb.ben_codigo = bb.ben_codigo and sb.sol_codigo = :codSolicitante ) ";
		}

		if (!StringUtils.isBlank(codBeneficiario)) {
			query = query + "AND bb.ben_codigo = :codBeneficiario ";
		} else {
			query = query + "AND bb.cla_vigente = 1 ";
		}

		if (codMoneda != null) {
			query = query + "AND ss.moneda = :codMoneda ";
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			query = query + "AND cc.cta_nrocuenta = :ctaNrocuenta ";
		} else {
			query = query.concat("AND trim(cc.cta_nrocuenta) != '' ");
		}

		if (ctaCodigocont != null) {
			query = query + "AND cc.cta_ctacodigo = :ctaCodigocont ";
		}

		if (!StringUtils.isBlank(ctaAfectable)) {
			query = query + "AND ss.cta_afectable = :ctaAfectable ";
		}

		Query consulta = getSession().createSQLQuery(query);

		if (!StringUtils.isBlank(codSolicitante)) {
			consulta.setParameter("codSolicitante", codSolicitante);
		}

		if (!StringUtils.isBlank(codBeneficiario)) {
			consulta.setParameter("codBeneficiario", codBeneficiario);
		}

		if (codMoneda != null) {
			consulta.setParameter("codMoneda", codMoneda);
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			consulta.setParameter("ctaNrocuenta", ctaNrocuenta);
		}
		if (ctaCodigocont != null) {
			consulta.setParameter("ctaCodigocont", ctaCodigocont);
		}
		if (!StringUtils.isBlank(ctaAfectable)) {
			consulta.setParameter("ctaAfectable", ctaAfectable);
		}
		List lista = consulta.list();
		List<Map<String, Object>> resultado = UtilsQNatives.convertListToMap(lista,
				"ben_codigo, ben_nombre, cta_codigo, cta_nrocuenta, cta_ctacodigo, cta_movimiento, moneda, cta_nommovimiento, cta_nombre, ben_factura, ben_nit, cta_vigente, ben_vigente,cta_afectable"
						.split(","));

		CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
		cuentaMovimientoDao.setSessionFactory(SiocCoinService.getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());
		Integer ctaCodigo = null;
		try {
			for (Map<String, Object> res : resultado) {
				CuentasBen cuentasBen = new CuentasBen();
				ctaCodigo = (Integer) res.get("cta_codigo");
				cuentasBen.setCtaCodigo((Integer) res.get("cta_codigo"));
				cuentasBen.setCtaNroCuenta((String) res.get("cta_nrocuenta"));
				cuentasBen.setMoneda((Integer) res.get("moneda"));

				String ctaMovimiento = (String) res.get("cta_movimiento");

				CuentaMovimiento cuentaMovimiento = cuentaMovimientoDao.findCuentaMovimiento(ctaMovimiento);
				if (cuentaMovimiento != null) {
					cuentasBen.setBcoCodigo(cuentaMovimiento.getCodPersona().trim());

					SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(cuentaMovimiento.getCodPersona().trim());

					cuentasBen.setBcoNombre(cuentaMovimiento.getNomMovimiento());

					if (socSolicitante != null) {
						cuentasBen.setBcoNombre(socSolicitante.getSolPersona());
						cuentasBen.setCodBancoSigep(socSolicitante.getSolCodsigep());
					}
				}

				cuentasBen.setCtaNombre((String) res.get("cta_nommovimiento"));
				cuentasBen.setBenCodigo((String) res.get("ben_codigo"));
				cuentasBen.setBenNombre((String) res.get("ben_nombre"));
				cuentasBen.setNit((String) res.get("ben_nit"));
				cuentasBen.setFactura((String) res.get("ben_factura"));
				cuentasBen.setCtaVigente((Short) res.get("cta_vigente"));
				cuentasBen.setBenVigente((Short) res.get("ben_vigente"));
				cuentasBen.setCtaCodigoCont((Integer) res.get("cta_ctacodigo"));
				cuentasBen.setCtaMovimiento((String) res.get("cta_movimiento"));
				cuentasBen.setCtaNommovimiento((String) res.get("cta_nommovimiento"));
				cuentasBen.setCtaAfectable((String) res.get("cta_afectable"));

				listaCuentasB.add(cuentasBen);
			}
		} catch (Exception e) {
			log.error("Error al recuperar cuentas benef locales: " + e.getMessage(), e);
			throw new BusinessException(
					"Error al recuperar cuentas benef locales[" + codBeneficiario + ", ctaCodigo:" + ctaCodigo + "]: " + e.getMessage(), e);
		}

		if (listaCuentasB == null || listaCuentasB.size() == 0) {
			log.error("Consulta cuentasBenefLocal sin registros " + query);
		}
		return listaCuentasB;
	}

	public List<CuentasBen> cuentasBenefExterior(String codSolicitante, String codBenef, Integer ctaCodigo, Integer codMoneda, String bcoCodigo,
			String ctaNrocuenta, String bcoCodigoInter, String bcoNrocuentaben, String codSolicitanteCta, boolean filtrarVigente) {
		List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();

		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());

		String query = "SELECT be.ben_codigo, be.ben_nombre, be.ben_direccion, be.ben_plaza, be.ben_nit, be.ben_factura, cc.cta_codigo, cc.cta_nrocuenta, cc.cta_info, cc.moneda, bb.bco_codigo, bb.bco_nombre, cc.cla_esquema, ";
		query = query
				.concat("pp.pla_nombre, pp.pla_bic, cc.bco_nrocuentaben,cc.cla_vigente cta_vigente, bb.cla_vigente ben_vigente,cc.bco_codigointer, ");
		query = query.concat("(SELECT pp1.pla_bic ");
		query = query.concat("        FROM soc_plazas pp1, soc_bancos bb1 ");
		query = query.concat("        WHERE pp1.bco_codigo = bb1.bco_codigo ");
		query = query.concat("        AND bb1.bco_codigo = cc.bco_codigointer ");
		query = query.concat("    ) intermed_bic,  ");
		query = query.concat("(SELECT bb1.bco_nombre ");
		query = query.concat("        FROM soc_plazas pp1, soc_bancos bb1 ");
		query = query.concat("        WHERE pp1.bco_codigo = bb1.bco_codigo ");
		query = query.concat("        AND bb1.bco_codigo = cc.bco_codigointer ");
		query = query.concat("    ) intermed_bconombre,  ");
		query = query.concat("(SELECT pp1.pla_nombre ");
		query = query.concat("        FROM soc_plazas pp1, soc_bancos bb1 ");
		query = query.concat("        WHERE pp1.bco_codigo = bb1.bco_codigo ");
		query = query.concat("        AND bb1.bco_codigo = cc.bco_codigointer ");
		query = query.concat("    ) intermed_plazanombre  ");
		query = query.concat("FROM soc_benefs be, soc_cuentas cc, soc_plazas pp , soc_bancos bb ");
		query = query.concat("WHERE be.ben_codigo = cc.ben_codigo ");
		query = query.concat("AND cc.bco_codigo = pp.bco_codigo ");
		query = query.concat("AND cc.pla_codigo = pp.pla_codigo ");
		query = query.concat("AND pp.bco_codigo = bb.bco_codigo ");

		if (filtrarVigente) {
			query = query + "AND cc.cla_vigente = 1 ";
			query = query + "and pp.cla_vigente = 1 ";
		}

		if (!StringUtils.isBlank(codBenef)) {
			query = query + "AND be.ben_codigo = :codBenef ";
		}

		if (!StringUtils.isBlank(codSolicitante)) {
			query = query
					+ "AND exists (select 1 from soc_solbenefs ss where ss.ben_codigo = be.ben_codigo and trim(ss.sol_codigo) = :codSolicitante ) ";
		}

		if (codMoneda != null) {
			query = query + "and cc.moneda = :codMoneda ";
		}

		if (!StringUtils.isBlank(bcoCodigo)) {
			query = query + "AND bb.bco_codigo = :bcoCodigo ";
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			query = query + "AND trim(cc.cta_nrocuenta) = :ctaNrocuenta ";
		}

		if (!StringUtils.isBlank(bcoNrocuentaben)) {
			query = query + "AND trim(cc.bco_nrocuentaben) = :bcoNrocuentaben ";
		}

		if (!StringUtils.isBlank(codSolicitanteCta)) {
			query = query + "AND trim(cc.sol_codigo) = :codSolicitanteCta ";
		}

		log.info("Extraendo datos de cuentasB " + query);

		Query consulta = getSession().createSQLQuery(query);

		if (!StringUtils.isBlank(codBenef)) {
			consulta.setParameter("codBenef", codBenef);
		}

		if (!StringUtils.isBlank(codSolicitante)) {
			consulta.setParameter("codSolicitante", codSolicitante);
		}

		if (codMoneda != null) {
			consulta.setParameter("codMoneda", codMoneda);
		}

		if (!StringUtils.isBlank(bcoCodigo)) {
			consulta.setParameter("bcoCodigo", bcoCodigo);
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			consulta.setParameter("ctaNrocuenta", ctaNrocuenta);
		}

		if (!StringUtils.isBlank(bcoNrocuentaben)) {
			consulta.setParameter("bcoNrocuentaben", bcoNrocuentaben);
		}

		if (!StringUtils.isBlank(codSolicitanteCta)) {
			consulta.setParameter("codSolicitanteCta", codSolicitanteCta);
		}
		List lista = consulta.list();
		List<Map<String, Object>> resultado = UtilsQNatives.convertListToMap(lista,
				"ben_codigo,ben_nombre,ben_direccion,ben_plaza,ben_nit,ben_factura,cta_codigo,cta_nrocuenta,cta_info,moneda,bco_codigo,bco_nombre,cla_esquema,pla_nombre,pla_bic,bco_nrocuentaben,cta_vigente,ben_vigente,bco_codigointer,intermed_bic,intermed_bconombre,intermed_plazanombre"
						.split(","));
		Integer ctaCodigoBen = null;
		try {
			for (Map<String, Object> res : resultado) {
				CuentasBen cuentasBen = new CuentasBen();

				ctaCodigoBen = (Integer) res.get("cta_codigo");
				cuentasBen.setCtaCodigo((Integer) res.get("cta_codigo"));
				cuentasBen.setCtaNroCuenta((String) res.get("cta_nrocuenta"));
				cuentasBen.setCtaInfo((String) res.get("cta_info"));
				cuentasBen.setMoneda((Integer) res.get("moneda"));
				cuentasBen.setBcoCodigo((String) res.get("bco_codigo"));
				cuentasBen.setCodBancoSigep((String) res.get("bco_codigo"));
				cuentasBen.setBcoNombre((String) res.get("bco_nombre"));
				cuentasBen.setPlaNombre((String) res.get("pla_nombre"));
				cuentasBen.setPlaBic((String) res.get("pla_bic"));
				cuentasBen.setBcoCodigoI((String) res.get("bco_codigointer"));
				cuentasBen.setPlaIntermediario((String) res.get("intermed_bic"));
				cuentasBen.setPlaNroCuenta((String) res.get("bco_nrocuentaben"));
				cuentasBen.setBcoNombreI((String) res.get("intermed_bconombre"));
				cuentasBen.setPlaNombreI((String) res.get("intermed_plazanombre"));
				cuentasBen.setBenCodigo((String) res.get("ben_codigo"));
				cuentasBen.setBenNombre((String) res.get("ben_nombre"));
				cuentasBen.setBenDireccion((String) res.get("ben_direccion"));
				cuentasBen.setBenPlaza((String) res.get("ben_plaza"));
				cuentasBen.setNit((String) res.get("ben_nit"));
				cuentasBen.setFactura((String) res.get("ben_factura"));
				cuentasBen.setClaEsquema((String) res.get("cla_esquema"));
				cuentasBen.setCtaVigente((Short) res.get("cta_vigente"));
				cuentasBen.setBenVigente((Short) res.get("ben_vigente"));

				listaCuentasB.add(cuentasBen);
			}
		} catch (Exception e) {
			log.error("Error al recuperar cuentas benef exterior: " + e.getMessage(), e);
			throw new BusinessException(
					"Error al recuperar cuentas benef exterior[" + codBenef + ", ctaCodigo:" + ctaCodigoBen + "]: " + e.getMessage(), e);
		}

		if (listaCuentasB.size() == 0) {
			log.error("Consulta cuentasBenefExterior sin registros " + query);
		}
		return listaCuentasB;
	}

	/**
	 * recupera los datos de cuentas del beneficiario
	 * 
	 * @param socSolicitudes
	 * @param codBeneficiario
	 * @param detCtabenef
	 * @param codMoneda
	 * @param bcoCodigo
	 * @param ctaNrocuenta
	 * @param nombreBenef
	 * @param ctaCodigocont
	 * @param ctaAfectable
	 * @param codMttransfer
	 * @return
	 */
	public List<CuentasBen> recuperarCuentasB(SocSolicitudes socSolicitudes, String codBeneficiario, Integer codMoneda, String bcoCodigo,
			String ctaNrocuenta, Integer ctaCodigocont, String ctaAfectable) {
		List<CuentasBen> listaCuentasB = new ArrayList<CuentasBen>();

		if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA))) {
			// en el campo ctaAfectable detalle se guarda la cuenta de
			// movimiento de la entidad del beneficiario
			listaCuentasB = cuentasBenefLocal(socSolicitudes.getSolCodigo(), codBeneficiario, null, codMoneda, ctaNrocuenta, ctaCodigocont,
					ctaAfectable);

		} else if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {
			listaCuentasB = cuentasBenefExterior(socSolicitudes.getSolCodigo(), codBeneficiario, null, codMoneda, bcoCodigo, ctaNrocuenta, null, null,
					null, true);

		} else if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG))) {
			log.info("Cuenta benef de orden de pago " + codBeneficiario);
			CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
			cuentaMovimientoDao.setSessionFactory(SiocCoinService.getSessionFactory());

			SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
			socSolicitanteDao.setSessionFactory(getSessionFactory());

			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());

			List<SocCuentassol> socCuentassolLista = socCuentassolDao.findByClaveCuenta("ORDENESPAGO");
			if (socCuentassolLista.size() == 0) {
				throw new BusinessException("Cta afectable no registrada en socCuentassol: ORDENESPAGO");
			}

			SocCuentassol socCuentassol = socCuentassolLista.get(0);

			CuentasBen cuentasBen = new CuentasBen();

			cuentasBen.setCtaCodigo(socCuentassol.getCtaCodigo());
			cuentasBen.setCtaNroCuenta(socCuentassol.getCtaMovimiento());
			cuentasBen.setMoneda(socCuentassol.getMoneda());
			cuentasBen.setCtaNombre(socCuentassol.getCtaNommovimiento());
			cuentasBen.setCtaNommovimiento(socCuentassol.getCtaNommovimiento());
			cuentasBen.setBenCodigo(codBeneficiario);
			cuentasBen.setMonedaLit(String.valueOf(socCuentassol.getMoneda()));
			cuentasBen.setCtaCodigoCont(socCuentassol.getCtaCodigo());
			cuentasBen.setCtaMovimiento(socCuentassol.getCtaMovimiento());
			cuentasBen.setCtaVigente(Short.valueOf("1"));
			cuentasBen.setBenVigente(Short.valueOf("1"));
			cuentasBen.setCtaAfectable(socCuentassol.getCtaAfectable());

			CuentaMovimiento cuentaMovimiento = cuentaMovimientoDao.getCuentaMovimiento(socCuentassol.getCtaMovimiento());
			cuentasBen.setBcoCodigo(cuentaMovimiento.getCodPersona().trim());
			SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodigo(cuentaMovimiento.getCodPersona().trim());

			cuentasBen.setBcoNombre(cuentaMovimiento.getNomMovimiento());
			if (socSolicitante != null) {
				cuentasBen.setBcoNombre(socSolicitante.getSolPersona());
				cuentasBen.setCodBancoSigep(socSolicitante.getSolCodsigep());
			}
			listaCuentasB.add(cuentasBen);
		} else if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT))) {
			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());
			SocSolcuentasDao socSolcuentasDao = new SocSolcuentasDao();
			socSolcuentasDao.setSessionFactory(getSessionFactory());
			CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
			cuentaMovimientoDao.setSessionFactory(SiocCoinService.getSessionFactory());

			SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
			socSolicitanteDao.setSessionFactory(getSessionFactory());

			if (!StringUtils.isBlank(socSolicitudes.getTipoConcepto())) {
				if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)
						|| socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
					
					List<SocCuentassol> socCuentassolLista = socCuentassolDao.ctasSolicitante(codBeneficiario, null,
							ctaAfectable, codMoneda, null, null, null);
					for (SocCuentassol socCuentassol : socCuentassolLista) {
						CuentasBen cuentasBen = new CuentasBen();
						cuentasBen.setCtaCodigo(socCuentassol.getCtaCodigo());
						cuentasBen.setBenCodigo(codBeneficiario);
						cuentasBen.setMoneda(socCuentassol.getMoneda());
						cuentasBen.setMonedaLit(String.valueOf(socCuentassol.getMoneda()));
						cuentasBen.setCtaCodigoCont(socCuentassol.getCtaCodigo());
						cuentasBen.setCtaMovimiento(socCuentassol.getCtaMovimiento());
						cuentasBen.setCtaNommovimiento(socCuentassol.getCtaNommovimiento());
						cuentasBen.setCtaVigente(Short.valueOf("1"));
						cuentasBen.setBenVigente(Short.valueOf("1"));
						cuentasBen.setCtaAfectable(socCuentassol.getCtaAfectable());
						cuentasBen.setCtaNroCuenta(socCuentassol.getCtaMovimiento());
						cuentasBen.setCtaNombre(socCuentassol.getCtaNommovimiento());
						
						CuentaMovimiento cuentaMovimiento = cuentaMovimientoDao.getCuentaMovimiento(socCuentassol.getCtaMovimiento());
						cuentasBen.setBcoCodigo(cuentaMovimiento.getCodPersona().trim());
						cuentasBen.setBcoNombre(cuentaMovimiento.getNomMovimiento());
						
						if (!StringUtils.isBlank(ctaNrocuenta) && !StringUtils.isBlank(ctaAfectable)){
							// si existe nro de cuenta / libreta se busca en solcuentas
							List<SocSolcuentas> socSolcuentasLista = socSolcuentasDao.cuentasEnCuentaSolicitante(codBeneficiario, null, socCuentassol.getCtaAfectable(),
									null, ctaNrocuenta, null);
							if (socSolcuentasLista.size() == 0){
								// la cuenta del beneficiario no existe
								continue;
							}
							cuentasBen.setCtaNroCuenta(socSolcuentasLista.get(0).getCtaNumero());							
							cuentasBen.setCtaNombre(socSolcuentasLista.get(0).getCtaNombre());							
						}
						listaCuentasB.add(cuentasBen);						
					}
				} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ACREEDORES)) {
					List<SocCuentassol> socCuentassolLista = socCuentassolDao.findByClaveCuenta(Constants.COD_CLAVE_CTAACREEDORES);

					for (SocCuentassol socCuentassol : socCuentassolLista) {
						CuentasBen cuentasBen = new CuentasBen();
						cuentasBen.setCtaCodigo(socCuentassol.getCtaCodigo());
						cuentasBen.setBenCodigo(Constants.COD_BCB);
						cuentasBen.setMoneda(socCuentassol.getMoneda());
						cuentasBen.setMonedaLit(String.valueOf(socCuentassol.getMoneda()));
						cuentasBen.setCtaCodigoCont(socCuentassol.getCtaCodigo());
						cuentasBen.setCtaMovimiento(socCuentassol.getCtaMovimiento());
						cuentasBen.setCtaNommovimiento(socCuentassol.getCtaNommovimiento());
						cuentasBen.setCtaVigente(Short.valueOf("1"));
						cuentasBen.setBenVigente(Short.valueOf("1"));
						cuentasBen.setCtaAfectable(socCuentassol.getCtaAfectable());
						cuentasBen.setCtaNroCuenta(ctaNrocuenta);
						cuentasBen.setCtaNombre(socCuentassol.getCtaNommovimiento());
						cuentasBen.setBcoCodigo(Constants.COD_BCB);
						cuentasBen.setBcoNombre(socCuentassol.getCtaNommovimiento());
						listaCuentasB.add(cuentasBen);
					}
				} else {
					listaCuentasB = cuentasBenefLocal(socSolicitudes.getSolCodigo(), codBeneficiario, null, codMoneda, ctaNrocuenta, ctaCodigocont, ctaAfectable);
				}
			} else {

			}
		}

		return listaCuentasB;
	}

	public List<Beneficiario> beneficiariosLocalesSolicitante(String codSolicitante, String codBen, Integer codMoneda, Short claVigente) {
		log.info("Recuperando Benfs locales " + codSolicitante + " ben:" + codBen + " moneda:" + codMoneda + " vig: " + claVigente);
		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		List<SocBenefsloc> socBenefsLista = beneficiariosLocales(codSolicitante, codMoneda, codBen, claVigente);
		for (SocBenefsloc socBenefs : socBenefsLista) {
			Beneficiario benefi = new Beneficiario();

			benefi.setBenCodigo(socBenefs.getBenCodigo());
			benefi.setSolCodigo(codSolicitante);
			benefi.setBenNit(socBenefs.getBenNit());
			benefi.setBenFactura(socBenefs.getBenFactura());
			benefi.setBenNombre(socBenefs.getBenNombre());

			if (socBenefs.getClaVigente() != null)
				benefi.setClaEntidad(Integer.valueOf(socBenefs.getClaVigente()));

			beneficiarios.add(benefi);
		}

		return beneficiarios;
	}

	public List<Beneficiario> beneficiariosExternosSolicitante(String codSolicitante, String codBen, Integer codMoneda, Short claVigente,
			boolean verificaDirYPlaza) {
		log.info("Recuperando Benfs exterior " + codSolicitante + " ben:" + codBen + " moneda:" + codMoneda + " vig: " + claVigente);

		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		List<SocBenefs> socBenefsLista = beneficiariosExterior(codSolicitante, codMoneda, codBen, claVigente, verificaDirYPlaza);
		for (SocBenefs socBenefs : socBenefsLista) {
			Beneficiario benefi = new Beneficiario();
			benefi.setBenCodigo(socBenefs.getBenCodigo());
			benefi.setSolCodigo(codSolicitante);
			benefi.setBenNit(socBenefs.getBenNit());
			benefi.setBenFactura(socBenefs.getBenFactura());
			benefi.setBenNombre(socBenefs.getBenNombre());
			benefi.setBenDireccion(socBenefs.getBenDireccion());
			benefi.setBenPlaza(socBenefs.getBenPlaza());
			if (socBenefs.getClaVigente() != null)
				benefi.setClaEntidad(Integer.valueOf(socBenefs.getClaVigente()));

			beneficiarios.add(benefi);
		}
		return beneficiarios;
	}

	public List<SocBenefsloc> beneficiariosLocales(String solCodigo, Integer codMoneda, String benCodigo, Short claVigente) {
		String query = "SELECT bb ";
		query = query.concat("FROM SocSolbenefsloc ss, SocBenefsloc bb ");
		query = query.concat("WHERE ss.id.benCodigo = bb.benCodigo ");

		if (!StringUtils.isBlank(solCodigo))
			query = query.concat("AND trim(ss.id.solCodigo) = :solCodigo ");

		if (codMoneda != null)
			query = query + "and exists (select 1 from SocCuentasloc c where c.benCodigo = bb.benCodigo and c.moneda = :codMoneda ) ";

		if (!StringUtils.isBlank(benCodigo)) {
			query = query.concat("AND bb.benCodigo = :benCodigo ");
		} else {
			if (claVigente != null) {
				query = query.concat("and bb.claVigente = :claVigente ");
			}
		}

		query = query.concat("ORDER BY bb.benNombre ");

		log.info("Consulta benefs locales " + query + " solCodigo: " + solCodigo + " moneda : " + codMoneda);

		Query consulta = getSession().createQuery(query);

		if (!StringUtils.isBlank(solCodigo))
			consulta.setParameter("solCodigo", solCodigo.trim());

		if (codMoneda != null)
			consulta.setParameter("codMoneda", codMoneda);

		if (!StringUtils.isBlank(benCodigo))
			consulta.setParameter("benCodigo", benCodigo);

		if (claVigente != null)
			consulta.setParameter("claVigente", claVigente);
		List lista = consulta.list();

		return lista;
	}

	public List<SocBenefs> beneficiariosExterior(String solCodigo, Integer codMoneda, String benCodigo, Short claVigente, boolean verificaDirYPlaza) {
		String query = "SELECT bb ";
		query = query.concat("FROM SocSolbenefs ss, SocBenefs bb ");
		query = query.concat("WHERE ss.id.benCodigo = bb.benCodigo ");
		query = query.concat("AND trim(ss.id.solCodigo) = :solCodigo ");

		if (codMoneda != null) {
			query = query + "and exists (select 1 from SocCuentas c where c.benCodigo = bb.benCodigo and c.moneda = :codMoneda ) ";
		}

		if (!StringUtils.isBlank(benCodigo)) {
			query = query.concat("AND bb.benCodigo = :benCodigo ");
		} else {
			if (claVigente != null) {
				query = query.concat("and bb.claVigente = :claVigente ");
			}
		}

		if (verificaDirYPlaza) {
			query = query.concat("and (length(bb.benDireccion) >= 1)  and (length(bb.benPlaza) >= 1) ");
		}

		log.info("beneficiariosExterior: " + solCodigo + " " + codMoneda + " " + benCodigo + query.toString());
		query = query.concat("ORDER BY bb.benNombre ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("solCodigo", solCodigo.trim());

		if (codMoneda != null) {
			consulta.setParameter("codMoneda", codMoneda);
		}

		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);
		} else {
			if (claVigente != null) {
				consulta.setParameter("claVigente", claVigente);
			}
		}
		List lista = consulta.list();

		return lista;
	}

	public List<Beneficiario> recuperarBeneficiariosSolicitante(SocSolicitudes socSolicitudes, String codBen, Integer codMoneda, Short claVigente,
			boolean verificaDirYPlaza) {
		log.info("Entre a recuperarSolicitud con el id: [" + socSolicitudes.getSolCodigo() + "] ");
		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();

		if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA))) {
			beneficiarios = beneficiariosLocalesSolicitante(socSolicitudes.getSolCodigo(), codBen, codMoneda, claVigente);

		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());

			beneficiarios = beneficiariosExternosSolicitante(socSolicitudes.getSolCodigo(), codBen, codMoneda, claVigente, verificaDirYPlaza);
		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
			socSolicitanteDao.setSessionFactory(getSessionFactory());

			SocBenefsexpDao socBenefsexpDao = new SocBenefsexpDao();
			socBenefsexpDao.setSessionFactory(getSessionFactory());

			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());

			if (!StringUtils.isBlank(socSolicitudes.getTipoConcepto())) {
				if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SISTFIN)) {
					beneficiarios = socSolicitanteDao.getListaBeneficiariosSolicitantes(codBen, Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO);
				} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_SECPUB)) {
					beneficiarios = socSolicitanteDao.getListaBeneficiariosSolicitantes(codBen, Constants.CLAVE_CLAENTIDAD_SISTPUBLICO);
				} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ORDPAGO)) {
					beneficiarios = beneficiariosLocalesSolicitante(socSolicitudes.getSolCodigo(), codBen, codMoneda, claVigente);
				} else if (socSolicitudes.getTipoConcepto().equals(Constants.CLAVE_DELEXT_TIPCONCEPTO_ACREEDORES)) {
					SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(Constants.COD_BCB);

					Beneficiario benefi = new Beneficiario();

					benefi.setBenCodigo(Constants.COD_BCB);
					benefi.setSolCodigo(Constants.COD_BCB);
					benefi.setBenNit(socSolicitante.getSolNit());
					benefi.setBenFactura(socSolicitante.getSolFactura());
					benefi.setBenNombre(socSolicitante.getSolPersona());
					beneficiarios.add(benefi);
				}
			} else {
				if (!StringUtils.isBlank(socSolicitudes.getSolCodigo()))
					beneficiarios = socSolicitanteDao.getListaBeneficiariosSolicitantes(socSolicitudes.getSolCodigo(), null);
			}
		}
		log.info("cuentas Solicitantes recuperadas: " + socSolicitudes.getSolCodigo() + " " + beneficiarios.size());

		return beneficiarios;
	}

	public Beneficiario recuperarBeneficiario(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {
		log.info("XXX: en recuperarBeneficiario " + socSolicitudes.getCveSubtipooper());
		Beneficiario benefi = null;
		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_CARTAS)
				|| socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
			benefi = new Beneficiario();

			benefi.setBenCodigo(socDetallessol.getBenCodigo());
			benefi.setSolCodigo(socSolicitudes.getSolCodigo());
			benefi.setBenNombre(socDetallessol.getBeneficiario());

		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
			socCuentassolDao.setSessionFactory(getSessionFactory());
			List<Beneficiario> beneficiarios = beneficiariosExternosSolicitante(socSolicitudes.getSolCodigo(), socDetallessol.getBenCodigo(), null,
					null, false);
			if (beneficiarios.size() == 1)
				benefi = beneficiarios.get(0);
		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)) {
			List<Beneficiario> beneficiarios = beneficiariosLocalesSolicitante(socSolicitudes.getSolCodigo(), socDetallessol.getBenCodigo(), null,
					null);
			if (beneficiarios.size() == 1)
				benefi = beneficiarios.get(0);
		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
			List<Beneficiario> beneficiarios = recuperarBeneficiariosSolicitante(socSolicitudes, socDetallessol.getBenCodigo(), null, null, false);
			if (beneficiarios.size() == 1)
				benefi = beneficiarios.get(0);
		}

		return benefi;
	}

	public List<SocBenefs> findBenefsExt(String benNombre, String solCodigo, String ctaNrocuenta, Integer codMoneda) {
		String query = "SELECT bb ";
		query = query.concat("FROM SocBenefs bb ");
		query = query.concat("WHERE trim(bb.benNombre) != '' ");

		if (!StringUtils.isBlank(benNombre))
			query = query.concat("and upper(bb.benNombre) like :benNombre ");

		if (codMoneda != null)
			query = query + "and exists (select 1 from SocCuentas c where c.benCodigo = bb.benCodigo and c.moneda = :codMoneda ) ";

		if (!StringUtils.isBlank(ctaNrocuenta))
			query = query
					.concat("and exists (select 1 from SocCuentas c where c.benCodigo = bb.benCodigo and upper(c.ctaNrocuenta) like :ctaNrocuenta) ");

		if (!StringUtils.isBlank(solCodigo)) {
			query = query + "AND exists (select 1 from SocSolbenefs ss where ss.id.benCodigo = bb.benCodigo and ss.id.solCodigo = :solCodigo ) ";
		}

		query = query.concat("ORDER BY bb.benNombre ");

		Query consulta = getSession().createQuery(query);

		if (!StringUtils.isBlank(benNombre))
			consulta.setParameter("benNombre", "%" + benNombre.toUpperCase() + "%");

		if (codMoneda != null)
			consulta.setParameter("codMoneda", codMoneda);

		if (!StringUtils.isBlank(ctaNrocuenta))
			consulta.setParameter("ctaNrocuenta", "%" + ctaNrocuenta.toUpperCase() + "%");

		if (!StringUtils.isBlank(solCodigo))
			consulta.setParameter("solCodigo", solCodigo);

		List lista = consulta.list();

		if (lista.size() == 0) {
			log.info("Lista sin valores find benef " + benNombre + " " + ctaNrocuenta + " " + solCodigo + ":: " + query);
		}
		return lista;
	}

	public List<SocBenefsreg> findBenefsPendientes(String solCodigo, String benEstcta) {

		StringBuffer query = new StringBuffer();
		query = query.append("select br ");
		query = query.append("from SocBenefs be, SocBenefsreg br ");
		query = query.append("where be.benCodigo = br.benCodigo ");

		if (!StringUtils.isBlank(solCodigo))
			query = query.append("and br.solCodigo = :solCodigo ");

		query = query.append("and br.benEstcta = :benEstcta ");

		log.debug("Entre a buscar findBenefsPendientes id: " + solCodigo + " " + benEstcta);
		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(solCodigo))
			consulta.setParameter("solCodigo", solCodigo);

		consulta.setParameter("benEstcta", benEstcta);
		List lista = consulta.list();

		return lista;
	}

	public List<Beneficiario> beneficiariosExt(String benNombre, String solCodigo, String ctaNrocuenta, Integer codMoneda) {
		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		List<SocBenefs> socBenefsLista = findBenefsExt(benNombre, solCodigo, ctaNrocuenta, codMoneda);
		for (SocBenefs socBenefs : socBenefsLista) {
			Beneficiario benefi = new Beneficiario();
			benefi.setBenCodigo(socBenefs.getBenCodigo());
			benefi.setSolCodigo(solCodigo);
			benefi.setBenNit(socBenefs.getBenNit());
			benefi.setBenFactura(socBenefs.getBenFactura());
			benefi.setBenNombre(socBenefs.getBenNombre());
			benefi.setBenDireccion(socBenefs.getBenDireccion());
			benefi.setBenPlaza(socBenefs.getBenPlaza());

			if (socBenefs.getClaVigente() != null)
				benefi.setClaEntidad(Integer.valueOf(socBenefs.getClaVigente()));
			benefi.setSocBenefs(socBenefs);

			beneficiarios.add(benefi);
		}

		return beneficiarios;
	}

	public List<Beneficiario> beneficiariosDelExt(String benNombre, String solCodigo, String ctaNrocuenta, Integer codMoneda) {

		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		List<SocBenefs> socBenefsLista = findBenefsExt(benNombre, solCodigo, ctaNrocuenta, codMoneda);
		for (SocBenefs socBenefs : socBenefsLista) {
			Beneficiario benefi = new Beneficiario();
			benefi.setBenCodigo(socBenefs.getBenCodigo());
			benefi.setSolCodigo(solCodigo);
			benefi.setBenNit(socBenefs.getBenNit());
			benefi.setBenFactura(socBenefs.getBenFactura());
			benefi.setBenNombre(socBenefs.getBenNombre());
			benefi.setBenDireccion(socBenefs.getBenDireccion());
			benefi.setBenPlaza(socBenefs.getBenPlaza());

			if (socBenefs.getClaVigente() != null)
				benefi.setClaEntidad(Integer.valueOf(socBenefs.getClaVigente()));
			benefi.setSocBenefs(socBenefs);

			beneficiarios.add(benefi);
		}

		return beneficiarios;
	}

	public List<Beneficiario> beneficiariosPendientes(String solCodigo, String benEstcta) {
		List<Beneficiario> beneficiarios = new ArrayList<Beneficiario>();
		List<SocBenefsreg> socBenefsLista = findBenefsPendientes(solCodigo, benEstcta);
		for (SocBenefsreg socBenefs : socBenefsLista) {
			Beneficiario benefi = new Beneficiario();

			benefi.setBenCodigo(socBenefs.getBenCodigo());
			benefi.setSolCodigo(socBenefs.getSolCodigo());

			SocBenefs socBenefsOld = getBenefsByBenCodigo(socBenefs.getBenCodigo());

			benefi.setBenNit(socBenefsOld.getBenNit());
			benefi.setBenFactura(socBenefsOld.getBenFactura());
			benefi.setBenNombre(socBenefsOld.getBenNombre());
			benefi.setBenDireccion(socBenefsOld.getBenDireccion());
			benefi.setBenPlaza(socBenefsOld.getBenPlaza());

			if (socBenefsOld.getClaVigente() != null)
				benefi.setClaEntidad(Integer.valueOf(socBenefsOld.getClaVigente()));

			benefi.setSocBenefs(socBenefsOld);
			benefi.setSocBenefsreg(socBenefs);

			beneficiarios.add(benefi);
		}

		return beneficiarios;
	}

}
