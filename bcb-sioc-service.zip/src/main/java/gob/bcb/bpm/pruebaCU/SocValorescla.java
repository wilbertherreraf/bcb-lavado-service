package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the soc_valorescla database table.
 * 
 */
@Entity
@Table(name="soc_valorescla")
public class SocValorescla implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocValoresclaPK id;

	@Column(name="cla_vigente")
	private Short claVigente;

	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	@Column(name="usr_codigo")
	private String usrCodigo;

	@Column(name="val_nombre")
	private String valNombre;
	
	public SocValorescla() {
    }

	public SocValoresclaPK getId() {
		return this.id;
	}

	public void setId(SocValoresclaPK id) {
		this.id = id;
	}
	
	public Short getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(Short claVigente) {
		this.claVigente = claVigente;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getValNombre() {
		return this.valNombre;
	}

	public void setValNombre(String valNombre) {
		this.valNombre = valNombre;
	}

}