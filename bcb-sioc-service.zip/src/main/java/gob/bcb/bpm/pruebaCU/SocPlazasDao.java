package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocPlazasDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocPlazasDao.class);
	
	public void saveOrUpdate(SocBancos socBancos, SocPlazas socPlazas) {
		SocPlazas socPlazasOld = getSocPlazaByCodigo(socBancos.getBcoCodigo(), 1);

		if (StringUtils.isBlank(socPlazas.getPlaNombre())) {
			throw new BusinessException("Nombre de Plaza invalido");
		}
		
		socPlazas.setPlaNombre(socPlazas.getPlaNombre().trim().toUpperCase());
		socPlazas.setEstacion(socBancos.getEstacion());
		socPlazas.setUsrCodigo(socBancos.getUsrCodigo());
		socPlazas.setFechaHora(new Date());		
		if (socPlazasOld == null){
			socPlazas.getId().setBcoCodigo(socBancos.getBcoCodigo());
			socPlazas.getId().setPlaCodigo(1);
			socPlazas.setClaVigente(Short.valueOf("1"));
			
			this.getHibernateTemplate().saveOrUpdate(socPlazas);			
		} else {
			socPlazas.setClaVigente(socBancos.getClaVigente());
			
			this.getHibernateTemplate().saveOrUpdate(socPlazas);
		}
		log.info("Plaza salvada " + socPlazas.getId().getBcoCodigo());
	}
	public SocPlazas getSocPlazaByCodigo(String bcoCodigo, Integer plaCodigo) {
		log.debug("Entre a buscar getBenefsByBenCodigo id: " + bcoCodigo  + " " + plaCodigo);

		List lista = getSocPlazasByCodigo(bcoCodigo, plaCodigo);

		if (lista.size() > 0) {
			return (SocPlazas) lista.get(0);
		}

		return null;
	}
	
	public SocPlazas findSocPlazasByCodigo(String bcoCodigo, Integer plaCodigo) {
		log.debug("Entre a buscar findSocPlazasByCodigo id: " + bcoCodigo  + " " + plaCodigo);

		SocPlazas benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocPlazas be ");
		query = query.append("where be.id.bcoCodigo = :bcoCodigo ");			
		query = query.append("and be.id.plaCodigo = :plaCodigo ");			
		
		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("bcoCodigo", bcoCodigo);			
		consulta.setParameter("plaCodigo", plaCodigo);			

		List lista = consulta.list();
		if (lista.size() > 0){
			return (SocPlazas) lista.get(0);
		}
		return null;
	}

	
	public List<SocPlazas> getSocPlazasByCodigo(String bcoCodigo, Integer plaCodigo) {
		log.debug("Entre a buscar getSocPlazasByCodigo id: " + bcoCodigo  + " " + plaCodigo);

		SocPlazas benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocPlazas be ");
		query = query.append("where length(be.plaNombre) > 1 ");
		
		if (!StringUtils.isBlank(bcoCodigo)) {
			query = query.append("and be.id.bcoCodigo = :bcoCodigo ");			
		}
		if (plaCodigo != null){
			query = query.append("and be.id.plaCodigo = :plaCodigo ");			
		}
		
		Query consulta = getSession().createQuery(query.toString());
		if (!StringUtils.isBlank(bcoCodigo)) {
			consulta.setParameter("bcoCodigo", bcoCodigo);			
		}
		if (plaCodigo != null){
			consulta.setParameter("plaCodigo", plaCodigo);			
		}

		@SuppressWarnings("unchecked")
		List lista = consulta.list();
		return lista;
	}
	public Integer generarCodigo(String bcoCodigo) {
		// 1327501391867 codigo menor de solicitudes en historico
		StringBuffer query = new StringBuffer();
		query = query.append("select max(pla_codigo) ");
		query = query.append("from soc_plazas ");
		query = query.append("where bco_codigo = : bcoCodigo");
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("bcoCodigo", bcoCodigo);
		log.debug("Entre a generarCod " + consulta.toString());

		Integer maxi = null;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (Integer) result.get(0);

		if (maxi != null) {
			maxi++;
		} else {
			maxi = Integer.valueOf(1);
		}

		log.info("Cod solicitud nuevo: " + maxi);
		return maxi;
	}
	
}
