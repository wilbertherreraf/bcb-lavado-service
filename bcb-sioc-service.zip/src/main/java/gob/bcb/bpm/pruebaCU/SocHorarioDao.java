package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.qnatives.coin.CalendarioComun;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocHorarioDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocHorarioDao.class);


	public void saveOrUpdate(SocHorario pm) {
		log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public boolean operacionEstaEnHorario(String codTipoOper, Date hora, String codUsuario) {

		// determinar si la operacion esta como controlada por horario
		SocHorario socHorario = findByTOper(codTipoOper);
		if (socHorario == null) {
			return true;
		}
		
		if (!StringUtils.isBlank(socHorario.getCveEstadoHor()) && socHorario.getCveEstadoHor().equals("S")){
			// horario suspendido
			return true;
		}
		if (!StringUtils.isBlank(socHorario.getClaTiporestricc()) ){
			if (socHorario.getClaTiporestricc().equals("S")){
				// el horario se restringe solo a los partivipantes usuario del bcb no se controla
				if (!StringUtils.isBlank(codUsuario) && codUsuario.equals(Constants.COD_BCB)) {
					log.debug("Habilitado por ser usuario BCB " + UserSessionHolder.get(Constants.COD_IFA_REQUEST));
					return true;
				}
			}
		}

		CalendarioComun calendarioComun = new CalendarioComun();
		calendarioComun.setSessionFactory(SiocCoinService.getSessionFactory());
		
		boolean isHabil = calendarioComun.isHabil(hora);
		// determinar si el dia es habil
		if (!isHabil) {
			return false;
		}

		// determinar si esta en horario
		SocHorario horario = findByTOper(codTipoOper, hora);
		return (horario != null);

	}
	public boolean operacionEstaEnHorario2(String codTipoOper, Date hora, String codUsuario) {

		// determinar si la operacion esta como controlada por horario
		SocHorario socHorario = findByTOper(codTipoOper);
		if (socHorario == null) {
			return true;
		}
		
		if (!StringUtils.isBlank(socHorario.getCveEstadoHor()) && socHorario.getCveEstadoHor().equals("S")){
			return true;
		}
		if (!StringUtils.isBlank(socHorario.getClaTiporestricc()) ){
			if (socHorario.getClaTiporestricc().equals("S")){
				// el horario se restringe solo a los partivipantes usuario del bcb no se controla
				if (!StringUtils.isBlank(codUsuario) && codUsuario.equals(Constants.COD_BCB)) {
					log.debug("Habilitado por ser usuario BCB " + UserSessionHolder.get(Constants.COD_IFA_REQUEST));
					return true;
				}
			}
		}

		// determinar si esta en horario
		SocHorario horario = findByTOper(codTipoOper, hora);
		return (horario != null);

	}

	public List<SocHorario> getSocHorarioList() {
		StringBuffer query = new StringBuffer();
		
		query = query.append("SELECT h ");
		query = query.append("FROM SocHorario h ");
		query = query.append("order by h.codOperacion ");		
		Query consulta = getSession().createQuery(query.toString());
		
		return consulta.list();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.bpm.siraladi.dao.HorarioLocal#findHorarioByTOper(java.lang.String
	 * , java.lang.String, java.util.Date)
	 */
	public SocHorario findByTOper(String codTipoOper, Date hora) {
		StringBuffer query = new StringBuffer();
		query = query.append("SELECT h ");
		query = query.append("FROM SocHorario h ");
		query = query.append("where h.codOperacion = :codTipoOper ");
		query = query.append("and h.cveEstadoHor = 'V' ");		

		Calendar horaParam = GregorianCalendar.getInstance();

		if (hora != null) {
			horaParam.setTime(hora);
			query = query.append("and :hora between h.horaIni and h.horaFin ");			
		}
		log.info("consulta horario " + query.toString() + " " + codTipoOper + " " + hora);
		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codTipoOper", codTipoOper);
		if (hora != null) {
			consulta.setTime("hora", horaParam.getTime());			
		}

		List result = consulta.list();
		if (result.size() > 0) {
			return (SocHorario) result.get(0);
		}

		return null;

	}
	public SocHorario findByTOper(String codTipoOper) {
		StringBuffer query = new StringBuffer();
		query = query.append("SELECT h ");
		query = query.append("FROM SocHorario h ");
		query = query.append("where h.codOperacion = :codTipoOper ");

		log.info("consulta horario " + query.toString() + " " + codTipoOper );
		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codTipoOper", codTipoOper);
		List result = consulta.list();
		if (result.size() > 0) {
			return (SocHorario) result.get(0);
		}

		return null;

	}

	public List<SocHorario> findListByTOper(String codTipoOper) {
		StringBuffer query = new StringBuffer();
		
		query = query.append("SELECT h ");
		query = query.append("FROM SocHorario h ");
		
		
		query = query.append("where h.cveEstadoHor = 'V' ");			
		query = query.append("and h.codOperacion = :codTipoOper ");			
		
		Query consulta = getSession().createQuery(query.toString());
		
		consulta.setParameter("codTipoOper", codTipoOper);			

		return consulta.list();
	}

	public void controlHorario(Solicitud solicitud, SocEsquemas socEsquemas, String tipoProceso) {
		// en clasubtipo se almacena el tipo de operacion este agrupa diferentes
		// tipos de operaciones
		// el mismo codigo debe estar registrado en soc horario

		String codTipoOperacion = StringUtils.trimToEmpty(socEsquemas.getClaSubtipo()) + tipoProceso;

		log.info("Control de horario por solicitud " + codTipoOperacion + " PersonaAudit: " + solicitud.getCodPersonaAudit());
		Date horarecep = new Date();
		boolean enHorario = operacionEstaEnHorario(codTipoOperacion, horarecep, solicitud.getCodPersonaAudit());

		if (!enHorario) {
			// temporal por ahora se verifica estos dos valores
			log.error("Tipo de Operacion " + codTipoOperacion + ", FUERA DE HORARIO, hora recepcion: "
					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
			throw new RuntimeException("Tipo de Operacion " + codTipoOperacion + " FUERA DE HORARIO, hora recepcion: "
					+ UtilsDate.stringFromDate(horarecep, Constants.FORMAT_DATE_TIME));
		}

	}
	
}
