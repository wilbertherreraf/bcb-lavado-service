/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocFacturasDao extends HibernateDaoSupport {
	// private static FactoryDao factoryDao;
	private static final Log log = LogFactory.getLog(SocFacturasDao.class);

	public void saveOrUpdate(SocFacturas pm) {
		// parche: si no existe nom factura y

		if (StringUtils.isBlank(pm.getFacNit()) || StringUtils.isBlank(pm.getFacNombre())) {
			// throw new RuntimeException("Valor de nit o razon social nulo");
		}
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminar(SocFacturas pm) {
		// log.info("Eliminando factura... " + pm);
		this.getHibernateTemplate().delete(pm);
	}

	public void eliminarRegs(String codigo) {
		List<SocFacturas> facts = getFacturas(codigo);
		this.getHibernateTemplate().deleteAll(facts);
		int i = 0;
		// while (facts.size() > 0) {
		// SocFacturas fact = facts.get(0);
		// eliminar(fact);
		// facts = getFacturas(codigo);
		// i++;
		// }
		log.info("Eliminados Facturas [ " + i + " ] regs.");
	}

	public SocFacturas getFactura(String cpbCodigo, Integer renCodigo, String claTipofact) {
		StringBuffer query = new StringBuffer();
		query = query.append("select fa ");
		query = query.append("from SocFacturas fa ");
		query = query.append("where fa.id.cpbCodigo = :cpbCodigo ");
		query = query.append("and fa.id.renCodigo = :renCodigo ");
		query = query.append("and fa.claTipofact = :claTipofact ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("cpbCodigo", cpbCodigo);
		consulta.setParameter("renCodigo", renCodigo);
		consulta.setParameter("claTipofact", claTipofact);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocFacturas) lista.get(0);
		}
		return null;
	}

	public List<SocFacturas> getFacturas(String id) {
		List<SocFacturas> lista = new ArrayList<SocFacturas>();

		StringBuffer query = new StringBuffer();
		query = query.append("select fa ");
		query = query.append("from ");
		query = query.append("SocFacturas fa ");
		query = query.append("where fa.id.cpbCodigo = :codigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codigo", id);

		lista = consulta.list();

		return lista;
	}

	public Boolean crearFactura(String cpb, int reng, String soli) {
		String ope = this.getOperacion(cpb);
		char tipoR = 'P';

		String query = "select o.cla_comision, v.val_nombre, o.oco_monto " + "from soc_opecomi o, soc_valorescla v "
				+ "where v.cla_codigo = 'cla_tcomision' " + "and o.cla_comision = v.val_codigo " + "and o.ope_codigo = '" + ope + "' "
				+ "and o.cla_comision <> '4' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cla_comision, val_nombre, oco_monto".split(","));
		if (resultado.size() > 0) {
			String nit = "";
			String nombre = "";

			log.debug("Llamando al servicio de coin: nit");

			Map<String, Object> mapaResultado = getDatosFactura(soli);

			nit = (String) mapaResultado.get("nit");

			if (tipoR == 'P') {
				nombre = (String) mapaResultado.get("persona");
			} else {
				nombre = Servicios.getSolicitante(soli);
			}

			if (soli.trim().equals("207")) {
				nit = "121989025";
				nombre = "COMANDO GENERAL DE LA POLICIA NACIONAL";
				tipoR = 'N';
			}

			int i = 0;
			SocFacturasId id = null;
			for (Map<String, Object> res : resultado) {
				i++;
				log.info("resultado " + i + " " + res.toString());
				BigDecimal monto = (BigDecimal) res.get("oco_monto");
				int porcentajeIva = 13;
				BigDecimal montoIva = (monto.multiply(BigDecimal.valueOf(porcentajeIva))).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
				id = new SocFacturasId(cpb, reng, i);
				SocFacturas factura = new SocFacturas(id, nit, nombre, monto, montoIva, BigDecimal.valueOf(0), BigDecimal.valueOf(0),
						(String) res.get("val_nombre"), tipoR);
				this.saveOrUpdate(factura);
			}
			id = new SocFacturasId(cpb, reng, i++);
			Boolean continuar = crearFacturaSinCredito(id, nit, nombre, tipoR, ope);
			if (continuar == false) {
				return false;
			}
		} else {
			log.error("Error No pudo encontrar comisiones para " + soli);
			throw new RuntimeException("Error No pudo encontrar comisiones para " + soli);
		}

		return true;
	}

	public Boolean crearFactura(String cpb, int reng, String benef, char tipo) {
		String ope = this.getOperacion(cpb);
		String query1 = "";

		if (tipo == 'B') {
			query1 = "select ben_nit, ben_factura " + "from soc_benefsloc " + "where ben_codigo = '" + benef + "'";
		} else {
			if (tipo == 'E') {
				query1 = "select ben_nit, ben_factura " + "from soc_benefsexp " + "where ben_codigo = '" + benef + "'";
			} else {
				query1 = "select ben_nit, ben_factura " + "from soc_benefs " + "where ben_codigo = '" + benef + "'";
			}
		}

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1, "ben_nit, ben_factura".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res1 : resultado1) {
				log.info("resultado" + res1.toString());
				String nit = (String) res1.get("ben_nit");
				String nombre = (String) res1.get("ben_factura");

				String query = "select o.cla_comision, v.val_nombre, o.oco_monto " + "from soc_opecomi o, soc_valorescla v "
						+ "where v.cla_codigo = 'cla_tcomision' " + "and o.cla_comision = v.val_codigo " + "and o.ope_codigo = '" + ope + "' "
						+ "and o.cla_comision <> '4' ";

				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cla_comision, val_nombre, oco_monto".split(","));
				if (resultado.size() > 0) {
					int i = 0;
					SocFacturasId id = null;
					for (Map<String, Object> res : resultado) {
						log.info("resultado" + res.toString());
						i++;

						int porcentajeIva = 13;
						BigDecimal monto = (BigDecimal) res.get("oco_monto");
						BigDecimal montoIva = (monto.multiply(BigDecimal.valueOf(porcentajeIva))).divide(BigDecimal.valueOf(100), 2,
								RoundingMode.HALF_UP);
						id = new SocFacturasId(cpb, reng, i);
						SocFacturas factura = new SocFacturas(id, nit, nombre, monto, montoIva, BigDecimal.valueOf(0), BigDecimal.valueOf(0),
								(String) res.get("val_nombre"), 'N');
						this.saveOrUpdate(factura);
					}
					id = new SocFacturasId(cpb, reng, i++);
					Boolean continuar = crearFacturaSinCredito(id, nit, nombre, 'N', ope);
					if (continuar == false) {
						return false;
					}
					return true;
				} else {
					log.error("Error No pudo encontrar comisiones para " + benef);
					throw new RuntimeException("Error No pudo encontrar comisiones para " + benef);
				}
			}
		} else {
			log.error("Error No pudo encontrar datos para factura de " + benef);
			throw new RuntimeException("Error No pudo encontrar datos para factura de " + benef);
		}

		return false;
	}

	/**
	 * Factura para venta de divisas
	 * 
	 * @param cpb
	 * @param reng
	 * @param benef
	 * @param soli
	 * @return
	 */

	public Boolean crearFactura(String cpb, int reng, String benef, String soli, boolean generarFacturaSinCredito) {
		String ope = this.getOperacion(cpb);
		String query1 = "";
		SocFacturas factura;

		query1 = "select ben_nit, ben_factura " + "from soc_benefs " + "where ben_codigo = '" + benef + "'";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query1, "ben_nit, ben_factura".split(","));
		if (resultado1.size() == 1) {
			for (Map<String, Object> res1 : resultado1) {
				log.info("resultado" + res1.toString());
				String nit = (String) res1.get("ben_nit");
				String nombre = (String) res1.get("ben_factura");
				// extraemos las comisiones las que se debe facturar
				String query = "select o.cla_comision, v.val_nombre, o.oco_monto " + "from soc_opecomi o, soc_valorescla v "
						+ "where v.cla_codigo = 'cla_tcomision' " + "and o.cla_comision = v.val_codigo " + "and o.ope_codigo = '" + ope + "' "
						+ "and o.cla_comision <> '4' ";
				List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cla_comision, val_nombre, oco_monto".split(","));
				if (resultado.size() > 0) {
					int i = 0;

					for (Map<String, Object> res : resultado) {
						log.info("resultado:: " + res.toString());
						i++;
						String cod = (String) res.get("cla_comision");
						BigDecimal monto = (BigDecimal) res.get("oco_monto");
						int porcentajeIva = 13;
						BigDecimal montoIva = (monto.multiply(BigDecimal.valueOf(porcentajeIva))).divide(BigDecimal.valueOf(100), 2,
								RoundingMode.HALF_UP);
						SocFacturasId id = new SocFacturasId(cpb, reng, i);
						if (!cod.equals("4")) {
							factura = new SocFacturas(id, nit, nombre, monto, montoIva, BigDecimal.valueOf(0), BigDecimal.valueOf(0),
									(String) res.get("val_nombre"), 'N');
							this.saveOrUpdate(factura);
						}
					}
					if (generarFacturaSinCredito) {
						nombre = Servicios.getSolicitante(soli);

						// el nit sin credito es para el solictiante (p.e.
						// YACIMEITNOS)
						// el nit CON credito es para el beneficiario (p.e. A
						// evangelist)
						nit = "";

						// Metodo estatico que se encarga de manejar las
						// consultas al
						// servicio
						log.info("Llamando al servicio de coin: nit");
						Map<String, Object> mapaResultado = getDatosFactura(soli);

						nit = (String) mapaResultado.get("nit");
						// el codigo de renglon es siempre 1
						i = 1;
						SocFacturasId id = new SocFacturasId(cpb, 0, i);
						// /////////////////////
						// PARA VENTAS CON DESCUENTO: para el 1er comprob genera
						// solo sin credito
						// para el 2do solo la primera parte (con credito)

						Boolean continuar = crearFacturaSinCredito(id, nit, nombre, 'P', ope);
						if (continuar == false) {
							return false;
						}
					}

					// //////////////////////////////
					return true;
				} else {
					log.error("Error No pudo encontrar comisiones para " + benef);
					throw new RuntimeException("Error No pudo encontrar comisiones para " + benef);
				}
			}
		} else {
			log.error("Error No pudo encontrar datos para factura de " + benef);
			throw new RuntimeException("Error No pudo encontrar datos para factura de " + benef);
		}

		return false;
	}

	private String getOperacion(String cod) {
		String ope = "";

		String query = "SELECT ope_codigo " + "FROM soc_comprobante WHERE cpb_codigo = '" + cod + "'";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ope_codigo".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				ope = (String) res.get("ope_codigo");
			}
		} else {
			log.info("Lista Nula");
		}

		return ope;
	}

	public Boolean crearFacturaSinCredito(SocFacturasId id, String nit, String nombre, char tipoR, String ope) {
		QueryProcessor.flush();
		Boolean continuar = true;

		String query = "select o.cla_comision, v.val_nombre, o.oco_monto " + "from soc_opecomi o, soc_valorescla v "
				+ "where v.cla_codigo = 'cla_tcomision' " + "and o.cla_comision = v.val_codigo " + "and o.ope_codigo = '" + ope + "' "
				+ "and o.cla_comision = '4' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "cla_comision, val_nombre, oco_monto".split(","));

		if (resultado.size() > 0) {
			for (Map<String, Object> res : resultado) {

				Integer renglon = null;
				// buscamos el afectable de la venta @cventa
				String query2 = "select r.ren_codigo " + "from soc_comprobante c, soc_rengscomp r " + "where c.cpb_codigo = r.cpb_codigo "
						+ "and ope_codigo = '" + ope + "' " + "and r.ren_afectable = '" + Servicios.getParam("@cventa") + "' ";

				List<Map<String, Object>> resultado2 = Servicios.ejecutarQuery(query2, "ren_codigo".split(","));
				if (resultado2.size() > 0) {
					for (Map<String, Object> res2 : resultado2) {
						renglon = (Integer) res2.get("ren_codigo");
					}
				}

				if (renglon == null || renglon <= 0) {
					log.error("Nro de renglon para factura sin credito invalido NIT " + nit);
					throw new RuntimeException("Nro de renglon para factura sin credito invalido NIT " + nit);
				}
				BigDecimal montoExcento = getMontoExcento(ope);

				BigDecimal tc = QueryProcessor.getTipoCambio(35, new Date());

				id.setRenCodigo(renglon);
				id.setFacCodigo(1);
				SocFacturas factura = new SocFacturas(id, nit, nombre, montoExcento, BigDecimal.valueOf(0), montoExcento, tc,
						(String) res.get("val_nombre"), tipoR);
				this.saveOrUpdate(factura);
			}
		}
		return continuar;
	}

	// whf rq01
	public BigDecimal getMontoExcento(String opeCodigo) {
		BigDecimal montoExcento;
		// SocOperacionesDao socOperacionesDao = (SocOperacionesDao)
		// QueryProcessor.factoryDao.getDao("socOperacionesDao");
		SocOperacionesDao socOperacionesDao = new SocOperacionesDao();
		socOperacionesDao.setSessionFactory(getSessionFactory());

		SocOperaciones socOperacion = (SocOperaciones) socOperacionesDao.getOperacionByCod(opeCodigo);

		// se calcula el monto si el monto ordenado es mayor a cero la factura
		// debera ser del monto ordenado sino es el monto de la operacion
		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		String socCodigo = socOperacion.getSocCodigo();
		BigDecimal montoFactura = socOperacion.getOpeMontome();

		SocSolicitudes socSolicitudes = null;
		if (socCodigo != null && !socCodigo.trim().isEmpty()) {
			socSolicitudes = socSolicitudesDao.getSolicitud(socCodigo);

			if (socSolicitudes != null && socSolicitudes.getSocMontoord() != null && socSolicitudes.getSocMontoord().compareTo(BigDecimal.ZERO) != 0)
				// si el monto ordenado es diferente de cero
				montoFactura = socSolicitudes.getSocMontoord();
		}

		if (34 == socOperacion.getMoneda()) {
			montoExcento = montoFactura.multiply(getTipoCambio(35));
		} else {
			BigDecimal montoMonedaExtranjera = montoFactura.multiply(getTipoCambio(socOperacion.getMoneda()));
			BigDecimal tc34 = getTipoCambio(34);
			tc34 = tc34.setScale(2, BigDecimal.ROUND_HALF_UP);
			BigDecimal montoTcCompra = BigDecimal.ZERO;
			montoMonedaExtranjera = montoMonedaExtranjera.setScale(2, BigDecimal.ROUND_HALF_UP);
			montoTcCompra = montoMonedaExtranjera.divide(tc34, 2, RoundingMode.HALF_UP).setScale(2, BigDecimal.ROUND_HALF_UP);
			montoExcento = montoTcCompra.multiply(getTipoCambio(35));
		}
		montoExcento = montoExcento.divide(BigDecimal.ONE, 2, RoundingMode.HALF_UP);
		return montoExcento;
	}

	public BigDecimal getTipoCambio(Integer codMoneda) {
		BigDecimal tc = BigDecimal.valueOf(0);
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		mapaParametros.put("consulta", "tc");
		mapaParametros.put("fecha", new Date());
		mapaParametros.put("moneda", codMoneda);
		String iid = new Long(new Date().getTime()).toString();

		Map<String, Object> mapaResultado;

		SiocCoinService siocCoinService = new SiocCoinService();
		mapaResultado = siocCoinService.executeTask(mapaParametros);
		// mapaResultado = ManejadorServicioBPM.consultaServidor("sioc",
		// "172.29.18.3", "cliente", "query", mapaParametros, iid);
		tc = (BigDecimal) mapaResultado.get("tc");
		return tc;
	}

	public Map<String, Object> getDatosFactura(String soli) {
		log.info("Obteniendo datos factura solicitante " + soli);
		Map<String, Object> mapaParametros = new HashMap<String, Object>();
		if (soli.trim().equals("509"))
			mapaParametros.put("soli", "517");
		else
			mapaParametros.put("soli", soli.trim());
		mapaParametros.put("consulta", "persona");

		SiocCoinService siocCoinService = new SiocCoinService();
		Map<String, Object> mapaResultado = siocCoinService.executeTask(mapaParametros);
		return mapaResultado;
	}

	/***********************/
	private Integer getMaxFactura(String cpbCodigo, Integer renCodigo) {
		Integer maxDet = Integer.valueOf(0);
		StringBuffer query = new StringBuffer();
		query = query.append("select max(fa.id.facCodigo) ");
		query = query.append("from SocFacturas fa ");
		query = query.append("where fa.id.cpbCodigo = :cpbCodigo ");
		query = query.append("and fa.id.renCodigo = :renCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("cpbCodigo", cpbCodigo);
		consulta.setParameter("renCodigo", renCodigo);

		log.debug("Entre a getMaxFactura [cpbCodigo=" + cpbCodigo + "] " + consulta.toString());

		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;

		return maxDet;

	}

	public SocFacturas actualizar(Solicitud solicitud, SocFacturas socFacturas, int renCodigo) {
		SocFacturas socFacturasOld = getFactura(socFacturas.getId().getCpbCodigo(), renCodigo, socFacturas.getClaTipofact());

		if (socFacturasOld == null) {
			Integer maximo = getMaxFactura(socFacturas.getId().getCpbCodigo(), renCodigo);
			maximo++;
			socFacturas.getId().setRenCodigo(renCodigo);
			socFacturas.getId().setFacCodigo(maximo);

			this.getHibernateTemplate().saveOrUpdate(socFacturas);
		} else {
			socFacturasOld.setFacNit(socFacturas.getFacNit());
			socFacturasOld.setFacNombre(socFacturas.getFacNombre());
			socFacturasOld.setFacMontomn(socFacturas.getFacMontomn());
			socFacturasOld.setFacMontoiva(socFacturas.getFacMontoiva());
			socFacturasOld.setFacMontoexcento(socFacturas.getFacMontoiva());
			socFacturasOld.setFacPreciounitario(socFacturas.getFacMontoiva());
			socFacturasOld.setFacConcepto(socFacturas.getFacConcepto());
			socFacturasOld.setCveRuc(socFacturas.getCveRuc());
			socFacturasOld.setClaTipofact(socFacturas.getClaTipofact());

			this.getHibernateTemplate().saveOrUpdate(socFacturasOld);
		}

		return socFacturas;
	}

	public SocFacturas crearFactura(Solicitud solicitud, SocRengscomp socRengscomp, Integer nroRenglon, String varClaComision, String codConcepto,
			String tipoFactura) {
		// tipoFactura : sin credito (S) o con credito (C)
		SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
		socOpecomiDao.setSessionFactory(getSessionFactory());

		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		log.info("Factura [" + tipoFactura + "]=> " + solicitud.getSolicitud().getSocCodigo() + ", varClaComision:" + varClaComision
				+ ", codConcepto:" + codConcepto + ", CpbCodigo:" + socRengscomp.getId().getCpbCodigo() + ", renglon:"
				+ socRengscomp.getId().getRenCodigo());

		SocFacturas socFacturas = getFactura(socRengscomp.getId().getCpbCodigo(), nroRenglon, varClaComision);

		if (socFacturas == null) {
			log.info("Nueva factura CpbCodigo:" + socRengscomp.getId().getCpbCodigo() + ", renglon:" + socRengscomp.getId().getRenCodigo());

			Integer maximo = getMaxFactura(socRengscomp.getId().getCpbCodigo(), nroRenglon);
			maximo++;

			SocFacturasId socFacturasId = new SocFacturasId(socRengscomp.getId().getCpbCodigo(), nroRenglon, maximo);

			socFacturas = new SocFacturas();
			socFacturas.setId(socFacturasId);
		}

		socFacturas.setFacMontoexcento(BigDecimal.ZERO);
		socFacturas.setFacPreciounitario(BigDecimal.ZERO);

		SocOpecomi socOpecomi = socOpecomiDao.getOpeComisByDetCodClaCom(solicitud.getSolicitud().getSocCodigo(), 0, varClaComision);
		if (socOpecomi == null) {
			throw new BusinessException(solicitud.getSolicitud().getSocCodigo() + ": Proceso de generacion de facturas: variable " + varClaComision
					+ " inexistente en socOpecomi");
		}

		if (StringUtils.isBlank(socOpecomi.getNit())){
			throw new BusinessException(solicitud.getSolicitud().getSocCodigo() + ": Proceso de generacion de facturas: NIT invalido para " + varClaComision
					+ " inexistente en socOpecomi");			
		}
		
		socFacturas.setFacMontomn(socOpecomi.getOcoMonto());
		socFacturas.setFacNit(socOpecomi.getNit());
		socFacturas.setFacNombre(socOpecomi.getFactura());

		Character cveRuc = 'N';
		if (!StringUtils.isBlank(socOpecomi.getNroCuenta())) {
			cveRuc = socOpecomi.getNroCuenta().charAt(0);
		}
		socFacturas.setCveRuc(cveRuc);
		socFacturas.setFacMontoiva(socOpecomi.getOcoMontoimpt());

		SocValorescla socValorescla = socValoresclaDao.getValoresByCod(Constants.CLAVE_CONCEPTOFAC, codConcepto);

		String concepto = socValorescla.getValNombre();

		socFacturas.setClaTipofact(varClaComision);
		socFacturas.setFacConcepto(concepto);

		if (tipoFactura.equals("S")) {
			socFacturas.setFacMontoexcento(socOpecomi.getOcoMonto());
			socFacturas.setFacMontoiva(BigDecimal.ZERO);
			socFacturas.setFacPreciounitario(socOpecomi.getTipoCambio());
		}

		this.getHibernateTemplate().saveOrUpdate(socFacturas);

		log.info("Factura CREADA [" + tipoFactura + "]=> " + solicitud.getSolicitud().getSocCodigo() + ", varClaComision:" + varClaComision
				+ ", codConcepto:" + codConcepto + ", CpbCodigo:" + socRengscomp.getId().getCpbCodigo() + ", renglon:"
				+ socRengscomp.getId().getRenCodigo());
		return socFacturas;
	}

	public static void main(String[] args) {
		String c = "";
		char cc = c.charAt(0);
		System.out.println(cc);
	}
}