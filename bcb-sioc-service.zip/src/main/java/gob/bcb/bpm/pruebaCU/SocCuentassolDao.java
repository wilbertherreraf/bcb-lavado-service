/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.servicioSioc.common.Constants;

import gob.bcb.service.servicioSioc.pojos.CuentaS;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author wherrera
 * 
 */
public class SocCuentassolDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocCuentassolDao.class);

	public void saveOrUpdate(SocCuentassol pm) {
		log.info("Guardando cuentasol " + pm);
		if (pm.getCtaCodigo() == null) {
			Integer cod = generarCodigo();
			pm.setCtaCodigo(cod);
		}

		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminar(SocCuentassol pm) {
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public SocCuentassol getByCodigo(Integer ctaCodigo) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from SocCuentassol cc ");
		query = query.append("where cc.ctaCodigo = :ctaCodigo ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ctaCodigo", ctaCodigo);

		List lista = consulta.list();
		if (lista.size() > 0) {
			return (SocCuentassol) lista.get(0);
		}
		log.error("Consulta getByCodigo sin registros: " + ctaCodigo + " " + query.toString());
		return null;
	}

	public SocCuentassol getByClaveCuenta(String claCuenta, Integer moneda) {
		List lista = listaByClaveCuenta(claCuenta, moneda);
		if (lista.size() > 0) {
			return (SocCuentassol) lista.get(0);
		}

		return null;
	}

	public List<SocCuentassol> listaByClaveCuenta(String claCuenta, Integer moneda) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from SocCuentassol cc ");
		query = query.append("where cc.claCuenta = :claCuenta ");
		query = query.append("and cc.moneda = :moneda ");
		query = query.append("and cc.claVigente = 1 ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("claCuenta", claCuenta);
		consulta.setParameter("moneda", moneda);

		List lista = consulta.list();

		if (lista.size() == 0)
			log.error("Consulta listaByClaveCuenta sin registros: " + claCuenta + " " + moneda + " " + query.toString());
		return lista;
	}

	public List<SocCuentassol> findByClaveCuenta(String claCuenta) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cc ");
		query = query.append("from SocCuentassol cc ");
		query = query.append("where cc.claCuenta = :claCuenta ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("claCuenta", claCuenta);

		List lista = consulta.list();

		return lista;
	}

	public SocCuentassol ctaExpBcoLocalByCtaBenef(Integer ctaCodigoExp) {

		SocCuentassol socCuentassol = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select c ");
		query = query.append("from SocCuentasexp e, SocSolcuentas s, SocCuentassol c ");
		query = query.append("where e.bcoCodigo = s.solCodigo ");
		query = query.append("and s.id.ctaCodigo = c.ctaCodigo ");
		query = query.append("and e.moneda = c.moneda ");
		query = query.append("and e.claVigente = 1 ");
		query = query.append("and s.claVigente = 1 ");
		query = query.append("and c.claVigente = 1 ");
		query = query.append("and e.ctaCodigo = :ctaCodigoExp ");

		Query consulta = getSession().createQuery(query.toString());
		log.debug("Consulta cuentaExpBcoLocalByCtaBenef: " + query.toString() + " ctaCodigo " + ctaCodigoExp);
		consulta.setParameter("ctaCodigoExp", ctaCodigoExp);

		List lista = consulta.list();

		if (lista.size() > 0) {
			socCuentassol = (SocCuentassol) lista.get(0);
		}
		return socCuentassol;
	}

	public SocCuentassol ctaExpComisBcoLocalByCtaBenef(Integer ctaCodigoExp) {

		SocCuentassol socCuentassol = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select c ");
		query = query.append("from SocCuentasexp e, SocSolcuentas s, SocCuentassol c ");
		query = query.append("where e.bcoCodigo1 = s.solCodigo ");
		query = query.append("and s.id.ctaCodigo = c.ctaCodigo ");
		query = query.append("and e.moneda1 = c.moneda ");
		query = query.append("and e.claVigente = 1 ");
		query = query.append("and s.claVigente = 1 ");
		query = query.append("and c.claVigente = 1 ");
		query = query.append("and e.ctaCodigo = :ctaCodigoExp ");

		Query consulta = getSession().createQuery(query.toString());
		log.debug("Consulta cuentaExpComisBcoLocalByCtaBenef: " + query.toString() + " ctaCodigo " + ctaCodigoExp);
		consulta.setParameter("ctaCodigoExp", ctaCodigoExp);

		List lista = consulta.list();

		if (lista.size() > 0) {
			socCuentassol = (SocCuentassol) lista.get(0);
		}
		return socCuentassol;
	}

	public SocCuentassol getByAfectable(String ctaAfectable) {
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocCuentassol op ");
		query = query.append("where op.ctaAfectable = :ctaAfectable ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("ctaAfectable", ctaAfectable);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (SocCuentassol) lista.get(0);
		}
		log.info("Consulta getByAfectable sin resultado:: " + query.toString() + " ctaAfectable " + ctaAfectable);
		return null;
	}

	public List<SocCuentassol> ctasUnicas(String ctaMovimiento, String ctaAfectable, Integer moneda, boolean soloUnicas) {
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocCuentassol op ");
		query = query.append("where op.ctaNommovimiento is not null ");

		if (soloUnicas) {
			query = query.append(
					"and op.id.ctaCodigo = (select min(s2.id.ctaCodigo) from SocCuentassol s2 where s2.ctaMovimiento = op.ctaMovimiento and s2.moneda = op.moneda and s2.ctaAfectable = op.ctaAfectable) ");
		}

		if (!StringUtils.isBlank(ctaMovimiento)) {
			query = query.append("and op.ctaMovimiento = :ctaMovimiento ");
		}
		if (!StringUtils.isBlank(ctaAfectable)) {
			query = query.append("and op.ctaAfectable = :ctaAfectable ");
		}
		if (moneda != null) {
			query = query.append("and op.moneda = :moneda ");
		}
		query = query.append("order by op.ctaNommovimiento ");

		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(ctaMovimiento)) {
			consulta.setParameter("ctaMovimiento", ctaMovimiento);
		}
		if (!StringUtils.isBlank(ctaAfectable)) {
			consulta.setParameter("ctaAfectable", ctaAfectable);
		}
		if (moneda != null) {
			consulta.setParameter("moneda", moneda);
		}

		List lista = consulta.list();

		return lista;

	}

	public List<SocCuentassol> ctasSolicitante(String solCodigo, String ctaMovimiento, String ctaAfectable, Integer codMoneda, String ctaNumero,
			Integer ctaCodigo, Integer claVigenteCta) {
		StringBuffer query = new StringBuffer();

		query = query.append("select s2 ");
		query = query.append("from SocCuentassol s2 ");
		query = query.append("where s2.ctaCodigo =  ( ");
		query = query.append("select min(cc.id.ctaCodigo) ");
		query = query.append("FROM SocSolcuentas sc, SocCuentassol cc ");
		query = query.append("WHERE sc.id.ctaCodigo = cc.id.ctaCodigo ");
		query = query.append("AND trim(sc.id.solCodigo) = :solCodigo ");

		if (!StringUtils.isBlank(ctaNumero))
			query = query.append("AND sc.ctaNumero = :ctaNumero ");

		if (ctaCodigo != null)
			query = query.append("and cc.id.ctaCodigo = :ctaCodigo ");

		query = query.append("and s2.ctaMovimiento = cc.ctaMovimiento ");
		query = query.append("and s2.moneda = cc.moneda ");
		query = query.append("and s2.ctaAfectable = cc.ctaAfectable ) ");

		if (claVigenteCta != null)
			query = query.append("and s2.claVigente = :claVigenteCta ");

		if (!StringUtils.isBlank(ctaMovimiento))
			query = query.append("and s2.ctaMovimiento = :ctaMovimiento ");
		if (!StringUtils.isBlank(ctaAfectable))
			query = query.append("and s2.ctaAfectable = :ctaAfectable ");
		if (codMoneda != null)
			query = query.append("and s2.moneda = :moneda ");
		query = query.append("order by s2.ctaNommovimiento ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("solCodigo", solCodigo);

		if (!StringUtils.isBlank(ctaNumero))
			consulta.setParameter("ctaNumero", ctaNumero);
		if (ctaCodigo != null)
			consulta.setParameter("ctaCodigo", ctaCodigo);

		if (claVigenteCta != null)
			consulta.setParameter("claVigenteCta", claVigenteCta);
		if (!StringUtils.isBlank(ctaMovimiento))
			consulta.setParameter("ctaMovimiento", ctaMovimiento);
		if (!StringUtils.isBlank(ctaAfectable))
			consulta.setParameter("ctaAfectable", ctaAfectable);
		if (codMoneda != null)
			consulta.setParameter("moneda", codMoneda);

		List lista = consulta.list();

		if (lista.size() == 0) {
			log.info("Consulta sin resultados:: " + solCodigo + " % " + ctaMovimiento + " % " + ctaAfectable + " % " + codMoneda + " % " + ctaNumero
					+ " % " + ctaCodigo + " % " + claVigenteCta + "····" + query.toString());
		}

		return lista;
	}

	public List<SocCuentassol> getCtasParaBenefs() {
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocCuentassol op ");
		query = query.append("where op.claVigente = 1 ");
		query = query.append("and exists (select 1 from SocSolcuentas s where s.id.ctaCodigo = op.ctaCodigo) ");
		query = query.append(
				"and op.id.ctaCodigo = (select min(s2.id.ctaCodigo) from SocCuentassol s2 where s2.ctaMovimiento = op.ctaMovimiento and s2.moneda = op.moneda and s2.ctaAfectable = op.ctaAfectable) ");
		query = query.append("order by op.ctaNommovimiento ");
		Query consulta = getSession().createQuery(query.toString());

		List lista = consulta.list();

		return lista;

	}

	public List<SocCuentassol> getCtasByCods(String solCodigo, Integer moneda) {
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocCuentassol op ");
		query = query.append("where op.claVigente = 1 ");
		query = query.append("and op.moneda = :moneda ");
		query = query.append("and exists (select 1 from SocSolcuentas s where s.id.ctaCodigo = op.ctaCodigo and s.id.solCodigo = :solCodigo) ");
		query = query.append(
				"and op.id.ctaCodigo = (select min(s2.id.ctaCodigo) from SocCuentassol s2 where s2.ctaMovimiento = op.ctaMovimiento and s2.moneda = op.moneda and s2.ctaAfectable = op.ctaAfectable) ");
		query = query.append("order by op.ctaNommovimiento ");
		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("solCodigo", solCodigo);
		consulta.setParameter("moneda", moneda);
		List lista = consulta.list();

		return lista;
	}

	public CuentaS cuentaSByAfectableMoneda(String ctaAfectable) {
		SocCuentassol socCuentassol = getByAfectable(ctaAfectable);
		if (socCuentassol == null) {
			throw new RuntimeException("Cuenta inexistente " + ctaAfectable);
		}
		CuentaS cta = cuentaSFromCtaSol(socCuentassol);
		return cta;
	}

	public SocCuentassol getByCtaMovMoneda(String ctaMovimiento, Integer codMoneda) {
		SocCuentassol socCuentassol = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocCuentassol op ");
		query = query.append("where op.ctaMovimiento = :ctaMovimiento ");
		query = query.append("and op.moneda = :codMoneda ");
		query = query.append("order by op.ctaCodigo ");

		log.info("query.toString() " + ctaMovimiento + " " + codMoneda);

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ctaMovimiento", ctaMovimiento);
		consulta.setParameter("codMoneda", codMoneda);

		List lista = consulta.list();

		if (lista != null && lista.size() > 0) {
			socCuentassol = (SocCuentassol) lista.get(0);
		} else {
			log.error(
					"Consulta getByCtaMovMoneda sin registros: " + query.toString() + " ctaMovimiento " + ctaMovimiento + " codMoneda " + codMoneda);
		}

		return socCuentassol;

	}

	public SocCuentassol getByCtaMovMonedaVig(String ctaMovimiento, Integer codMoneda) {
		SocCuentassol socCuentassol = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select op ");
		query = query.append("from SocCuentassol op ");
		query = query.append("where op.ctaMovimiento = :ctaMovimiento ");
		query = query.append("and op.moneda = :codMoneda ");
		query = query.append("and op.claVigente = 1 ");
		query = query.append("order by op.ctaCodigo ");

		log.info("query.toString() " + ctaMovimiento + " " + codMoneda);

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ctaMovimiento", ctaMovimiento);
		consulta.setParameter("codMoneda", codMoneda);

		List lista = consulta.list();

		if (lista.size() > 0) {
			socCuentassol = (SocCuentassol) lista.get(0);
		}

		return socCuentassol;

	}

	private CuentaS cuentaSFromCtaSol(SocCuentassol socCuentassol) {
		CuentaS cta = new CuentaS();

		cta.setCtaCodigo(socCuentassol.getCtaCodigo());
		cta.setCtaMovi(socCuentassol.getCtaMovimiento());
		cta.setClaVigente(socCuentassol.getClaVigente());
		cta.setMoneda(socCuentassol.getMoneda());
		cta.setCtaNommovimiento(socCuentassol.getCtaNommovimiento());
		cta.setCtaAfectable(socCuentassol.getCtaAfectable());
		cta.setSocCuentassol(socCuentassol);

		return cta;

	}

	public SocCuentassol cuentaBeneficiario0(SocSolicitudes socSolicitudes, SocDetallessol socDetallessol) {
		SocCuentassol socCuentassol = null;
		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {

			List<SocCuentassol> socCuentassolLista = listaByClaveCuenta(Constants.COD_CLAVE_FONDOSVISTA, socSolicitudes.getCodMonedat());
			if (socCuentassolLista.size() > 1) {
				// mas de una moneda en cuentas vista
				log.warn("Mas de una cuenta en fondos vista " + socSolicitudes.getCodMonedat() + " " + socCuentassolLista.size());
				if (socSolicitudes.getCodMonedat().compareTo(Constants.COD_MONEDA_USD) == 0) {
					// por ahora seteamos el por defecto
					log.warn("OOOJOOO (REVISAR) se setea la cuenta de USD por defecto " + socSolicitudes.getCodMonedat() + " "
							+ socCuentassolLista.size());
					socCuentassol = getByAfectable("011058");
				} else {
					socCuentassol = socCuentassolLista.get(0);
				}
			} else {
				if (socCuentassolLista.size() == 1) {
					socCuentassol = socCuentassolLista.get(0);
				}
			}
		} else if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRACTA)
				|| socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_ORDPAG)) {
			//
			socCuentassol = getByAfectable(socDetallessol.getNroCuentabcointer());

		}

		if (socCuentassol == null) {
			throw new RuntimeException("Cuenta inexistente ctaCodigo " + socDetallessol.getId().getDetCodigo());
		}
		return socCuentassol;
	}

	public SocCuentassol getCtaITF(String ctaAfectable) {
		SocCuentassol socCuentassol = getByAfectable(ctaAfectable);

		if (socCuentassol != null) {
			if (socCuentassol.getGenItf() != null && socCuentassol.getGenItf().compareTo(Integer.valueOf(1)) == 0) {
				return socCuentassol;
			}
		}
		return null;
	}

	public List<CuentaS> listaCuentasSolicitante(String solCodigo, Integer codMoneda, String ctamovimiento, Integer ctaCodigo, String ctaafectable,
			String ctaNumero, String claEntidad, boolean filtraVigentes) {
		List<CuentaS> cuentas = new ArrayList<CuentaS>();
		if (!StringUtils.isBlank(claEntidad)) {
			// para consultas que vienen con un solo caracter
			claEntidad = (!claEntidad.startsWith("'") ? "'" : "") + claEntidad + (!claEntidad.endsWith("'") ? "'" : "");
		}

		String query = "select sc.sol_codigo, sc.cta_codigo, sc.cta_numero, sc.cta_nombre, ";
		query = query + "cc.cta_movimiento, cc.moneda, cc.cta_nommovimiento, cc.cta_afectable, cc.cla_vigente, sc.cla_vigente solcta_vigente, ";
		query = query + "sc.corr_cuenta, ";
		query = query
				+ "(SELECT vc.val_nombre FROM soc_valorescla vc WHERE vc.cla_codigo = 'cla_moneda' AND vc.val_codigo = cc.moneda) codmonedactalit ";
		query = query + "from soc_solicitante s, soc_solcuentas sc, soc_cuentassol cc ";
		query = query + "where s.sol_codigo = sc.sol_codigo ";
		query = query + "and sc.cta_codigo = cc.cta_codigo ";

		if (filtraVigentes) {
			query = query + "and sc.cla_vigente = 1 ";
			query = query + "and cc.cla_vigente = 1 ";
		}

		if (!StringUtils.isBlank(solCodigo)) {
			query = query + "and trim(sc.sol_codigo) = '" + solCodigo + "' ";
		}

		if (codMoneda != null) {
			query = query + "and cc.moneda = " + codMoneda + " ";
		}

		if (!StringUtils.isBlank(ctamovimiento)) {
			query = query + "and cc.cta_movimiento = '" + ctamovimiento + "' ";
		}

		if (!StringUtils.isBlank(ctaNumero)) {
			query = query + "and sc.cta_numero = '" + ctaNumero + "' ";
		}

		if (ctaCodigo != null) {
			query = query + "and cc.cta_codigo = " + ctaCodigo + " ";
		}
		if (!StringUtils.isBlank(ctaafectable)) {
			query = query + "and cc.cta_afectable = '" + ctaafectable + "' ";
		}

		if (!StringUtils.isBlank(claEntidad)) {
			query = query + "and s.cla_entidad in (" + claEntidad + ") ";
		}

		query = query + "order by cta_nommovimiento ";

		List<Map<String, Object>> resultado1 = Servicios.ejecutarQuery(query);
		for (Map<String, Object> res : resultado1) {

			CuentaS cta = new CuentaS((String) res.get("sol_codigo"), (Integer) res.get("cta_codigo"), (String) res.get("cta_movimiento"),
					(String) res.get("cta_numero"), (String) res.get("cta_nombre"), (Short) res.get("cla_vigente"));

			cta.setMoneda((Integer) res.get("moneda"));
			cta.setCtaNommovimiento((String) res.get("cta_nommovimiento"));

			String monedaSwift = (String) res.get("codmonedactalit");
			cta.setMonedaLit(monedaSwift);
			cta.setCtaAfectable((String) res.get("cta_afectable"));

			cta.setCorrCuenta((Integer) res.get("corr_cuenta"));
			cta.setSolCtaVigente((Short) res.get("solcta_vigente"));
			cuentas.add(cta);

		}

		return cuentas;
	}

	private Integer generarCodigo() {
		Integer maxDet = Integer.valueOf(0);
		StringBuffer query = new StringBuffer();
		query = query.append("select max(ctaCodigo) ");
		query = query.append("from SocCuentassol ");

		Query consulta = getSession().createQuery(query.toString());

		log.debug("Entre a generarCod " + consulta.toString());

		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;
		maxDet++;
		return maxDet;
	}

	public SocCuentassol getSocCuentasolBanqueroExt(SocSolicitudes socSolicitudes, Integer codMoneda, String ctaAfectable) {
		// retorna la cuenta del banco asignado segun la moneda de transferencia
		log.info("recuperando getSocCuentasolBanqueroExt FONDOSVISTA: " + codMoneda + " ctaAfectable " + ctaAfectable);
		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		SocCuentassol socCuentassol = null;
		if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {

			if (!StringUtils.isBlank(ctaAfectable)) {
				socCuentassol = getByAfectable(ctaAfectable);
				return socCuentassol;
			}

			List<SocCuentassol> socCuentassolLista = listaByClaveCuenta(Constants.COD_CLAVE_FONDOSVISTA, codMoneda);

			Map<String, SocCuentassol> mapactrl = new HashMap<String, SocCuentassol>();

			for (SocCuentassol socCuentassol2 : socCuentassolLista) {
				if (!mapactrl.containsKey(socCuentassol2.getCtaAfectable())) {
					mapactrl.put(socCuentassol2.getCtaAfectable(), socCuentassol2);
				}
			}
			// verificamos que exista el banco destino

			if (mapactrl.size() > 1) {
				// existen mas de un registro para la moneda en cuentassol
				// se busca la cta por defecto
				if (codMoneda != null) {
					SocValorescla socValorescla = socValoresclaDao.getValoresByCodigo("cla_af_banq", String.valueOf((codMoneda)));

					if (socValoresclaDao != null) {
						if (!StringUtils.isBlank(socValorescla.getValNombre())) {
							Integer ctaCodigo = Integer.valueOf(socValorescla.getValNombre());
							socCuentassol = getByCodigo(ctaCodigo);
						}
					}
				}
			} else {
				if (mapactrl.size() == 1) {
					// existe cuenta de fondos vista en moneda de la
					// transferencia
					socCuentassol = socCuentassolLista.get(0);
				}
			}
		}
		return socCuentassol;
	}

	public SocCuentas getSocCuentaBanqueroExt(SocSolicitudes socSolicitudes, Integer codMoneda, String ctaAfectable) {
		// recupera la cuenta del moneda del BCB
		log.info("recuperando getSocCuentaBanqueroExt: " + codMoneda + " " + ctaAfectable);
		SocValoresclaDao socValoresclaDao = new SocValoresclaDao();
		socValoresclaDao.setSessionFactory(getSessionFactory());

		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());

		SocCuentas socCuentas = null;
		if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {

			List<SocCuentas> socCuentasLista = socCuentasDao.cuentasBeneficiarioExt(null, Constants.COD_BCB_SWIFT, null, null, codMoneda, null,
					ctaAfectable, null);

			Map<String, SocCuentas> mapactrl = new HashMap<String, SocCuentas>();

			for (SocCuentas socCuentassol2 : socCuentasLista) {
				if (!mapactrl.containsKey(socCuentassol2.getCtaAfectable())) {
					mapactrl.put(socCuentassol2.getCtaAfectable(), socCuentassol2);
				}
			}

			if (mapactrl.size() > 1) {
				// existen mas de un registro para la moneda en cuentas
				// se busca la cta por defecto
				if (codMoneda != null) {
					SocValorescla socValorescla = socValoresclaDao.getValoresByCodigo("cla_banquero", String.valueOf((codMoneda)));

					if (socValoresclaDao != null) {
						if (!StringUtils.isBlank(socValorescla.getValNombre())) {
							String codBancomoneda = socValorescla.getValNombre().trim();

							List<SocCuentas> socCuentasLista2 = socCuentasDao.cuentasBeneficiarioExt(null, Constants.COD_BCB_SWIFT, codBancomoneda,
									null, codMoneda, null, ctaAfectable, null);

							if (socCuentasLista2.size() > 0) {
								socCuentas = socCuentasLista2.get(0);
							}
						}
					}
				}
			} else {
				if (mapactrl.size() == 1) {
					// existe cuenta de fondos vista en moneda de la
					// transferencia
					socCuentas = socCuentasLista.get(0);
				}
			}
		}
		return socCuentas;
	}
}
