/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.servicioSioc.common.Constants;

//import java.util.ArrayList;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class SocOperacionesDao extends HibernateDaoSupport implements BcbDao {
	private static final Log log = LogFactory.getLog(SocOperacionesDao.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * gob.bcb.service.pruebaCU.model.SolicitudDao#saveOrUpdate(gob.bcb.service
	 * .pruebaCU .model.Solicitud)
	 */
	
	public void saveOrUpdate(BcbEntity pm) {
		log.info("Saving or updating " + pm);
		// this.getHibernateTemplate().saveOrUpdate(pm);
		this.getHibernateTemplate().merge(pm);
	}
	public void saveOrUpdate(SocOperaciones pm) {
		log.info("Saving or updating " + pm);
		// this.getHibernateTemplate().saveOrUpdate(pm);
		this.getHibernateTemplate().merge(pm);
	}

	public void eliminarOperacion(SocOperaciones pm) {
		log.info("Eliminando operacion... " + pm);
		this.getHibernateTemplate().delete(pm);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see gob.bcb.core.infra.datastore.BcbDao#find(java.lang.Long)
	 */
	
	public BcbEntity find(Long id) {
		SocOperaciones operaciones = null;
		log.info("Entre a buscar el objeto con el id: " + id);
		return null;
	}

	public SocOperaciones getOperacionByCod(String opeCodigo) {

		SocOperaciones operaciones = null;
		StringBuffer query = new StringBuffer();
		query = query.append(" select op ");
		query = query.append(" from ");
		query = query.append(" SocOperaciones op ");
		query = query.append(" where op.opeCodigo = ? ");

		List<SocOperaciones> lista = (List<SocOperaciones>) getHibernateTemplate().find(query.toString(), opeCodigo);

		if (lista != null) {
			for (SocOperaciones ope : lista) {
				operaciones = ope;
			}
		}

		return operaciones;
	}
// whf req
	public List<SocOperaciones> getOperaciones(char estado) {
		List<SocOperaciones> lista = new ArrayList<SocOperaciones>();
		Query consulta = getSession().createQuery("from SocOperaciones where claEstado = :estado");

		consulta.setParameter("estado", estado);

		lista = consulta.list();

		return lista;
	}

	public SocOperaciones crearOperacion(SocSolicitudes solicitud, Date fechaValor) {
		String USUARIO = (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID);
		String estacion = (String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION);
		BigDecimal tipo = BigDecimal.valueOf(0.00);
		BigDecimal montoMN = BigDecimal.valueOf(0.00);		
		
		Date hoy = new Date();		
		// generando la operaciÃ³n
		SocOperaciones operacion = new SocOperaciones();
		String codOperacion = Long.toString(hoy.getTime());
		operacion.setOpeCodigo(codOperacion);		
		operacion.setSolCodigo(solicitud.getSolCodigo());
		operacion.setClaOperacion(solicitud.getClaTipo());
		operacion.setOpeFecha(fechaValor);
		operacion.setOpeMontome(solicitud.getSocMontome());

		String moneda = solicitud.getMonedaT();

		int mon = Servicios.getMoneda(moneda);
		operacion.setMoneda(mon);
		operacion.setOpeCtaoperacion(solicitud.getSocCuentad());
		operacion.setOpeCtacomision(solicitud.getSocCuentac());
		operacion.setOpeNrocuentac(solicitud.getSocNrocuentac());
		operacion.setOpeNrocuentad(solicitud.getSocNrocuentad());
		operacion.setSocCorrelativo(solicitud.getSocCorrelativo());
		operacion.setSocCodigo(solicitud.getSocCodigo());
		// estado default pendiente
		operacion.setClaEstado('P');
		operacion.setUsrCodigo(USUARIO);
		operacion.setEstacion(estacion);
		operacion.setFechaHora(hoy);

		tipo = QueryProcessor.getTipoCambio(mon, hoy);
		
		montoMN = solicitud.getSocMontome().multiply(tipo);
		operacion.setOpeMontomn(montoMN);

		saveOrUpdate(operacion);
		QueryProcessor.flush();
		log.info("OperaciÃ³n generada: " + operacion.getOpeCodigo());		
		return operacion;
	}
}
