package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_detallessol database table.
 * 
 */
@Embeddable
public class SocDetallessolId implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="soc_codigo")
	private String socCodigo;

	@Column(name="det_codigo")
	private Integer detCodigo;

    public SocDetallessolId() {
    }
    public SocDetallessolId(String socCodigo, int detCodigo) {
        this.socCodigo = socCodigo;
        this.detCodigo = detCodigo;
      }
    
	public String getSocCodigo() {
		return this.socCodigo;
	}
	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}
	public Integer getDetCodigo() {
		return this.detCodigo;
	}
	public void setDetCodigo(Integer detCodigo) {
		this.detCodigo = detCodigo;
	}
	
	public String toString() {
		return "SocDetallessolId [socCodigo=" + socCodigo + ", detCodigo=" + detCodigo + "]";
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((detCodigo == null) ? 0 : detCodigo.hashCode());
		result = prime * result + ((socCodigo == null) ? 0 : socCodigo.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocDetallessolId other = (SocDetallessolId) obj;
		if (detCodigo == null) {
			if (other.detCodigo != null)
				return false;
		} else if (!detCodigo.equals(other.detCodigo))
			return false;
		if (socCodigo == null) {
			if (other.socCodigo != null)
				return false;
		} else if (!socCodigo.equals(other.socCodigo))
			return false;
		return true;
	}
	
}
