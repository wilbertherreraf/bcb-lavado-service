package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_rengscomp database table.
 * 
 */
@Embeddable
public class SocRengscompId implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cpb_codigo")
	private String cpbCodigo;

	@Column(name="ren_codigo")
	private int renCodigo;

    public SocRengscompId() {
    }
    public SocRengscompId(String cpbCodigo, int renCodigo)
    {
      this.cpbCodigo = cpbCodigo;
      this.renCodigo = renCodigo;
    }
    
	public String getCpbCodigo() {
		return this.cpbCodigo;
	}
	public void setCpbCodigo(String cpbCodigo) {
		this.cpbCodigo = cpbCodigo;
	}
	public int getRenCodigo() {
		return this.renCodigo;
	}
	public void setRenCodigo(int renCodigo) {
		this.renCodigo = renCodigo;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SocRengscompId)) {
			return false;
		}
		SocRengscompId castOther = (SocRengscompId)other;
		return 
			this.cpbCodigo.equals(castOther.cpbCodigo)
			&& (this.renCodigo == castOther.renCodigo);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.cpbCodigo.hashCode();
		hash = hash * prime + this.renCodigo;
		
		return hash;
    }
	
	public String toString() {
		return "SocRengscompId [cpbCodigo=" + cpbCodigo + ", renCodigo=" + renCodigo + "]";
	}
	
}
