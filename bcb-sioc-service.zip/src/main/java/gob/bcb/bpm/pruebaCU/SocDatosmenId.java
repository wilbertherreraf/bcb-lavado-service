package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the soc_datosmen database table.
 * 
 */
@Embeddable
public class SocDatosmenId implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="cam_codigo")
	private String camCodigo;

	@Column(name="ins_codigo")
	private String insCodigo;

    public SocDatosmenId() {
    }
    public SocDatosmenId(String camCodigo, String insCodigo) {
        this.camCodigo = camCodigo;
        this.insCodigo = insCodigo;
      }
    
	public String getCamCodigo() {
		return this.camCodigo;
	}
	public void setCamCodigo(String camCodigo) {
		this.camCodigo = camCodigo;
	}
	public String getInsCodigo() {
		return this.insCodigo;
	}
	public void setInsCodigo(String insCodigo) {
		this.insCodigo = insCodigo;
	}
	
	public String toString() {
		return "SocDatosmenId [camCodigo=" + camCodigo + ", insCodigo=" + insCodigo + "]";
	}
	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((camCodigo == null) ? 0 : camCodigo.hashCode());
		result = prime * result + ((insCodigo == null) ? 0 : insCodigo.hashCode());
		return result;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SocDatosmenId other = (SocDatosmenId) obj;
		if (camCodigo == null) {
			if (other.camCodigo != null)
				return false;
		} else if (!camCodigo.equals(other.camCodigo))
			return false;
		if (insCodigo == null) {
			if (other.insCodigo != null)
				return false;
		} else if (!insCodigo.equals(other.insCodigo))
			return false;
		return true;
	}

}
