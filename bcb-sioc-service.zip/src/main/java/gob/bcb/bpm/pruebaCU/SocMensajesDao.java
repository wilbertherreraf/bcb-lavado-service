/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.exception.GenericJDBCException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author parenas
 * 
 */
public class SocMensajesDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocMensajesDao.class);

	public void saveOrUpdate(SocMensajes pm) {
		// log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public void eliminarMensaje(SocMensajes pm) {
		log.info("Eliminando mensaje... " + pm);
		this.getHibernateTemplate().delete(pm);
	}

	public SocMensajes getMensaje(String insCodigo) {

		SocMensajes men = null;

		List<SocMensajes> lista = new ArrayList<SocMensajes>();

		StringBuffer query = new StringBuffer();

		query = query.append("select m ");
		query = query.append("from SocMensajes m ");
		query = query.append("where m.claEstadomen <> 'Z' ");
		query = query.append("and m.insCodigo = :insCodigo ");

		log.info("procesando " + query.toString() + " insCodigo: " + insCodigo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("insCodigo", insCodigo);

		lista = consulta.list();

		if (lista.size() > 0) {
			men = lista.get(0);
		}
		return men;

	}

	/**
	 * Modifica el estado del registro mensajes swift
	 * 
	 * @param codMensaje
	 */
	public void grabaMensajeSwift(String codMensaje, Integer men_nroswift) {
		// guardamos el registro con el estado de que el archivo fue guardado
		// PERO lo realizamos nativamente en otra transacciÃƒÂ³n
		// el mensaje SWIFT debe ser guardado aun si la transacciÃƒÂ³n tuvo
		// errores
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
			conn.setAutoCommit(true);
			ps = conn.prepareStatement("update soc_mensajes set cla_estadomen = 'V', men_nroswift = ? where ins_codigo = ? and cla_estadomen = ? ");
			ps.setInt(1, men_nroswift);
			ps.setString(2, codMensaje);
			ps.setString(3, "E");
			// ps.setTimestamp(3, new Timestamp(new Date().getTime()));
			ps.executeUpdate();
			log.info("Estado mensaje Swift modificado " + codMensaje + " " + ps.getUpdateCount());
			ps.close();
		} catch (GenericJDBCException e) {
			log.error(e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			throw new BusinessException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));
		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			log.error("Error al ejecutar query swift " + e.getMessage(), e);
			throw new BusinessException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));

		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					log.error("EXCEPCION BASE DE DATOS: " + e.getMessage(), e);
				}
			}
			if (conn != null)
				try {
					if (!conn.isClosed()) {
						conn.close();
					}
				} catch (SQLException e) {
					log.warn("Error al realizar cerrar transaccion", e);
				}
		}

	}

	/**
	 * Modifica el estado del registro mensajes swift
	 * 
	 * @param codMensaje
	 */
	public void grabaMensajeSwift(String codMensaje) {
		// guardamos el registro con el estado de que el archivo fue guardado
		// PERO lo realizamos nativamente en otra transacciÃƒÆ’Ã‚Â³n
		// el mensaje SWIFT debe ser guardado aun si la transacciÃƒÆ’Ã‚Â³n tuvo
		// errores
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
			conn.setAutoCommit(true);
			ps = conn.prepareStatement("update soc_mensajes set cla_estadomen = 'V' where ins_codigo = ? ");
			ps.setString(1, codMensaje);
			// ps.setString(2, receiverEntityID);
			// ps.setTimestamp(3, new Timestamp(new Date().getTime()));
			ps.executeUpdate();
			// conn.commit();
			log.info("Estado mensaje Swift modificado " + codMensaje + " " + ps.getUpdateCount());
			ps.close();
		} catch (GenericJDBCException e) {
			log.error(e.getMessage(), e);
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			throw new BusinessException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));
		} catch (Exception e) {
			StringBuilder sb = new StringBuilder();
			int count = 0;
			for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
				if (cause instanceof SQLException) {
					count++;
					sb.append(cause.getMessage());
					sb.append(" , ");
				}
			}
			log.error("Error al ejecutar query swift " + e.getMessage(), e);
			throw new BusinessException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));

		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					log.error("EXCEPCION BASE DE DATOS: " + e.getMessage(), e);
				}
			}
			if (conn != null)
				try {
					if (!conn.isClosed()) {
						conn.close();
					}
				} catch (SQLException e) {
					log.warn("Error al realizar cerrar transaccion", e);
				}
		}
	}

	public List<SocMensajes> mensajesByOpeCodigo(String opeCodigo, String claEstadomen) {
		List<SocMensajes> lista = new ArrayList<SocMensajes>();

		StringBuffer query = new StringBuffer();

		query = query.append("select m ");
		query = query.append("from SocMensajes m ");
		query = query.append("where m.claEstadomen <> 'Z' ");
		query = query.append("and m.opeCodigo = :opeCodigo ");

		if (!StringUtils.isBlank(claEstadomen)) {
			query = query.append("and m.claEstadomen = :claEstadomen ");
		}
		// log.info("procesando " + query.toString() + " opeCodigo: " +
		// opeCodigo + " claEstadomen: " + claEstadomen);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);

		if (!StringUtils.isBlank(claEstadomen)) {
			consulta.setParameter("claEstadomen", claEstadomen);
		}
		lista = consulta.list();

		return lista;
	}

	public List<SocMensajes> mensajesByOpeCodigoDetCodigo(String opeCodigo, Integer detCodigo) {
		List<SocMensajes> lista = new ArrayList<SocMensajes>();

		StringBuffer query = new StringBuffer();

		query = query.append("select m ");
		query = query.append("from SocMensajes m ");
		query = query.append("where m.claEstadomen <> 'Z' ");
		query = query.append("and m.opeCodigo = :opeCodigo ");
		query = query.append("and m.detCodigo = :detCodigo ");

		log.debug("procesando " + query.toString() + " opeCodigo: " + opeCodigo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("opeCodigo", opeCodigo);
		consulta.setParameter("detCodigo", detCodigo);

		lista = consulta.list();

		return lista;
	}

	public List<SocMensajes> mensajesByParams(String insCodigo, String opeCodigo, Integer detCodigo, String claEstadomen) {
		List<SocMensajes> lista = new ArrayList<SocMensajes>();

		StringBuffer query = new StringBuffer();

		query = query.append("select m ");
		query = query.append("from SocMensajes m ");
		query = query.append("where m.claEstadomen <> 'Z' ");

		if (!StringUtils.isBlank(insCodigo)) {
			query = query.append("and m.insCodigo = :insCodigo ");
		}
		if (!StringUtils.isBlank(opeCodigo)) {
			query = query.append("and m.opeCodigo = :opeCodigo ");
		}
		if (detCodigo != null) {
			query = query.append("and m.detCodigo = :detCodigo ");
		}

		if (!StringUtils.isBlank(claEstadomen)) {
			query = query.append("and m.claEstadomen = :claEstadomen ");
		}

		query = query.append("order by m.menFechavalor ");

		log.debug("procesando " + query.toString() + " opeCodigo: " + opeCodigo);
		Query consulta = getSession().createQuery(query.toString());

		if (!StringUtils.isBlank(insCodigo)) {
			consulta.setParameter("insCodigo", insCodigo);
		}

		if (!StringUtils.isBlank(opeCodigo)) {
			consulta.setParameter("opeCodigo", opeCodigo);
		}
		if (detCodigo != null) {
			consulta.setParameter("detCodigo", detCodigo);
		}

		if (!StringUtils.isBlank(claEstadomen)) {
			consulta.setParameter("claEstadomen", claEstadomen);
		}

		lista = consulta.list();

		return lista;
	}

	public SocMensajes crearActualizar(SocMensajes mensaje, String flagCreaLoader) {
		log.info("Ingresando a Mensaje(registrarMensSwift): " + mensaje.toString());

		// verificamos que no se duplique mensajes
		List<SocMensajes> mensajelist = mensajesByOpeCodigoDetCodigo(mensaje.getOpeCodigo(), mensaje.getDetCodigo());

		if (mensajelist.size() == 0) {
			// no existe el registro se crea
			String InsCodigo = mensaje.getOpeCodigo() + String.format("%03d", mensaje.getDetCodigo());
			// String InsCodigo =
			// mensaje.getOpeCodigo().concat(mensaje.getDetCodigo().toString());
			mensaje.setFechaHora(new Date());
			mensaje.setInsCodigo(InsCodigo);
			mensaje.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
			if (flagCreaLoader != null && flagCreaLoader.equals("E")) {
				saveOrUpdate(mensaje);
			}

			return mensaje;
		} else {
			// se actualiza
			SocMensajes mensajeOld = mensajelist.get(0);
			if (mensajeOld.getInsCodigo().equals(mensaje.getInsCodigo())) {
				// existe el mensaje
				mensaje.setFechaHora(new Date());
				mensaje.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));
				saveOrUpdate(mensaje);

				return mensaje;

			} else {
				log.error("Control de duplicados: codoperacion " + mensaje.getOpeCodigo() + " detalle " + mensaje.getDetCodigo()
						+ " ya tiene registro en mensaje swift con codigo " + mensajeOld.getInsCodigo());
				throw new BusinessException("Control de duplicados: codoperacion " + mensaje.getOpeCodigo() + " detalle " + mensaje.getDetCodigo()
						+ " ya tiene registro en mensaje swift con codigo " + mensajeOld.getInsCodigo());
			}
		}
	}
}

