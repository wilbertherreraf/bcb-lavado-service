package gob.bcb.bpm.pruebaCU;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocComitipoopeDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocComitipoopeDao.class);

	public List<SocComitipoope> comisionesByTipoOper(String claOperacion) {
		List<SocComitipoope> lista = new ArrayList<SocComitipoope>();

		StringBuffer query = new StringBuffer();

		query = query.append(" select da");
		query = query.append(" from SocComitipoope da");
		query = query.append(" where da.id.claOperacion = :claOperacion ");

		log.debug("procesando " + query.toString() + " " + claOperacion);
		Query consulta = getSession().createQuery(query.toString());

		if (claOperacion != null) {
			consulta.setParameter("claOperacion", claOperacion);
		}

		lista = consulta.list();

		return lista;
	}

	public List<SocComitipoope> comisionesByCodCargo(Integer codCargo) {
		List<SocComitipoope> lista = new ArrayList<SocComitipoope>();
		// whf ojo cambiar o filtrar det_comi
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);

		lista = consulta.list();

		return lista;
	}

	public SocComitipoope comisionByCodCargoTipoComis(Integer codCargo, String claComision) {
		SocComitipoope socComitipoope = null;
		
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");
		query = query.append("and da.id.claComision = :claComision ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo+ " claComision: " + claComision);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);
		consulta.setParameter("claComision", claComision);
		List lista = consulta.list();

		if (lista.size() > 0) {
			socComitipoope = (SocComitipoope) lista.get(0);
		}
		return socComitipoope;
	}
	
	public SocComitipoope comisionByCargo(Integer codCargo, String claTipocargo) {
		StringBuffer query = new StringBuffer();

		query = query.append("select da ");
		query = query.append("from SocComitipoope da ");
		query = query.append("where da.id.codCargo = :codCargo ");
		query = query.append("and da.claTipocargo = :claTipocargo ");

		log.debug("procesando " + query.toString() + " codCargo: " + codCargo+ " claTipocargo: " + claTipocargo);
		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("codCargo", codCargo);
		consulta.setParameter("claTipocargo", claTipocargo);
		List lista = consulta.list();

		if (lista.size() == 1) {
			return (SocComitipoope) lista.get(0);
		}
		return null;		
	}
	
}
