/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author faflores
 */
@Entity
@Table(name = "soc_usuariosol")
public class SocUsuariosol implements Serializable {
    private static final long serialVersionUID = 1L;
    @EmbeddedId
    private SocUsuariosolPK socUsuariosolPK;
    
    @Column(name = "cla_vigente")
    private Short claVigente;
    
    @Column(name = "usr_email")
    private String usrEmail;
    
    @Column(name = "usr_notifica")
    private String usrNotifica;

    @Column(name = "usr_codigo")
    private String usrCodigo;

    @Column(name = "usr_nombre")
    private String usrNombre;
    
    @Column(name = "usr_iniciales")
    private String usrIniciales;
    
    @Column(name = "fecha_hora")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaHora;
    
    @Column(name = "estacion")
    private String estacion;

    public SocUsuariosol() {
    }

    public SocUsuariosol(SocUsuariosolPK socUsuariosolPK) {
        this.socUsuariosolPK = socUsuariosolPK;
    }

    public SocUsuariosol(String solCodigo, String login) {
        this.socUsuariosolPK = new SocUsuariosolPK(solCodigo, login);
    }

    public SocUsuariosolPK getSocUsuariosolPK() {
        return socUsuariosolPK;
    }

    public void setSocUsuariosolPK(SocUsuariosolPK socUsuariosolPK) {
        this.socUsuariosolPK = socUsuariosolPK;
    }

    public Short getClaVigente() {
        return claVigente;
    }

    public void setClaVigente(Short claVigente) {
        this.claVigente = claVigente;
    }

    public String getUsrCodigo() {
        return usrCodigo;
    }

    public void setUsrCodigo(String usrCodigo) {
        this.usrCodigo = usrCodigo;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getEstacion() {
        return estacion;
    }

    public void setEstacion(String estacion) {
        this.estacion = estacion;
    }

    
    public int hashCode() {
        int hash = 0;
        hash += (socUsuariosolPK != null ? socUsuariosolPK.hashCode() : 0);
        return hash;
    }

    
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SocUsuariosol)) {
            return false;
        }
        SocUsuariosol other = (SocUsuariosol) object;
        if ((this.socUsuariosolPK == null && other.socUsuariosolPK != null) || (this.socUsuariosolPK != null && !this.socUsuariosolPK.equals(other.socUsuariosolPK))) {
            return false;
        }
        return true;
    }

    
    public String toString() {
        return "websiocproduccion.SocUsuariosol[socUsuariosolPK=" + socUsuariosolPK + "]";
    }

	public String getUsrEmail() {
		return usrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		this.usrEmail = usrEmail;
	}

	public String getUsrNotifica() {
		return usrNotifica;
	}

	public void setUsrNotifica(String usrNotifica) {
		this.usrNotifica = usrNotifica;
	}

	public String getUsrNombre() {
		return usrNombre;
	}

	public void setUsrNombre(String usrNombre) {
		this.usrNombre = usrNombre;
	}

	public String getUsrIniciales() {
		return usrIniciales;
	}

	public void setUsrIniciales(String usrIniciales) {
		this.usrIniciales = usrIniciales;
	}

}
