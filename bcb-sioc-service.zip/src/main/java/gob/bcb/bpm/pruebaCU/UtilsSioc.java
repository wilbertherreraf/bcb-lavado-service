package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;
import gob.bcb.service.servicioTres.model.FactorConvMnDao;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.collections.map.LRUMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class UtilsSioc {
	private static final Log log = LogFactory.getLog(UtilsSioc.class);
	public static final String COD_MONEDA_USD_COMPRA = "34";
	public static final String COD_MONEDA_USD_VENTA = "35";
	public static final String COD_MONEDA_BS = "69";

	private static FactorConvMnDao factorConvMnDao;

	private BigDecimal montoOrigen;
	private String monedaOrigen;
	private String monedaDestino;
	private Date fecha;
	private BigDecimal tcDefecto;
	private String compraVenta;
	private String monedaCompraVenta;

	// expresa el monto en bolivianos del monto original segun el tipo de la
	// cuenta
	/**
	 * expresa el monto en bolivianos del monto original segun el tipo de la
	 * cuenta
	 */
	private BigDecimal montoBS = BigDecimal.ZERO;
	/**
	 * monto que se expresa en la moneda destino
	 */
	private BigDecimal montoConvMonDestino = BigDecimal.ZERO;

	/**
	 * expresa el monto en dolares del monto original segun el tipo de la cuenta
	 */
	private BigDecimal montoSUS = BigDecimal.ZERO;

	/**
	 * expresa la cantidad de bolivianos por la venta de dolares depende a la
	 * moneda de la cuenta
	 */

	private BigDecimal ventaUSDEnBS = BigDecimal.ZERO.setScale(2, BigDecimal.ROUND_HALF_UP);

	/**
	 * Diferencial de ajuste por la venta de usd es el total por vender en bs
	 * real menos el total compra
	 */
	private BigDecimal diferencialCambPorVenta = BigDecimal.ZERO;

	/**
	 * Diferencial de ajuste por la venta de usd es el total por vender en bs
	 * real menos el total registrado
	 */
	private BigDecimal diferencialAjusteBs = BigDecimal.ZERO;

	/**
	 * Tipo de cambio de moneda origen
	 */
	private BigDecimal tcMonedaOrigen;

	private static boolean initializedFactores = false;
	private static Map<String, BigDecimal> factores;

	public UtilsSioc() {
	}

	private UtilsSioc(BigDecimal montoOrigen, String monedaOrigen, String monedaDestino, Date fecha, BigDecimal tcDefecto, String compraVenta) {
		this();
		montoOrigen = montoOrigen.setScale(2, BigDecimal.ROUND_HALF_UP);

		monedaCompraVenta = (compraVenta.equals("V") ? COD_MONEDA_USD_VENTA : COD_MONEDA_USD_COMPRA);

		this.montoOrigen = montoOrigen;
		this.monedaOrigen = monedaOrigen;
		this.monedaDestino = monedaDestino;
		this.fecha = fecha;
		this.tcDefecto = tcDefecto;
		this.compraVenta = compraVenta;

	}

	private void initFactores() {
		if (!initializedFactores) {
			factores = new LRUMap(100);
			initializedFactores = true;
			log.info("Cache Factores inicializado!...");
		}
	}

	public static UtilsSioc getInstance(BigDecimal monto, String monOrigen, String monDestino, Date fecha, BigDecimal tcDefecto, String debitoAbono) {
		monto = (monto == null ? BigDecimal.ZERO : monto);

		if (StringUtils.isBlank(debitoAbono) || (!debitoAbono.equalsIgnoreCase("V") && !debitoAbono.equalsIgnoreCase("C"))) {
			throw new RuntimeException("Tipo Compra venta debe ser V o C. " + debitoAbono);
		}

		debitoAbono = debitoAbono.toUpperCase();

		UtilsSioc utilsSioc = new UtilsSioc(monto, monOrigen, monDestino, fecha, tcDefecto, debitoAbono);
		return utilsSioc;
	}

	public static UtilsSioc getInstance(BigDecimal monto, Integer monOrigen, Integer monDestino, Date fecha, BigDecimal tcDefecto, String debitoAbono) {
		monOrigen = (monOrigen == null ? Integer.valueOf(0) : monOrigen);
		monDestino = (monDestino == null ? Integer.valueOf(0) : monDestino);

		UtilsSioc utilsSioc = getInstance(monto, monOrigen.toString(), monDestino.toString(), fecha, tcDefecto, debitoAbono);
		return utilsSioc;
	}

	/**
	 * convierte una moneda a otra con el tipo de cambio especificado TipoCotiz
	 * = 'V' Venta,TipoCotiz = 'C' Compra, nulo o vacio tipoc de cambio Venta
	 * compra
	 * 
	 * @param monOrigen
	 * @param monDestino
	 * @param monto
	 * @param fecha
	 * @param tipoCotiz
	 * @return
	 */

	public static Map<String, Object> conversion(BigDecimal monto, Integer monOrigen, Integer monDestino, Date fechaTc, BigDecimal tcDefecto,
			String debitoAbono) {
		UtilsSioc utilsSioc = getInstance(monto, monOrigen, monDestino, fechaTc, tcDefecto, debitoAbono);

		return utilsSioc.conversion();
	}

	public static Map<String, Object> conversion(BigDecimal monto, Integer monOrigen, Integer monDestino, Date fechaTc, String debitoAbono) {
		// UtilsSioc utilsSioc = getInstance(monto, monOrigen, monDestino,
		// fechaTc, null, debitoAbono);

		return conversion(monto, monOrigen, monDestino, fechaTc, null, debitoAbono);
	}

	public static Map<String, Object> conversion(BigDecimal montoOrdenado, String codMonedaOrdenado, String codMonedaCtaDebito, Date fechaTc,
			BigDecimal tcDefecto, String debitoAbono) {

		UtilsSioc utilsSioc = getInstance(montoOrdenado, codMonedaOrdenado, codMonedaCtaDebito, fechaTc, tcDefecto, debitoAbono);

		Map<String, Object> montoConvertido = utilsSioc.conversion();
		return montoConvertido;
	}

	private Map<String, Object> conversion() {

		Map<String, Object> resp = new HashMap<String, Object>();

		tcMonedaOrigen = getFactorTC(monedaOrigen, fecha);
		tcMonedaOrigen = tcMonedaOrigen.setScale(5, BigDecimal.ROUND_HALF_UP);
		// tipo de cambio mon origen por boliviano . valor extraido de coin
		BigDecimal tipoCambioMOxBS = BigDecimal.ZERO;
		BigDecimal tipoCambioMDest = BigDecimal.ZERO;

		BigDecimal tipoCambioCompra = getFactorTC(COD_MONEDA_USD_COMPRA, fecha);
		tipoCambioCompra = tipoCambioCompra.setScale(5, BigDecimal.ROUND_HALF_UP);

		// ********************************************************************************/
		// si debitoAbono = V es Venta: que la cuenta de donde se sacara la
		// platita es de Bolivianos

		// si debitoAbono = C es Compra: que la cuenta de donde se sacara la
		// platita es de Dolares o es para una conversion contable que siempre
		// es a tipo de cambio de compra

		BigDecimal tipoCambioSUS = getFactorTC(monedaCompraVenta, fecha);
		tipoCambioSUS = tipoCambioSUS.setScale(5, BigDecimal.ROUND_HALF_UP);

		if (monedaDestino.trim().equals(COD_MONEDA_BS)) {
			// moneda cta del prestamo es en bols
			if (monedaOrigen.trim().equals(COD_MONEDA_BS)) {
				// el monto esta en bols
				// tipocambio deberÃƒÂ­a de ser 1
				montoSUS = montoOrigen.divide(tipoCambioSUS, 2, RoundingMode.HALF_UP);
				montoConvMonDestino = montoSUS.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				tipoCambioMOxBS = BigDecimal.ONE;

				if (compraVenta.equals("C")) {
					montoConvMonDestino = montoOrigen;
				}

			} else if (monedaOrigen.equals(COD_MONEDA_USD_COMPRA)) {
				// moneda es dolar el tipo de cambio debe se el de venta ya que
				// se compra dolares del BCB

				montoConvMonDestino = montoOrigen.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);
				montoSUS = montoOrigen;

				tcMonedaOrigen = tipoCambioSUS;
				tipoCambioMOxBS = tipoCambioSUS;
			} else if (monedaOrigen.equals("76")) {
				montoConvMonDestino = montoOrigen.multiply(tcMonedaOrigen).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoSUS = montoConvMonDestino.divide(tipoCambioCompra, 2, RoundingMode.HALF_UP);

				ventaUSDEnBS = BigDecimal.ZERO;

				tipoCambioMOxBS = tcMonedaOrigen;

			} else if (monedaOrigen.equals("50")) {
				// SDR
				// se trabaja con dolares
				BigDecimal montoUSDSDR = montoOrigen.multiply(tcDefecto).setScale(2, BigDecimal.ROUND_HALF_UP);
				montoConvMonDestino = montoUSDSDR.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoSUS = montoUSDSDR;

				// hay venta de dolar
				ventaUSDEnBS = montoConvMonDestino;

				// venta - compra de usd
				diferencialCambPorVenta = ventaUSDEnBS.subtract(montoUSDSDR.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioCompra)
						.setScale(2, BigDecimal.ROUND_HALF_UP));

				tipoCambioMOxBS = tcMonedaOrigen;
				tcMonedaOrigen = tcDefecto;
			} else {
				// convertimos a bs; ojo que el tipoCambioMO es a tc compra
				// segun bolsin
				BigDecimal montoConvBsTCcompra = montoOrigen.multiply(tcMonedaOrigen);
				montoConvBsTCcompra = montoConvBsTCcompra.setScale(2, BigDecimal.ROUND_HALF_UP);
				// convertimos a SUS por el tipo de cambio de compra
				// monto al tipo ce cambio de venta ya el montosus expresa
				// los bolivianos lo convertimos a dolar por el tc compra
				BigDecimal montoEnUSDTCCOmpra = montoConvBsTCcompra.divide(tipoCambioCompra, 5, RoundingMode.HALF_UP);

				// si es sin venta sera el monto multiplicado por el tc de la
				// moneda
				// si es con con venta sera el equivalente de los dolares
				// vendidos
				montoConvMonDestino = montoEnUSDTCCOmpra.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoSUS = montoEnUSDTCCOmpra.setScale(2, BigDecimal.ROUND_HALF_UP);

				tipoCambioMOxBS = tcMonedaOrigen;
			}
			montoBS = montoConvMonDestino;

			tipoCambioMDest = BigDecimal.ONE;
		} else if (monedaDestino.equals(COD_MONEDA_USD_COMPRA)) {

			// *****************************************************///
			// *****************************************************///

			// la moneda de la cuenta es SUS de la cual se debitara
			if (monedaOrigen.equals(COD_MONEDA_USD_COMPRA)) {
				// la moneda es en dolares el tipo de cambio debe ser el de
				// compra
				montoConvMonDestino = montoOrigen;

				montoBS = montoConvMonDestino.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);
				tcMonedaOrigen = tipoCambioSUS;
				tipoCambioMOxBS = tipoCambioSUS;

			} else if (monedaOrigen.trim().equals("50")) {
				montoConvMonDestino = montoOrigen.multiply(tcDefecto).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoBS = montoConvMonDestino.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				// tc del coin
				tipoCambioMOxBS = tcMonedaOrigen;

				tcMonedaOrigen = tcDefecto;
			} else if (monedaOrigen.trim().equals(COD_MONEDA_BS)) {
				// se debe convertir a dolar al tipo de cambio de venta
				// monto en dolares que se vende o compra
				montoConvMonDestino = montoOrigen.divide(tipoCambioSUS, 2, RoundingMode.HALF_UP);
				montoBS = montoOrigen;

				tipoCambioMOxBS = tipoCambioSUS;

			} else {
				// otra moneda se convierte a bs y posterior a ello se dolariza
				// se conv a bolivianos

				BigDecimal montoConvBsTCcompra = montoOrigen.multiply(tcMonedaOrigen);
				montoConvBsTCcompra = montoConvBsTCcompra.setScale(2, BigDecimal.ROUND_HALF_UP);
				// convertimos a SUS por el tipo de cambio de compra
				// monto al tipo ce cambio de venta ya el montosus expresa
				// los bolivianos lo convertimos a dolar por el tc compra
				montoConvMonDestino = montoConvBsTCcompra.divide(tipoCambioCompra, 5, RoundingMode.HALF_UP);

				montoBS = montoConvMonDestino.multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				tipoCambioMOxBS = tcMonedaOrigen;

			}

			montoSUS = montoConvMonDestino;
			tipoCambioMDest = tipoCambioSUS;
		} else {

			// si la moneda destino no es USD ni BS y la moneda origen
			// es
			// USD
			// se realiza un puente en sus

			Map<String, Object> montoConvertido = getInstance(montoOrigen, monedaOrigen, COD_MONEDA_USD_COMPRA, fecha, tcDefecto, compraVenta)
					.conversion();

			montoSUS = (BigDecimal) montoConvertido.get("monto");

			montoBS = montoSUS.multiply(tipoCambioCompra).setScale(2, BigDecimal.ROUND_HALF_UP);

			tipoCambioMDest = getFactorTC(monedaDestino, fecha);
			tipoCambioMDest = tipoCambioMDest.setScale(5, BigDecimal.ROUND_HALF_UP);
			montoConvMonDestino = montoBS.divide(tipoCambioMDest, 2, RoundingMode.HALF_UP);

			montoSUS = montoBS.divide(tipoCambioSUS, 2, RoundingMode.HALF_UP);
			tipoCambioMOxBS = tcMonedaOrigen;

		}
		montoConvMonDestino = montoConvMonDestino.setScale(2, BigDecimal.ROUND_HALF_UP);
		BigDecimal montoBSxSUSVenta = montoSUS.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioSUS).setScale(2, BigDecimal.ROUND_HALF_UP);
		if (compraVenta.equals("V")) {
			ventaUSDEnBS = montoBSxSUSVenta;
		}
		BigDecimal montoBSxSUSCompra = montoSUS.setScale(2, BigDecimal.ROUND_HALF_UP).multiply(tipoCambioCompra)
				.setScale(2, BigDecimal.ROUND_HALF_UP);

		diferencialCambPorVenta = montoBSxSUSVenta.subtract(montoBSxSUSCompra);

		// si las monedas origen y destino son iguales se almacena el monto
		// origen
		// sino sera el calculado

		// si las monedas origen y destino son iguales se almacena el monto
		// origen
		// sino sera el calculado
		BigDecimal montoMO = BigDecimal.ZERO;
		if (monedaDestino.equals(monedaOrigen)) {
			montoMO = montoOrigen;
		} else {
			montoMO = montoConvMonDestino;
		}
		montoMO = montoMO.setScale(2, BigDecimal.ROUND_HALF_UP);
		montoSUS = montoSUS.setScale(2, BigDecimal.ROUND_HALF_UP);

		resp.put("tipocambiosus", tipoCambioSUS);
		resp.put("tipocambiomo", tcMonedaOrigen);
		resp.put("tipocambiomoxbs", tipoCambioMOxBS);
		resp.put("tipocambiomdest", tipoCambioMDest);
		resp.put("monto", montoConvMonDestino);
		resp.put("montomo", montoMO);
		resp.put("montobs", montoBS);
		resp.put("montosus", montoSUS);
		resp.put("ventasusexpenbs", ventaUSDEnBS);
		resp.put("difventasus", diferencialCambPorVenta);

		// log.info("Conversion[" + monto + " (" + monOrigen + " -> " +
		// monDestino + ")] a " + tipoCambioSUS + " es=> " +
		// ArrayUtils.toString(resp));

		return resp;
	}

	public BigDecimal getFactorTC0(String codMoneda, Date fecha) {
		String key = codMoneda.concat(UtilsDate.stringFromDate(fecha, "ddMMyyyy"));
		BigDecimal tipoCambio = BigDecimal.ZERO;
		initFactores();
		if (!factores.containsKey(key)) {
			tipoCambio = QueryProcessor.getTipoCambio(codMoneda, fecha);
			factores.put(key, tipoCambio);
		}

		return factores.get(key);
	}

	public BigDecimal getFactorTC(String codMoneda, Date fecha) {
		String key = codMoneda.concat(UtilsDate.stringFromDate(fecha, "ddMMyyyy"));

		initFactores();
		BigDecimal tipoCambio = factores.get(key);

		if (tipoCambio == null || tipoCambio.compareTo(BigDecimal.ZERO) <= 0) {
			if (factorConvMnDao == null) {
				throw new RuntimeException("Parametro factorConvMnDao nulo, setear valor");
			}
			tipoCambio = factorConvMnDao.getTC(Integer.valueOf(codMoneda), fecha);
			factores.put(key, tipoCambio);
			log.info("Cacheando TC " + key + " => " + tipoCambio);
		}

		return tipoCambio;
	}

	public static void main(String[] args) {
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		if (!pathHome.startsWith("e:")) {
			pathHome = "e:".concat(pathHome);
		}
		ConfigurationServ.setServiceName(properties.getProperty("service.name"));

		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);

		BigDecimal montoOrdenado = BigDecimal.valueOf(32230856.8);
		Integer codMonedaOrdenado = 53;

		Integer codMonedaCtaDebito = 34;
		Date fechaTc = UtilsDate.dateFromString("29/03/2016", "dd/MM/yyyy");

		String compraVenta = "V";

		String urlBroker = ConfigurationServ.getConfigProperty("jms.broker.url");
		gob.bcb.core.jms.Constants.setUrlBroker(urlBroker);

		String[] appContextList = { "classpath:applicationcontextSioc.xml", "classpath:applicationcontextSiocCoin.xml",
				"classpath:applicationcontextPortia.xml" };
		try {
			FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(appContextList);
			ApplicationContext applicationContext = appContext;
			SessionFactory sessionFactorySioc = (SessionFactory) applicationContext.getBean("sessionFactoryBean");
			SessionFactory sessionFactoryBeanSiocCoin = (SessionFactory) applicationContext.getBean("sessionFactoryBeanSiocCoin");

			QueryProcessor.setSessionFactory(sessionFactorySioc);
			QueryProcessor.setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
			SiocCoinService.setSessionFactory(sessionFactoryBeanSiocCoin);
			SiocCoinService.setNameSessionFactory(Constants.PROP_ALIAS_COIN);

			Map<String, Object> montoConvertido = UtilsSioc.conversion(montoOrdenado, codMonedaOrdenado.toString(), codMonedaCtaDebito.toString(),
					fechaTc, null, compraVenta);
			BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
			BigDecimal monto = (BigDecimal) montoConvertido.get("monto");
			BigDecimal montosus = (BigDecimal) montoConvertido.get("montosus");
			System.out.println("montomo " + montoMO + " -> monto " + monto + " --> ".concat(" montosus ").concat(montosus.toString())
					+ ArrayUtils.toString(montoConvertido));

			montoConvertido = UtilsSioc.conversion(montoOrdenado, codMonedaOrdenado.toString(), "34", fechaTc, null, compraVenta);
			montoMO = (BigDecimal) montoConvertido.get("montomo");
			monto = (BigDecimal) montoConvertido.get("monto");
			montosus = (BigDecimal) montoConvertido.get("montosus");
			System.out.println("montomo " + montoMO + " -> monto " + monto + " --> ".concat(" montosus ").concat(montosus.toString())
					+ ArrayUtils.toString(montoConvertido));
			// montoConvertido = UtilsSioc.conversion(montoMO,
			// codMonedaCtaDebito.toString(), codMonedaOrdenado.toString(),
			// fechaTc, null, "V");
			// BigDecimal montoMOv = (BigDecimal)
			// montoConvertido.get("montomo");
			// System.out.println("VE " + montoMOv + " " +
			// ArrayUtils.toString(montoConvertido));
			//
			// montoConvertido = UtilsSioc.conversion(montoMO,
			// codMonedaCtaDebito.toString(), codMonedaOrdenado.toString(),
			// fechaTc, null, "C");
			// BigDecimal montoMOc = (BigDecimal)
			// montoConvertido.get("montomo");
			// System.out.println("CO " + montoMOc + " " +
			// ArrayUtils.toString(montoConvertido));

			sessionFactorySioc.close();
			appContext.stop();
			appContext.close();
			System.out.println("==========================FIN MENSAJE RECIBIDO==========================");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.exit(0);
		}
	}

	public FactorConvMnDao getFactorConvMnDao() {
		return factorConvMnDao;
	}

	public void setFactorConvMnDao(FactorConvMnDao factorConvMnDao) {
		UtilsSioc.factorConvMnDao = factorConvMnDao;
	}
}
