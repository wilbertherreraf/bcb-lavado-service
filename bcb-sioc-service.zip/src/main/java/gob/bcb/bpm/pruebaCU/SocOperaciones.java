package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the soc_operaciones database table.
 * 
 */
@Entity
@Table(name="soc_operaciones")
public class SocOperaciones implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ope_codigo")
	private String opeCodigo;

	@Column(name="cla_estado")
	private Character claEstado;

	@Column(name="cla_operacion")
	private String claOperacion;

	@Column(name="cve_subtipooper")
	private String cveSubtipooper;

	@Column(name="cve_tipoctacom")
	private String cveTipoctacom;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)	
	@Column(name="fecha_hora")
	private Date fechaHora;

    @Temporal( TemporalType.DATE)
	@Column(name="fecha_reg")
	private Date fechaReg;

	private Integer moneda;

	@Column(name="cod_transac")
	private Integer codTransac;
	
	@Column(name="esq_codigo")
	private Integer esqCodigo;

	@Column(name="ope_ctacomision")
	private Integer opeCtacomision;

	@Column(name="ope_ctaoperacion")
	private Integer opeCtaoperacion;

	@Temporal(TemporalType.DATE)	
	@Column(name="ope_fecha")
	private Date opeFecha;

	@Column(name="ope_montome")
	private BigDecimal opeMontome;

	@Column(name="ope_montomn")
	private BigDecimal opeMontomn;

	@Column(name="ope_nrocuentac")
	private String opeNrocuentac;

	@Column(name="ope_nrocuentad")
	private String opeNrocuentad;

	@Column(name="soc_codigo")
	private String socCodigo;

	@Column(name="soc_correlativo")
	private String socCorrelativo;

	@Column(name="sol_codigo")
	private String solCodigo;

	@Column(name="usr_codigo")
	private String usrCodigo;

	@Column(name="sol_entsolic")
	private String solEntsolic;
	
	@Column(name="glosa_refencia")
	private String glosaRefencia;

	public SocOperaciones() {
    }

    public SocOperaciones(String opeCodigo, String solCodigo)
    {
      this.opeCodigo = opeCodigo;
      this.solCodigo = solCodigo;
    }

    public SocOperaciones(String opeCodigo, String solCodigo,
          String claOperacion, Date opeFecha, BigDecimal opeMontome,
          BigDecimal opeMontomn, int moneda, Integer opeCtaoperacion,
        Integer opeCtacomision,
          Character claEstado, String opeNrocuentac, String socCorrelativo,
        String opeNrocuentad, String socCodigo)
    {
      this.opeCodigo = opeCodigo;
      this.solCodigo = solCodigo;
      this.claOperacion = claOperacion;
      this.opeFecha = opeFecha;
      this.opeMontome = opeMontome;
      this.opeMontomn = opeMontomn;
      this.moneda = moneda;
      this.opeCtaoperacion = opeCtaoperacion;
      this.opeCtacomision = opeCtacomision;
      this.claEstado = claEstado;
      this.opeNrocuentac = opeNrocuentac;
      this.socCorrelativo = socCorrelativo;
      this.opeNrocuentad = opeNrocuentad;
      this.socCodigo = socCodigo;
    }

    public SocOperaciones(String opeCodigo, String solCodigo,
        String claOperacion, Date opeFecha, BigDecimal opeMontome,
        BigDecimal opeMontomn, int moneda, Integer opeCtaoperacion,
        Integer opeCtacomision,
        Character claEstado, String opeNrocuentac, String socCorrelativo,
        String opeNrocuentad)
    {
      this.opeCodigo = opeCodigo;
      this.solCodigo = solCodigo;
      this.claOperacion = claOperacion;
      this.opeFecha = opeFecha;
      this.opeMontome = opeMontome;
      this.opeMontomn = opeMontomn;
      this.moneda = moneda;
      this.opeCtaoperacion = opeCtaoperacion;
      this.opeCtacomision = opeCtacomision;
      this.claEstado = claEstado;
      this.opeNrocuentac = opeNrocuentac;
      this.socCorrelativo = socCorrelativo;
      this.opeNrocuentad = opeNrocuentad;
    }

    public SocOperaciones(String opeCodigo, String solCodigo,
        String claOperacion, Date opeFecha, BigDecimal opeMontome,
        BigDecimal opeMontomn, int moneda, Integer opeCtaoperacion,
        Integer opeCtacomision, String usrCodigo, Date fechaHora,
        String estacion,
        Character claEstado, String opeNrocuentac, String socCorrelativo,
        String opeNrocuentad)
    {
      this.opeCodigo = opeCodigo;
      this.solCodigo = solCodigo;
      this.claOperacion = claOperacion;
      this.opeFecha = opeFecha;
      this.opeMontome = opeMontome;
      this.opeMontomn = opeMontomn;
      this.moneda = moneda;
      this.opeCtaoperacion = opeCtaoperacion;
      this.opeCtacomision = opeCtacomision;
      this.usrCodigo = usrCodigo;
      this.fechaHora = fechaHora;
      this.estacion = estacion;
      this.claEstado = claEstado;
      this.opeNrocuentac = opeNrocuentac;
      this.socCorrelativo = socCorrelativo;
      this.opeNrocuentad = opeNrocuentad;
    }

    public SocOperaciones(String opeCodigo, String solCodigo,
        String claOperacion, Date opeFecha, BigDecimal opeMontome,
        BigDecimal opeMontomn, int moneda, Integer opeCtaoperacion,
        Integer opeCtacomision, String usrCodigo, Date fechaHora,
        String estacion,
        Character claEstado, String opeNrocuentac, String socCorrelativo,
        String opeNrocuentad, String socCodigo)
    {
      this.opeCodigo = opeCodigo;
      this.solCodigo = solCodigo;
      this.claOperacion = claOperacion;
      this.opeFecha = opeFecha;
      this.opeMontome = opeMontome;
      this.opeMontomn = opeMontomn;
      this.moneda = moneda;
      this.opeCtaoperacion = opeCtaoperacion;
      this.opeCtacomision = opeCtacomision;
      this.usrCodigo = usrCodigo;
      this.fechaHora = fechaHora;
      this.estacion = estacion;
      this.claEstado = claEstado;
      this.opeNrocuentac = opeNrocuentac;
      this.socCorrelativo = socCorrelativo;
      this.opeNrocuentad = opeNrocuentad;
      this.socCodigo = socCodigo;
    }
    
	public String getOpeCodigo() {
		return this.opeCodigo;
	}

	public void setOpeCodigo(String opeCodigo) {
		this.opeCodigo = opeCodigo;
	}

	public Character getClaEstado() {
		return this.claEstado;
	}

	public void setClaEstado(Character claEstado) {
		this.claEstado = claEstado;
	}

	public String getClaOperacion() {
		return this.claOperacion;
	}

	public void setClaOperacion(String claOperacion) {
		this.claOperacion = claOperacion;
	}

	public String getCveSubtipooper() {
		return this.cveSubtipooper;
	}

	public void setCveSubtipooper(String cveSubtipooper) {
		this.cveSubtipooper = cveSubtipooper;
	}

	public String getCveTipoctacom() {
		return this.cveTipoctacom;
	}

	public void setCveTipoctacom(String cveTipoctacom) {
		this.cveTipoctacom = cveTipoctacom;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaReg() {
		return this.fechaReg;
	}

	public void setFechaReg(Date fechaReg) {
		this.fechaReg = fechaReg;
	}

	public Integer getMoneda() {
		return this.moneda;
	}

	public void setMoneda(Integer moneda) {
		this.moneda = moneda;
	}

	public Integer getOpeCtacomision() {
		return this.opeCtacomision;
	}

	public void setOpeCtacomision(Integer opeCtacomision) {
		this.opeCtacomision = opeCtacomision;
	}

	public Integer getOpeCtaoperacion() {
		return this.opeCtaoperacion;
	}

	public void setOpeCtaoperacion(Integer opeCtaoperacion) {
		this.opeCtaoperacion = opeCtaoperacion;
	}

	public Date getOpeFecha() {
		return this.opeFecha;
	}

	public void setOpeFecha(Date opeFecha) {
		this.opeFecha = opeFecha;
	}

	public BigDecimal getOpeMontome() {
		return this.opeMontome;
	}

	public void setOpeMontome(BigDecimal opeMontome) {
		this.opeMontome = opeMontome;
	}

	public BigDecimal getOpeMontomn() {
		return this.opeMontomn;
	}

	public void setOpeMontomn(BigDecimal opeMontomn) {
		this.opeMontomn = opeMontomn;
	}

	public String getOpeNrocuentac() {
		return this.opeNrocuentac;
	}

	public void setOpeNrocuentac(String opeNrocuentac) {
		this.opeNrocuentac = opeNrocuentac;
	}

	public String getOpeNrocuentad() {
		return this.opeNrocuentad;
	}

	public void setOpeNrocuentad(String opeNrocuentad) {
		this.opeNrocuentad = opeNrocuentad;
	}

	public String getSocCodigo() {
		return this.socCodigo;
	}

	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}

	public String getSocCorrelativo() {
		return this.socCorrelativo;
	}

	public void setSocCorrelativo(String socCorrelativo) {
		this.socCorrelativo = socCorrelativo;
	}

	public String getSolCodigo() {
		return this.solCodigo;
	}

	public void setSolCodigo(String solCodigo) {
		this.solCodigo = solCodigo;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public void setSolEntsolic(String solEntsolic) {
		this.solEntsolic = solEntsolic;
	}

	public String getSolEntsolic() {
		return solEntsolic;
	}

	public void setCodTransac(Integer codTransac) {
		this.codTransac = codTransac;
	}

	public Integer getCodTransac() {
		return codTransac;
	}

	public void setEsqCodigo(Integer esqCodigo) {
		this.esqCodigo = esqCodigo;
	}

	public Integer getEsqCodigo() {
		return esqCodigo;
	}

	public void setGlosaRefencia(String glosaRefencia) {
		this.glosaRefencia = glosaRefencia;
	}

	public String getGlosaRefencia() {
		return glosaRefencia;
	}

	
	public String toString() {
		return "SocOperaciones [opeCodigo=" + opeCodigo + ", claEstado=" + claEstado + ", claOperacion=" + claOperacion + ", cveSubtipooper="
				+ cveSubtipooper + ", cveTipoctacom=" + cveTipoctacom + ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", fechaReg="
				+ fechaReg + ", moneda=" + moneda + ", codTransac=" + codTransac + ", esqCodigo=" + esqCodigo + ", opeCtacomision=" + opeCtacomision
				+ ", opeCtaoperacion=" + opeCtaoperacion + ", opeFecha=" + opeFecha + ", opeMontome=" + opeMontome + ", opeMontomn=" + opeMontomn
				+ ", opeNrocuentac=" + opeNrocuentac + ", opeNrocuentad=" + opeNrocuentad + ", socCodigo=" + socCodigo + ", socCorrelativo="
				+ socCorrelativo + ", solCodigo=" + solCodigo + ", usrCodigo=" + usrCodigo + ", solEntsolic=" + solEntsolic + ", glosaRefencia="
				+ glosaRefencia + "]";
	}

}
