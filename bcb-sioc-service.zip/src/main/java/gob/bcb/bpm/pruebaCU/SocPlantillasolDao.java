/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;

//import java.util.ArrayList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
//import org.hibernate.Query;

/**
 * @author parenas
 * 
 */
public class SocPlantillasolDao extends HibernateDaoSupport implements BcbDao
{
  private static final Log log = LogFactory.getLog(SocPlantillasolDao.class);

  /*
   * (non-Javadoc)
   * @see
   * gob.bcb.service.pruebaCU.model.SolicitudDao#saveOrUpdate(gob.bcb.service.pruebaCU
   * .model.Solicitud)
   */
  
  public void saveOrUpdate(BcbEntity pm)
  {
    log.info("Saving or updating " + pm);
    //this.getHibernateTemplate().saveOrUpdate(pm);
    this.getHibernateTemplate().merge(pm);
  }

  public void deleteAll(Collection<BcbEntity> cuentas)
  {
    log.info("procesando " + cuentas.size() + " registros");
    this.getHibernateTemplate().deleteAll(cuentas);
  }
  
  /*
   * (non-Javadoc)
   * @see gob.bcb.core.infra.datastore.BcbDao#find(java.lang.Long)
   */
  
  public BcbEntity find(Long solicitudId)
  { 
    log.info("Entre a buscar el objeto con el id: " + solicitudId);

    SocPlantillasol detalles = null;
      StringBuffer query = new StringBuffer();
      query = query.append(" select de ");
      query = query.append(" from ");
      query = query.append(" SocPlantillasol de ");
      query = query.append(" where de.id.solCodigo = ? ");
      query = query.append(" and de.id.detCodigo = 1 ");

      @SuppressWarnings("unchecked")
      List<SocPlantillasol> lista = (List<SocPlantillasol>) getHibernateTemplate().find(query.toString(), Long.toString(solicitudId));

      if (lista != null)
      {
        for (SocPlantillasol det : lista)
        {
          detalles = det;
        }
      }

 
    return detalles;
  }

  public List<SocPlantillasol> getDetalle(String id)
  {
    List<SocPlantillasol> lista = new ArrayList<SocPlantillasol>();
      StringBuffer query = new StringBuffer();
      query = query.append(" select de ");
      query = query.append(" from ");
      query = query.append(" SocPlantillasol de ");
      query = query.append(" where de.id.solCodigo = :codigo ");
      
      Query consulta = getSession().createQuery(query.toString());
      
      consulta.setParameter("codigo", id);
      
      lista = consulta.list();
    
    return lista;
  }
  
}
