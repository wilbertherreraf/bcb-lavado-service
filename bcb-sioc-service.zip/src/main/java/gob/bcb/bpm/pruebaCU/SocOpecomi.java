package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the soc_opecomi database table.
 * 
 */
@Entity
@Table(name="soc_opecomi")
public class SocOpecomi implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocOpecomiId id;

	@Column(name="cod_moneda")
	private Integer codMoneda;

	@Column(name="cve_tipocomis")
	private String cveTipocomis;

	@Column(name="oco_monto")
	private BigDecimal ocoMonto;
	
	@Column(name="oco_montoimpt")
	private BigDecimal ocoMontoimpt;	

//	@Column(name="cod_cargo")
//	private Integer codCargo;
	
	@Column(name="monto_mo")
	private BigDecimal montoMo;
	
	@Column(name="tipo_cambio")
	private BigDecimal tipoCambio;

	@Column(name="nro_cuenta")
	private String nroCuenta;

//	@Column(name="cta_codigo")
//	private Integer ctaCodigo;
	
	@Column(name = "cla_estadovar")
	private String claEstadovar;
	
	@Column(name = "nit")
	private String nit;
	
	@Column(name = "factura")
	private String factura;
	
	@Column(name = "estacion")
	private String estacion;
	
	@Column(name = "usr_codigo")
	private String usrCodigo;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="cod_moneda", insertable = false, updatable = false)
	private GenMoneda genMoneda;
	
    public SocOpecomi() {
    }

	public SocOpecomi(SocOpecomiId id) {
		this.id = id;
	}

	public SocOpecomi(SocOpecomiId id, BigDecimal ocoMonto) {
		this.id = id;
		this.ocoMonto = ocoMonto;
	}
    
	public SocOpecomiId getId() {
		return this.id;
	}

	public void setId(SocOpecomiId id) {
		this.id = id;
	}
	
	public Integer getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCveTipocomis() {
		return this.cveTipocomis;
	}

	public void setCveTipocomis(String cveTipocomis) {
		this.cveTipocomis = cveTipocomis;
	}

	public BigDecimal getOcoMonto() {
		return this.ocoMonto;
	}

	public void setOcoMonto(BigDecimal ocoMonto) {
		this.ocoMonto = ocoMonto;
	}

//	public void setCodCargo(Integer codCargo) {
//		this.codCargo = codCargo;
//	}
//
//	public Integer getCodCargo() {
//		return codCargo;
//	}
//
	public void setMontoMo(BigDecimal montoMo) {
		this.montoMo = montoMo;
	}

	public BigDecimal getMontoMo() {
		return montoMo;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNit() {
		return nit;
	}

	public void setFactura(String factura) {
		this.factura = factura;
	}

	public String getFactura() {
		return factura;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

//	public void setCtaCodigo(Integer ctaCodigo) {
//		this.ctaCodigo = ctaCodigo;
//	}
//
//	public Integer getCtaCodigo() {
//		return ctaCodigo;
//	}

	public void setTipoCambio(BigDecimal tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public BigDecimal getTipoCambio() {
		return tipoCambio;
	}

	public String getClaEstadovar() {
		return claEstadovar;
	}

	public void setClaEstadovar(String claEstadovar) {
		this.claEstadovar = claEstadovar;
	}

	
	public String toString() {
		return "SocOpecomi [id=" + id + ", codMoneda=" + codMoneda + ", cveTipocomis=" + cveTipocomis + ", ocoMonto=" + ocoMonto + ", montoMo=" + montoMo + ", tipoCambio=" + tipoCambio + ", nroCuenta=" + nroCuenta + ", claEstadovar=" + claEstadovar
				+ ", nit=" + nit + ", factura=" + factura + ", estacion=" + estacion + ", usrCodigo=" + usrCodigo
				+ ", fechaHora=" + fechaHora + "]";
	}

	public String getNroCuenta() {
		return nroCuenta;
	}

	public void setNroCuenta(String nroCuenta) {
		this.nroCuenta = nroCuenta;
	}

	public GenMoneda getGenMoneda() {
		return genMoneda;
	}

	public void setGenMoneda(GenMoneda genMoneda) {
		this.genMoneda = genMoneda;
	}

	public BigDecimal getOcoMontoimpt() {
		return ocoMontoimpt;
	}

	public void setOcoMontoimpt(BigDecimal ocoMontoimpt) {
		this.ocoMontoimpt = ocoMontoimpt;
	}

}
