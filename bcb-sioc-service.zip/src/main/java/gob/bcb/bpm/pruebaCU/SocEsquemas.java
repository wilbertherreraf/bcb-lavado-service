package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the soc_esquemas database table.
 * 
 */
@Entity
@Table(name="soc_esquemas")
public class SocEsquemas implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="esq_codigo")
	private Integer esqCodigo;

	@Column(name="cla_operacion")
	private String claOperacion;

	@Column(name="cla_subtipo")
	private String claSubtipo;

	@Column(name="cla_vigente")
	private String claVigente;

	@Column(name="cod_cargo")
	private Integer codCargo;

	@Column(name="cod_esqref")
	private Integer codEsqref;

	@Column(name="cod_moneda")
	private String codMoneda;

	@Column(name="cod_tipooper")
	private String codTipooper;

	@Column(name="cve_tiposolic")
	private String cveTiposolic;

	@Column(name="esq_descrip")
	private String esqDescrip;
	
	@Column(name="cve_subtipooper")
	private String cveSubtipooper;

	@Column(name="cod_tipoperacion")
	private String codTipoperacion;
	
	private String estacion;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="fecha_hora")
	private Date fechaHora;

	private String provisiona;
	
	@Column(name="genera")
	private String genera;
	
	@Column(name="tipo_retencion")
	private String tipoRetencion;

	@Column(name="tipo_transfer")
	private String tipoTransfer;

	@Column(name="usr_codigo")
	private String usrCodigo;

	@Column(name="glosa_comp")
	private String glosaComp;
	
    public SocEsquemas() {
    }

	public Integer getEsqCodigo() {
		return this.esqCodigo;
	}

	public void setEsqCodigo(Integer esqCodigo) {
		this.esqCodigo = esqCodigo;
	}

	public String getClaOperacion() {
		return this.claOperacion;
	}

	public void setClaOperacion(String claOperacion) {
		this.claOperacion = claOperacion;
	}

	public String getClaSubtipo() {
		return this.claSubtipo;
	}

	public void setClaSubtipo(String claSubtipo) {
		this.claSubtipo = claSubtipo;
	}

	public String getClaVigente() {
		return this.claVigente;
	}

	public void setClaVigente(String claVigente) {
		this.claVigente = claVigente;
	}

	public Integer getCodCargo() {
		return this.codCargo;
	}

	public void setCodCargo(Integer codCargo) {
		this.codCargo = codCargo;
	}

	public Integer getCodEsqref() {
		return this.codEsqref;
	}

	public void setCodEsqref(Integer codEsqref) {
		this.codEsqref = codEsqref;
	}

	public String getCodMoneda() {
		return this.codMoneda;
	}

	public void setCodMoneda(String codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getCodTipooper() {
		return this.codTipooper;
	}

	public void setCodTipooper(String codTipooper) {
		this.codTipooper = codTipooper;
	}

	public String getCveTiposolic() {
		return this.cveTiposolic;
	}

	public void setCveTiposolic(String cveTiposolic) {
		this.cveTiposolic = cveTiposolic;
	}

	public String getEsqDescrip() {
		return this.esqDescrip;
	}

	public void setEsqDescrip(String esqDescrip) {
		this.esqDescrip = esqDescrip;
	}

	public String getEstacion() {
		return this.estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return this.fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getProvisiona() {
		return this.provisiona;
	}

	public void setProvisiona(String provisiona) {
		this.provisiona = provisiona;
	}

	public String getTipoRetencion() {
		return this.tipoRetencion;
	}

	public void setTipoRetencion(String tipoRetencion) {
		this.tipoRetencion = tipoRetencion;
	}

	public String getTipoTransfer() {
		return this.tipoTransfer;
	}

	public void setTipoTransfer(String tipoTransfer) {
		this.tipoTransfer = tipoTransfer;
	}

	public String getUsrCodigo() {
		return this.usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public void setGenera(String genera) {
		this.genera = genera;
	}

	public String getGenera() {
		return genera;
	}

	public void setGlosaComp(String glosaComp) {
		this.glosaComp = glosaComp;
	}

	public String getGlosaComp() {
		return glosaComp;
	}

	public String getCveSubtipooper() {
		return cveSubtipooper;
	}

	public void setCveSubtipooper(String cveSubtipooper) {
		this.cveSubtipooper = cveSubtipooper;
	}

	public String getCodTipoperacion() {
		return codTipoperacion;
	}

	public void setCodTipoperacion(String codTipoperacion) {
		this.codTipoperacion = codTipoperacion;
	}

	
	public String toString() {
		return "SocEsquemas [esqCodigo=" + esqCodigo + ", claOperacion=" + claOperacion + ", claSubtipo=" + claSubtipo + ", claVigente=" + claVigente
				+ ", codCargo=" + codCargo + ", codEsqref=" + codEsqref + ", codMoneda=" + codMoneda + ", codTipooper=" + codTipooper
				+ ", cveTiposolic=" + cveTiposolic + ", esqDescrip=" + esqDescrip + ", cveSubtipooper=" + cveSubtipooper + ", codTipoperacion="
				+ codTipoperacion + ", estacion=" + estacion + ", fechaHora=" + fechaHora + ", provisiona=" + provisiona + ", genera=" + genera
				+ ", tipoRetencion=" + tipoRetencion + ", tipoTransfer=" + tipoTransfer + ", usrCodigo=" + usrCodigo + ", glosaComp=" + glosaComp
				+ "]";
	}

	
}
