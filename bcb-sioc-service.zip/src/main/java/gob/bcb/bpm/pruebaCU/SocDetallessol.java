package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * The persistent class for the soc_detallessol database table.
 * 
 */
@Entity
@Table(name = "soc_detallessol")
public class SocDetallessol implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SocDetallessolId id;

	@Column(name = "ben_codigo")
	private String benCodigo;

	@Column(name = "det_concepto")
	private String detConcepto;

	@Column(name = "det_ctabenef")
	private Integer detCtabenef;

	@Column(name = "cta_codigo")
	private Integer ctaCodigo;
	
	@Column(name = "det_info")
	private String detInfo;

	@Column(name = "det_monto")
	private BigDecimal detMonto;

	@Column(name = "det_montotrans")
	private BigDecimal detMontotrans;
	
	@Column(name = "cod_monedatdet")
	private Integer codMonedatdet;
	
	@Column(name = "det_montoord")
	private BigDecimal detMontoord;

	@Column(name = "cod_moneda")
	private Integer codMoneda;
	
	private String moneda;

	private String monedaT;

	@Column(name="tipo_concepto")
	private String tipoConcepto;
	
	@Column(name = "det_facturas")
	private String detFacturas;

	@Column(name = "beneficiario")
	private String beneficiario;

	@Column(name = "cla_estadodet")
	private String claEstadodet;
	
	@Column(name = "cod_banco")
	private String codBanco;
	
	@Column(name = "nro_cuentabco")
	private String nroCuentabco;

	@Column(name = "cod_bancointer")
	private String codBancointer;
	
	@Column(name = "nro_cuentabcointer")
	private String nroCuentabcointer;

	@Column(name = "det_codttransfer")
	private String detCodttransfer;
	
	@Column(name = "usr_codigo")
	private String usrCodigo;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;
	
	public SocDetallessol() {
	}

	public SocDetallessol(SocDetallessolId id, String benCodigo, String moneda) {
		this.id = id;
		this.benCodigo = benCodigo;
		this.moneda = moneda;
	}

	public SocDetallessol(SocDetallessolId id, String benCodigo, BigDecimal detMonto, String moneda, String detConcepto, BigDecimal detMontoord) {
		this.id = id;
		this.benCodigo = benCodigo;
		this.detMonto = detMonto;
		this.moneda = moneda;
		this.detConcepto = detConcepto;
		this.detMontoord = detMontoord;
	}

	public SocDetallessol(SocDetallessolId id, String benCodigo, BigDecimal detMonto, String moneda, Integer detCtabenef, String detConcepto,
			String detInfo) {
		this.id = id;
		this.benCodigo = benCodigo;
		this.detMonto = detMonto;
		this.moneda = moneda;
		this.detCtabenef = detCtabenef;
		this.detConcepto = detConcepto;
		this.detInfo = detInfo;
	}

	public SocDetallessol(SocDetallessolId id, String benCodigo, BigDecimal detMonto, String moneda, Integer detCtabenef, String detConcepto,
			String detInfo, BigDecimal detMontoord, String monedaT, String detFacturas) {
		this.id = id;
		this.benCodigo = benCodigo;
		this.detMonto = detMonto;
		this.moneda = moneda;
		this.detCtabenef = detCtabenef;
		this.detConcepto = detConcepto;
		this.detInfo = detInfo;
		this.detMontoord = detMontoord;
		this.monedaT = monedaT;
		this.detFacturas = detFacturas;
	}

	public SocDetallessolId getId() {
		return this.id;
	}

	public void setId(SocDetallessolId id) {
		this.id = id;
	}

	public String getBenCodigo() {
		return this.benCodigo;
	}

	public void setBenCodigo(String benCodigo) {
		this.benCodigo = benCodigo;
	}

	public String getDetConcepto() {
		return this.detConcepto;
	}

	public void setDetConcepto(String detConcepto) {
		this.detConcepto = detConcepto;
	}

	public Integer getDetCtabenef() {
		return this.detCtabenef;
	}

	public void setDetCtabenef(Integer detCtabenef) {
		this.detCtabenef = detCtabenef;
	}

	public String getDetInfo() {
		return this.detInfo;
	}

	public void setDetInfo(String detInfo) {
		this.detInfo = detInfo;
	}

	public BigDecimal getDetMonto() {
		return this.detMonto;
	}

	public void setDetMonto(BigDecimal detMonto) {
		this.detMonto = detMonto;
	}

	public BigDecimal getDetMontoord() {
		return this.detMontoord;
	}

	public void setDetMontoord(BigDecimal detMontoord) {
		this.detMontoord = detMontoord;
	}

	public String getMoneda() {
		return this.moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getMonedaT() {
		return this.monedaT;
	}

	public void setMonedaT(String monedaT) {
		this.monedaT = monedaT;
	}

	public String getDetFacturas() {
		return detFacturas;
	}

	public void setDetFacturas(String detFacturas) {
		this.detFacturas = detFacturas;
	}

	public void setBeneficiario(String beneficiario) {
		this.beneficiario = beneficiario;
	}

	public String getBeneficiario() {
		return beneficiario;
	}

	public void setCtaCodigo(Integer ctaCodigo) {
		this.ctaCodigo = ctaCodigo;
	}

	public Integer getCtaCodigo() {
		return ctaCodigo;
	}

	public Integer getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public BigDecimal getDetMontotrans() {
		return detMontotrans;
	}

	public void setDetMontotrans(BigDecimal detMontotrans) {
		this.detMontotrans = detMontotrans;
	}

	public String getNroCuentabco() {
		return nroCuentabco;
	}

	public void setNroCuentabco(String nroCuentabco) {
		this.nroCuentabco = nroCuentabco;
	}

	public String getClaEstadodet() {
		return claEstadodet;
	}

	public void setClaEstadodet(String claEstadodet) {
		this.claEstadodet = claEstadodet;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public String getCodBanco() {
		return codBanco;
	}

	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	public String getCodBancointer() {
		return codBancointer;
	}

	public void setCodBancointer(String codBancointer) {
		this.codBancointer = codBancointer;
	}

	public String getNroCuentabcointer() {
		return nroCuentabcointer;
	}

	public void setNroCuentabcointer(String nroCuentabcointer) {
		this.nroCuentabcointer = nroCuentabcointer;
	}

	
	public String toString() {
		return "SocDetallessol [id=" + id + ", benCodigo=" + benCodigo + ", detConcepto=" + detConcepto + ", detCtabenef=" + detCtabenef
				+ ", ctaCodigo=" + ctaCodigo + ", detInfo=" + detInfo + ", detMonto=" + detMonto + ", detMontotrans=" + detMontotrans
				+ ", detMontoord=" + detMontoord + ", codMoneda=" + codMoneda + ", moneda=" + moneda + ", monedaT=" + monedaT + ", detFacturas="
				+ detFacturas + ", beneficiario=" + beneficiario + ", claEstadodet=" + claEstadodet + ", codBanco=" + codBanco + ", nroCuentabco="
				+ nroCuentabco + ", codBancointer=" + codBancointer + ", nroCuentabcointer=" + nroCuentabcointer + ", usrCodigo=" + usrCodigo
				+ ", estacion=" + estacion + ", fechaHora=" + fechaHora + "]";
	}

	public String getDetCodttransfer() {
		return detCodttransfer;
	}

	public void setDetCodttransfer(String detCodttransfer) {
		this.detCodttransfer = detCodttransfer;
	}

	public String getTipoConcepto() {
		return tipoConcepto;
	}

	public void setTipoConcepto(String tipoConcepto) {
		this.tipoConcepto = tipoConcepto;
	}

	public Integer getCodMonedatdet() {
		return codMonedatdet;
	}

	public void setCodMonedatdet(Integer codMonedatdet) {
		this.codMonedatdet = codMonedatdet;
	}

	
}
