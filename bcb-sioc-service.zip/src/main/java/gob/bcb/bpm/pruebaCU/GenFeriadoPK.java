package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the gen_feriado database table.
 * 
 */
@Embeddable
public class GenFeriadoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

    @Temporal( TemporalType.DATE)
	@Column(name="fecha_feriado")
	private java.util.Date fechaFeriado;

	@Column(name="cod_moneda")
	private int codMoneda;

    public GenFeriadoPK() {
    }
	public java.util.Date getFechaFeriado() {
		return this.fechaFeriado;
	}
	public void setFechaFeriado(java.util.Date fechaFeriado) {
		this.fechaFeriado = fechaFeriado;
	}
	public int getCodMoneda() {
		return this.codMoneda;
	}
	public void setCodMoneda(int codMoneda) {
		this.codMoneda = codMoneda;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof GenFeriadoPK)) {
			return false;
		}
		GenFeriadoPK castOther = (GenFeriadoPK)other;
		return 
			this.fechaFeriado.equals(castOther.fechaFeriado)
			&& (this.codMoneda == castOther.codMoneda);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.fechaFeriado.hashCode();
		hash = hash * prime + this.codMoneda;
		
		return hash;
    }
}