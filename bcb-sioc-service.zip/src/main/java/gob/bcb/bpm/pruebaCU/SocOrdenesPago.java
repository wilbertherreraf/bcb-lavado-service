package gob.bcb.bpm.pruebaCU;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the soc_ordenespago database table.
 * 
 */
@Entity
@Table(name = "soc_ordenespago")
public class SocOrdenesPago implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ins_codigo")
	private String insCodigo;

	@Column(name = "opa_nroordenpago")
	private String opaNroordenpago;

	@Column(name = "cla_estadoopa")
	private Character claEstadoopa;

	@Column(name = "opa_benef")
	private String opaBenef;

	@Temporal(TemporalType.DATE)
	@Column(name = "opa_fecha")
	private Date opaFecha;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "opa_fechavenc")
	private Date opaFechavenc;

	@Column(name = "soc_codigo")
	private String socCodigo;
	
	@Column(name = "opa_imp")
	private Integer opaImp;

	@Column(name = "opa_reng")
	private Integer opaReng;

	@Column(name = "monto")
	private BigDecimal monto;

	@Column(name = "cod_moneda")
	private Integer codMoneda;
	
	@Column(name = "concepto")
	private String concepto;
	
	@Column(name = "usr_codigo")
	private String usrCodigo;

	private String estacion;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fecha_hora")
	private Date fechaHora;

	public SocOrdenesPago() {
	}

	public SocOrdenesPago(String insCodigo, Date opaFechavenc, char claEstadoopa, Integer opaReng, Integer opaImp, String opaBenef) {
		this.insCodigo = insCodigo;
		this.opaFechavenc = opaFechavenc;
		this.claEstadoopa = claEstadoopa;
		this.opaReng = opaReng;
		this.opaImp = opaImp;
		this.opaBenef = opaBenef;
	}

	public SocOrdenesPago(String insCodigo, String nroOrdenpago, Date opaFechavenc, char claEstadoopa, Integer opaReng, Integer opaImp,
			String opaBenef) {
		this.insCodigo = insCodigo;
		this.opaNroordenpago = nroOrdenpago;
		this.opaFechavenc = opaFechavenc;
		this.claEstadoopa = claEstadoopa;
		this.opaReng = opaReng;
		this.opaImp = opaImp;
		this.opaBenef = opaBenef;
	}

	public String getInsCodigo() {
		return this.insCodigo;
	}

	public void setInsCodigo(String insCodigo) {
		this.insCodigo = insCodigo;
	}

	public Character getClaEstadoopa() {
		return this.claEstadoopa;
	}

	public void setClaEstadoopa(Character claEstadoopa) {
		this.claEstadoopa = claEstadoopa;
	}

	public String getOpaBenef() {
		return this.opaBenef;
	}

	public void setOpaBenef(String opaBenef) {
		this.opaBenef = opaBenef;
	}

	public Date getOpaFechavenc() {
		return this.opaFechavenc;
	}

	public void setOpaFechavenc(Date opaFechavenc) {
		this.opaFechavenc = opaFechavenc;
	}

	public Integer getOpaImp() {
		return this.opaImp;
	}

	public void setOpaImp(Integer opaImp) {
		this.opaImp = opaImp;
	}

	public String getOpaNroordenpago() {
		return this.opaNroordenpago;
	}

	public void setOpaNroordenpago(String opaNroordenpago) {
		this.opaNroordenpago = opaNroordenpago;
	}

	public Integer getOpaReng() {
		return this.opaReng;
	}

	public void setOpaReng(Integer opaReng) {
		this.opaReng = opaReng;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public Integer getCodMoneda() {
		return codMoneda;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	
	public String toString() {
		return "SocOrdenesPago [insCodigo=" + insCodigo + ", opaNroordenpago=" + opaNroordenpago + ", claEstadoopa=" + claEstadoopa + ", opaBenef="
				+ opaBenef + ", opaFechavenc=" + opaFechavenc + ", opaImp=" + opaImp + ", opaReng=" + opaReng + ", monto=" + monto + ", codMoneda="
				+ codMoneda + ", codUsuario=" + usrCodigo + ", estacion=" + estacion + ", fechaHora=" + fechaHora + "]";
	}

	public String getSocCodigo() {
		return socCodigo;
	}

	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getUsrCodigo() {
		return usrCodigo;
	}

	public void setUsrCodigo(String usrCodigo) {
		this.usrCodigo = usrCodigo;
	}

	public Date getOpaFecha() {
		return opaFecha;
	}

	public void setOpaFecha(Date opaFecha) {
		this.opaFecha = opaFecha;
	}

}
