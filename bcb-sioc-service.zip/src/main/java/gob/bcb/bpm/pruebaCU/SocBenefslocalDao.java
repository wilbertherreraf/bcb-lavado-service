/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.bpm.pruebaCU;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

public class SocBenefslocalDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocBenefslocalDao.class);

	public void saveOrUpdate(SocBenefslocal pm) {
		// log.info("Saving or updating " + pm);
		this.getHibernateTemplate().saveOrUpdate(pm);
	}

	public SocBenefslocal find(Long solicitudId) {
		log.info("Entre a buscar el objeto con el id: " + solicitudId);

		SocBenefslocal benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append(" select be ");
		query = query.append(" from SocBenefslocal be ");
		query = query.append(" where be.id.socCodigo = ? ");
		query = query.append(" and be.id.detCodigo = 1 ");

		List<SocBenefslocal> lista = (List<SocBenefslocal>) getHibernateTemplate().find(query.toString(), Long.toString(solicitudId));

		if (lista != null) {
			for (SocBenefslocal ben : lista) {
				benefs = ben;
			}
		}

		return benefs;
	}

}
