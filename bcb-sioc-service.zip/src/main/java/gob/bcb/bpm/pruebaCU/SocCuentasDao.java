package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.dao.SwfPersonactaBean;
import gob.bcb.swift.model.SwfPersonacta;
import gob.bcb.swift.model.SwfPersonactaPK;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class SocCuentasDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocCuentasDao.class);

	public SocCuentas saveOrUpdate(SocCuentas socCuentas) {
		log.info("Ingresando a guardar soccuentas " + socCuentas.toString());
		SwfPersonactaBean swfPersonactaBean = new SwfPersonactaBean();
		swfPersonactaBean.setSessionFactory(getSessionFactory());

		validarDato(socCuentas);
		if (!StringUtils.isBlank(socCuentas.getCveTipbcoben()) && socCuentas.getCveTipbcoben().equals(Constants.CVE_TIPOBCOINST_ABA)){
			socCuentas.setBcoCodigointer(ConstantsSwift.PEC_CODBCOFEEDWARE);
		}

		List<SocCuentas> socCuentasLista = cuentasBeneficiarioExt(socCuentas.getCtaCodigo(), socCuentas.getBenCodigo(), socCuentas.getBcoCodigo(),
				socCuentas.getCtaNrocuenta(), socCuentas.getMoneda(), null, null, null);

		if (socCuentasLista.size() == 0) {
			log.info("Nueva cuenta ext " + socCuentas.getCtaNrocuenta());

			int cod = generarCodigo();
			//socCuentas.setClaVigente(Short.valueOf("1"));
			socCuentas.setCtaCodigo(cod);
			socCuentas.setFechaHora(new Date());
			getHibernateTemplate().saveOrUpdate(socCuentas);			
		} else {
			socCuentas.setFechaHora(new Date());
			this.getHibernateTemplate().merge(socCuentas);			
		}

		SocCuentas socCuentasnew = getSocCuentasByCodigo(socCuentas.getCtaCodigo());
		
		log.info("Cuenta ext salvada ... " + socCuentas.getCtaCodigo());
		
		if (!StringUtils.isBlank(socCuentasnew.getBcoCodigointer()) && !StringUtils.isBlank(socCuentasnew.getBcoNrocuentaben())){
			log.info("Salvando registro de persona ... " + socCuentasnew.getBcoCodigo());
			
			SwfPersonacta swfPersonacta = new SwfPersonacta();
			swfPersonacta.setId(new SwfPersonactaPK());
			
			swfPersonacta.getId().setPecCodpersona(socCuentasnew.getBcoCodigo());
			swfPersonacta.getId().setPecCodinst(socCuentasnew.getBcoCodigointer());
			swfPersonacta.getId().setPecNrocta(socCuentasnew.getBcoNrocuentaben());
			swfPersonacta.setPecTipoctainst(socCuentasnew.getCveTipbcoben());
			swfPersonacta.setPecAuditusr(socCuentasnew.getUsrCodigo());
			swfPersonacta.setPecAuditwst(socCuentasnew.getEstacion());
			
			swfPersonactaBean.guardarCuenta(swfPersonacta);
		}
		
		return socCuentasnew;
	}

	public SocCuentas getSocCuentasByCodigo(Integer ctaCodigo) {
		log.debug("Entre a buscar getSocCuentasByCodigo id: " + ctaCodigo);

		SocCuentas benefs = null;
		StringBuffer query = new StringBuffer();
		query = query.append("select be ");
		query = query.append("from SocCuentas be ");
		query = query.append("where be.ctaCodigo = :ctaCodigo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("ctaCodigo", ctaCodigo);

		List lista = consulta.list();

		if (lista.size() > 0) {
			benefs = (SocCuentas) lista.get(0);
		}

		return benefs;
	}

	public List<SocCuentas> cuentasBeneficiarioExt(Integer ctaCodigo, String benCodigo, String bcoCodigo, String ctaNrocuenta, Integer codMoneda,
			String claEsquema, String ctaAfectable, Short claVigente) {
		StringBuffer query = new StringBuffer();
		query = query.append("select sc ");
		query = query.append("from SocCuentas sc, SocBancos b ");
		query = query.append("where sc.bcoCodigo = b.bcoCodigo ");

		if (ctaCodigo != null) {
			query = query.append("and sc.ctaCodigo = :ctaCodigo ");
		} else {
			if (claVigente == null)
				query = query.append("and sc.claVigente = 1 ");
		}
		if (!StringUtils.isBlank(benCodigo)) {
			query = query.append("and sc.benCodigo = :benCodigo ");
		}

		if (!StringUtils.isBlank(bcoCodigo)) {
			query = query.append("and sc.bcoCodigo = :bcoCodigo ");
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			query = query.append("and sc.ctaNrocuenta = :ctaNrocuenta ");
		}

		if (codMoneda != null)
			query = query.append("and sc.moneda = :codMoneda ");

		if (!StringUtils.isBlank(claEsquema)) {
			query = query.append("and sc.claEsquema = :claEsquema ");
		}

		if (!StringUtils.isBlank(ctaAfectable)) {
			query = query.append("and sc.ctaAfectable = :ctaAfectable ");
		}

		log.info("Consulta cuentasBeneficiarioExt " + benCodigo + " " + bcoCodigo + " " + ctaNrocuenta + " " + codMoneda + " " + ctaAfectable
				+ " :: " + query.toString());

		Query consulta = getSession().createQuery(query.toString());

		if (ctaCodigo != null) {
			consulta.setParameter("ctaCodigo", ctaCodigo);
		} else {
			if (claVigente != null)
				consulta.setParameter("claVigente", claVigente);
		}

		if (!StringUtils.isBlank(benCodigo)) {
			consulta.setParameter("benCodigo", benCodigo);
		}

		if (!StringUtils.isBlank(bcoCodigo)) {
			consulta.setParameter("bcoCodigo", bcoCodigo);
		}

		if (!StringUtils.isBlank(ctaNrocuenta)) {
			consulta.setParameter("ctaNrocuenta", ctaNrocuenta);
		}

		if (codMoneda != null)
			consulta.setParameter("codMoneda", codMoneda);

		if (!StringUtils.isBlank(claEsquema)) {
			consulta.setParameter("claEsquema", claEsquema);
		}

		if (!StringUtils.isBlank(ctaAfectable)) {
			consulta.setParameter("ctaAfectable", ctaAfectable);
		}
		List lista = consulta.list();

		return lista;
	}

	private void validarDato(SocCuentas socCuentas) {
		if (StringUtils.isBlank(socCuentas.getBenCodigo())) {
			throw new BusinessException("Codigo de beneficiario invalido");
		}
		if (StringUtils.isBlank(socCuentas.getBcoCodigo())) {
			throw new BusinessException("Codigo de banco beneficiario invalido");
		}

		if (StringUtils.isBlank(socCuentas.getCtaNrocuenta())) {
			throw new BusinessException("Numero de cuenta beneficiario invalido");
		}

		if (socCuentas.getMoneda() == null) {
			throw new BusinessException("Moneda de cuenta beneficiario invalido");
		}
		
		if (StringUtils.isBlank(socCuentas.getClaEsquema())) {
			//throw new BusinessException("Esquema swift invalido");
		}		
	}

	public Integer generarCodigo() {
		Integer maxDet = Integer.valueOf(0);
		StringBuffer query = new StringBuffer();
		query = query.append("select max(ctaCodigo) ");
		query = query.append("from SocCuentas ");

		Query consulta = getSession().createQuery(query.toString());

		log.debug("Entre a generarCod " + consulta.toString());

		List result = consulta.list();
		if (result.size() > 0)
			maxDet = (Integer) result.get(0);

		if (maxDet == null)
			maxDet = 0;
		maxDet++;
		return maxDet;
	}

}
