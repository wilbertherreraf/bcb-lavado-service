package gob.bcb.bpm.pruebaCU;

import gob.bcb.core.exception.DataBaseException;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.UtilsQNatives;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.OperacionesCambiarias;
import gob.bcb.service.servicioSioc.pojos.SolicitudesS;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.ServicioSioc;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.dao.SwfMensajeBean;
import gob.bcb.swift.model.SwfMensaje;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.exception.GenericJDBCException;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author wherrera
 * 
 */
public class SocSolicitudesDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SocSolicitudesDao.class);

	public void saveOrUpdate(SocSolicitudes pm) {
		pm.setFechaHora(new Date());
		if (UserSessionHolder.get(Constants.AUDIT_USER_ESTACION) != null)
			pm.setEstacion((String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		if (UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID) != null)
			pm.setUsrCodigo((String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID));

		this.getHibernateTemplate().merge(pm);
	}

	public void saveOrUpdateSinAud(SocSolicitudes pm) {
		pm.setFechaHora(new Date());
		this.getHibernateTemplate().merge(pm);
	}

	public void remove(SocSolicitudes socSolicitudes) {
		SocSolicitudes socSolicitudesOld = getSolicitud(socSolicitudes.getSocCodigo());

		if (socSolicitudesOld == null) {
			throw new BusinessException("Error No pudo encontrar solicitud para " + socSolicitudes.getSocCodigo());
		}

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudesOld.getSolCodigo().trim());

		if (!socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
			throw new BusinessException("EL solicitante debe ser del sistema financiero");
		}
		socSolicitudesOld.setUsrCodigo(socSolicitudes.getUsrCodigo());
		socSolicitudesOld.setEstacion(socSolicitudes.getEstacion());
		socSolicitudesOld.setFechaHora(new Date());
		socSolicitudesOld.setClaEstado(Constants.CLAVE_ESTSOLIC_ANULADO);
		this.getHibernateTemplate().merge(socSolicitudesOld);
	}

	public SocSolicitudes getSolicitud(String solicitudId) {
		// QueryProcessor.flush();
		SocSolicitudes solicitudes = null;
		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select so ");
		consulta = consulta.append("from SocSolicitudes so ");
		consulta = consulta.append("where so.socCodigo = :solicitudId ");

		log.info("XXX: exists session "+ getSessionFactory().isClosed());
		
//		Session session = SessionFactoryUtils.getSession(getSessionFactory(), true);
		Query query = getSession().createQuery(consulta.toString());
		query.setParameter("solicitudId", solicitudId);

		List result = query.list();
//		SessionFactoryUtils.closeSession(session);
		
		if (result.size() > 0) {
			solicitudes = (SocSolicitudes) result.get(0);
			solicitudes.setSolCodigo(solicitudes.getSolCodigo().trim());
		}

		return solicitudes;
	}

	public SocSolicitudes generarSolicitud(SocSolicitudes solicitud) {
		Date hoy = new Date();
		String solCodigo = Long.toString(hoy.getTime());

		solicitud.setSocCodigo(solCodigo);
		solicitud.setFecha(hoy);
		
		if (solicitud.getSolCodigo() == null){
			throw new BusinessException("Código de solicitante inválido");
		}
		
		if (solicitud.getClaTipo().equals(Constants.CLAVE_TIPOOPER_TRAEXT) && !solicitud.getSolCodigo().equals(Constants.COD_BCB) && (solicitud.getSocCuentac() == null || solicitud.getSocCuentac().compareTo(0) <= 0)){
			throw new BusinessException("Cuenta de comisiones inválida");			
		}
		
		if ((solicitud.getClaTipo().equals(Constants.CLAVE_TIPOOPER_TRAEXT) || solicitud.getClaTipo().equals(Constants.CLAVE_TIPOOPER_DELEXT)) && !solicitud.getSolCodigo().equals(Constants.COD_BCB) && (solicitud.getSocCuentad() == null || solicitud.getSocCuentad().compareTo(0) <= 0)){
			throw new BusinessException("Cuenta a debitar inválida");			
		}		
		
		saveOrUpdate(solicitud);
		return solicitud;
	}

	public SocSolicitudes generarSolicitud(SocSolicitudes solicitud, SocDetallessol detalle, Integer codDetalle) {
		solicitud = generarSolicitud(solicitud);
		return solicitud;
	}

	/****************************************************/
	public SocSolicitudes getByCodSolicitudorig(String codSolicitudorig) {

		SocSolicitudes solicitudes = null;
		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select so ");
		consulta = consulta.append("from SocSolicitudes so ");
		consulta = consulta.append("where so.codSolicitudorig = :codSolicitudorig ");

		Query query = getSession().createQuery(consulta.toString());
		query.setParameter("codSolicitudorig", codSolicitudorig);

		log.info("Entre a buscar el objeto codSolicitudorig: [" + codSolicitudorig + "] " + consulta.toString());

		List result = query.list();
		if (result.size() > 0) {
			return (SocSolicitudes) result.get(0);
		}

		return solicitudes;
	}

	public List<SocSolicitudes> solicitudesPendientes(Date fecha, Date fechaReg, Character claEstado, String claEstadows) {

		List<SocSolicitudes> socSolicitudesLista = new ArrayList<SocSolicitudes>();

		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select so ");
		consulta = consulta.append("from SocSolicitudes so ");
		consulta = consulta.append("where so.claEstado = :claEstado ");
		consulta = consulta.append("and so.fecha = :fecha ");
		consulta = consulta.append("and date(so.fechaReg) = :fechaReg ");
		consulta = consulta.append("and so.claEstadows = :claEstadows ");
		consulta = consulta.append("and so.codSolicitudorig is not null ");

		Query query = getSession().createQuery(consulta.toString());

		query.setParameter("claEstado", claEstado);
		query.setParameter("claEstadows", claEstadows);
		query.setDate("fecha", fecha);
		query.setDate("fechaReg", fechaReg);

		log.info("solicitudesPendientes con el id: [claEstado = " + claEstado + ", claEstadows = " + claEstadows + ", fecha = " + fecha
				+ ", fechaReg = " + fechaReg + "] " + consulta.toString());

		socSolicitudesLista = query.list();
		log.info("socSolicitudesLista = " + socSolicitudesLista.size());
		return socSolicitudesLista;
	}

	public SocSolicitudes crearActualizar(SocSolicitudes solicitud) {
		SocSolicitudes socSolicitudesOld = getSolicitud(solicitud.getSocCodigo());

		if (socSolicitudesOld == null) {
			log.info("En crear Solicitud " + solicitud.getSolCodigo());
			String socCodigo = generarCodSolicitud();

			solicitud.setDetConcepto((solicitud.getDetConcepto() == null) ? null : solicitud.getDetConcepto().trim().toUpperCase());
			solicitud.setReferencia((solicitud.getReferencia() == null) ? null : solicitud.getReferencia().trim().toUpperCase());
			solicitud.setDetFacturas((solicitud.getDetFacturas() == null) ? null : solicitud.getDetFacturas().trim().toUpperCase());
			solicitud.setSocCodigo(socCodigo);
			solicitud.setClaEstado(Constants.CLAVE_ESTSOLIC_PENDIENTE);
			solicitud.setClaEstadows(Constants.CLAVE_ESTWS_PROCESADO);
			solicitud.setFechaReg(new Date());
			solicitud.setFecha(new Date());
			solicitud.setUsrCodauto(null);

			if (!solicitud.getSolEntsolic().trim().equals(Constants.COD_BCB)) {
				// el correlativo solo no es generado si es generado por el
				// sistema y el solicitante no es el bcb
				if (solicitud.getCveTipctasolic() != null && solicitud.getCveTipctasolic().equals(Constants.CLAVE_GENERADOPOR_SISTEMA)) {
					String correlativo = getCorrelativo(solicitud);
					solicitud.setSocCorrelativo(correlativo);
				}
			}

			String tipoNegaocia = getTipoDeNegociacionSolicitud(solicitud);

			solicitud.setSocTipnegociacion(tipoNegaocia);
			validarDatos(solicitud);

			saveOrUpdate(solicitud);
			socSolicitudesOld = getSolicitud(solicitud.getSocCodigo());
			log.info("Solicitud CREADA: " + socSolicitudesOld.toString());
		} else {
			log.info("En Actualizar Solicitud " + solicitud.getSocCodigo());
			validarEstado(solicitud.getSocCodigo(), true);

			if (socSolicitudesOld.getCveSubtipooper() != null && socSolicitudesOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
				SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
				socSolicitanteDao.setSessionFactory(getSessionFactory());

				SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudesOld.getSolCodigo().trim());
				if (!socSolicitudesOld.getSolCodigo().trim().equals(Constants.COD_BCB)
						&& socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {

					if (!socSolicitudesOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_PENDIENTE)) {
						throw new BusinessException("Solicitud ya fue pre autorizada no puede modificar");
					}
				}
			}
			socSolicitudesOld.setFecha(new Date());
			socSolicitudesOld.setFechaReg(new Date());
			socSolicitudesOld.setFechaCont(null);
			socSolicitudesOld.setSocCuentad(solicitud.getSocCuentad());
			socSolicitudesOld.setSocCuentac(solicitud.getSocCuentac());
			socSolicitudesOld.setSocMontome(solicitud.getSocMontome());
			socSolicitudesOld.setSocMontoord(solicitud.getSocMontoord());
			socSolicitudesOld.setSocMontomn(solicitud.getSocMontomn());
			socSolicitudesOld.setSocTipoc(solicitud.getSocTipoc());
			socSolicitudesOld.setDetConcepto((solicitud.getDetConcepto() == null) ? null : solicitud.getDetConcepto().trim().toUpperCase());
			socSolicitudesOld.setDetFacturas((solicitud.getDetFacturas() == null) ? null : solicitud.getDetFacturas().trim().toUpperCase());
			socSolicitudesOld.setReferencia((solicitud.getReferencia() == null) ? null : solicitud.getReferencia().trim().toUpperCase());
			socSolicitudesOld.setUsrCodauto(null);
			socSolicitudesOld.setUsrCodreg(solicitud.getUsrCodreg());
			socSolicitudesOld.setUsrCodigo(solicitud.getUsrCodigo());
			socSolicitudesOld.setEstacion(solicitud.getEstacion());

			String tipoNegaocia = getTipoDeNegociacionSolicitud(solicitud);
			socSolicitudesOld.setSocTipnegociacion(tipoNegaocia);

			validarDatos(socSolicitudesOld);

			saveOrUpdate(socSolicitudesOld);
			socSolicitudesOld = getSolicitud(socSolicitudesOld.getSocCodigo());
			log.info("Solicitud MODIFICADA: " + socSolicitudesOld.toString());
		}

		return socSolicitudesOld;
	}

	public SocSolicitudes cambiarEstadoSolicitud(SocSolicitudes solicitud, Character nuevoEstado, String claEstadows) {
		// registra el sol P
		// pre autoriza el sol A
		// verifica y cambia la fecha de operacion 1
		// autoriza la contabilizacion operacion O -> C
		//
		//
		// registra op P
		// verifica y cambia la fecha de operacion 1
		// autoriza la contabilizacion operacion C
		//
		// registra ws A genera solicitud
		// se provisiona con LIP V genera variables y swift
		// verifica y cambia la fecha de operacion 1 :: genera variables y swift
		// y comprob
		// autoriza la contabilizacion operacion O y posterior cambio a C

		log.info("Solicitud cambiarEstadoSolicitud: nuevoEstado [" + nuevoEstado + " , " + claEstadows + "] " + solicitud.toString());
		SocSolicitudes socSolicitudesOld = getSolicitud(solicitud.getSocCodigo());

		if (socSolicitudesOld == null) {
			log.error("Error No pudo encontrar solicitud para " + solicitud.getSocCodigo());
			throw new BusinessException("Error No pudo encontrar solicitud para " + solicitud.getSocCodigo());
		}
		Character estadoAnt = socSolicitudesOld.getClaEstado();
		String estadoAntWS = socSolicitudesOld.getClaEstadows();

		if (nuevoEstado != null) {
			socSolicitudesOld.setClaEstado(nuevoEstado);
		}

		if (!StringUtils.isBlank(claEstadows)) {
			socSolicitudesOld.setClaEstadows(claEstadows);
		}
		if (!StringUtils.isBlank(solicitud.getUsrCodreg())) {
			socSolicitudesOld.setUsrCodreg(solicitud.getUsrCodreg());
		}
		if (!StringUtils.isBlank(solicitud.getUsrCodauto())) {
			socSolicitudesOld.setUsrCodauto(solicitud.getUsrCodauto());
		}

		socSolicitudesOld.setFechaHora(new Date());
		socSolicitudesOld.setUsrCodigo(solicitud.getUsrCodigo());
		socSolicitudesOld.setEstacion(solicitud.getEstacion());

		this.getHibernateTemplate().merge(socSolicitudesOld);

		socSolicitudesOld = getSolicitud(solicitud.getSocCodigo());
		if (nuevoEstado != null)
			log.info("Solicitud [" + solicitud.getSocCodigo() + "] Cambio de estado de [" + estadoAnt + "] => [" + socSolicitudesOld.getClaEstado());

		if (!StringUtils.isBlank(claEstadows))
			log.info("Solicitud [" + solicitud.getSocCodigo() + "] Cambio de estado WS de [" + estadoAntWS + "] => [" + claEstadows);

		return socSolicitudesOld;
	}

	private static final Object monitor = new Object();

	private synchronized String generarCodSolicitud() {
		// guardamos el registro con el estado de que el archivo fue guardado
		// PERO lo realizamos nativamente en otra transacciÃƒÆ’Ã‚Â³n
		// el mensaje SWIFT debe ser guardado aun si la transacciÃƒÆ’Ã‚Â³n tuvo
		// errores
		String codSolicitud = "";
		synchronized (monitor) {
//			log.info("XXX:Funcionaraaa: " + UtilsDate.stringFromDate(new Date(), Constants.FORMAT_DATE_TIME));

			Connection conn = null;
			PreparedStatement ps = null;
			try {
				conn = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_SIOC).getHandler().getConnection();
				conn.setAutoCommit(true);
				ps = conn
						.prepareStatement("update soc_parametros set par_valor = trunc(to_number(to_number(nvl(par_valor,'0')) + 1),0) where par_codigo = 'sgte_codsol'");
				// ps.setTimestamp(3, new Timestamp(new Date().getTime()));
				ps.executeUpdate();
				// conn.commit();
				ps.close();
			} catch (GenericJDBCException e) {
				log.error(e.getMessage(), e);
				StringBuilder sb = new StringBuilder();
				int count = 0;
				for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
					if (cause instanceof SQLException) {
						count++;
						sb.append(cause.getMessage());
						sb.append(" , ");
					}
				}
				throw new DataBaseException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));
			} catch (Exception e) {
				StringBuilder sb = new StringBuilder();
				int count = 0;
				for (Throwable cause = e; (cause != null && cause != cause.getCause()); cause = cause.getCause()) {
					if (cause instanceof SQLException) {
						count++;
						sb.append(cause.getMessage());
						sb.append(" , ");
					}
				}
				log.error("Error al ejecutar query swift " + e.getMessage(), e);
				throw new DataBaseException((count > 0 ? sb.toString().replace(", null ,", "") : e.getMessage().replace(", null ,", "")));

			} finally {
				if (ps != null) {
					try {
						ps.close();
					} catch (SQLException e) {
						log.error("EXCEPCION BASE DE DATOS: " + e.getMessage(), e);
					}
				}
				if (conn != null)
					try {
						if (!conn.isClosed()) {
							conn.close();
						}
					} catch (SQLException e) {
						log.warn("Error al cerrar transaccion " + e.getMessage(), e);
					}
			}

			String codSol = Servicios.getParam("sgte_codsol");
			Long codigo = Long.valueOf(codSol);
			codSolicitud = String.format("%06d", codigo);

			log.info("==>Nuevo Cod Solicitud generado: " + codSolicitud);
		}

		if (StringUtils.isBlank(codSolicitud)) {
			throw new BusinessException("Error al generar codigo de solicitud");
		}
		return codSolicitud;
	}

	public SocSolicitudes fromServicioSioc(ServicioSioc servicioSioc, String solEntsolic, String tipoOrigenSolicitud) {
		log.info("Mapeando ServicioSioc a SocSolicitudes " + servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen());

		SocSolicitudes socSolicitudesOrig = getByCodSolicitudorig(servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen());

		if (socSolicitudesOrig != null) {
			log.error("Codigo solicitud origen " + socSolicitudesOrig.getCodSolicitudorig() + " duplicada, registrada en solicitud "
					+ socSolicitudesOrig.getSocCodigo());
			throw new BusinessException("Codigo solicitud origen " + servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen()
					+ " duplicada, registrada en solicitud " + socSolicitudesOrig.getSocCodigo());
		}
		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocUsuariosolDao socUsuariosolDao = new SocUsuariosolDao();
		socUsuariosolDao.setSessionFactory(getSessionFactory());

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCodTipooperacion(servicioSioc.getCabeceraMensaje().getCodTipoOperacion());

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCodSigep(servicioSioc.getDatosOperacion().getSolicitud().getCodEntidad());

		SocSolicitudes socSolicitudes = new SocSolicitudes();

		socSolicitudes.setSolCodigo(socSolicitante.getSolCodigo().trim());
		socSolicitudes.setEsqCodigo(socEsquemas.getEsqCodigo());
		socSolicitudes.setClaTipo(socEsquemas.getCodTipooper());
		socSolicitudes.setCveSubtipooper(socEsquemas.getCveSubtipooper());
		socSolicitudes.setTipoRetencion(socEsquemas.getTipoRetencion());
		// solicitud verificada
		// soliciud autorizada por el origen
		socSolicitudes.setClaEstadows(Constants.CLAVE_ESTWS_PROCESADO);
		socSolicitudes.setFecha(new Date());

		socSolicitudes.setFechaReg(new Date());
		socSolicitudes.setSocMontome(servicioSioc.getDatosOperacion().getSolicitud().getMontoOrigen());
		socSolicitudes.setCodMoneda(Integer.valueOf(servicioSioc.getDatosOperacion().getSolicitud().getMonedaOrigen()));
		// socSolicitudes.setSocMontome(servicioSioc.getDatosOperacion().getSolicitud().getMontoTotal());
		// socSolicitudes.setCodMoneda(Integer.valueOf(servicioSioc.getDatosOperacion().getSolicitud().getCodMonedaMonto()));

		socSolicitudes.setSocMontoord(BigDecimal.ZERO);
		socSolicitudes.setSocMontomn(BigDecimal.ZERO);

		if (servicioSioc.getDatosOperacion().getSolicitud().getCodMonedaMonto().equals(Constants.COD_MONEDA_BS)) {
			socSolicitudes.setSocMontomn(servicioSioc.getDatosOperacion().getSolicitud().getMontoTotal());
		} else {
			socSolicitudes.setSocMontoord(servicioSioc.getDatosOperacion().getSolicitud().getMontoTotal());
		}

		socSolicitudes.setCodMonedat(Integer.valueOf(servicioSioc.getDatosOperacion().getSolicitud().getCodMoneda()));
		socSolicitudes.setSolEntsolic(solEntsolic);
		socSolicitudes.setCodSolicitudorig(servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen());

		if (StringUtils.isBlank(servicioSioc.getDatosOperacion().getSolicitud().getTipoConcepto())) {
			throw new BusinessException("Error tipo concepto nulo");
		}

		socSolicitudes.setTipoConcepto(servicioSioc.getDatosOperacion().getSolicitud().getTipoConcepto());

		socSolicitudes.setDetFacturas(servicioSioc.getDatosOperacion().getSolicitud().getFacturas());
		socSolicitudes.setDetConcepto(servicioSioc.getDatosOperacion().getSolicitud().getGlosaConcepto());

		socSolicitudes.setCveTipctasolic(tipoOrigenSolicitud);

		return socSolicitudes;
	}

	public void validarDatos(SocSolicitudes socSolicitudes) {
		if (StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
			throw new BusinessException("Codigo de solicitante nulo");
		}

		if (StringUtils.isBlank(socSolicitudes.getClaTipo())) {
			throw new BusinessException("Tipo de operacion nulo");
		}
		if (StringUtils.isBlank(socSolicitudes.getCveSubtipooper())) {
			throw new BusinessException("Sub Tipo de operacion nulo");
		}
		if (StringUtils.isBlank(socSolicitudes.getTipoRetencion())) {
			throw new BusinessException("Tipo de retencion nulo");
		}
		if (StringUtils.isBlank(socSolicitudes.getSocTipnegociacion())) {
			throw new BusinessException("Campo Tipnegociacion nulo");
		}
		if (socSolicitudes.getEsqCodigo() == null || socSolicitudes.getEsqCodigo().compareTo(0) == 0) {
			throw new BusinessException("Codigo tipo operacion (esquema) nulo");
		}
		if (socSolicitudes.getCodMoneda() == null) {
			throw new BusinessException("Moneda provision nulo");
		}
		if (socSolicitudes.getCodMonedat() == null) {
			throw new BusinessException("Moneda transferencia nulo");
		}
		if (socSolicitudes.getFecha() == null) {
			throw new BusinessException("Fecha operacion nulo");
		}

		if (socSolicitudes.getSocMontome() == null || socSolicitudes.getSocMontome().compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException("Monto operacion invalido");
		}

		if (StringUtils.isBlank(socSolicitudes.getSolEntsolic())) {
			throw new BusinessException("Codigo de entidad origen de la solicitud nulo");
		}
		if (StringUtils.isBlank(socSolicitudes.getCveTipctasolic())) {
			throw new BusinessException("Tipo de proceso nulo, comunique al administrador");
		}
	}

	public boolean validarEstado(String socCodigo, boolean lanzaError) {
		log.info("validar Estado " + socCodigo);

		SocSolicitudes solicitudOld = getSolicitud(socCodigo);

		if (solicitudOld == null) {
			log.error("Solicitud [" + socCodigo + "] inexistente");
			throw new BusinessException("Solicitud [" + socCodigo + "] inexistente");
		}

		if (solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_CONTAB)
				|| solicitudOld.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_ANULADO)) {
			if (lanzaError)
				throw new BusinessException("Solicitud con estado invalido[" + solicitudOld.getClaEstado() + "] no puede continuar " + socCodigo);
			return false;
		}

		SocComprobanteDao socComprobanteDao = new SocComprobanteDao();
		socComprobanteDao.setSessionFactory(getSessionFactory());

		if (solicitudOld.getCveSubtipooper() != null && solicitudOld.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {

			SwfMensajeBean swfMensajeBean = new SwfMensajeBean();
			swfMensajeBean.setSessionFactory(getSessionFactory());

			List<SwfMensaje> swfMensajeLista = swfMensajeBean.findOperaciones(socCodigo, null, ConstantsSwift.PAR_ESTSWIFT_AUTO);

			if (swfMensajeLista.size() > 0) {
				if (lanzaError)
					throw new BusinessException("Solicitud con mensajes swift aprobados no puede continuar " + socCodigo);
				return false;
			}
		}
		return true;
	}

	public List<SocEsquemas> obtenerEsquemas(SocSolicitudes socSolicitudes, SocEsquemas socEsquemasPar, SocSolicitudctas socSolicitudctasMOVPROVISION) {
		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		List<SocEsquemas> socEsquemasLista = new ArrayList<SocEsquemas>();

		if (!StringUtils.isBlank(socSolicitudes.getSocCodigo()) && socSolicitudes.getEsqCodigo() != null) {
			socEsquemasPar = socEsquemasDao.esquemaByCod(socSolicitudes.getEsqCodigo());
			socEsquemasLista.add(socEsquemasPar);
			return socEsquemasLista;
		}

		if (StringUtils.isBlank(socSolicitudes.getSolCodigo())) {
			log.warn("Obtener esq sin codigo de solicitante");
			return socEsquemasLista;
		}
		if (StringUtils.isBlank(socSolicitudes.getCveTipctasolic())) {
			log.warn("Obtener esq sin tipo de generacion CveTipctasolic");
			return socEsquemasLista;
		}
		// se concatena el tipo de generacion (S:sistema, W:webservices) + tipo
		// de entidad SF o SP
		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo());

		boolean provisiona = solicitudProvisiona(socSolicitudes, socSolicitante, null, socSolicitudctasMOVPROVISION);
		String tipoTransfer = Constants.CLAVE_TIPOTRANSFER_SINPROV;
		if (provisiona) {
			tipoTransfer = Constants.CLAVE_TIPOTRANSFER_CONPROV;
		}

		SocEsquemas socEsquemas = new SocEsquemas();
		socEsquemas.setCodTipooper(socSolicitudes.getClaTipo());

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
			socEsquemas.setTipoRetencion(socSolicitudes.getTipoRetencion());
		} else {
			socEsquemas.setTipoRetencion(socEsquemasPar.getTipoRetencion());
		}

		socEsquemas.setCveSubtipooper(socSolicitudes.getCveSubtipooper());
		socEsquemas.setCodEsqref(socEsquemas.getCodEsqref());
		// concatenamos el tipo de generacion de la solicitud W:webservices,
		// S;sistema y tipo de entidad SP: sector publico, SF sist financ.
		socEsquemas.setGenera(socSolicitudes.getCveTipctasolic().trim() + socSolicitante.getClaEntidad().trim());

		// primero se busca con los parametros base
		socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);

		if (socEsquemasLista.size() <= 1) {
			// ya no se continua la bÃƒÆ’Ã‚Âºsqueda
			log.info("Esquema encontrado o sin resultados size " + socEsquemasLista.size());
			return socEsquemasLista;
		}

		// se agrega monedas de solicitud y transferencia
		// moneda de la solicitud
		String codMonedaSolicitud = (socSolicitudes.getCodMoneda() != null ? socSolicitudes.getCodMoneda().toString() : "");

		// moneda de la transferencia
		String codMonedaTrans = (socSolicitudes.getCodMonedat() != null ? socSolicitudes.getCodMonedat().toString() : "");
		socEsquemas.setCveTiposolic(codMonedaTrans);

		log.info("Varios Esquemas encontrados, segundo ciclo " + socEsquemasLista.size());

		socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);

		if (socEsquemasLista.size() > 1) {
			// existe resultados se busca con la alternativa de otras
			// monedas
			if (!StringUtils.isBlank(codMonedaTrans) && !codMonedaTrans.equals(Constants.COD_MONEDA_USD)
					&& !codMonedaTrans.equals(Constants.COD_MONEDA_BS)) {
				// la moneda es diferente a bs y usd
				codMonedaTrans = "999";
			}

			socEsquemas.setCveTiposolic(codMonedaTrans);

			socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);
		}

		if (socEsquemasLista.size() == 1) {
			// ya no se continua la bÃƒÆ’Ã‚Âºsqueda
			log.info("Esquema encontrado o sin resultados size " + socEsquemasLista.size());
			return socEsquemasLista;
		}

		socEsquemas.setCodMoneda(codMonedaSolicitud);

		log.info("Varios Esquemas encontrados, tercer ciclo " + socEsquemasLista.size());
		// se agrega la condicion de la moneda de la solicitud
		socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);

		if (socEsquemasLista.size() > 1) {

			// si no existe resultados se busca con la alternativa de otras
			// monedas
			if (!StringUtils.isBlank(codMonedaSolicitud) && !codMonedaSolicitud.equals(Constants.COD_MONEDA_USD)
					&& !codMonedaSolicitud.equals(Constants.COD_MONEDA_BS)) {
				// la moneda es diferente a bs y usd
				codMonedaSolicitud = "999";
			}
			socEsquemas.setCodMoneda(codMonedaSolicitud);
			socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);
		}

		log.info("Esquemas encontrados, ciclo todos " + socEsquemasLista.size());
		if (socEsquemasLista.size() > 1) {
			// si no existe resultados se busca con la alternativa de moneda
			// solicitada, es decir el esquema acepta cualquier moneda
			codMonedaSolicitud = "000";
			socEsquemas.setCodMoneda(codMonedaSolicitud);
			socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);
		}

		if (socEsquemasLista.size() == 0) {
			socEsquemas.setCveTiposolic(null);
			socEsquemas.setCodMoneda(null);
			// no aseguramos que haya un esquema seleccionado
			socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);
		}

		if (socEsquemasLista.size() > 1) {
			socEsquemas.setTipoTransfer(tipoTransfer);
			socEsquemasLista = socEsquemasDao.obtenerEsquema(socEsquemas);
		}

		return socEsquemasLista;

	}

	public List<SolicitudesS> recuperarSolicitudes(Integer esqCodigo, String claTipo, String cveSubtipooper, String estado, String estadoNotif,
			String codEnt, String codEntSolicitante, String cla_entidad, Date fechaDesde, Date fechaAl, String usrAudit) {

		StringBuffer query = new StringBuffer();

		List<SolicitudesS> solicitudesSLista = new ArrayList<SolicitudesS>();

		query = query
				.append("select s.soc_codigo,s.esq_codigo,s.sol_codigo,s.cla_tipo,s.fecha,s.soc_montome,s.soc_correlativo,s.soc_montoord,s.soc_montomn,s.cod_moneda,s.cod_monedat,s.cla_estado,s.cla_estadows,s.cod_solicitudorig,s.cve_subtipooper,s.fecha_reg,ss.sol_persona, ");
		query = query
				.append("(SELECT val_nombre FROM soc_valorescla vc WHERE cla_codigo = 'cla_estsolic' AND vc.val_codigo = s.cla_estado) claestadodesc, ");
		query = query.append("(SELECT mon_sigla FROM gen_moneda m WHERE m.cod_moneda = s.cod_moneda) monedadesc, ");
		query = query.append("(SELECT mon_sigla FROM gen_moneda m WHERE m.cod_moneda = s.cod_monedat) monedatdesc, ");
		query = query.append("(SELECT es.cla_operacion FROM soc_esquemas es WHERE es.esq_codigo = s.esq_codigo) tipooperaciondesc ");
		query = query.append("from soc_solicitudes s, soc_solicitante ss ");
		query = query.append("where s.sol_codigo = ss.sol_codigo ");
		query = query.append("and s.esq_codigo > 100 ");

		if (!StringUtils.isBlank(estado)) {
			query = query.append("and s.cla_estado in (:estado ) ");
		} else {
			query = query.append("and s.cla_estado != 'Z' ");
		}

		if (!StringUtils.isBlank(estadoNotif)) {
			query = query.append("and s.cla_estadows in (:estadoNotif ) ");
		}

		if (!StringUtils.isBlank(claTipo)) {
			query = query.append("and s.cla_tipo in (:claTipo) ");
		}

		if (!StringUtils.isBlank(cveSubtipooper)) {
			query = query.append("and s.cve_subtipooper in (:cveSubtipooper) ");
		}

		if (esqCodigo != null && esqCodigo.compareTo(0) != 0) {
			query = query.append("and s.esq_codigo = :esqCodigo  ");
		}

		if (!StringUtils.isBlank(codEntSolicitante)) {
			// no es usuario del bcb
			query = query.append("and s.sol_entsolic = :codEntSolicitante ");
		}

		if (!StringUtils.isBlank(codEnt)) {
			query = query.append("and s.sol_codigo = :solCodigo ");
		} else {
			if (!StringUtils.isBlank(usrAudit)) {

				if (usrAudit.equals(Constants.COD_BCB)) {
					// si es usuario del bcb
					// se busca todos las solicitudes no generadas por el bcb
					if (StringUtils.isBlank(codEntSolicitante)) {
						query = query.append("and s.sol_entsolic != :codEntSolicitante ");
					}
				}
			}
		}

		if (fechaDesde != null) {
			query = query.append("and s.fecha >= :fechaDesde ");
		}
		if (fechaAl != null) {
			query = query.append("and s.fecha <= :fechaAl ");
		}
		if (!StringUtils.isBlank(cla_entidad)) {
			query = query.append("and ss.cla_entidad = :cla_entidad  ");
		}

		query = query.append("order by s.fecha, s.soc_codigo ");

		Query consulta = getSession().createSQLQuery(query.toString());

		if (!StringUtils.isBlank(estado)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(estado.split(",")));
			consulta.setParameterList("estado", estadosList);
		}

		if (!StringUtils.isBlank(estadoNotif)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(estadoNotif.split(",")));
			consulta.setParameterList("estadoNotif", estadosList);
		}

		if (!StringUtils.isBlank(claTipo)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(claTipo.split(",")));
			consulta.setParameterList("claTipo", estadosList);
		}

		if (!StringUtils.isBlank(cveSubtipooper)) {
			List estadosList = new ArrayList();
			estadosList.addAll(Arrays.asList(cveSubtipooper.split(",")));

			consulta.setParameterList("cveSubtipooper", estadosList);
		}

		if (esqCodigo != null && esqCodigo.compareTo(0) != 0) {
			consulta.setParameter("esqCodigo", esqCodigo);
		}

		if (!StringUtils.isBlank(codEntSolicitante)) {
			consulta.setParameter("codEntSolicitante", codEntSolicitante);
		}

		if (!StringUtils.isBlank(codEnt)) {
			consulta.setParameter("solCodigo", codEnt);
		} else {
			if (!StringUtils.isBlank(usrAudit)) {

				if (usrAudit.equals(Constants.COD_BCB)) {
					// si es usuario del bcb
					// se busca todos las solicitudes no generadas por el bcb
					if (StringUtils.isBlank(codEntSolicitante)) {
						consulta.setParameter("codEntSolicitante", usrAudit);
					}
				}
			}
		}

		if (fechaDesde != null) {
			consulta.setParameter("fechaDesde", fechaDesde);
		}
		if (fechaAl != null) {
			consulta.setParameter("fechaAl", fechaAl);
		}
		if (!StringUtils.isBlank(cla_entidad)) {
			consulta.setParameter("cla_entidad", cla_entidad);
		}

		SolicitudesS solicitudSS = null;
		try {
			List lista = consulta.list();

			List<Map<String, Object>> resultado = UtilsQNatives
					.convertListToMap(
							lista,
							"soc_codigo,esq_codigo,sol_codigo,cla_tipo,fecha,soc_montome,soc_correlativo,soc_montoord,soc_montomn,cod_moneda,cod_monedat,cla_estado,cla_estadows,cod_solicitudorig, cve_subtipooper,fecha_reg,sol_persona,claestadodesc,monedadesc,monedatdesc,tipooperaciondesc"
									.split(","));

			for (Map<String, Object> res : resultado) {

				solicitudSS = new SolicitudesS();
				solicitudSS.setSocCodigo((String) res.get("soc_codigo"));
				solicitudSS.setEsqCodigo((Integer) res.get("esq_codigo"));
				solicitudSS.setSolCodigo((String) res.get("sol_codigo"));
				solicitudSS.setSolicitante((String) res.get("sol_persona"));
				solicitudSS.setClaTipo((String) res.get("cla_tipo"));
				solicitudSS.setFecha((Date) res.get("fecha"));
				solicitudSS.setSocMontome((BigDecimal) res.get("soc_montome"));
				solicitudSS.setSocCorrelativo((String) res.get("soc_correlativo"));
				solicitudSS.setSocMontoord((BigDecimal) res.get("soc_montoord"));
				solicitudSS.setSocMontomn((BigDecimal) res.get("soc_montomn"));

				if (res.get("cod_moneda") != null) {
					Integer codMoneda = (Integer) res.get("cod_moneda");
					solicitudSS.setMoneda(String.valueOf(codMoneda));
					solicitudSS.setMonedaDesc((String) res.get("monedadesc"));
				}
				if (res.get("cod_monedat") != null) {
					Integer codMonedat = (Integer) res.get("cod_monedat");
					solicitudSS.setMonedaT(String.valueOf(codMonedat));
					solicitudSS.setMonedaTDesc((String) res.get("monedatdesc"));
				}
				solicitudSS.setClaEstado((Character) res.get("cla_estado"));
				solicitudSS.setClaEstadows((String) res.get("cla_estadows"));
				solicitudSS.setClaEstadoDesc((String) res.get("claestadodesc"));
				solicitudSS.setCodSolicitudorig((String) res.get("cod_solicitudorig"));
				solicitudSS.setTipo((String) res.get("tipooperaciondesc"));
				solicitudSS.setCveSubtipooper((String) res.get("cve_subtipooper"));
				solicitudSS.setFechaReg((Date) res.get("fecha_reg"));

				SocSolicitudes socSolicitudes = getSolicitud(solicitudSS.getSocCodigo());
				solicitudSS.setSocSolicitudes(socSolicitudes);

				solicitudesSLista.add(solicitudSS);
			}

			if (solicitudesSLista.size() == 0) {
				log.warn("Consulta sin resultado " + esqCodigo + ", " + claTipo + ", " + estado + ", " + estadoNotif + ", " + codEnt + ", "
						+ codEntSolicitante + ", " + cla_entidad + ", " + fechaDesde + ", " + fechaAl + "==Z " + query.toString());
			}
		} catch (Exception e) {
			log.error("Error al buscar solicitudes " + e.getMessage(), e);
			throw new BusinessException("Error al buscar solicitudes " + e.getMessage(), e);
		}
		return solicitudesSLista;
	}

	private String getCorrelativo(SocSolicitudes socSolicitudes) {
		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocSolicitante socSolicitante = socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo().trim());

		Integer corr = 0;
		Integer actual = 0;
		String corrs = "";

		String sigla = (StringUtils.isBlank(socSolicitante.getSigla()) ? "GRAL" : socSolicitante.getSigla());
		String formato = "yyyy";
		SimpleDateFormat dateFormat = new SimpleDateFormat(formato);
		Long gestion = Long.valueOf(dateFormat.format(new Date()));

		StringBuffer consulta = new StringBuffer();
		consulta = consulta.append("select so ");
		consulta = consulta.append("from SocSolicitudes so ");
		consulta = consulta.append("where trim(so.solCodigo) = :solCodigo ");
		// consulta = consulta.append("and year(so.fecha) = :gestion ");
		consulta = consulta.append("and so.socCorrelativo like :correlativo ");

		Query query = getSession().createQuery(consulta.toString());
		query.setParameter("solCodigo", socSolicitudes.getSolCodigo().trim());
		// query.setParameter("gestion", gestion);
		query.setParameter("correlativo", sigla + "-%-" + String.format("%04d", gestion));

		List<SocSolicitudes> result = query.list();
		for (SocSolicitudes socSolicitudes2 : result) {
			String cc = socSolicitudes2.getSocCorrelativo();
			corrs = StringUtils.substringBetween(cc, "-", "-");
			if (corrs.length() <= 4) {
				if (NumberUtils.isNumber(corrs)) {
					actual = Integer.valueOf(corrs);
				}
			}

			if (actual.compareTo(corr) > 0) {
				corr = actual;
			}
		}

		corr++;

		String correl = sigla + "-" + String.format("%04d", corr) + "-" + gestion;
		log.info("Nuevo Correlativo " + correl);
		return correl;
	}

	public boolean solicitudProvisiona(SocSolicitudes socSolicitudes, SocSolicitante socSolicitante, SocEsquemas socEsquemas,
			SocSolicitudctas socSolicitudctasMOVPROVISION) {
		// determinamos si la solicitud provisiona o no
		boolean provisiona = false;

		if (socSolicitudctasMOVPROVISION == null || StringUtils.isBlank(socSolicitudctasMOVPROVISION.getNroCuenta())
				|| StringUtils.isBlank(socSolicitudes.getSolCodigo()) || socSolicitudes.getSolEntsolic() == null
				|| socSolicitante.getClaEntidad() == null) {
			log.info("No provisiona por cuenta movprovision nulo o condiciones");
			return false;
		}
		if (socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_SECPUBGOI)
				|| socSolicitudctasMOVPROVISION.getNroCuenta().equals(Constants.CTA_TRANSIT_PROV)) {
			log.info("No provisiona por cuenta movprovision " + socSolicitudctasMOVPROVISION.getNroCuenta());
			return false;
		}

		if (socSolicitudes.getSolCodigo().trim().equals(Constants.COD_BCB)) {
			log.info("No provisiona por solcodigo BCB " + socSolicitudes.getSolCodigo());
			return false;
		}

		if (!socSolicitudes.getSolEntsolic().trim().equals(Constants.COD_BCB)) {
			// el que registra no es un usuario del bcb
			if (socSolicitante.getClaEntidad().equals(Constants.CLAVE_CLAENTIDAD_SISTFINANCIERO)) {
				log.info("Provisiona por solcodigo SF " + socSolicitante.getSolCodigo());
				return true;
			}
			log.info("Provisiona por SolEntsolic diferente a BCB " + socSolicitudes.getSolEntsolic());
			return true;
		}

		log.info("No Provisiona por no cumplir anteriores " + socSolicitudes.getSolEntsolic());
		return false;
	}

	public boolean mayorALimite(SocSolicitudes socSolicitudes, BigDecimal montoOrdenado, Integer codMoneda) {
		// calculamos si el monto provisionado excede el limite permitido
		boolean mayorALim = false;

		if ((socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT))) {
			SocParametrosDao socParametrosDao = new SocParametrosDao();
			socParametrosDao.setSessionFactory(getSessionFactory());

			Date fechaTc = new Date();
			Map<String, Object> montoConvertido = UtilsSioc.conversion(montoOrdenado, codMoneda, Constants.COD_MONEDA_USD, fechaTc, null,
					((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

			BigDecimal montoADebitarSUS = (BigDecimal) montoConvertido.get("montosus");

			SocParametros socParametros = socParametrosDao.getByCodigo("lim-maxUSD");
			String montomax_lim = socParametros.getParValor();

			BigDecimal montomaxConvertUSD = UtilsGeneric.bigDecimalFromString(montomax_lim.trim());

			if (montoADebitarSUS.compareTo(montomaxConvertUSD) > 0) {
				// la transferencia se realiza de manera manual por
				// el area
				// compran la moneda en el exterior pero
				// contablemente se transfiere dolares
				mayorALim = true;
			}
			log.info("mayorlimite: ... " + mayorALim);
		}
		return mayorALim;
	}

	public String getTipoDeNegociacionSolicitud(SocSolicitudes socSolicitudes) {
		// tipo de registro en cuenta del beneficiario
		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		SocCuentasDao socCuentasDao = new SocCuentasDao();
		socCuentasDao.setSessionFactory(getSessionFactory());

		String tipoNegocia = Constants.CLAVE_TIPNEGOCIA_NORMAL;

		if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT) && socSolicitudes.getCodMoneda() != null
				&& socSolicitudes.getCodMonedat() != null) {
			if (socSolicitudes.getCodMonedat().compareTo(Constants.COD_MONEDA_USD) != 0) {
				boolean mayorlimite = mayorALimite(socSolicitudes, socSolicitudes.getSocMontome(), socSolicitudes.getCodMoneda());

				if (mayorlimite) {
					// el monto es mayor al limite
					tipoNegocia = Constants.CLAVE_TIPNEGOCIA_OPER;
				} else {
					// se verifica que existan cuentas
					SocCuentassol socCuentassol = socCuentassolDao.getSocCuentasolBanqueroExt(socSolicitudes, socSolicitudes.getCodMonedat(), null);
					SocCuentas socCuentas = socCuentassolDao.getSocCuentaBanqueroExt(socSolicitudes, socSolicitudes.getCodMonedat(), null);

					if (socCuentassol == null || socCuentas == null) {
						// si no existe las cuentas en soccuentassol o
						// soccuentas es moneda que no esta registrada o
						log.warn("Cuenta moneda FONDOS VISTA no para moneda " + socSolicitudes.getCodMonedat());
						tipoNegocia = Constants.CLAVE_TIPNEGOCIA_OPER;
					}

					if (socCuentassol != null && socCuentas == null) {
						// inconsistencia falta parametrizacion
						log.error("Inconsistencia Cuenta contable FONDOS VISTA registrada para moneda " + socSolicitudes.getCodMonedat()
								+ " , sin banco beneficiario parametrizado en soccuentas");
						// throw new
						// BusinessException("Inconsistencia Cuenta contable FONDOS VISTA registrada para moneda "
						// + socSolicitudes.getCodMonedat()
						// +
						// " , sin banco beneficiario parametrizado en soccuentas");
					}

					if (socCuentassol == null && socCuentas != null) {
						// inconsistencia falta parametrizacion
						log.error("Inconsistencia Cuenta contable FONDOS VISTA NO registrada en soccuentassol para moneda "
								+ socSolicitudes.getCodMonedat() + " , con banco beneficiario parametrizado en soccuentas bco: "
								+ socCuentas.getBcoCodigo());
						// throw new
						// BusinessException("Inconsistencia Cuenta contable FONDOS VISTA NO registrada en soccuentassol para moneda "
						// + socSolicitudes.getCodMonedat() +
						// " , con banco beneficiario parametrizado en soccuentas bco: "
						// + socCuentas.getBcoCodigo());
					}

				}
			}
		}
		log.info("Solicitud con tipo de negaciacion " + tipoNegocia + " " + socSolicitudes.getCodMonedat());
		return tipoNegocia;
	}
	
	
	public List<OperacionesCambiarias> obtenerInsitutcionOpeCambiariasSecPublico(Date fechaInicio, Date fechaFin){

		List<OperacionesCambiarias> resultado = new ArrayList<OperacionesCambiarias>();
		// Obtenemos las entidades Por JDBC
		StringBuffer queryVentasDia = new StringBuffer();
		StringBuffer queryCompras = new StringBuffer();
		StringBuffer queryAlExterior = new StringBuffer();
		StringBuffer queryDelExterior = new StringBuffer();
		StringBuffer queryFinal = new StringBuffer();
		String union = "UNION ";
		
		
		//Armamos el query para ventas en el dia
		queryVentasDia.append("SELECT t.sol_codigo, t.sol_persona, SUM(t.m_venta_dia) as m_venta_dia, ");
		queryVentasDia.append("SUM(t.m_ventas_bolsin) as m_ventas_bolsin, SUM(t.m_compras) as m_compras, ");
		queryVentasDia.append("SUM(t.m_al_exterior) as m_al_exterior, SUM(t.m_del_exterior) as m_del_exterior  FROM (");
		queryVentasDia.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryVentasDia.append("SUM(nvl((SELECT SUM(oc.monto_mo) FROM soc_opecomi oc "); 
		queryVentasDia.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_comision = 'VENTAUSD'),0)) AS m_venta_dia, ");
		queryVentasDia.append("0 AS m_ventas_bolsin, 0 AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryVentasDia.append("FROM soc_solicitudes s, soc_solicitante sol ");
		queryVentasDia.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryVentasDia.append("AND sol.cla_entidad = 'SP' ");
		queryVentasDia.append("AND s.soc_codigo IN(SELECT c.ope_codigo FROM soc_comprobante c ");
		queryVentasDia.append("WHERE mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta AND c.ope_codigo = s.soc_codigo ");
		queryVentasDia.append("AND c.cve_dettipocomp != 'O' AND c.cpb_nrocpbte IS NOT NULL AND c.esq_codigo <> '301') ");
		queryVentasDia.append("AND s.cla_estado in ('C') ");
		queryVentasDia.append("AND EXISTS ( SELECT * FROM soc_opecomi oc WHERE s.soc_codigo = oc.ope_codigo ");
		queryVentasDia.append("AND oc.cla_comision = 'MONTODIFCAMBVENDIV' ");
		queryVentasDia.append("AND oc.cla_estadovar = 'C') ");
		queryVentasDia.append("GROUP BY 1,2 ");
		queryVentasDia.append("ORDER BY 2 ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		queryVentasDia.append(union);
		queryVentasDia.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryVentasDia.append("SUM(se.est_montous) as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryVentasDia.append("0 AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryVentasDia.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryVentasDia.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryVentasDia.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryVentasDia.append("AND se.cla_operacion IN ('VED', 'VTE') ");
		queryVentasDia.append("AND se.cla_estado = 'D' ");
		queryVentasDia.append("GROUP BY 1,2 ");
		queryVentasDia.append("ORDER BY 2) t ");
		queryVentasDia.append("GROUP BY 1,2 ");
		queryVentasDia.append("ORDER BY 2 ");
		
		//Armamos el query para compras
		queryCompras.append("SELECT t.sol_codigo, t.sol_persona, SUM(t.m_venta_dia) as m_venta_dia, ");
		queryCompras.append("SUM(t.m_ventas_bolsin) as m_ventas_bolsin, SUM(t.m_compras) as m_compras, ");
		queryCompras.append("SUM(t.m_al_exterior) as m_al_exterior, SUM(t.m_del_exterior) as m_del_exterior  FROM (");
		queryCompras.append("SELECT sol.sol_codigo, sol.sol_persona,0 AS m_venta_dia, 0 AS m_ventas_bolsin, ");
		queryCompras.append("SUM(s.soc_montome) AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryCompras.append("FROM soc_solicitudes s, soc_solicitante sol ");
		queryCompras.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryCompras.append("AND s.cve_subtipooper = 'TC' ");
		queryCompras.append("AND sol.cla_entidad = 'SP' ");
		queryCompras.append("AND EXISTS ( SELECT * FROM soc_comprobante c ");
		queryCompras.append("WHERE s.soc_codigo = c.ope_codigo ");
		queryCompras.append("AND c.cve_dettipocomp = 'P' ");
		queryCompras.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		queryCompras.append("AND c.cve_estadocpb = 'C') ");
		queryCompras.append("AND EXISTS( SELECT * FROM soc_solicitudctas sc ");
		queryCompras.append("WHERE s.soc_codigo = sc.soc_codigo ");
		queryCompras.append("AND sc.tipo_cuenta = 'MOVPROVISION' ");
		queryCompras.append("AND sc.cod_moneda = 34) ");
		queryCompras.append("AND EXISTS( SELECT * FROM soc_opecomi oc ");
		queryCompras.append("WHERE s.soc_codigo = oc.ope_codigo ");
		queryCompras.append("AND oc.cla_comision = 'MONTOD' ");
		queryCompras.append("AND oc.cod_moneda = 69 ");
		queryCompras.append("AND oc.cla_estadovar = 'C') ");
		queryCompras.append("GROUP BY 1,2 ");
		queryCompras.append("ORDER BY 2 ");
		// Agregamos las cuentas que tienen cuenta solo en bolivianos
		queryCompras.append(union);
		queryCompras.append("SELECT sol.sol_codigo, sol.sol_persona, 0 AS m_venta_dia, ");
		queryCompras.append("0 AS m_ventas_bolsin, ");
		queryCompras.append("SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		queryCompras.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryCompras.append("AND oc.cla_comision = 'TOTALPROV'),0), ");
		queryCompras.append("(SELECT oc.cod_moneda from soc_opecomi oc ");
		queryCompras.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryCompras.append("AND oc.cla_comision = 'TOTALPROV'), '34',");
		queryCompras.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		queryCompras.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		queryCompras.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS m_compras, ");
		queryCompras.append("0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryCompras.append("FROM soc_solicitudes s,  soc_solicitante sol ");
		queryCompras.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryCompras.append("AND s.cod_moneda <> s.cod_monedat ");
		queryCompras.append("AND s.sol_codigo = sol.sol_codigo ");
		queryCompras.append("AND s.cla_tipo IN ('TD','RGAC') AND sol.cla_entidad = 'SP' ");
		queryCompras.append("AND EXISTS ( SELECT * FROM soc_comprobante c ");
		queryCompras.append("WHERE s.soc_codigo = c.ope_codigo ");
		queryCompras.append("AND c.cve_dettipocomp = 'P' ");
		queryCompras.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		queryCompras.append("AND c.cve_estadocpb = 'C') ");
		queryCompras.append("GROUP BY 1,2 ");
		queryCompras.append("ORDER BY 2 ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		queryCompras.append(union);
		queryCompras.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryCompras.append("0 as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryCompras.append("SUM(se.est_montous) AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryCompras.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryCompras.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryCompras.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryCompras.append("AND se.cla_operacion IN ('TRL' , 'CTE') ");
		queryCompras.append("AND se.cla_estado = 'D' ");
		queryCompras.append("GROUP BY 1,2 ");
		queryCompras.append("ORDER BY 2) t ");
		queryCompras.append("GROUP BY 1,2 ");
		queryCompras.append("ORDER BY 2 ");
				
				
		// Armamos el query al exterior
		queryAlExterior.append("SELECT t.sol_codigo, t.sol_persona, SUM(t.m_venta_dia) as m_venta_dia, ");
		queryAlExterior.append("SUM(t.m_ventas_bolsin) as m_ventas_bolsin, SUM(t.m_compras) as m_compras, ");
		queryAlExterior.append("SUM(t.m_al_exterior) as m_al_exterior, SUM(t.m_del_exterior) as m_del_exterior  FROM ( ");
		queryAlExterior.append("SELECT q.sol_codigo, q.sol_persona,0 AS m_venta_dia, 0 AS m_ventas_bolsin,0 AS m_compras, ");
		queryAlExterior.append("SUM(q.m_al_exterior) AS m_al_exterior, 0 AS m_del_exterior ");
		queryAlExterior.append("FROM ( SELECT s.soc_codigo, sol.sol_codigo, sol_persona, ");
		queryAlExterior.append("SUM(f_conversion(NVL(( SELECT SUM(oc.monto_mo) FROM soc_opecomi oc WHERE oc.ope_codigo = s.soc_codigo ");
		queryAlExterior.append("AND oc.cla_comision = 'TOTTRANSMT'), 0), (SELECT oc.cod_moneda FROM soc_opecomi oc ");
		queryAlExterior.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_comision = 'TOTTRANSMT'), '34', ");
		queryAlExterior.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		queryAlExterior.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' AND c0.cve_estadocpb = 'C'), ");
		queryAlExterior.append("0, 'MONTO')) AS m_al_exterior ");
		queryAlExterior.append("FROM soc_solicitudes s,  soc_solicitante sol ");
		queryAlExterior.append("WHERE s.sol_codigo = sol.sol_codigo AND s.cve_subtipooper = 'TE' ");
		queryAlExterior.append("AND sol.cla_entidad = 'SP' ");
		queryAlExterior.append("AND s.cla_estado = 'C' ");
		queryAlExterior.append("AND s.fecha_cont BETWEEN :fechaInicio AND :fechaHasta ");
		queryAlExterior.append("GROUP BY 1,2,3 ORDER BY 2) AS q ");
		queryAlExterior.append("GROUP BY 1,2 ");
		queryAlExterior.append("ORDER BY 2 ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		queryAlExterior.append(union);
		queryAlExterior.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryAlExterior.append("0 as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryAlExterior.append("0 AS m_compras, SUM(se.est_montous) AS m_al_exterior, 0 AS m_del_exterior ");
		queryAlExterior.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryAlExterior.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryAlExterior.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryAlExterior.append("AND se.cla_operacion IN ('TAE' ,'VTE') ");
		queryAlExterior.append("AND se.cla_estado = 'D' ");
		queryAlExterior.append("GROUP BY 1,2 ");
		queryAlExterior.append("ORDER BY 2) t ");
		queryAlExterior.append("GROUP BY 1,2 ");
		queryAlExterior.append("ORDER BY 2 ");
		
		//Armamos el query del exterior
		queryDelExterior.append("SELECT t.sol_codigo, t.sol_persona, SUM(t.m_venta_dia) as m_venta_dia, ");
		queryDelExterior.append("SUM(t.m_ventas_bolsin) as m_ventas_bolsin, SUM(t.m_compras) as m_compras, ");
		queryDelExterior.append("SUM(t.m_al_exterior) as m_al_exterior, SUM(t.m_del_exterior) as m_del_exterior  FROM (");
		queryDelExterior.append("SELECT sol.sol_codigo, sol.sol_persona, 0 AS m_venta_dia, ");
		queryDelExterior.append("0 AS m_ventas_bolsin,0 AS m_compras, 0 AS m_al_exterior, ");
		queryDelExterior.append("SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		queryDelExterior.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryDelExterior.append("AND oc.cla_comision = 'TOTALPROV'),0), ");
		queryDelExterior.append("(SELECT oc.cod_moneda from soc_opecomi oc ");
		queryDelExterior.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryDelExterior.append("AND oc.cla_comision = 'TOTALPROV'), '34',");
		queryDelExterior.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		queryDelExterior.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		queryDelExterior.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS m_del_exterior ");
		queryDelExterior.append("FROM soc_solicitudes s,  soc_solicitante sol ");
		queryDelExterior.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryDelExterior.append("AND s.sol_codigo = sol.sol_codigo ");
		queryDelExterior.append("AND s.cla_tipo IN ('TD','RGAC') AND sol.cla_entidad = 'SP' ");
		queryDelExterior.append("AND EXISTS ( SELECT * FROM soc_comprobante c ");
		queryDelExterior.append("WHERE s.soc_codigo = c.ope_codigo ");
		queryDelExterior.append("AND c.cve_dettipocomp = 'P' ");
		queryDelExterior.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		queryDelExterior.append("AND c.cve_estadocpb = 'C') ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2 ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		queryDelExterior.append(union);
		queryDelExterior.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryDelExterior.append("0 as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryDelExterior.append("0 AS m_compras, 0 AS m_al_exterior, SUM(se.est_montous) AS m_del_exterior ");
		queryDelExterior.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryDelExterior.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryDelExterior.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryDelExterior.append("AND se.cla_operacion IN ('TDE' ,'CTE') ");
		queryDelExterior.append("AND se.cla_estado = 'D' ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2) t ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2 ");
		
				
		// Armamos todo el query
		queryFinal.append("SELECT * FROM (");
		queryFinal.append(queryVentasDia).append(union);
		queryFinal.append(queryCompras).append(union);
		queryFinal.append(queryAlExterior).append(union);
		queryFinal.append(queryDelExterior).append(") AS t ");
		queryFinal.append("ORDER BY 2");
		
		
		
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(queryFinal.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
		OperacionesCambiarias cambiarias = null;		
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "sol_codigo,sol_persona,m_venta_dia,m_ventas_bolsin,m_compras,m_al_exterior,m_del_exterior".split(","));
		
		
		Map<String, OperacionesCambiarias> resultadoSolicitantes = new HashMap<String, OperacionesCambiarias>();
		BigDecimal montoValidador = BigDecimal.ZERO;
		BigDecimal ventaDia = null;
		BigDecimal ventasBolsin = null;
		BigDecimal compras = null;
		BigDecimal alExterior = null;
		BigDecimal delExterior = null;
		String solCodigo = "";
		
		for (Map<String, Object> res : resultadoQuery) {
			
			ventaDia = new BigDecimal(res.get("m_venta_dia") == null? "0": res.get("m_venta_dia").toString());
			ventasBolsin = new BigDecimal(res.get("m_ventas_bolsin") == null? "0": res.get("m_ventas_bolsin").toString());
			compras = new BigDecimal(res.get("m_compras") == null ? "0":res.get("m_compras").toString());
			alExterior = new BigDecimal(res.get("m_al_exterior") == null? "0" :res.get("m_al_exterior").toString());
			delExterior = new BigDecimal(res.get("m_del_exterior") == null? "0":res.get("m_del_exterior").toString());
			solCodigo = res.get("sol_codigo").toString().trim();			
			
			if (resultadoSolicitantes.containsKey(solCodigo)) {
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = resultadoSolicitantes.get(solCodigo);
				
				cambiarias.setVentasDia(cambiarias.getVentasDia().add(ventaDia));
				cambiarias.setVentasBolsin(cambiarias.getVentasBolsin().add(ventasBolsin));
				cambiarias.setCompras(cambiarias.getCompras().add(compras));
				cambiarias.setAlExterior(cambiarias.getAlExterior().add(alExterior));
				cambiarias.setDelExterior(cambiarias.getDelExterior().add(delExterior));
				
				if (montoValidador.compareTo(BigDecimal.ZERO) == 0 ){
					// Quitamos el objeto con valor total vero
					resultadoSolicitantes.remove(solCodigo);					
				}
				

			} else {
				montoValidador = BigDecimal.ZERO;
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = new OperacionesCambiarias();
				cambiarias.setCodInstitucion(solCodigo);
				cambiarias.setInstitucion((String) res.get("sol_persona"));
				cambiarias.setVentasDia(ventaDia.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setVentasBolsin(ventasBolsin.setScale(2, BigDecimal.ROUND_HALF_UP));
				cambiarias.setCompras(compras.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setAlExterior(alExterior.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setDelExterior(delExterior.setScale(0, BigDecimal.ROUND_HALF_UP));
				if (montoValidador.compareTo(BigDecimal.ZERO) > 0 ){
					resultadoSolicitantes.put(solCodigo,cambiarias);	
				}
				
			}		
			
			
		}
				
		//Obtenemos la coleccion final
		resultado = new ArrayList<OperacionesCambiarias>(resultadoSolicitantes.values());
		Comparator<OperacionesCambiarias> comparator = new Comparator<OperacionesCambiarias>() {
			
			public int compare(OperacionesCambiarias o1, OperacionesCambiarias o2) {
				return o1.getInstitucion().compareTo(o2.getInstitucion());
			}
		};
		
		java.util.Collections.sort(resultado,comparator);
						
		return resultado;
		
	}
	
	
	
	public List<OperacionesCambiarias> obtenerInsitutcionOpeCambiariasSisFinanciero(Date fechaInicio, Date fechaFin){

		List<OperacionesCambiarias> resultado = new ArrayList<OperacionesCambiarias>();
		// Obtenemos las entidades Por JDBC
		StringBuffer queryVentasDia = new StringBuffer();
		StringBuffer queryVentasBolsin = new StringBuffer();
		StringBuffer queryAlExterior = new StringBuffer();
		StringBuffer queryDelExterior = new StringBuffer();
		StringBuffer queryFinal = new StringBuffer();
		StringBuffer queryCompras = new StringBuffer();
		String union = "UNION ";
		
		
		//Armamos el query para ventas en el dia
		
		queryVentasDia.append("SELECT s.sol_codigo,sol.sol_persona, SUM(s.montosol) AS m_venta_dia, ");
		queryVentasDia.append("0 AS m_ventas_bolsin, 0 AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryVentasDia.append("FROM soc_bolsin s, soc_solicitante sol ");
		queryVentasDia.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryVentasDia.append("AND s.cla_tipsolic in ('ED') ");
		queryVentasDia.append("AND s.cla_estado in ('5') ");
		queryVentasDia.append("AND sol.cla_entidad = 'SF' ");
		queryVentasDia.append("AND s.fecha  BETWEEN :fechaInicio AND :fechaHasta  ");		
		queryVentasDia.append("GROUP BY 1,2 ");
				
		//Armamos el query para ventas bolsin
		
		queryVentasBolsin.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryVentasBolsin.append("0 as m_venta_dia, SUM(s.montosol) as m_ventas_bolsin, "); 
		queryVentasBolsin.append("0 AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryVentasBolsin.append("FROM soc_bolsin s, soc_solicitante sol ");
		queryVentasBolsin.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryVentasBolsin.append("AND s.soc_codigo IN ( SELECT sc.ope_codigo FROM ( ");
		queryVentasBolsin.append("SELECT c.ope_codigo, MAX(mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion)) AS fecha ");
		queryVentasBolsin.append("FROM soc_comprobante c WHERE c.ope_codigo= s.soc_codigo ");
		queryVentasBolsin.append("AND c.cpb_nrocpbte IS NOT NULL GROUP BY 1) AS sc  ");
		queryVentasBolsin.append("WHERE sc.fecha BETWEEN :fechaInicio AND :fechaHasta) ");
		queryVentasBolsin.append("AND s.cla_tipsolic in ('E') AND s.cla_estado in ('5') ");
		queryVentasBolsin.append("AND sol.cla_entidad = 'SF' ");
		queryVentasBolsin.append("GROUP BY 1,2 ");
		
		
		
		
		//Armamos el query para compras
		queryCompras.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryCompras.append("0 as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryCompras.append("SUM(se.est_montous) AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryCompras.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryCompras.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryCompras.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryCompras.append("AND se.cla_operacion IN ('CSF') ");
		queryCompras.append("AND se.cla_estado = 'D' ");
		queryCompras.append("GROUP BY 1,2 ");
		
		// Armamos el query al exterior
		queryAlExterior.append("SELECT s.sol_codigo, sol.sol_persona,0 AS m_venta_dia, 0 AS m_ventas_bolsin,0 AS m_compras, ");
		queryAlExterior.append("SUM(s.soc_montome) AS m_al_exterior, 0 AS m_del_exterior ");
		queryAlExterior.append("FROM soc_solicitudes s, soc_operaciones o, soc_solicitante sol ");
		queryAlExterior.append("WHERE s.soc_codigo = o.soc_codigo ");
		queryAlExterior.append("AND s.sol_codigo = sol.sol_codigo ");
		queryAlExterior.append("AND s.cla_tipo = 'TE' AND sol.cla_entidad = 'SF' ");
		queryAlExterior.append("AND EXISTS ( SELECT * FROM soc_comprobante c ");
		queryAlExterior.append("WHERE c.ope_codigo = o.ope_codigo ");
		queryAlExterior.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		queryAlExterior.append("AND c.cve_estadocpb = 'C') ");
		queryAlExterior.append("GROUP BY 1,2 ");
		
		
		//Armamos el query del exterior
		queryDelExterior.append("SELECT t.sol_codigo, t.sol_persona, SUM(t.m_venta_dia) as m_venta_dia, ");
		queryDelExterior.append("SUM(t.m_ventas_bolsin) as m_ventas_bolsin, SUM(t.m_compras) as m_compras, ");
		queryDelExterior.append("SUM(t.m_al_exterior) as m_al_exterior, SUM(t.m_del_exterior) as m_del_exterior  FROM (");
		queryDelExterior.append("SELECT sol.sol_codigo, sol.sol_persona, 0 AS m_venta_dia, ");
		queryDelExterior.append("0 AS m_ventas_bolsin,0 AS m_compras, 0 AS m_al_exterior, ");
		queryDelExterior.append("SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		queryDelExterior.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryDelExterior.append("AND oc.cla_comision = 'TOTALPROV'),0), ");
		queryDelExterior.append("(SELECT oc.cod_moneda from soc_opecomi oc ");
		queryDelExterior.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryDelExterior.append("AND oc.cla_comision = 'TOTALPROV'), '34',");
		queryDelExterior.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		queryDelExterior.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		queryDelExterior.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS m_del_exterior ");
		queryDelExterior.append("FROM soc_solicitudes s,  soc_solicitante sol, soc_detallessol ds ");
		queryDelExterior.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryDelExterior.append("AND s.soc_codigo = ds.soc_codigo ");
		queryDelExterior.append("AND ds.tipo_concepto = 'BCO' ");
		queryDelExterior.append("AND s.sol_codigo = sol.sol_codigo AND sol.cla_entidad = 'SF' ");
		queryDelExterior.append("AND s.cla_tipo IN ('TD','RGAC') ");
		queryDelExterior.append("AND s.fecha_cont BETWEEN :fechaInicio AND :fechaHasta ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2 ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		queryDelExterior.append(union);
		queryDelExterior.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryDelExterior.append("0 as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryDelExterior.append("0 AS m_compras, 0 AS m_al_exterior, SUM(se.est_montous) AS m_del_exterior ");
		queryDelExterior.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryDelExterior.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryDelExterior.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryDelExterior.append("AND se.cla_operacion IN ('OTE') ");
		queryDelExterior.append("AND se.cla_estado = 'D' ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2) t ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2 ");
		
		// Armamos todo el query
		
		queryFinal.append("SELECT * FROM (");
		queryFinal.append(queryVentasDia).append(union);
		queryFinal.append(queryVentasBolsin).append(union);
		queryFinal.append(queryCompras).append(union);
		queryFinal.append(queryAlExterior).append(union);
		queryFinal.append(queryDelExterior).append(") AS t ");
		queryFinal.append("ORDER BY 2");
				
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(queryFinal.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
		OperacionesCambiarias cambiarias = null;		
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "sol_codigo,sol_persona,m_venta_dia,m_ventas_bolsin,m_compras,m_al_exterior,m_del_exterior".split(","));
		
		
		Map<String, OperacionesCambiarias> resultadoSolicitantes = new HashMap<String, OperacionesCambiarias>();
		BigDecimal montoValidador = BigDecimal.ZERO;
		BigDecimal ventaDia = null;
		BigDecimal ventasBolsin = null;
		BigDecimal compras = null;
		BigDecimal alExterior = null;
		BigDecimal delExterior = null;
		String solCodigo = "";
		
		for (Map<String, Object> res : resultadoQuery) {
			
			ventaDia = new BigDecimal(res.get("m_venta_dia") == null? "0": res.get("m_venta_dia").toString());
			ventasBolsin = new BigDecimal(res.get("m_ventas_bolsin") == null? "0": res.get("m_ventas_bolsin").toString());
			compras = new BigDecimal(res.get("m_compras") == null ? "0":res.get("m_compras").toString());
			alExterior = new BigDecimal(res.get("m_al_exterior") == null? "0" :res.get("m_al_exterior").toString());
			delExterior = new BigDecimal(res.get("m_del_exterior") == null? "0":res.get("m_del_exterior").toString());
			solCodigo = ((String)res.get("sol_codigo")).trim();
			
			if (resultadoSolicitantes.containsKey(solCodigo)) {
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = resultadoSolicitantes.get(solCodigo);
				
				cambiarias.setVentasDia(cambiarias.getVentasDia().add(ventaDia));
				cambiarias.setVentasBolsin(cambiarias.getVentasBolsin().add(ventasBolsin));
				cambiarias.setCompras(cambiarias.getCompras().add(compras));
				cambiarias.setAlExterior(cambiarias.getAlExterior().add(alExterior));
				cambiarias.setDelExterior(cambiarias.getDelExterior().add(delExterior));
				
				if(montoValidador.compareTo(BigDecimal.ZERO) == 0){
					resultadoSolicitantes.remove(solCodigo);
				}

			} else {
				montoValidador = BigDecimal.ZERO;
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = new OperacionesCambiarias();
				cambiarias.setCodInstitucion(solCodigo);
				cambiarias.setInstitucion((String) res.get("sol_persona"));
				cambiarias.setVentasDia(ventaDia.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setVentasBolsin(ventasBolsin.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setCompras(compras.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setAlExterior(alExterior.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setDelExterior(delExterior.setScale(0, BigDecimal.ROUND_HALF_UP));
				if (montoValidador.compareTo(BigDecimal.ZERO) > 0 ){
					resultadoSolicitantes.put(solCodigo,cambiarias);	
				} 
				
			}
		}
		
		
		//Obtenemos la coleccion final
		resultado = new ArrayList<OperacionesCambiarias>(resultadoSolicitantes.values());
		Comparator<OperacionesCambiarias> comparator = new Comparator<OperacionesCambiarias>() {
			
			public int compare(OperacionesCambiarias o1, OperacionesCambiarias o2) {
				return o1.getInstitucion().compareTo(o2.getInstitucion());
			}
		};
		
		java.util.Collections.sort(resultado,comparator);
		
		return resultado;
		
	}
	
	public List<OperacionesCambiarias> obtenerInsitutcionOpeCambiariasCliSisFinanciero(Date fechaInicio, Date fechaFin){

		List<OperacionesCambiarias> resultado = new ArrayList<OperacionesCambiarias>();
		// Obtenemos las entidades Por JDBC
		StringBuffer queryVentasDia = new StringBuffer();
		StringBuffer queryVentasBolsin = new StringBuffer();
		StringBuffer queryCompras = new StringBuffer();
		StringBuffer queryAlExterior = new StringBuffer();
		StringBuffer queryDelExterior = new StringBuffer();
		StringBuffer queryFinal = new StringBuffer();
		String union = "UNION ";
		
		
		//Armamos el query para ventas en el dia
		queryVentasDia.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryVentasDia.append("SUM(s.montosol) AS m_venta_dia, ");
		queryVentasDia.append("0 AS m_ventas_bolsin, 0 AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryVentasDia.append("FROM soc_bolsin s, soc_solicitante sol ");
		queryVentasDia.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryVentasDia.append("AND s.cla_tipsolic in ('GD') ");
		queryVentasDia.append("AND s.cla_estado in ('5') ");
		queryVentasDia.append("AND sol.cla_entidad = 'SF' ");
		queryVentasDia.append("AND s.fecha BETWEEN :fechaInicio AND :fechaHasta ");
		queryVentasDia.append("GROUP BY 1,2 ");
		
		//Armamos el query para ventas bolsin
		queryVentasBolsin.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryVentasBolsin.append("0 as m_venta_dia, SUM(s.montosol) as m_ventas_bolsin, "); 
		queryVentasBolsin.append("0 AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryVentasBolsin.append("FROM soc_bolsin s, soc_solicitante sol ");
		queryVentasBolsin.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryVentasBolsin.append("AND s.soc_codigo IN ( SELECT sc.ope_codigo FROM ( ");
		queryVentasBolsin.append("SELECT c.ope_codigo, MAX(mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion)) AS fecha ");
		queryVentasBolsin.append("FROM soc_comprobante c WHERE c.ope_codigo= s.soc_codigo ");
		queryVentasBolsin.append("AND c.cpb_nrocpbte IS NOT NULL GROUP BY 1) AS sc  ");
		queryVentasBolsin.append("WHERE sc.fecha BETWEEN :fechaInicio AND :fechaHasta) ");
		queryVentasBolsin.append("AND s.cla_tipsolic in ('G') AND s.cla_estado in ('5') ");
		queryVentasBolsin.append("AND sol.cla_entidad = 'SF' ");
		queryVentasBolsin.append("GROUP BY 1,2 ");
		
		
		
		
		//Armamos el query para compras NO EXISTE
		
		// Armamos el query al exterior NO EXISTE
		
		
		//Armamos el query del exterior NO EXISTE
		
		// Armamos todo el query
		
		queryFinal.append("SELECT * FROM (");
		queryFinal.append(queryVentasDia).append(union);
		queryFinal.append(queryVentasBolsin).append(") AS t ");
		queryFinal.append("ORDER BY 2");
				
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(queryFinal.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
		OperacionesCambiarias cambiarias = null;		
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "sol_codigo,sol_persona,m_venta_dia,m_ventas_bolsin,m_compras,m_al_exterior,m_del_exterior".split(","));
		
		
		Map<String, OperacionesCambiarias> resultadoSolicitantes = new HashMap<String, OperacionesCambiarias>();
		BigDecimal montoValidador = BigDecimal.ZERO;
		BigDecimal ventaDia = null;
		BigDecimal ventasBolsin = null;
		BigDecimal compras = null;
		BigDecimal alExterior = null;
		BigDecimal delExterior = null;
		String solCodigo = "";
		
		
		for (Map<String, Object> res : resultadoQuery) {
			
			ventaDia = new BigDecimal(res.get("m_venta_dia") == null? "0": res.get("m_venta_dia").toString());
			ventasBolsin = new BigDecimal(res.get("m_ventas_bolsin") == null? "0": res.get("m_ventas_bolsin").toString());
			compras = new BigDecimal(res.get("m_compras") == null ? "0":res.get("m_compras").toString());
			alExterior = new BigDecimal(res.get("m_al_exterior") == null? "0" :res.get("m_al_exterior").toString());
			delExterior = new BigDecimal(res.get("m_del_exterior") == null? "0":res.get("m_del_exterior").toString());
			solCodigo = ((String)res.get("sol_codigo")).trim();
			
			if (resultadoSolicitantes.containsKey(solCodigo)) {
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = resultadoSolicitantes.get(solCodigo);
				
				cambiarias.setVentasDia(cambiarias.getVentasDia().add(ventaDia));
				cambiarias.setVentasBolsin(cambiarias.getVentasBolsin().add(ventasBolsin));
				cambiarias.setCompras(cambiarias.getCompras().add(compras));
				cambiarias.setAlExterior(cambiarias.getAlExterior().add(alExterior));
				cambiarias.setDelExterior(cambiarias.getDelExterior().add(delExterior));

			} else {
				montoValidador = BigDecimal.ZERO;
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = new OperacionesCambiarias();
				cambiarias.setCodInstitucion(solCodigo);
				cambiarias.setInstitucion((String) res.get("sol_persona"));
				cambiarias.setVentasDia(ventaDia.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setVentasBolsin(ventasBolsin.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setCompras(compras.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setAlExterior(alExterior.setScale(0, BigDecimal.ROUND_HALF_UP));
				cambiarias.setDelExterior(delExterior.setScale(0, BigDecimal.ROUND_HALF_UP));
				if (montoValidador.compareTo(BigDecimal.ZERO) > 0 ){
					resultadoSolicitantes.put(solCodigo,cambiarias);	
				}
				
			}			
			
		}
		
		
		resultado = new ArrayList<OperacionesCambiarias>(resultadoSolicitantes.values());
		Comparator<OperacionesCambiarias> comparator = new Comparator<OperacionesCambiarias>() {
			
			public int compare(OperacionesCambiarias o1, OperacionesCambiarias o2) {
				return o1.getInstitucion().compareTo(o2.getInstitucion());
			}
		};
		
		java.util.Collections.sort(resultado,comparator);				
		return resultado;
		
	}
	
	
	
	public List<OperacionesCambiarias> obtenerInsitutcionOpeCambiariasOtros(Date fechaInicio, Date fechaFin){

		List<OperacionesCambiarias> resultado = new ArrayList<OperacionesCambiarias>();
		// Obtenemos las entidades Por JDBC
		StringBuffer queryVentasDia = new StringBuffer();
		StringBuffer queryVentasBolsin = new StringBuffer();
		StringBuffer queryCompras = new StringBuffer();
		StringBuffer queryAlExterior = new StringBuffer();
		StringBuffer queryDelExterior = new StringBuffer();
		StringBuffer queryFinal = new StringBuffer();
				
				
		// Armamos query para compras (Otros)
		
		queryCompras.append("SELECT q.sol_codigo, q.sol_persona, SUM(q.m_venta_dia) as m_venta_dia,");
		queryCompras.append("SUM(q.m_ventas_bolsin) as m_ventas_bolsin,  SUM(q.m_compras) AS m_compras, ");
		queryCompras.append("SUM(q.m_al_exterior) AS m_al_exterior, ");
		queryCompras.append("SUM(q.m_del_exterior) AS m_del_exterior FROM ( ");
		queryCompras.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryCompras.append("0 as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryCompras.append("SUM(se.est_montous) AS m_compras, 0 AS m_al_exterior, 0 AS m_del_exterior ");
		queryCompras.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryCompras.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryCompras.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryCompras.append("AND se.cla_operacion IN ('OO2','OO4') ");
		queryCompras.append("AND se.cla_estado = 'D' ");
		queryCompras.append("GROUP BY 1,2 ");
		queryCompras.append("ORDER BY 2 ");
		queryCompras.append("UNION ");
		queryCompras.append("SELECT se.sol_codigo, se.sol_codigo AS sol_persona, ");
		queryCompras.append("0 as m_venta_dia, 0 as m_ventas_bolsin,  ");
		queryCompras.append("SUM(se.est_montous) AS m_compras, 0 AS m_al_exterior, 0 m_del_exterior ");
		queryCompras.append("FROM d_siocw.soc_estadistica se ");
		queryCompras.append("WHERE DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryCompras.append("AND se.sol_codigo = 'Otros' AND se.cla_estado = 'D' ");
		queryCompras.append("AND se.cla_operacion IN ('OO2','OO4') ");
		queryCompras.append("GROUP BY 1,2 ");
		queryCompras.append("ORDER BY 2) q ");
		queryCompras.append("GROUP BY 1,2 ");
		queryCompras.append("ORDER BY 2 ");
		
		
		
		//Armamos el query para transferencias del exterior no existe
		
		
		//Armamos el query del exterior
		queryDelExterior.append("SELECT t.sol_codigo, t.sol_persona, SUM(t.m_venta_dia) as m_venta_dia, ");
		queryDelExterior.append("SUM(t.m_ventas_bolsin) as m_ventas_bolsin, SUM(t.m_compras) as m_compras, ");
		queryDelExterior.append("SUM(t.m_al_exterior) as m_al_exterior, SUM(t.m_del_exterior) as m_del_exterior  FROM (");
		queryDelExterior.append("SELECT sol.sol_codigo, sol.sol_persona, 0 AS m_venta_dia, ");
		queryDelExterior.append("0 AS m_ventas_bolsin,0 AS m_compras, 0 AS m_al_exterior, ");
		queryDelExterior.append("SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		queryDelExterior.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryDelExterior.append("AND oc.cla_comision = 'TOTALPROV'),0), ");
		queryDelExterior.append("(SELECT oc.cod_moneda from soc_opecomi oc ");
		queryDelExterior.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		queryDelExterior.append("AND oc.cla_comision = 'TOTALPROV'), '34',");
		queryDelExterior.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		queryDelExterior.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		queryDelExterior.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS m_del_exterior ");
		queryDelExterior.append("FROM soc_solicitudes s,  soc_solicitante sol, soc_detallessol ds ");
		queryDelExterior.append("WHERE s.sol_codigo = sol.sol_codigo ");
		queryDelExterior.append("AND s.soc_codigo = ds.soc_codigo ");
		queryDelExterior.append("AND (ds.tipo_concepto <> 'BCO' OR ds.tipo_concepto IS NULL) ");
		queryDelExterior.append("AND s.sol_codigo = sol.sol_codigo AND sol.cla_entidad = 'SF' ");
		queryDelExterior.append("AND s.cla_tipo IN ('TD','RGAC') ");
		queryDelExterior.append("AND s.fecha_cont BETWEEN :fechaInicio AND :fechaHasta ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2 ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		queryDelExterior.append("UNION ");
		queryDelExterior.append("SELECT q.sol_codigo, q.sol_persona, SUM(q.m_venta_dia) as m_venta_dia,");
		queryDelExterior.append("SUM(q.m_ventas_bolsin) as m_ventas_bolsin,  SUM(q.m_compras) AS m_compras, ");
		queryDelExterior.append("SUM(q.m_al_exterior) AS m_al_exterior, ");
		queryDelExterior.append("SUM(q.m_del_exterior) AS m_del_exterior FROM ( ");
		queryDelExterior.append("SELECT sol.sol_codigo, sol.sol_persona, ");
		queryDelExterior.append("0 as m_venta_dia, 0 as m_ventas_bolsin, "); 
		queryDelExterior.append("0 AS m_compras, 0 AS m_al_exterior, SUM(se.est_montous) AS m_del_exterior ");
		queryDelExterior.append("FROM soc_estadistica se, soc_solicitante sol ");
		queryDelExterior.append("WHERE se.sol_codigo = sol.sol_codigo ");
		queryDelExterior.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryDelExterior.append("AND se.cla_operacion LIKE ('%OO%') ");
		queryDelExterior.append("AND se.cla_estado = 'D' ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2 ");
		queryDelExterior.append("UNION ");
		queryDelExterior.append("SELECT se.sol_codigo, se.sol_codigo AS sol_persona, ");
		queryDelExterior.append("0 as m_venta_dia, 0 as m_ventas_bolsin,  ");
		queryDelExterior.append("0 AS m_compras, 0 AS m_al_exterior, SUM(se.est_montous) AS m_del_exterior ");
		queryDelExterior.append("FROM d_siocw.soc_estadistica se ");
		queryDelExterior.append("WHERE DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		queryDelExterior.append("AND se.sol_codigo = 'Otros' AND se.cla_estado = 'D' ");
		queryDelExterior.append("AND se.cla_operacion LIKE ('%OO%') ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2) q ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2) t ");
		queryDelExterior.append("GROUP BY 1,2 ");
		queryDelExterior.append("ORDER BY 2 ");
		
					
		// Armamos todo el query
		
		queryFinal.append("SELECT * FROM (");
		queryFinal.append(queryCompras).append("UNION ");
		queryFinal.append(queryDelExterior).append(") AS t ");
		queryFinal.append("ORDER BY 2");
				
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(queryFinal.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
		OperacionesCambiarias cambiarias = null;		
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "sol_codigo,sol_persona,m_venta_dia,m_ventas_bolsin,m_compras,m_al_exterior,m_del_exterior".split(","));
		
		
		Map<String, OperacionesCambiarias> resultadoSolicitantes = new HashMap<String, OperacionesCambiarias>();
		BigDecimal montoValidador = BigDecimal.ZERO;
		BigDecimal ventaDia = null;
		BigDecimal ventasBolsin = null;
		BigDecimal compras = null;
		BigDecimal alExterior = null;
		BigDecimal delExterior = null;
		String solCodigo = "";
		
		
		for (Map<String, Object> res : resultadoQuery) {
			
			ventaDia = new BigDecimal(res.get("m_venta_dia") == null? "0": res.get("m_venta_dia").toString());
			ventasBolsin = new BigDecimal(res.get("m_ventas_bolsin") == null? "0": res.get("m_ventas_bolsin").toString());
			compras = new BigDecimal(res.get("m_compras") == null ? "0":res.get("m_compras").toString());
			alExterior = new BigDecimal(res.get("m_al_exterior") == null? "0" :res.get("m_al_exterior").toString());
			delExterior = new BigDecimal(res.get("m_del_exterior") == null? "0":res.get("m_del_exterior").toString());
			solCodigo = ((String)res.get("sol_codigo")).trim();
			if (resultadoSolicitantes.containsKey(solCodigo)) {
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = resultadoSolicitantes.get(solCodigo);
				
				cambiarias.setVentasDia(cambiarias.getVentasDia().add(ventaDia));
				cambiarias.setVentasBolsin(cambiarias.getVentasBolsin().add(ventasBolsin));
				cambiarias.setCompras(cambiarias.getCompras().add(compras));
				cambiarias.setAlExterior(cambiarias.getAlExterior().add(alExterior));
				cambiarias.setDelExterior(cambiarias.getDelExterior().add(delExterior));
				
				if(montoValidador.compareTo(BigDecimal.ZERO) == 0){
					resultadoSolicitantes.remove(solCodigo);
				}

			} else {
				montoValidador = BigDecimal.ZERO;
				montoValidador = montoValidador.add(ventaDia).add(ventasBolsin).add(compras).add(alExterior).add(delExterior);
				cambiarias = new OperacionesCambiarias();
				cambiarias.setCodInstitucion(solCodigo);
				cambiarias.setInstitucion((String) res.get("sol_persona"));
				cambiarias.setVentasDia(ventaDia);
				cambiarias.setVentasBolsin(ventasBolsin);
				cambiarias.setCompras(compras);
				cambiarias.setAlExterior(alExterior);
				cambiarias.setDelExterior(delExterior);
				if (montoValidador.compareTo(BigDecimal.ZERO) > 0 || montoValidador.signum() == -1){
					resultadoSolicitantes.put(solCodigo,cambiarias);	
				}
				
			}
			
		}
		
		
		//Obtenemos la coleccion final
		resultado = new ArrayList<OperacionesCambiarias>(resultadoSolicitantes.values());				
		return resultado;
		
	}
	
	
	public BigDecimal obtenerMontoBolSisFin(String fechaInicio, String fechaFin){

		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
				
		
		//Armamos el query para ventas en el dia para el sistema financiero
								
		query.append("SELECT SUM(b.montoadj) as monto "); 
		query.append("FROM soc_bolsin b, soc_solicitante sol ");
		query.append("WHERE b.sol_codigo = sol.sol_codigo ");
		query.append("AND b.soc_codigo IN( ");
		query.append("SELECT sc.ope_codigo FROM ( ");
		query.append("SELECT c.ope_codigo, MAX(mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion)) AS fecha ");
		query.append("FROM soc_comprobante c WHERE c.ope_codigo= b.soc_codigo ");
		query.append("AND c.cpb_nrocpbte IS NOT NULL GROUP BY 1) AS sc ");
		query.append("WHERE sc.fecha BETWEEN :fechaInicio AND :fechaHasta) ");
		query.append("AND b.cla_tipsolic in ('E') ");
		query.append("AND b.cla_estado in ('5') ");
		query.append("AND sol.cla_entidad = 'SF' ");
		
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
				
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));
					
		BigDecimal monto = null;
			
				
		for (Map<String, Object> res : resultadoQuery) {
			
			if(res.get("monto") == null){
				monto = new BigDecimal("0");
			} else{
				monto = new BigDecimal(res.get("monto").toString());	
			}	
			
		}
						
		return monto;
		
	}
	
	public BigDecimal obtenerMontoVentDiaSisFin(String fechaInicio, String fechaFin){

		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
				
		
		//Armamos el query para ventas en el dia para el sistema financiero
		
						
		query.append("SELECT SUM(b.montoadj) AS monto "); 
		query.append("FROM soc_bolsin b, soc_solicitante sol ");
		query.append("WHERE b.sol_codigo = sol.sol_codigo ");
		query.append("AND b.cla_tipsolic IN ('ED') ");		
		query.append("AND b.cla_estado IN ('5') ");
		query.append("AND b.fecha BETWEEN :fechaInicio AND :fechaHasta ");		
		query.append("AND sol.cla_entidad = 'SF' ");	
		
				
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
				
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));
					
		BigDecimal monto = null;
			
				
		for (Map<String, Object> res : resultadoQuery) {
			
			if(res.get("monto") == null){
				monto = new BigDecimal("0");
			} else{
				monto = new BigDecimal(res.get("monto").toString());	
			}
			
		}
						
		return monto;
		
	}
	
	
	
	public BigDecimal obtenerMontoBolCliSisFin(String fechaInicio, String fechaFin){
		
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		
				
		query.append("SELECT  SUM(b.montoadj) as monto "); 
		query.append("FROM soc_bolsin b, soc_solicitante sol ");
		query.append("WHERE b.sol_codigo = sol.sol_codigo ");
		query.append("AND b.soc_codigo IN( ");
		query.append("SELECT sc.ope_codigo FROM ( ");
		query.append("SELECT c.ope_codigo, MAX(mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion)) AS fecha ");
		query.append("FROM soc_comprobante c WHERE c.ope_codigo= b.soc_codigo ");
		query.append("AND c.cpb_nrocpbte IS NOT NULL GROUP BY 1) AS sc ");
		query.append("WHERE sc.fecha BETWEEN :fechaInicio AND :fechaHasta) ");
		query.append("AND b.cla_tipsolic in ('G') ");
		query.append("AND b.cla_estado in ('5') ");
		query.append("AND sol.cla_entidad = 'SF' ");
				
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
				
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));
					
		BigDecimal monto = null;
			
				
		for (Map<String, Object> res : resultadoQuery) {
			
			if(res.get("monto") == null){
				monto = new BigDecimal("0");
			} else{
				monto = new BigDecimal(res.get("monto").toString());	
			}
			
		}
						
		return monto;		
		
	}
	
	
public BigDecimal obtenerMontoVentDiaCliSisFin(String fechaInicio, String fechaFin){
		
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		
		query.append("SELECT SUM(b.montoadj) as monto ");
		query.append("FROM soc_bolsin b, soc_solicitante sol ");
		query.append("WHERE b.sol_codigo = sol.sol_codigo ");		
		query.append("AND b.cla_tipsolic = 'GD' ");
		query.append("AND b.cla_estado = '5' ");		
		query.append("AND b.fecha BETWEEN :fechaInicio AND :fechaHasta ");		
		query.append("AND sol.cla_entidad = 'SF' ");
				
				
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
				
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));
					
		BigDecimal monto = null;
			
				
		for (Map<String, Object> res : resultadoQuery) {
			
			if(res.get("monto") == null){
				monto = new BigDecimal("0");
			} else{
				monto = new BigDecimal(res.get("monto").toString());	
			}
			
		}
						
		return monto;		
		
	}


	public BigDecimal obtenerMontoSecPublico(String fechaInicio, String fechaFin){
		
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		
		//Armamos el query para ventas en el dia
		query.append("SELECT SUM(t.monto) AS monto FROM ( "); 
		query.append("SELECT SUM(nvl((SELECT SUM(oc.monto_mo) FROM soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_comision = 'VENTAUSD'),0)) AS monto ");
		query.append("FROM soc_solicitudes s, soc_solicitante sol ");
		query.append("WHERE s.sol_codigo = sol.sol_codigo ");
		query.append("AND sol.cla_entidad = 'SP' ");
		query.append("AND s.soc_codigo IN(SELECT c.ope_codigo FROM soc_comprobante c ");
		query.append("WHERE mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND c.ope_codigo = s.soc_codigo AND c.cve_dettipocomp != 'O' ");
		query.append("AND c.cpb_nrocpbte IS NOT NULL AND c.esq_codigo <> '301') ");
		query.append("AND s.cla_estado IN ('C') ");
		query.append("AND EXISTS ( SELECT * FROM soc_opecomi oc WHERE s.soc_codigo = oc.ope_codigo ");
		query.append("AND oc.cla_comision = 'MONTODIFCAMBVENDIV' AND oc.cla_estadovar = 'C') ");
		query.append("UNION ");
		query.append("SELECT SUM(se.est_montous) as monto ");
		query.append("FROM soc_estadistica se, soc_solicitante sol ");
		query.append("WHERE se.sol_codigo = sol.sol_codigo ");
		query.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND se.cla_operacion IN ('VED', 'VTE') ");
		query.append("AND se.cla_estado = 'D') t  ");
				
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
				
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));
					
		BigDecimal monto = null;
			
				
		for (Map<String, Object> res : resultadoQuery) {
			
			if(res.get("monto") == null){
				monto = new BigDecimal("0");
			} else{
				monto = new BigDecimal(res.get("monto").toString());	
			}
			
		}
						
		return monto;	
		
	}
	
	public BigDecimal obtenerMontoOtros(String fechaInicio, String fechaFin){
		
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		
		
		
		//Armamos el query para otros
		query.append("SELECT SUM(t.monto) as monto FROM (");
		query.append("SELECT SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		query.append("AND oc.cla_comision = 'TOTALPROV'),0), ");
		query.append("(SELECT oc.cod_moneda from soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		query.append("AND oc.cla_comision = 'TOTALPROV'), '34',");
		query.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		query.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		query.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS monto ");
		query.append("FROM soc_solicitudes s,  soc_solicitante sol, soc_detallessol ds ");
		query.append("WHERE s.sol_codigo = sol.sol_codigo ");
		query.append("AND s.soc_codigo = ds.soc_codigo ");
		query.append("AND (ds.tipo_concepto <> 'BCO' OR ds.tipo_concepto IS NULL) ");
		query.append("AND s.sol_codigo = sol.sol_codigo AND sol.cla_entidad = 'SF' ");
		query.append("AND s.cla_tipo IN ('TD','RGAC') ");
		query.append("AND s.fecha_cont BETWEEN :fechaInicio AND :fechaHasta ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		query.append("UNION ");
		query.append("SELECT SUM(se.est_montous) AS monto ");
		query.append("FROM soc_estadistica se ");
		query.append("WHERE DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND se.cla_operacion LIKE ('%OO%') ");
		query.append("AND se.cla_estado = 'D') t  ");
			
		
						
		//AÃƒÂ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
				
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));
					
		BigDecimal monto = null;
			
				
		for (Map<String, Object> res : resultadoQuery) {
			
			if(res.get("monto") == null){
				monto = new BigDecimal("0");
			} else{
				monto = new BigDecimal(res.get("monto").toString());	
			}
			
		}
						
		return monto;	
		
		
	}
	
	
	public BigDecimal obtenerMontoComprasSectorPublico(String fechaInicio, String fechaFin){
		BigDecimal monto = new BigDecimal("0");
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		//Armamos el query para compras Sector PÃºblico
		query.append("SELECT SUM(t.monto) AS monto  FROM ( ");
		query.append("SELECT SUM(s.soc_montome) AS monto FROM soc_solicitudes s, soc_solicitante sol ");
		query.append("WHERE s.sol_codigo = sol.sol_codigo AND s.cve_subtipooper = 'TC' ");
		query.append("AND sol.cla_entidad = 'SP' AND EXISTS ( SELECT * FROM soc_comprobante c ");
		query.append("WHERE s.soc_codigo = c.ope_codigo AND c.cve_dettipocomp = 'P' ");
		query.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND c.cve_estadocpb = 'C') AND EXISTS( SELECT * FROM soc_solicitudctas sc ");
		query.append("WHERE s.soc_codigo = sc.soc_codigo AND sc.tipo_cuenta = 'MOVPROVISION' ");
		query.append("AND sc.cod_moneda = 34) AND EXISTS( SELECT * FROM soc_opecomi oc ");
		query.append("WHERE s.soc_codigo = oc.ope_codigo AND oc.cla_comision = 'MONTOD' ");
		query.append("AND oc.cod_moneda = 69 AND oc.cla_estadovar = 'C') ");
		query.append("UNION ");
		query.append("SELECT SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		query.append("AND oc.cla_comision = 'TOTALPROV'),0), (SELECT oc.cod_moneda from soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C'  ");
		query.append("AND oc.cla_comision = 'TOTALPROV'),'34',(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) ");
		query.append("FROM soc_comprobante c0 WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		query.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS monto ");
		query.append("FROM soc_solicitudes s,  soc_solicitante sol WHERE s.sol_codigo = sol.sol_codigo ");
		query.append("AND s.cod_moneda <> s.cod_monedat ");
		query.append("AND s.cla_tipo IN ('TD','RGAC') AND sol.cla_entidad = 'SP' ");
		query.append("AND EXISTS ( SELECT * FROM soc_comprobante c WHERE s.soc_codigo = c.ope_codigo ");
		query.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND c.cve_estadocpb = 'C') ");
		query.append("UNION ");
		query.append("SELECT SUM(se.est_montous) AS monto FROM soc_estadistica se, soc_solicitante sol ");
		query.append("WHERE se.sol_codigo = sol.sol_codigo AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND se.cla_operacion IN ('TRL' , 'CTE') AND se.cla_estado = 'D')t ");
				
		// AÃ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);

		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}

		return monto;		
		
		
	}
	
	public BigDecimal obtenerMontoTransDelExteriorSecPub(String fechaInicio, String fechaFin){
		BigDecimal monto = new BigDecimal("0");
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();

		//Armamos el query del exterior al sector publico
		query.append("SELECT SUM(t.monto) as monto FROM ( ");
		query.append("SELECT SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		query.append("AND oc.cla_comision = 'TOTALPROV'),0), ");
		query.append("(SELECT oc.cod_moneda from soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		query.append("AND oc.cla_comision = 'TOTALPROV'), '34',");
		query.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		query.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		query.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS monto ");
		query.append("FROM soc_solicitudes s,  soc_solicitante sol ");
		query.append("WHERE s.sol_codigo = sol.sol_codigo ");
		query.append("AND s.cla_tipo IN ('TD','RGAC') AND sol.cla_entidad = 'SP' ");
		query.append("AND EXISTS ( SELECT * FROM soc_comprobante c ");
		query.append("WHERE s.soc_codigo = c.ope_codigo ");
		query.append("AND c.cve_dettipocomp = 'P' ");
		query.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND c.cve_estadocpb = 'C') ");
		query.append("UNION ");
		query.append("SELECT SUM(se.est_montous) AS monto FROM soc_estadistica se, soc_solicitante sol ");
		query.append("WHERE se.sol_codigo = sol.sol_codigo AND se.cla_operacion IN ('TDE' ,'CTE') ");
		query.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND se.cla_estado = 'D') t  ");
		
		// AÃ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);

		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		
		return monto;
	}
	
	
	public BigDecimal obtenerMontoTransDelExteriorSisFin(String fechaInicio, String fechaFin){
		BigDecimal monto = new BigDecimal("0");
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		
		
		//Armamos el query del exterior
		query.append("SELECT SUM(t.monto) as monto FROM (");
		query.append("SELECT SUM(f_conversion(nvl((SELECT oc.monto_mo FROM soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		query.append("AND oc.cla_comision = 'TOTALPROV'),0), ");
		query.append("(SELECT oc.cod_moneda from soc_opecomi oc ");
		query.append("WHERE oc.ope_codigo = s.soc_codigo AND oc.cla_estadovar = 'C' ");
		query.append("AND oc.cla_comision = 'TOTALPROV'), '34',");
		query.append("(SELECT MAX(mdy(c0.cpb_periodo, c0.cpb_dia, c0.cpb_gestion)) FROM soc_comprobante c0 ");
		query.append("WHERE s.soc_codigo = c0.ope_codigo AND c0.cve_dettipocomp = 'P' ");
		query.append("AND c0.cve_estadocpb = 'C'),0,'MONTO')) AS monto ");
		query.append("FROM soc_solicitudes s,  soc_solicitante sol, soc_detallessol ds ");
		query.append("WHERE s.sol_codigo = sol.sol_codigo ");
		query.append("AND s.soc_codigo = ds.soc_codigo ");
		query.append("AND s.sol_codigo = sol.sol_codigo AND sol.cla_entidad = 'SF' ");
		query.append("AND s.cla_tipo IN ('TD','RGAC')  AND ds.tipo_concepto = 'BCO' ");
		query.append("AND s.fecha_cont BETWEEN :fechaInicio AND :fechaHasta ");
		
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		query.append("UNION ");
		query.append("SELECT SUM(se.est_montous) AS monto ");
		query.append("FROM soc_estadistica se, soc_solicitante sol ");
		query.append("WHERE se.sol_codigo = sol.sol_codigo ");
		query.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND se.cla_operacion IN ('OTE') ");
		query.append("AND se.cla_estado = 'D' ) t ");
			
		
//		query.append("SELECT SUM(s.est_montous) AS monto ");
//		query.append("FROM soc_estadistica s, soc_solicitante sol ");
//		query.append("WHERE s.sol_codigo = sol.sol_codigo ");
//		query.append("AND s.cla_operacion = 'OTE' AND s.cla_estado = 'D' ");
//		query.append("AND DATE(s.fecha_hora) BETWEEN :fechaInicio AND :fechaHasta ");
		// AÃ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);

		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		return monto;
	}
	
	public BigDecimal obtenerMontoTransAlExteriorSecPub(String fechaInicio, String fechaFin){
		BigDecimal monto = new BigDecimal("0");
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		
		// Armamos el query al exterior
		
		
		query.append("SELECT SUM(t.monto) as monto FROM (");
		query.append("SELECT SUM(TOTTRANSMT) AS monto ");
		query.append("FROM ( SELECT fecha, s.soc_codigo, ");
		query.append("sol.sol_codigo, sol_persona,s.cod_monedat, ");
		query.append("nvl((SELECT SUM(oc.monto_mo) FROM soc_opecomi oc WHERE oc.ope_codigo = s.soc_codigo ");
		query.append("AND oc.cla_estadovar = 'C' AND oc.cla_comision = 'MONTOD'),0) TOTTRANSMT ");
//		query.append("( SELECT f.factor FROM vw_factor_conv_mn f ");
//		query.append("WHERE f.fecha_dia = s.fecha AND f.cod_moneda = 34 ) tc_usdcompra, ");
//		query.append("( SELECT f.factor FROM vw_factor_conv_mn f WHERE f.fecha_dia = fecha "); 
//		query.append("AND f.cod_moneda = s.cod_monedat ) tipo_cambiomo ");
		query.append("FROM soc_solicitudes s,  soc_solicitante sol ");
		query.append("WHERE s.sol_codigo = sol.sol_codigo AND s.cve_subtipooper = 'TE' ");
		query.append("AND sol.cla_entidad = 'SP' ");
		query.append("AND s.cla_estado = 'C'  ");
		query.append("AND s.fecha_cont BETWEEN :fechaInicio AND :fechaHasta) ");
		// Agregamos querys para los operaciones no registradas en el sioc para ventas en el dia
		query.append("UNION ");
		query.append("SELECT SUM(se.est_montous) AS monto ");
		query.append("FROM soc_estadistica se, soc_solicitante sol ");
		query.append("WHERE se.sol_codigo = sol.sol_codigo ");
		query.append("AND DATE(se.est_fecha) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND se.cla_operacion IN ('TAE' ,'VTE') ");
		query.append("AND se.cla_estado = 'D' ) t");
		
		
				
		// AÃ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);

		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		
		return monto;
	}
	
	
	public BigDecimal obtenerMontoTransAlExteriorSisFin(String fechaInicio, String fechaFin){
		BigDecimal monto = new BigDecimal("0");
		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();
		
		query.append("SELECT SUM(s.soc_montome) AS monto ");
		query.append("FROM soc_solicitudes s, soc_operaciones o, soc_solicitante sol ");
		query.append("WHERE s.soc_codigo = o.soc_codigo ");
		query.append("AND s.sol_codigo = sol.sol_codigo ");
		query.append("AND s.cla_tipo = 'TE' AND sol.cla_entidad = 'SF' ");
		query.append("AND EXISTS ( SELECT * FROM soc_comprobante c ");
		query.append("WHERE c.ope_codigo = o.ope_codigo ");
		query.append("AND mdy(c.cpb_periodo, c.cpb_dia,c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND c.cve_estadocpb = 'C') ");
		// AÃ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);

		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		
		return monto;
		
	}
	
	/**
	 * Obtiene una lista de las insituciones con movimiento para transferencias al exterior  
	 * @param fechaInicio Fecha de Inicio
	 * @param fechaFin Fecha de Fin
	 * @return Retorna una colección de instituciones financieras
	 */
	public List<OperacionesCambiarias> obtenerInstitucionesTransExterior(String fechaInicio, String fechaFin){
		List<OperacionesCambiarias> instituciones = new ArrayList<OperacionesCambiarias>();
		StringBuffer query = new StringBuffer();
		query.append("SELECT sol.sol_codigo, sol.sol_persona ");
		query.append("FROM soc_solicitudes s, soc_solicitante sol ");
		query.append("WHERE s.sol_codigo = sol.sol_codigo ");
		query.append("AND s.soc_codigo IN(  SELECT c.ope_codigo FROM soc_comprobante c ");
		query.append("WHERE mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta) ");
		query.append("AND sol.cla_entidad = 'SF' ");
		query.append("AND s.cla_tipo = 'TE' ");
		query.append("AND s.cla_estado = 'O' ");
		query.append("GROUP BY sol.sol_codigo, sol.sol_persona ");
		query.append("ORDER BY sol.sol_codigo ");
				// AÃ±adimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		List lista = consulta.list();
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "sol_codigo,sol_persona".split(","));
		
		OperacionesCambiarias institucion = new OperacionesCambiarias();
		for (Map<String, Object> res : resultadoQuery) {
			institucion = new OperacionesCambiarias();
			institucion.setCodInstitucion((String) res.get("sol_codigo"));
			institucion.setInstitucion((String) res.get("sol_persona"));
			instituciones.add(institucion);	
		}
		
			
		return instituciones;
	}
	
	/**
	 * Metodo que obitene el monto de una institucion para transferencias al exterior
	 * @param codInstitucion Codigo de la institución financiera
	 * @param fechaInicio Fecha de inicio
	 * @param fechaFin Fecha Fin
	 * @return returna el monto en un periodo de fecha de una institución
	 */
	public BigDecimal obtenerMontoInstitucionTransExteriorPorFecha(String codInstitucion, String fechaInicio, String fechaFin){
		BigDecimal monto = BigDecimal.ZERO;
		StringBuffer query = new StringBuffer();
		query.append("SELECT SUM(s.soc_montome) AS monto ");
		query.append("FROM soc_solicitudes s, soc_operaciones o, soc_solicitante sol  ");
		query.append("WHERE s.soc_codigo = o.soc_codigo ");
		query.append("AND s.sol_codigo = sol.sol_codigo  ");
		query.append("AND s.cla_tipo = 'TE' AND sol.cla_entidad = 'SF' ");
		query.append("AND EXISTS ( SELECT * FROM soc_comprobante c ");
		query.append("WHERE c.ope_codigo = o.ope_codigo ");
		query.append("AND mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND c.cve_estadocpb = 'C') ");
		query.append("AND sol.sol_codigo = :codInstitucion ");
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		consulta.setParameter("codInstitucion", codInstitucion);
		
		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		
		return monto;
				
	}
	
	
	
	/*
	 * MÃ©todo que obtiene el la suma de ventas a traves de bolsin del reporte de venta de dolares estadounidenses.
	 * */
	public BigDecimal obtenerTotalBolsinReporteVentaDolares(String fechaInicio, String fechaFin){

		// Obtenemos las entidades Por JDBC
		StringBuffer query = new StringBuffer();				
		BigDecimal monto = BigDecimal.ZERO;
		BigDecimal montoBolSisFin = obtenerMontoBolSisFin(fechaInicio, fechaFin);
		BigDecimal montoBolCliSisFin = obtenerMontoBolCliSisFin(fechaInicio, fechaFin);
		monto = montoBolSisFin.add(montoBolCliSisFin);					
		return monto;
		
	}
	
	/*
	 * MÃ©todo que obtiene el la suma de ventas del dia a traves de bolsin del reporte de venta de dolares estadounidenses.
	 * */
	public BigDecimal obtenerTotalBolsinReporteVentaDolaresDia(String fechaInicio, String fechaFin){

		BigDecimal monto = BigDecimal.ZERO;
		
		BigDecimal montoVentDSisFin = obtenerMontoVentDiaSisFin(fechaInicio, fechaFin);
		
		BigDecimal montoVentDCliSisFin = obtenerMontoVentDiaCliSisFin(fechaInicio, fechaFin);
		
		monto = montoVentDSisFin.add(montoVentDCliSisFin);
						
		return monto;
		
	}
	
	/**
	 * MÃ©todo que obtiene el la suma total general de ventas a traves de bolsin del reporte de venta de dolares estadounidenses.
	 * @param fechaInicio Fecha de Inicio
	 * @param fechaFin Fecha de Fin
	 * @return Monto total bolsin
	 */
	public BigDecimal obtenerTotalGeneralBolsinReporteVentaDolares(String fechaInicio, String fechaFin){

		BigDecimal monto = BigDecimal.ZERO;
		BigDecimal totalBolSisFin = obtenerTotalBolsinReporteVentaDolares(fechaInicio,fechaFin);
		BigDecimal totalVentaDia = obtenerTotalBolsinReporteVentaDolaresDia(fechaInicio,fechaFin);
		monto = totalBolSisFin.add(totalVentaDia);
						
		return monto;
		
	}
	
	/**
	 * Método que obtiene lista de entidades bancarias de bolsin de sistema financiero.
	 * @param fechaInicio, fecha de inicio.
	 * @param fechaFin, fecha fin.
	 */
	public List<OperacionesCambiarias> obtenerEntidadBancariaBolsinSistemaFinanciero(String fechaInicio, String fechaFin)
	{
		// Instancia lista de tipo "OperacionesCambiarias".
		List<OperacionesCambiarias> vListaEntidad = new ArrayList<OperacionesCambiarias>();
		// Instancia objeto de tipo "StringBuffer".
		StringBuffer query = new StringBuffer();
		
		// Adiciona consulta para obtener lista de entidades.
		query.append("SELECT ss.sol_codigo, ss.sol_persona ");
		query.append("FROM soc_bolsin s, soc_solicitante ss ");
		query.append("WHERE s.sol_codigo = ss.sol_codigo ");
		query.append("AND s.soc_codigo IN(SELECT c.ope_codigo FROM soc_comprobante c ");
		query.append("WHERE mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("AND c.ope_codigo = s.soc_codigo AND c.cpb_nrocpbte IS NOT NULL) ");
		query.append("and s.cla_tipsolic in ('E') ");
		query.append("and s.cla_estado in ('5') ");
		query.append("and ss.cla_entidad = 'SF' ");
		query.append("group by 1,2 order by ss.sol_codigo ");
		
		// Crea la consulta y la adicionamos en sesión.
		Query consulta = getSession().createSQLQuery(query.toString());
		// Adiciona parametros de entrada
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		
		// Convierte la consulta en lista.
		List lista = consulta.list();
		
		// Mapea la lista resultante. 
		List<Map<String, Object>> resultadoQuery = UtilsQNatives.convertListToMap(lista, "sol_codigo,sol_persona".split(","));
		
		// Recorre el resultado.
		for (Map<String, Object> res : resultadoQuery) {
			// Instancia clase de tipo "OperacionesCambiarias".
			OperacionesCambiarias vObjEntidad = new OperacionesCambiarias();
			// Almacena el código.
			vObjEntidad.setCodInstitucion((String) res.get("sol_codigo"));
			// Almacena la descripcion de la entidad.
			vObjEntidad.setInstitucion((String) res.get("sol_persona"));
			// Adiciona a la lista de entidades.
			vListaEntidad.add(vObjEntidad);	
		}		
		// Retorna lista de entidades.
		return vListaEntidad;
	}
	
	/**
	 * Método que obtiene lista de entidades bancarias en el dia de sistema financiero.
	 * @param fechaInicio, fecha de inicio.
	 * @param fechaFin, fecha fin.
	 */
	public List<OperacionesCambiarias> obtenerListaEntidadBancariaDiaSistemaFinanciero(String pFechaInicio, String pFechaFin)
	{
		// Instancia lista de tipo "OperacionesCambiarias".
		List<OperacionesCambiarias> vListaEntidad = new ArrayList<OperacionesCambiarias>();
		// Instancia objeto de tipo "StringBuffer".
		StringBuffer query = new StringBuffer();
		
		// Adiciona consulta para obtener lista de entidades.
		query.append("SELECT ss.sol_codigo,ss.sol_persona ");
		query.append("FROM soc_bolsin s, soc_solicitante ss ");
		query.append("WHERE s.sol_codigo = ss.sol_codigo ");
		query.append("AND s.cla_tipsolic IN ('ED') ");
		query.append("AND s.cla_estado IN ('5') ");
		query.append("AND ss.cla_entidad = 'SF' ");
		query.append("AND s.fecha BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("GROUP BY 1,2 ");
		query.append("ORDER BY 2 ");
		
		// Crea la consulta y la adicionamos en sesión.
		Query consulta = getSession().createSQLQuery(query.toString());
		
		
		// Adiciona parametros de entrada
		consulta.setParameter("fechaInicio", pFechaInicio);
		consulta.setParameter("fechaHasta", pFechaFin);
		
		// Convierte la consulta en lista.
		List lista = consulta.list();
	try{	
		// Mapea la lista resultante. 
		List<Map<String, Object>> resultadoQuery = UtilsQNatives.convertListToMap(lista, "sol_codigo,sol_persona".split(","));
		
		// Recorre el resultado.
		for (Map<String, Object> res : resultadoQuery) {
			// Instancia clase de tipo "OperacionesCambiarias".
			OperacionesCambiarias vObjEntidad = new OperacionesCambiarias();
			// Almacena el código.
			vObjEntidad.setCodInstitucion((String) res.get("sol_codigo"));
			// Almacena la descripcion de la entidad.
			vObjEntidad.setInstitucion((String) res.get("sol_persona"));
			// Adiciona a la lista de entidades.
			vListaEntidad.add(vObjEntidad);	
		}
	}
		catch (Exception e) 
		{
			// Escribe el errole en el log del sistema.
			log.error("Error al cargar " + e.getMessage(), e);
			// Adiciona error del mensaje.
			//addMessageError("Error", e.getMessage());
		}
		// Retorna lista de entidades.
		return vListaEntidad;
	}

	/**
	 * Método que obtiene suma total por entidad bancaria y fechas de bolsin de sistema financiero.
	 * @param codInstitucion, fecha de inicio.
	 * @param fechaInicio, fecha inicio.
	 * @param fechaFin, fecha fin.
	 */
	public BigDecimal obtenerMontoEntidadBancariaPorFechaIdInstitucion (String pIdInstitucion, String pFechaInicio, String pFechaFin)
	{
		// Inicializa variable para el monto.
		BigDecimal monto = BigDecimal.ZERO;
		// Instancia objeto de tipo "StringBuffer".
		StringBuffer query = new StringBuffer();
		
		// Adiciona consulta para obtener lista de entidades.
		query.append("SELECT SUM(b.montoadj) AS monto ");
		query.append("FROM soc_bolsin b, soc_solicitante sol WHERE b.sol_codigo = sol.sol_codigo ");
		query.append("AND b.soc_codigo IN( SELECT sc.ope_codigo FROM ( ");
		query.append("SELECT c.ope_codigo, MAX(mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion)) AS fecha ");
		query.append("FROM soc_comprobante c WHERE c.ope_codigo= b.soc_codigo ");
		query.append("AND c.cpb_nrocpbte IS NOT NULL GROUP BY 1) AS sc ");
		query.append("WHERE sc.fecha BETWEEN :fechaInicio AND :fechaHasta) ");
		query.append("AND b.cla_tipsolic in ('E') ");
		query.append("AND b.cla_estado in ('5') ");
		query.append("AND sol.cla_entidad = 'SF' ");
		query.append("AND sol.sol_codigo = :codInstitucion ");
		
		// Crea la consulta y la adicionamos en sesión.
		Query consulta = getSession().createSQLQuery(query.toString());
		
		// Adiciona parametros de entrada
		consulta.setParameter("fechaInicio", pFechaInicio);
		consulta.setParameter("fechaHasta", pFechaFin);
		consulta.setParameter("codInstitucion", pIdInstitucion);
		
		// Convierte la consulta en lista.
		List lista = consulta.list();

		// Mapea la lista resultante. 
		List<Map<String, Object>> resultadoQuery = UtilsQNatives.convertListToMap(lista, "monto".split(","));

		// Recorre el resultado.
		for (Map<String, Object> res : resultadoQuery) 
		{
			// Verifica si el monto es distinto de nulo.
			if (res.get("monto") == null) 
			{
				monto = new BigDecimal("0");
			} 
			else 
			{
				monto = new BigDecimal(res.get("monto").toString());
			}
		}
		// Retorna resultado.
		return monto;
				
	}
	
	/**
	 * Método que obtiene suma total por entidad bancaria y fechas de venta de dolares en el dia al sistema financiero.
	 * @param codInstitucion, fecha de inicio.
	 * @param fechaInicio, fecha inicio.
	 * @param fechaFin, fecha fin.
	 */
	public BigDecimal obtenerMontoVentaDolaresDiaSistemaFinancieroPorFechaIdInstitucion (String pIdInstitucion, String pFechaInicio, String pFechaFin)
	{
		// Inicializa variable para el monto.
		BigDecimal monto = BigDecimal.ZERO;
		// Instancia objeto de tipo "StringBuffer".
		StringBuffer query = new StringBuffer();
		
		// Adiciona consulta para obtener lista de entidades.
		query.append("select SUM (s.montosol) as monto ");
		query.append("from soc_bolsin s, soc_solicitante ss ");
		query.append("where s.sol_codigo = ss.sol_codigo ");
		query.append("and s.cla_tipsolic in ('ED') ");
		query.append("and s.cla_estado in ('5') ");
		query.append("and ss.cla_entidad = 'SF' ");
		query.append("and s.fecha between :fechaInicio AND :fechaHasta ");
		query.append("and s.sol_codigo =  :codInstitucion ");
		
		// Crea la consulta y la adicionamos en sesión.
		Query consulta = getSession().createSQLQuery(query.toString());
		
		// Adiciona parametros de entrada
		consulta.setParameter("fechaInicio", pFechaInicio);
		consulta.setParameter("fechaHasta", pFechaFin);
		consulta.setParameter("codInstitucion", pIdInstitucion);
		
		// Convierte la consulta en lista.
		List lista = consulta.list();

		// Mapea la lista resultante. 
		List<Map<String, Object>> resultadoQuery = UtilsQNatives.convertListToMap(lista, "monto".split(","));

		// Recorre el resultado.
		for (Map<String, Object> res : resultadoQuery) 
		{
			// Verifica si el monto es distinto de nulo.
			if (res.get("monto") == null) 
			{
				monto = new BigDecimal("0");
			} 
			else 
			{
				monto = new BigDecimal(res.get("monto").toString());
			}
		}
		// Retorna resultado.
		return monto;
				
	}
/**
	 * Obiene una lista de instituciones para el bolsin de los clientes del sistema financiero
	 * @param fechaInicio Fecha de Inicio
	 * @param fechaFin Fecha de fin
	 * @return Coleccion de instituciones
	 */
	public List<OperacionesCambiarias> obtenerInstitucionesBolCliSisFin(String fechaInicio, String fechaFin){
		List<OperacionesCambiarias> instituciones = new ArrayList<OperacionesCambiarias>();
		StringBuffer query = new StringBuffer();
		query.append("SELECT ss.sol_codigo, ss.sol_persona ");
		query.append("FROM soc_bolsin s, soc_solicitante ss ");
		query.append("WHERE s.sol_codigo = ss.sol_codigo ");
		query.append("AND s.soc_codigo IN(  SELECT c.ope_codigo FROM soc_comprobante c ");
		query.append("WHERE mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion) BETWEEN :fechaInicio AND :fechaHasta AND c.cpb_nrocpbte IS NOT NULL) ");
		query.append("AND s.cla_tipsolic in ('G') ");
		query.append("AND s.cla_estado = '5' ");
		query.append("AND ss.cla_entidad = 'SF' ");
		query.append("GROUP BY ss.sol_codigo, ss.sol_persona ");
		query.append("ORDER BY ss.sol_codigo ");
				// Añadimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		List lista = consulta.list();
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "sol_codigo,sol_persona".split(","));
		
		OperacionesCambiarias institucion = new OperacionesCambiarias();
		for (Map<String, Object> res : resultadoQuery) {
			institucion = new OperacionesCambiarias();
			institucion.setCodInstitucion((String) res.get("sol_codigo"));
			institucion.setInstitucion((String) res.get("sol_persona"));
			instituciones.add(institucion);	
		}
		
			
		return instituciones;
	}
	
	/**
	 * Obiene una lista de instituciones en el día a Clientes del sistema financiero
	 * @param fechaInicio Fecha de Inicio
	 * @param fechaFin Fecha de fin
	 * @return Coleccion de instituciones
	 */
	public List<OperacionesCambiarias> obtenerInstitucionesDiaClientesSisFin(String fechaInicio, String fechaFin){
		List<OperacionesCambiarias> instituciones = new ArrayList<OperacionesCambiarias>();
		StringBuffer query = new StringBuffer();
		query.append("SELECT ss.sol_codigo, ss.sol_persona ");
		query.append("FROM soc_bolsin s, soc_solicitante ss ");
		query.append("WHERE s.sol_codigo = ss.sol_codigo ");
		query.append("AND s.cla_tipsolic IN ('GD') ");
		query.append("AND s.cla_estado = '5' ");
		query.append("AND ss.cla_entidad = 'SF' ");
		query.append("AND s.fecha BETWEEN :fechaInicio AND :fechaHasta ");
		query.append("GROUP BY 1,2 ");
		query.append("ORDER BY 2 ");
				// Añadimos los parametros y ejecutamos el query
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		List lista = consulta.list();
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "sol_codigo,sol_persona".split(","));
		
		OperacionesCambiarias institucion = new OperacionesCambiarias();
		for (Map<String, Object> res : resultadoQuery) {
			institucion = new OperacionesCambiarias();
			institucion.setCodInstitucion((String) res.get("sol_codigo"));
			institucion.setInstitucion((String) res.get("sol_persona"));
			instituciones.add(institucion);	
		}
		
			
		return instituciones;
	}
	
	/**
	 * Obtiene el monto de institucion para el bolsin y sus clientes financieros
	 * @param codInstitucion Cod Institución
	 * @param fechaInicio Fecha Fin
	 * @param fechaFin Fecha Inicio
	 * @return Monto de la institución para el bolsin y sus clientes del sistema financiero
	 */
	public BigDecimal obtenerMontoInstitucionBolCliSisFinPorFecha(String codInstitucion, String fechaInicio, String fechaFin){
		BigDecimal monto = BigDecimal.ZERO;
		StringBuffer query = new StringBuffer();
		query.append("SELECT SUM(b.montoadj) AS monto ");
		query.append("FROM soc_bolsin b, soc_solicitante sol WHERE b.sol_codigo = sol.sol_codigo ");
		query.append("AND b.soc_codigo IN( SELECT sc.ope_codigo FROM ( ");
		query.append("SELECT c.ope_codigo, MAX(mdy(c.cpb_periodo, c.cpb_dia, c.cpb_gestion)) AS fecha ");
		query.append("FROM soc_comprobante c WHERE c.ope_codigo= b.soc_codigo ");
		query.append("AND c.cpb_nrocpbte IS NOT NULL GROUP BY 1) AS sc ");
		query.append("WHERE sc.fecha BETWEEN :fechaInicio AND :fechaHasta) ");
		query.append("AND b.cla_tipsolic in ('G') ");
		query.append("AND b.cla_estado in ('5') ");
		query.append("AND sol.cla_entidad = 'SF' ");
		query.append("AND sol.sol_codigo = :codInstitucion ");
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		consulta.setParameter("codInstitucion", codInstitucion);
		
		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		
		return monto;
				
	}
	
	/**
	 * Obtiene el monto de institucion para el bolsin y sus clientes financieros
	 * @param codInstitucion Cod Institución
	 * @param fechaInicio Fecha Fin
	 * @param fechaFin Fecha Inicio
	 * @return Monto de la institución para el bolsin y sus clientes del sistema financiero
	 */
	public BigDecimal obtenerMontoInstitucionDiaSisFinPorFecha(String codInstitucion, Date fechaInicio, Date fechaFin){
		BigDecimal monto = BigDecimal.ZERO;
		StringBuffer query = new StringBuffer();
		query.append("SELECT SUM(s.montosol) AS monto ");
		query.append("FROM soc_bolsin s, soc_solicitante ss ");
		query.append("WHERE s.sol_codigo = ss.sol_codigo ");
		query.append("AND s.cla_tipsolic IN ('ED') ");
		query.append("AND s.fecha between :fechaInicio  AND :fechaHasta ");
		query.append("AND s.cla_tipsolic in ('ED') ");
		query.append("AND s.cla_estado = '5' ");
		query.append("AND ss.sol_codigo = :codInstitucion ");
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		consulta.setParameter("codInstitucion", codInstitucion);
		
		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		
		return monto;
				
	}
	
	




	/**
	 * Obtiene el monto de institucion el dia de sus clientes financieros
	 * @param codInstitucion Cod Institución
	 * @param fechaInicio Fecha Fin
	 * @param fechaFin Fecha Inicio
	 * @return Monto de la institución para el dia y sus clientes del sistema financiero
	 */
	public BigDecimal obtenerMontoInstitucionDiaCliSisFinPorFecha(String codInstitucion, String fechaInicio, String fechaFin){
		BigDecimal monto = BigDecimal.ZERO;
		StringBuffer query = new StringBuffer();
		query.append("SELECT SUM(s.montosol) ");
		query.append("FROM soc_bolsin s, soc_solicitante ss ");
		query.append("WHERE s.sol_codigo = ss.sol_codigo ");
		query.append("AND s.cla_tipsolic in ('GD') ");
		query.append("AND s.cla_estado in ('5') ");
		query.append("AND ss.cla_entidad = 'SF' ");
		query.append("AND s.cla_estado = '5' ");
		query.append("AND s.fecha between :fechaInicio  AND :fechaHasta ");
		query.append("AND ss.sol_codigo = :codInstitucion ");
		
		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("fechaInicio", fechaInicio);
		consulta.setParameter("fechaHasta", fechaFin);
		consulta.setParameter("codInstitucion", codInstitucion);
		
		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "monto".split(","));

		for (Map<String, Object> res : resultadoQuery) {

			if (res.get("monto") == null) {
				monto = new BigDecimal("0");
			} else {
				monto = new BigDecimal(res.get("monto").toString());
			}

		}
		
		return monto;
				
	}
}
