package gob.bcb.bpm.pruebaCU;

import gob.bcb.service.servicioSioc.pojos.CuentaS;
import gob.bcb.swift.model.SwfMensaje;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Solicitud implements java.io.Serializable {

	private String socCodigo;
	private String claEstadodesc;
	private Integer codMoneda;
	private Integer codMonedat;
	private String sIOCWEB_TIPOPERACION;
	private String codTipoOperacion;
	private SocSolicitudes solicitud;
	private List<SocDetallessol> socDetallessolLista = new ArrayList<SocDetallessol>();
	private List<SocSolicitudctas> socSolicitudctasLista = new ArrayList<SocSolicitudctas>();	
	private Map<Integer, CuentasBen> cuentasBenLista;
	private Map<String, CuentaS> cuentasS = new HashMap<String, CuentaS>();
	private Map<String, SocSolicitudctas> socSolicitudctasMapa= new HashMap<String, SocSolicitudctas>();
	private List<SocOpecomi> socOpecomiLista = new ArrayList<SocOpecomi>();
	private Map<String, SocOpecomi> socOpecomiMap = new HashMap<String, SocOpecomi>();	
	private List<SocComprobante> socComprobanteLista = new ArrayList<SocComprobante>();
	private List<SocRengscomp> socRengscompLista  = new ArrayList<SocRengscomp>();
	private List<SocOrdenesPago> socOrdenesPagoLista = new ArrayList<SocOrdenesPago>();
	private List<SocFacturas> socFacturasLista;
	private SocSolicitante socSolicitante;
	private SocEsquemas socEsquemas;
	private SocBenefsreg socBenefsreg;	
	private SocBenefs socBenefs;
	private List<Beneficiario> beneficiarioLista;
	private SwfMensaje swfMensaje; 
	private String codUsuarioAudit; 
	private String codEstacionAudit;	
	private String codPersonaAudit;	
	private String codUsuarioCont;	
	private Beneficiario beneficiario;
	public Solicitud() {

	}

	public String getSocCodigo() {
		return socCodigo;
	}

	public void setSocCodigo(String socCodigo) {
		this.socCodigo = socCodigo;
	}

	public SocSolicitudes getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SocSolicitudes solicitud) {
		socCodigo = solicitud.getSocCodigo();
		this.solicitud = solicitud;
	}

	public List<SocDetallessol> getSocDetallessolLista() {
		return socDetallessolLista;
	}

	public void setSocDetallessolLista(List<SocDetallessol> socDetallessolList) {
		this.socDetallessolLista = socDetallessolList;
	}

	public SocDetallessol getSocDetallessol(Integer codDetalle) {
		for (SocDetallessol socDetallessol : socDetallessolLista) {
			if (socDetallessol.getId() != null && socDetallessol.getId().getDetCodigo().compareTo(codDetalle) == 0) { 
				return socDetallessol;
			}
		}
		return null;
	}
	
	
	public void setSocOpecomiLista(List<SocOpecomi> socOpecomiLista) {
		String codVaria = "";
		for (SocOpecomi socOpecomi : socOpecomiLista) {
			if (socOpecomi != null){
				if (socOpecomi.getId() != null){
					if (socOpecomi.getId().getDetCodigo() != null && !StringUtils.isBlank(socOpecomi.getId().getClaComision())){
						codVaria = String.valueOf(socOpecomi.getId().getDetCodigo()).concat(socOpecomi.getId().getClaComision());
						socOpecomiMap.put(codVaria, socOpecomi);
						
					}
				}
			}
		}
		
		this.socOpecomiLista = socOpecomiLista;
	}

	public List<SocOpecomi> getSocOpecomiLista() {
		return socOpecomiLista;
	}

	public SocOpecomi buscarClaComision(String claComision, Integer detComision) {
		String codVaria = String.valueOf(detComision).concat(claComision);		
		SocOpecomi socOpecomiResp = socOpecomiMap.get(codVaria);		
		return socOpecomiResp;
	}

	public void setSocFacturasLista(List<SocFacturas> socFacturasLista) {
		this.socFacturasLista = socFacturasLista;
	}

	public List<SocFacturas> getSocFacturasLista() {
		return socFacturasLista;
	}

	public Map<Integer, CuentasBen> getCuentasBenLista() {
		return cuentasBenLista;
	}

	public void setCuentasBenLista(Map<Integer, CuentasBen> cuentasBenLista) {
		this.cuentasBenLista = cuentasBenLista;
	}

	public void setClaEstadodesc(String claEstadodesc) {
		this.claEstadodesc = claEstadodesc;
	}

	public String getClaEstadodesc() {
		return claEstadodesc;
	}

	public void setSocSolicitante(SocSolicitante socSolicitante) {
		this.socSolicitante = socSolicitante;
	}

	public SocSolicitante getSocSolicitante() {
		return socSolicitante;
	}

	public void setCuentasS(Map<String, CuentaS> cuentasS) {
		this.cuentasS = cuentasS;
	}

	public Map<String, CuentaS> getCuentasS() {
		return cuentasS;
	}

	public void setCuentasS(String codCuentaS, CuentaS cuentas) {
		if (cuentasS == null) {
			cuentasS = new HashMap<String, CuentaS>();
		}

		cuentasS.put(codCuentaS, cuentas);
	}

	public CuentaS getCuentasSolic(String tipoCta) {
		if (cuentasS == null) {
			cuentasS = new HashMap<String, CuentaS>();
		}

		return cuentasS.get(tipoCta);
	}

	public void setSocComprobanteLista(List<SocComprobante> socComprobanteLista) {
		this.socComprobanteLista = socComprobanteLista;
	}

	public List<SocComprobante> getSocComprobanteLista() {
		return socComprobanteLista;
	}

	public void setCodMoneda(Integer codMoneda) {
		this.codMoneda = codMoneda;
	}

	public Integer getCodMoneda() {
		return codMoneda;
	}

	public void setCodMonedat(Integer codMonedat) {
		this.codMonedat = codMonedat;
	}

	public Integer getCodMonedat() {
		return codMonedat;
	}

	public List<Beneficiario> getBeneficiarioLista() {
		return beneficiarioLista;
	}

	public void setBeneficiarioLista(List<Beneficiario> beneficiarioLista) {
		this.beneficiarioLista = beneficiarioLista;
	}

	public String getsIOCWEB_TIPOPERACION() {
		return sIOCWEB_TIPOPERACION;
	}

	public void setsIOCWEB_TIPOPERACION(String sIOCWEB_TIPOPERACION) {
		this.sIOCWEB_TIPOPERACION = sIOCWEB_TIPOPERACION;
	}

	public List<SocRengscomp> getSocRengscompLista() {
		return socRengscompLista;
	}

	public void setSocRengscompLista(List<SocRengscomp> socRengscompLista) {
		this.socRengscompLista = socRengscompLista;
	}

	public Map<String, SocOpecomi> getSocOpecomiMap() {
		return socOpecomiMap;
	}

	public void setSocOpecomiMap(Map<String, SocOpecomi> socOpecomiMap) {
		this.socOpecomiMap = socOpecomiMap;
	}

	public List<SocOrdenesPago> getSocOrdenesPagoLista() {
		return socOrdenesPagoLista;
	}

	public void setSocOrdenesPagoLista(List<SocOrdenesPago> socOrdenesPagoLista) {
		this.socOrdenesPagoLista = socOrdenesPagoLista;
	}

	public String getCodUsuarioAudit() {
		return codUsuarioAudit;
	}

	public void setCodUsuarioAudit(String codUsuarioAudit) {
		this.codUsuarioAudit = codUsuarioAudit;
	}

	public String getCodEstacionAudit() {
		return codEstacionAudit;
	}

	public void setCodEstacionAudit(String codEstacionAudit) {
		this.codEstacionAudit = codEstacionAudit;
	}

	public SocEsquemas getSocEsquemas() {
		return socEsquemas;
	}

	public void setSocEsquemas(SocEsquemas socEsquemas) {
		this.socEsquemas = socEsquemas;
	}

	public String getCodPersonaAudit() {
		return codPersonaAudit;
	}

	public void setCodPersonaAudit(String codPersonaAudit) {
		this.codPersonaAudit = codPersonaAudit;
	}

	public List<SocSolicitudctas> getSocSolicitudctasLista() {
		return socSolicitudctasLista;
	}

	public void setSocSolicitudctasLista(List<SocSolicitudctas> socSolicitudctasLista) {
		this.socSolicitudctasLista = socSolicitudctasLista;
	}

	public String getCodUsuarioCont() {
		return codUsuarioCont;
	}

	public void setCodUsuarioCont(String codUsuarioCont) {
		this.codUsuarioCont = codUsuarioCont;
	}

	public String getCodTipoOperacion() {
		return codTipoOperacion;
	}

	public void setCodTipoOperacion(String codTipoOperacion) {
		this.codTipoOperacion = codTipoOperacion;
	}

	public SwfMensaje getSwfMensaje() {
		return swfMensaje;
	}

	public void setSwfMensaje(SwfMensaje swfMensaje) {
		this.swfMensaje = swfMensaje;
	}

	public Map<String, SocSolicitudctas> getSocSolicitudctasMapa() {
		return socSolicitudctasMapa;
	}

	public void setSocSolicitudctasMapa(Map<String, SocSolicitudctas> socSolicitudctasMapa) {
		this.socSolicitudctasMapa = socSolicitudctasMapa;
	}
	
	public SocBenefsreg getSocBenefsreg() {
		return socBenefsreg;
	}

	public void setSocBenefsreg(SocBenefsreg socBenefsreg) {
		this.socBenefsreg = socBenefsreg;
	}

	public SocBenefs getSocBenefs() {
		return socBenefs;
	}

	public void setSocBenefs(SocBenefs socBenefs) {
		this.socBenefs = socBenefs;
	}

	public Beneficiario getBeneficiario() {
		return beneficiario;
	}

	public void setBeneficiario(Beneficiario beneficiario) {
		this.beneficiario = beneficiario;
	}

}