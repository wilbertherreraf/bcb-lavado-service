package gob.bcb.service.servicioSiocCoin;

import java.util.HashMap;
import java.util.Map;

import gob.bcb.service.servicioTres.model.ComprobanteDao;
import gob.bcb.service.servicioTres.model.CuentaMovimientoDao;
import gob.bcb.service.servicioTres.model.EstadoComprobDao;
import gob.bcb.service.servicioTres.model.FactorConvMnDao;
import gob.bcb.service.servicioTres.model.FacturaConceptoDao;
import gob.bcb.service.servicioTres.model.FacturaConceptoSinCreditoDao;
import gob.bcb.service.servicioTres.model.FacturaDao;
import gob.bcb.service.servicioTres.model.FacturaSinCreditoDao;
import gob.bcb.service.servicioTres.model.FeriadoDao;
import gob.bcb.service.servicioTres.model.ImpOrdenPagoDao;
import gob.bcb.service.servicioTres.model.ImpPresupDao;
import gob.bcb.service.servicioTres.model.ImpSigmaDao;
import gob.bcb.service.servicioTres.model.RengComprobDao;
import gob.bcb.service.servicioTres.model.RengConciliaDao;
import gob.bcb.service.servicioTres.model.SaldoConciliaDao;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class ServicioCoinDao {
	private Logger log = Logger.getLogger(ServicioCoinDao.class);
	private SessionFactory sessionFactory;
	private HibernateTemplate hibernateTemplate;
	
	private FactorConvMnDao factorConvMnDao = new FactorConvMnDao();
	private ComprobanteDao comprobanteDao = new ComprobanteDao();
	private EstadoComprobDao estadoComprobDao = new EstadoComprobDao();
	private RengComprobDao rengComprobDao = new RengComprobDao();
	private ImpSigmaDao impSigmaDao = new ImpSigmaDao();
	private ImpPresupDao impPresupDao = new ImpPresupDao();
	private ImpOrdenPagoDao impOrdenPagoDao = new ImpOrdenPagoDao();
	private FacturaDao facturaDao = new FacturaDao();
	private FacturaConceptoDao facturaConceptoDao = new FacturaConceptoDao();
	private RengConciliaDao rengConciliaDao = new RengConciliaDao();
	private SaldoConciliaDao saldoConciliaDao = new SaldoConciliaDao();
	private FacturaSinCreditoDao facturaSinCreditoDao = new FacturaSinCreditoDao();
	private CuentaMovimientoDao cuentaMovimientoDao = new CuentaMovimientoDao();
	private FacturaConceptoSinCreditoDao facturaConceptoSinCreditoDao = new FacturaConceptoSinCreditoDao();
	private FeriadoDao feriadoDao = new FeriadoDao();
	
	public void inicializar() {
		
		factorConvMnDao.setSessionFactory(getSessionFactory());
		comprobanteDao.setSessionFactory(getSessionFactory());
		estadoComprobDao.setSessionFactory(getSessionFactory());
		rengComprobDao.setSessionFactory(getSessionFactory());
		impSigmaDao.setSessionFactory(getSessionFactory());
		impPresupDao.setSessionFactory(getSessionFactory());
		impOrdenPagoDao.setSessionFactory(getSessionFactory());
		facturaDao.setSessionFactory(getSessionFactory());
		facturaConceptoDao.setSessionFactory(getSessionFactory());
		rengConciliaDao.setSessionFactory(getSessionFactory());
		saldoConciliaDao.setSessionFactory(getSessionFactory());
		facturaSinCreditoDao.setSessionFactory(getSessionFactory());
		facturaConceptoSinCreditoDao.setSessionFactory(getSessionFactory());
		cuentaMovimientoDao.setSessionFactory(getSessionFactory());
		feriadoDao.setSessionFactory(getSessionFactory());
		SiocCoinService.setSessionFactory(getSessionFactory());
		log.info("ServicioCoinDao inicializadoooooooooooo ...");
	}
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
		inicializar();
	}
	public FactorConvMnDao getFactorConvMnDao() {
		return factorConvMnDao;
	}

	public void setFactorConvMnDao(FactorConvMnDao factorConvMnDao) {
		this.factorConvMnDao = factorConvMnDao;
	}

	public ComprobanteDao getComprobanteDao() {
		return comprobanteDao;
	}

	public void setComprobanteDao(ComprobanteDao comprobanteDao) {
		this.comprobanteDao = comprobanteDao;
	}

	public EstadoComprobDao getEstadoComprobDao() {
		return estadoComprobDao;
	}

	public void setEstadoComprobDao(EstadoComprobDao estadoComprobDao) {
		this.estadoComprobDao = estadoComprobDao;
	}

	public RengComprobDao getRengComprobDao() {
		return rengComprobDao;
	}

	public void setRengComprobDao(RengComprobDao rengComprobDao) {
		this.rengComprobDao = rengComprobDao;
	}

	public ImpSigmaDao getImpSigmaDao() {
		return impSigmaDao;
	}

	public void setImpSigmaDao(ImpSigmaDao impSigmaDao) {
		this.impSigmaDao = impSigmaDao;
	}

	public ImpPresupDao getImpPresupDao() {
		return impPresupDao;
	}

	public void setImpPresupDao(ImpPresupDao impPresupDao) {
		this.impPresupDao = impPresupDao;
	}

	public ImpOrdenPagoDao getImpOrdenPagoDao() {
		return impOrdenPagoDao;
	}

	public void setImpOrdenPagoDao(ImpOrdenPagoDao impOrdenPagoDao) {
		this.impOrdenPagoDao = impOrdenPagoDao;
	}

	public FacturaDao getFacturaDao() {
		return facturaDao;
	}

	public void setFacturaDao(FacturaDao facturaDao) {
		this.facturaDao = facturaDao;
	}

	public FacturaConceptoDao getFacturaConceptoDao() {
		return facturaConceptoDao;
	}

	public void setFacturaConceptoDao(FacturaConceptoDao facturaConceptoDao) {
		this.facturaConceptoDao = facturaConceptoDao;
	}

	public RengConciliaDao getRengConciliaDao() {
		return rengConciliaDao;
	}

	public void setRengConciliaDao(RengConciliaDao rengConciliaDao) {
		this.rengConciliaDao = rengConciliaDao;
	}

	public SaldoConciliaDao getSaldoConciliaDao() {
		return saldoConciliaDao;
	}

	public void setSaldoConciliaDao(SaldoConciliaDao saldoConciliaDao) {
		this.saldoConciliaDao = saldoConciliaDao;
	}

	public FacturaSinCreditoDao getFacturaSinCreditoDao() {
		return facturaSinCreditoDao;
	}

	public void setFacturaSinCreditoDao(FacturaSinCreditoDao facturaSinCreditoDao) {
		this.facturaSinCreditoDao = facturaSinCreditoDao;
	}

	public FacturaConceptoSinCreditoDao getFacturaConceptoSinCreditoDao() {
		return facturaConceptoSinCreditoDao;
	}

	public void setFacturaConceptoSinCreditoDao(FacturaConceptoSinCreditoDao facturaConceptoSinCreditoDao) {
		this.facturaConceptoSinCreditoDao = facturaConceptoSinCreditoDao;
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public CuentaMovimientoDao getCuentaMovimientoDao() {
		return cuentaMovimientoDao;
	}

	public void setCuentaMovimientoDao(CuentaMovimientoDao cuentaMovimientoDao) {
		this.cuentaMovimientoDao = cuentaMovimientoDao;
	}

	public FeriadoDao getFeriadoDao() {
		return feriadoDao;
	}

	public void setFeriadoDao(FeriadoDao feriadoDao) {
		this.feriadoDao = feriadoDao;
	}
	
	

}
