package gob.bcb.service.servicioTres.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author eborda
 */
@Entity
@Table(name = "feriado")
@NamedQueries({ @NamedQuery(name = "Feriado.findAll", query = "SELECT f FROM Feriado f") })
public class Feriado implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private Date fechaFeriado;
	
	private String descFeriado;

	public Feriado(Date fechaFeriado, String descFeriado) {
		this.fechaFeriado = fechaFeriado;
		this.descFeriado = descFeriado;
	}

	public Feriado() {
		
	}

	public Date getFechaFeriado() {
		return fechaFeriado;
	}

	public void setFechaFeriado(Date fechaFeriado) {
		this.fechaFeriado = fechaFeriado;
	}

	public String getDescFeriado() {
		return descFeriado;
	}

	public void setDescFeriado(String descFeriado) {
		this.descFeriado = descFeriado;
	}

	@Override
	public String toString() {
		return "Feriado [fechaFeriado=" + fechaFeriado + ", descFeriado="
				+ descFeriado + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((descFeriado == null) ? 0 : descFeriado.hashCode());
		result = prime * result
				+ ((fechaFeriado == null) ? 0 : fechaFeriado.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Feriado other = (Feriado) obj;
		if (descFeriado == null) {
			if (other.descFeriado != null)
				return false;
		} else if (!descFeriado.equals(other.descFeriado))
			return false;
		if (fechaFeriado == null) {
			if (other.fechaFeriado != null)
				return false;
		} else if (!fechaFeriado.equals(other.fechaFeriado))
			return false;
		return true;
	}	
}
