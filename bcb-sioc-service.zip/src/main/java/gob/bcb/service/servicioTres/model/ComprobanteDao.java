/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocFacturas;
import gob.bcb.bpm.pruebaCU.SocOrdenesPago;
import gob.bcb.bpm.pruebaCU.SocRengscomp;
import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

//import org.hibernate.Query;

/**
 * @author wherrera
 * 
 */
public class ComprobanteDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(ComprobanteDao.class);
	
	private static final char TIPO_C = 'G';
	private static final int CENTRO = 1;
	private static final String UNIDAD = "D0004";
	private static final char ESTADO = '1';

	public Comprobante getComprobante(String id) {
		log.info("Entre a buscar el objeto con el id: " + id);

		Comprobante comprobante = null;

		StringBuffer query = new StringBuffer();
		query = query.append(" select cp ");
		query = query.append(" from ");
		query = query.append(" Comprobante cp ");
		query = query.append(" where cp.id.nroComprob = ? ");
		query = query.append(" and cp.id.nroCentro = 1 ");
		query = query.append(" and cp.id.cveTipoComprob = 'G' ");

		List<Comprobante> lista = (List<Comprobante>) getHibernateTemplate().find(query.toString(), id);

		if (lista != null) {
			for (Comprobante comp : lista) {
				comprobante = comp;
			}
		}

		return comprobante;
	}

	public String getEsquemaContable(String codEsquema) {
		log.info("Entre a buscar esquema con el id: " + codEsquema);
		if (StringUtils.isBlank(codEsquema)){
			return "";
		}
		StringBuffer query = new StringBuffer();
		query = query.append("select e.nom_esquema ");
		query = query.append("from esquema e ");
		query = query.append("where e.cod_esquema = :codEsquema ");

		Query consulta = getSession().createSQLQuery(query.toString());
		consulta.setParameter("codEsquema", codEsquema);
		
		String nomesquema = "";
		List result = consulta.list();
		if (result.size() > 0)
			nomesquema = (String) result.get(0);

		return nomesquema;
	}
	
	public String getNroComprob(Integer centro, Character tipo) {
		log.info("Entre a buscar el n�mero de comprobante centro: " + centro + ", tipo: " + tipo);

		String corr = "";
		Long nro = (long) 0;

		StringBuffer query = new StringBuffer();
		query = query.append("select max(cp.id.nroComprob) ");
		query = query.append("from Comprobante cp ");
		query = query.append("where cp.id.nroCentro = :centro ");
		query = query.append("and cp.id.cveTipoComprob = :tipo ");

		Query consulta = getSession().createQuery(query.toString());

		consulta.setParameter("centro", centro);
		consulta.setParameter("tipo", tipo);

		corr = (String) consulta.uniqueResult();
		if (StringUtils.isBlank(corr)) {
			corr = "0";
		}
		nro = Long.valueOf(corr.trim());
		nro = nro + 1;
		corr = String.format("%07d", nro);

		return corr;
	}

	public Comprobante crearComprobante(SocComprobante socComprobante, String nroComprob, List<SocRengscomp> rengs, List<SocFacturas> facts, List<SocOrdenesPago> socOrdenesPagoLista) {
		FacturaDao facturaDao = new FacturaDao();
		facturaDao.setSessionFactory(getSessionFactory());

		ImpOrdenPagoDao impOrdenPagoDao = new ImpOrdenPagoDao();
		impOrdenPagoDao.setSessionFactory(getSessionFactory());
		
		RengComprobDao rengCompDao = new RengComprobDao();
		rengCompDao.setSessionFactory(getSessionFactory());

		EstadoComprobDao estadoComprobDao = new EstadoComprobDao();
		estadoComprobDao.setSessionFactory(getSessionFactory());

		nroComprob = getNroComprob(CENTRO, TIPO_C);
		log.info("ooooo===0 INICIO CONTABILIZACION 0===ooooo " +socComprobante.getCpbCodigo() + " por: " + socComprobante.getUsrCodigo());		
		log.info("NRO Comprobante COIN generado: " + nroComprob + " para cod. operacion " + socComprobante.getCpbCodigo());
		
		ComprobanteId idC = new ComprobanteId(CENTRO, TIPO_C, nroComprob);

		Comprobante cpb = new Comprobante();

		final String ESQUEMA = "LD0004";
		
		cpb.setComprobanteId(idC);
		cpb.setGestion(socComprobante.getCpbGestion());
		cpb.setNroPeriodo(socComprobante.getCpbPeriodo());
		cpb.setNroDia(socComprobante.getCpbDia());
		cpb.setFechaValor(new Date());
		cpb.setFactorConvUsMn(socComprobante.getCpbTipocambio());
		cpb.setGlosaComprob(socComprobante.getCpbGlosa());
		cpb.setCodEsquema(ESQUEMA);
		if (!StringUtils.isBlank(socComprobante.getEsqCodesqcont())){
			cpb.setCodEsquema(socComprobante.getEsqCodesqcont());
		}
		cpb.setCveEstadoComprob(ESTADO);
		cpb.setCodUsuario(socComprobante.getUsrCodigo()) ;
		cpb.setFechaHora(new Date());
		cpb.setEstacion(socComprobante.getEstacion());
		cpb.setCodUnidad(UNIDAD);
		cpb.setCveDevReal('N');
	    
		this.getHibernateTemplate().save(cpb);
		log.info("Comprobante COIN guardado: " + nroComprob + " para cod. operacion " + socComprobante.getCpbCodigo());
		
		rengCompDao.crearRenglones(cpb, socComprobante, rengs);
		
		facturaDao.crearFacturas(cpb, facts);
		impOrdenPagoDao.crearOrdenPago(cpb, socOrdenesPagoLista);

		// GWENERAMOS el estado comprobante
		EstadoComprobId estadoComprobId = new EstadoComprobId();
		estadoComprobId.setNroCentro(cpb.getComprobanteId().getNroCentro());
		estadoComprobId.setCveTipoComprob(cpb.getComprobanteId().getCveTipoComprob());
		estadoComprobId.setNroComprob(nroComprob);
		estadoComprobId.setCveEstadoComprob(Constants.CLAVE_ESTCOMP_PEND);

		EstadoComprob estadoComprob = new EstadoComprob(estadoComprobId, socComprobante.getUsrCodigo(), new Date(), socComprobante.getEstacion());

		this.getHibernateTemplate().save(estadoComprob);
		
		Comprobante cpbNew = cambiarEstadoComprobante(cpb);
		
		return cpbNew;
	}

	public Comprobante cambiarEstadoComprobante(Comprobante comp) {
		Comprobante cpb0 = getHibernateTemplate().get(Comprobante.class, comp.getComprobanteId());
		if (cpb0 == null) {
			log.error("No se encontro comprobante Contable: " + comp.getComprobanteId().getNroComprob());
			throw new RuntimeException("No se pudo encontrar comprobante: " + comp.getComprobanteId().getNroComprob());
		}
		if (cpb0.getCveEstadoComprob() != '1') {
			log.error("Comprobante Contable: " + cpb0.getComprobanteId().getNroComprob() + " en estado incorrecto ");
			throw new RuntimeException("Comprobante Contable: " + cpb0.getComprobanteId().getNroComprob() + " en estado incorrecto ");
		}
		// Comprobante cpb0 = getComprobante(nroComprob);

		EstadoComprobDao estadoComprobDao = new EstadoComprobDao();
		estadoComprobDao.setSessionFactory(getSessionFactory());

		EstadoComprobId estadoComprobId = new EstadoComprobId();
		estadoComprobId.setNroCentro(cpb0.getComprobanteId().getNroCentro());
		estadoComprobId.setCveTipoComprob(cpb0.getComprobanteId().getCveTipoComprob());
		estadoComprobId.setNroComprob(cpb0.getComprobanteId().getNroComprob());
		estadoComprobId.setCveEstadoComprob("1");

		EstadoComprob estadoComprob = new EstadoComprob(estadoComprobId, cpb0.getCodUsuario(), new Date(), cpb0.getEstacion());
		log.info("Antes de aprobacin comprobante: " + cpb0.getComprobanteId().getNroComprob());
		//estadoComprobDao.saveOrUpdate(estadoComprob);
		this.getHibernateTemplate().save(estadoComprob);
		// proceso de aprobacion en coin cambio de estado a Aprobado

		cpb0.setCveEstadoComprob('A');
		//this.saveOrUpdate(cpb0);
		this.getHibernateTemplate().update(cpb0);
		
		Comprobante cpbNew = getHibernateTemplate().get(Comprobante.class, comp.getComprobanteId());
		
		if (!String.valueOf(cpbNew.getCveEstadoComprob()).equals(Constants.CLAVE_ESTCOMP_AUT)) {
			throw new BusinessException("Error estado del comprobante en autorizar "
					+ comp.getComprobanteId().getNroComprob() + " con estado " + cpbNew.getCveEstadoComprob());
		}
		
		log.info("Comprobante COIN APROBADO: " + cpbNew.getComprobanteId().getNroComprob());
		return cpbNew;

	}

	public String CrearComprobante(SocComprobante comp, List<SocRengscomp> rengs, List<SocFacturas> facts) {
		boolean comprobAprobado = false;
		String nroComprob = "";
		Boolean renglones = true;
		nroComprob = this.getNroComprob(CENTRO, TIPO_C);
		if (nroComprob == null || nroComprob.equals("0000000") || nroComprob.trim().isEmpty()) {
			log.error("Error al generar nro de comprobante centro: " + CENTRO + " tipo: " + TIPO_C);
			throw new RuntimeException("Error al generar nro de comprobante centro: " + CENTRO + " tipo: " + TIPO_C);
		}
		ComprobanteId idC = new ComprobanteId(CENTRO, TIPO_C, nroComprob);
		String USUARIO = ServiciosSioc.getParam("@usuario");
		String ESTACION = (String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION);
		
		String ESQUEMA = "LD0004";

		Comprobante cpb = new Comprobante(idC, comp.getCpbGestion(), comp.getCpbPeriodo(), comp.getCpbDia(), new Date(), comp.getCpbTipocambio(),
				comp.getCpbGlosa(), ESQUEMA, ESTADO, USUARIO, new Date(), ESTACION, UNIDAD, 'N');

		if (!StringUtils.isBlank(comp.getEsqCodesqcont())){
			cpb.setCodEsquema(comp.getEsqCodesqcont());
		}
		
		this.getHibernateTemplate().save(cpb);
		SiocCoinService.flush();

		log.info("Comprobante COIN guardado: " + nroComprob + " para cod. operacion " + comp.getCpbCodigo());

		RengComprobDao rengCompDao = new RengComprobDao();
		rengCompDao.setSessionFactory(getSessionFactory());

		renglones = rengCompDao.CrearRenglones(idC, rengs, facts);

		if (!renglones) {
			log.error("error al generar renglones Comprobante " + nroComprob + " nor op. " + comp.getCpbCodigo());
			throw new RuntimeException("error al generar renglones Comprobante " + nroComprob + " nor op. " + comp.getCpbCodigo());
		}
		SiocCoinService.flush();

		// GWENERAMOS el estado comprobante
		EstadoComprobId estadoComprobId = new EstadoComprobId();
		estadoComprobId.setNroCentro(CENTRO);
		estadoComprobId.setCveTipoComprob(TIPO_C);
		estadoComprobId.setNroComprob(nroComprob);
		estadoComprobId.setCveEstadoComprob("P");

		EstadoComprobDao estadoComprobDao = new EstadoComprobDao();
		estadoComprobDao.setSessionFactory(getSessionFactory());
		EstadoComprob estadoComprob = new EstadoComprob(estadoComprobId, USUARIO, new Date(), ESTACION);

		this.getHibernateTemplate().save(estadoComprob);
		SiocCoinService.flush();
		estadoComprobId = new EstadoComprobId();
		estadoComprobId.setNroCentro(CENTRO);
		estadoComprobId.setCveTipoComprob(TIPO_C);
		estadoComprobId.setNroComprob(nroComprob);
		estadoComprobId.setCveEstadoComprob("1");

		estadoComprob = new EstadoComprob(estadoComprobId, USUARIO, new Date(), ESTACION);
		log.info("Antes de aprobacion comprobante: " + nroComprob);
		this.getHibernateTemplate().save(estadoComprob);
		SiocCoinService.flush();

		Comprobante cpb0 = getComprobante(nroComprob);
		// proceso de aprobacion en coin cambio de estado a Aprobado
		if (cpb0 != null) {
			if (cpb0.getCveEstadoComprob() != ' ' && cpb0.getCveEstadoComprob() == '1') {
				cpb0.setCveEstadoComprob('A');
				this.getHibernateTemplate().save(cpb0);

				SiocCoinService.flush();
				comprobAprobado = true;
				log.info("Comprobante COIN APROBADO: " + nroComprob + " para cod. operacion " + comp.getCpbCodigo());
			} else {
				log.error("Comprobante Contable: " + nroComprob + " para cod. " + comp.getCpbCodigo() + " en estado incorrecto ["
						+ cpb0.getCveEstadoComprob() + "]");
				throw new RuntimeException("Comprobante Contable: " + nroComprob + " para cod. " + comp.getCpbCodigo() + " en estado incorrecto ["
						+ cpb0.getCveEstadoComprob() + "]");
			}
		} else {
			log.error("No se encontro comprobante Contable: " + nroComprob + " para cod. " + comp.getCpbCodigo());
			throw new RuntimeException("No se pudo encontrar comprobante: " + nroComprob + " para cod. " + comp.getCpbCodigo());
		}

		if (comprobAprobado && !StringUtils.isBlank(nroComprob)) {
			// verificamos que el comprob haya sido aprobado
			return nroComprob;
		} else {
			log.error("Comprobante Contable: " + nroComprob + " NO APROBADO para cod. " + comp.getCpbCodigo() + " ");
			throw new RuntimeException("Comprobante Contable: " + nroComprob + " NO APROBADO para cod. " + comp.getCpbCodigo() + " ");
		}
	}

	public String getCodMayorFromNroMayor (String renMayor) {
		StringBuffer query = new StringBuffer();
		query = query.append("select cm.cod_mayor ");
		query = query.append("from cuenta_mayor cm, concepto_mayor com ");
		query = query.append("where cm.cod_mayor = com.cod_mayor ");
		query = query.append("and cm.nro_mayor = :renMayor ");
		Query consulta = getSession().createSQLQuery(query.toString());

		consulta.setParameter("renMayor", renMayor);
		String codMayor = "";
		List result = consulta.list();
		if (result.size() > 0)
			codMayor = (String) result.get(0);

		return codMayor;
	}
	
}
