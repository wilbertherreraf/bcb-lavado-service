package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;
import java.util.Date;

import gob.bcb.core.infra.datastore.BcbEntity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "estado_comprob")
public class EstadoComprob extends BcbEntity {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	private EstadoComprobId id;

	@Basic(optional = false)
	@Column(name = "cod_usuario")
	private String codUsuario;
	@Basic(optional = false)
	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Column(name = "estacion")
	private String estacion;

	public EstadoComprob() {

	}

	public EstadoComprob(EstadoComprobId id, String codUsuario, Date fechaHora, String estacion) {
		this.id = id;
		this.codUsuario = codUsuario;
		this.fechaHora = fechaHora;
		this.estacion = estacion;
	}

	public void setId(EstadoComprobId id) {
		this.id = id;
	}

	public EstadoComprobId getId() {
		return id;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

}
