/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.commons.Servicios
 * 26/07/2011 - 14:35:05
 * Creado por Gustavo Flores
 */
package gob.bcb.service.servicioTres.model;

import gob.bcb.core.persist.EntityUserTransaction;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.joda.time.DateTime;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

/**
 * Clase que contiene los metodos para comunicarse con la capa de bpm y
 * servicios.
 * 
 * @author Gustavo Flores
 * 
 */
public class Servicios {
	private static final Log log = LogFactory.getLog(Servicios.class);

	public static List<Map<String, Object>> ejecutarQuery(String query, String[] namesColumns) {
		log.info("Consulta nativa : " + query);
		if (!SiocCoinService.isActive()){
			SiocCoinService.begin();
		}
		Session session = SessionFactoryUtils.getSession(SiocCoinService.getSessionFactory(), false);
		List<Map<String, Object>> resultado = new ArrayList<Map<String, Object>>();
		SQLQuery sQLQuery = session.createSQLQuery(query);
		List result = sQLQuery.list();
		Iterator iter = result.iterator();
		if (!iter.hasNext()) {
			log.debug("No objects to display."  + query);
			return resultado;
		}

		while (iter.hasNext()) {
			Map<String, Object> fila = new LinkedHashMap<String, Object>();
			Object objeto = iter.next();
			Class clazz = objeto.getClass();

			if (clazz.isArray()) {
				// Object[] obj = (Object[]) iter.next();
				int length = Array.getLength(objeto);
				Object[] obj = (Object[]) objeto;
				for (int i = 0; i < length; i++) {
					fila.put((i > namesColumns.length ? String.valueOf(i) : namesColumns[i].trim()), obj[i]);
				}
				resultado.add(fila);
			} else {
				fila.put(namesColumns[0], objeto);
				resultado.add(fila);
			}

		}
		return resultado;
	}

	public static BigDecimal getSaldo(String afect, int gestion, int periodo, int dia) {
		BigDecimal saldo = BigDecimal.valueOf(0.00);
		BigDecimal debe = BigDecimal.valueOf(0.00);
		BigDecimal haber = BigDecimal.valueOf(0.00);

		String query = " select nvl(sum(debe_mo),0) as debe, nvl(sum(haber_mo),0) as haber " + "from afectable_periodo " + "where nro_afectable = '"
				+ afect + "' and gestion < " + gestion;

		List<Map<String, Object>> resultado = ejecutarQuery(query, "debe, haber".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				debe = (BigDecimal) res.get("debe");
				haber = (BigDecimal) res.get("haber");
				saldo = saldo.add(debe).subtract(haber);
			}

			query = "select nvl(sum(debe_mo),0) as debe, nvl(sum(haber_mo),0) as haber " + "from afectable_periodo " + "where nro_afectable = '"
					+ afect + "' and gestion = " + gestion + " and nro_periodo < " + periodo;

			List<Map<String, Object>> resultado1 = ejecutarQuery(query, "debe, haber".split(","));
			if (resultado1.size() == 1) {
				for (Map<String, Object> res : resultado1) {
					debe = (BigDecimal) res.get("debe");
					haber = (BigDecimal) res.get("haber");
					saldo = saldo.add(debe).subtract(haber);
				}

				query = "select nvl(sum(debe_mo),0) as debe, nvl(sum(haber_mo),0) as haber " + "from afectable_dia " + "where nro_afectable = '"
						+ afect + "' and gestion = " + gestion + " and nro_periodo = " + periodo + " and nro_dia <= " + dia;

				List<Map<String, Object>> resultado2 = ejecutarQuery(query, "debe, haber".split(","));
				if (resultado2.size() == 1) {
					for (Map<String, Object> res : resultado2) {
						debe = (BigDecimal) res.get("debe");
						haber = (BigDecimal) res.get("haber");
						saldo = saldo.add(debe).subtract(haber);
					}
				} else {
					log.info("Error al obtener el saldo de la cuenta");
					saldo = BigDecimal.valueOf(0.00);
				}
			} else {
				log.info("Error al obtener el saldo de la cuenta");
				saldo = BigDecimal.valueOf(0.00);
			}
		} 
		return saldo;
	}

	public static char getTipo(String mov) {
		char tipo = ' ';

		String query = "select cc.cve_tipo_mayor " + "from concepto_mayor cc, cuenta_movimiento mm "
				+ "where substr(mm.cod_tipo_cuenta,1,4) = cc.cod_mayor " + "and mm.cod_movimiento = '" + mov + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "cve_tipo_mayor".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				tipo = (Character) res.get("cve_tipo_mayor");
			}
		} 
		if (resultado.size() != 1 || tipo == ' ') {
			log.error("Error al obtener tipo mayor [mov:" + mov + "]");
			throw new RuntimeException("Error al obtener tipo mayor [mov:" + mov + "]");			
		}

		return tipo;
	}

	public static Integer getSobregiro(String afec) {
		int ss = 0;
		String ssS = "";

		String query = "select count(nro_afectable) as sobre " + "from sobregiro " + "where nro_afectable = '" + afec + "' "
				+ "and cod_unidad = 'D0004' " + "and cve_vigente = 'V'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "sobre".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				ssS = res.get("sobre").toString();
				ss = Integer.parseInt(ssS);
			}
		} else {
			log.error("Error al obtener sobregiro nro_afectable: " + afec);
			throw new RuntimeException("Error al obtener sobregiro nro_afectable: " + afec);
		}

		return ss;
	}

	public static String getMovimiento(String cod) {
		String mov = "";

		String query = " select cod_movimiento || '' cod_movimiento " + " from cuenta_afectable " + " where nro_afectable = '" + cod + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "cod_movimiento".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				mov = (String) res.get("cod_movimiento");
			}
		} else {
			log.info("Error al obtener cuenta movimiento para nro_afectable: " + cod);
			throw new RuntimeException("Error al obtener cuenta movimiento para nro_afectable: " + cod);
		}

		return mov;
	}

	public static boolean sobregirada(String mov, String afec, char dh, BigDecimal monto) {
		boolean ss = false; 
		BigDecimal saldoP = BigDecimal.ZERO;
		DateTime hoy = new DateTime();

		BigDecimal saldo = getSaldo(afec, hoy.getYear(), hoy.getMonthOfYear(), hoy.getDayOfMonth());
		char tipo = getTipo(mov.trim());
		if (tipo == 'A' || tipo == 'E') {
			if (dh == 'H') {
				saldoP = saldo.subtract(monto);
				if (saldoP.compareTo(BigDecimal.valueOf(0.00)) < 0) {
					if (getSobregiro(afec) == 0)
						ss = true;
				}
			}
		} else {
			if (tipo == 'P' || tipo == 'I' || tipo == 'C') {
				if (dh == 'D') {
					saldoP = saldo.add(monto);
					if (saldoP.compareTo(BigDecimal.valueOf(0.00)) > 0) {
						if (getSobregiro(afec) == 0)
							ss = true;
					}
				}
			}
		}

		if (ss)
			log.info("Cuenta [mov:" + mov + ",afec:" + afec + "] CON SOBREGIRO saldo: " + saldoP.toPlainString());
		else
			log.info("Cuenta [mov:" + mov + ",afec:" + afec + "] SIN sobregiro saldo: " + saldoP.toPlainString());
		return ss;
	}

	public static Integer getConciliable(String codigo) {
		int corr = 0;

		String query = " select nro_concilia as corr" + " from reng_concilia " + " where nro_centro = 1 " + " and cve_tipo_comprob = 'G' "
				+ " and nro_comprob = '" + codigo + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "corr".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				corr = (Integer) res.get("corr");
			}
		} else {
			log.info("Error al obtener numero concilia");
		}

		return corr;
	}

	public static String getGlosa(String cod) {
		String glosa = "";

		String query = " select glosa_comprob || '' glosa_comprob " + " from comprobante " + " where nro_centro = 1 "
				+ " and cve_tipo_comprob = 'G' " + " and nro_comprob = '" + cod + "'";

		List<Map<String, Object>> resultado = ejecutarQuery(query, "glosa_comprob".split(","));
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				glosa = (String) res.get("glosa_comprob");
			}
		} else {
			log.info("Error al obtener glosa comprobante");
		}

		return glosa;
	}

	public static String obtGestion() {
		String formato = "yyyy";
		SimpleDateFormat dateFormat = new SimpleDateFormat(formato);
		return dateFormat.format(new Date());
	}

}
