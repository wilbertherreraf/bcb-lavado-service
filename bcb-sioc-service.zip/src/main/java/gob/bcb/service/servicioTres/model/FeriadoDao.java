/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * SIOC
 * gob.bcb.service.servicioTres.model.FeriadoDao
 * 24/03/2017 - 14:07:17
 * Created by Erick Borda Mercado
 */
package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;
import gob.bcb.core.utils.UtilsQNatives;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author eborda
 * 
 */

public class FeriadoDao extends HibernateDaoSupport {

	private static final Log log = LogFactory.getLog(FacturaConceptoSinCreditoDao.class);
	
	
	public boolean existeFeriado(String fechaInicio, String fechaFin){
		boolean resultado = false;
		String query = " SELECT fecha_feriado FROM feriado WHERE fecha_feriado BETWEEN '" + fechaInicio  + "' AND '" + fechaFin + "'";
		Query consulta = getSession().createSQLQuery(query.toString());
		
		List lista = consulta.list();

		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "fecha_feriado,desc_feriado".split(","));
		
		if(resultadoQuery.size() > 0){
			resultado = true;
		}
		
		return resultado;
	}
	
	
	public List<Feriado> obtenerFeriados(String fechaInicio, String fechaFin){
		List<Feriado> resultado = new ArrayList<Feriado>();
		Feriado feriado = null;
		
		String query = " SELECT fecha_feriado, desc_feriado FROM feriado WHERE fecha_feriado BETWEEN '" + fechaInicio  + "' AND '" + fechaFin + "'";
		
		Query consulta = getSession().createSQLQuery(query.toString());
		
		List lista = consulta.list();
		
		List<Map<String, Object>> resultadoQuery = UtilsQNatives
				.convertListToMap(lista, "fecha_feriado,desc_feriado".split(","));
		
		for (Map<String, Object> fe : resultadoQuery) {
			feriado = new Feriado();
			feriado.setFechaFeriado((Date) fe.get("fecha_feriado"));
			feriado.setDescFeriado((String) fe.get("desc_feriado"));
			resultado.add(feriado);
		}
		
		return resultado;
	}	
}
