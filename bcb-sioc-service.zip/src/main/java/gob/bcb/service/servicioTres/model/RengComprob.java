/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import gob.bcb.core.infra.datastore.BcbEntity;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "reng_comprob")
@NamedQueries({ @NamedQuery(name = "RengComprob.findAll", query = "SELECT r FROM RengComprob r") })
public class RengComprob extends BcbEntity {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	protected RengComprobId id;
	@Basic(optional = false)
	@Column(name = "cve_debe_haber")
	private char cveDebeHaber;
	@Basic(optional = false)
	@Column(name = "monto_mo")
	private BigDecimal montoMo;
	@Basic(optional = false)
	@Column(name = "factor_conv_mo_mn")
	private BigDecimal factorConvMoMn;
	@Column(name = "glosa_reng")
	private String glosaReng;
	@Basic(optional = false)
	@Column(name = "nro_mayor")
	private String nroMayor;
	@Basic(optional = false)
	@Column(name = "nro_afectable")
	private String nroAfectable;
	@Column(name = "nro_reng_esq")
	private Integer nroRengEsq;
	@Basic(optional = false)
	@Column(name = "monto_mn")
	private BigDecimal montoMn;
//	@OneToMany(mappedBy = "rengComprob")
//	private List<RengConcilia> rengConciliaList;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "rengComprob")
	private List<ImpOrdenPago> impOrdenPagoList;

	public RengComprob() {
	}

	public RengComprob(RengComprobId id) {
		this.id = id;
	}

	public RengComprob(RengComprobId id, char cveDebeHaber, BigDecimal montoMo, BigDecimal factorConvMoMn, String nroMayor, String nroAfectable,
			BigDecimal montoMn) {
		this.id = id;
		this.cveDebeHaber = cveDebeHaber;
		this.montoMo = montoMo;
		this.factorConvMoMn = factorConvMoMn;
		this.nroMayor = nroMayor;
		this.nroAfectable = nroAfectable;
		this.montoMn = montoMn;
	}

	public RengComprob(RengComprobId id, char cveDebeHaber, BigDecimal montoMo, BigDecimal factorConvMoMn, String glosaReng, String nroMayor,
			String nroAfectable, BigDecimal montoMn) {
		this.id = id;
		this.cveDebeHaber = cveDebeHaber;
		this.montoMo = montoMo;
		this.factorConvMoMn = factorConvMoMn;
		this.glosaReng = glosaReng;
		this.nroMayor = nroMayor;
		this.nroAfectable = nroAfectable;
		this.montoMn = montoMn;
	}

	public RengComprob(RengComprobId id, char cveDebeHaber, BigDecimal montoMo, BigDecimal factorConvMoMn, String glosaReng, String nroMayor,
			String nroAfectable, Integer nroRengEsq, BigDecimal montoMn) {
		this.id = id;
		this.cveDebeHaber = cveDebeHaber;
		this.montoMo = montoMo;
		this.factorConvMoMn = factorConvMoMn;
		this.glosaReng = glosaReng;
		this.nroMayor = nroMayor;
		this.nroAfectable = nroAfectable;
		this.nroRengEsq = nroRengEsq;
		this.montoMn = montoMn;
	}

	public RengComprob(int nroCentro, char cveTipoComprob, String nroComprob, int nroReng) {
		this.id = new RengComprobId(nroCentro, cveTipoComprob, nroComprob, nroReng);
	}

	public RengComprobId getId() {
		return id;
	}

	public void setId(RengComprobId id) {
		this.id = id;
	}

	public char getCveDebeHaber() {
		return cveDebeHaber;
	}

	public void setCveDebeHaber(char cveDebeHaber) {
		this.cveDebeHaber = cveDebeHaber;
	}

	public BigDecimal getMontoMo() {
		return montoMo;
	}

	public void setMontoMo(BigDecimal montoMo) {
		this.montoMo = montoMo;
	}

	public BigDecimal getFactorConvMoMn() {
		return factorConvMoMn;
	}

	public void setFactorConvMoMn(BigDecimal factorConvMoMn) {
		this.factorConvMoMn = factorConvMoMn;
	}

	public String getGlosaReng() {
		return glosaReng;
	}

	public void setGlosaReng(String glosaReng) {
		this.glosaReng = glosaReng;
	}

	public String getNroMayor() {
		return nroMayor;
	}

	public void setNroMayor(String nroMayor) {
		this.nroMayor = nroMayor;
	}

	public String getNroAfectable() {
		return nroAfectable;
	}

	public void setNroAfectable(String nroAfectable) {
		this.nroAfectable = nroAfectable;
	}

	public Integer getNroRengEsq() {
		return nroRengEsq;
	}

	public void setNroRengEsq(Integer nroRengEsq) {
		this.nroRengEsq = nroRengEsq;
	}

	public BigDecimal getMontoMn() {
		return montoMn;
	}

	public void setMontoMn(BigDecimal montoMn) {
		this.montoMn = montoMn;
	}

//	public List<RengConcilia> getRengConciliaList() {
//		return rengConciliaList;
//	}
//
//	public void setRengConciliaList(List<RengConcilia> rengConciliaList) {
//		this.rengConciliaList = rengConciliaList;
//	}

	public List<ImpOrdenPago> getImpOrdenPagoList() {
		return impOrdenPagoList;
	}

	public void setImpOrdenPagoList(List<ImpOrdenPago> impOrdenPagoList) {
		this.impOrdenPagoList = impOrdenPagoList;
	}

	
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not
		// set
		if (!(object instanceof RengComprob)) {
			return false;
		}
		RengComprob other = (RengComprob) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	
	public String toString() {
		return "RengComprob [id=" + id + ", cveDebeHaber=" + cveDebeHaber + ", montoMo=" + montoMo + ", factorConvMoMn=" + factorConvMoMn
				+ ", glosaReng=" + glosaReng + ", nroMayor=" + nroMayor + ", nroAfectable=" + nroAfectable + ", nroRengEsq=" + nroRengEsq
				+ ", montoMn=" + montoMn + ", impOrdenPagoList=" + impOrdenPagoList + "]";
	}


}
