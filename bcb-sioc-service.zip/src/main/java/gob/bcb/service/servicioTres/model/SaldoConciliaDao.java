/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.servicioSioc.common.Constants;

/**
 * @author parenas
 * 
 */
public class SaldoConciliaDao extends HibernateDaoSupport {
	private static final String ACREE = "001665";

	private static final Log log = LogFactory.getLog(SaldoConciliaDao.class);

	public List<SaldoConcilia> findSaldosConcilia(String nroAfectable, String nroComprob) {
		StringBuffer query = new StringBuffer();
		query = query.append("select sco ");
		query = query.append("from SaldoConcilia sco ");
		query = query.append("where sco.nroAfectable = :nroAfectable ");
		query = query.append("and sco.saldo != 0 ");

		if (!StringUtils.isBlank(nroComprob)) {
			query = query.append("and exists (select 1 ");
			query = query.append("from RengConcilia rco ");
			query = query.append("where sco.id.nroConcilia = rco.id.nroConcilia ");
			query = query.append("and rco.nroComprob = :nroComprob) ");
		}

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("nroAfectable", nroAfectable);
		if (!StringUtils.isBlank(nroComprob))
			consulta.setParameter("nroComprob", nroComprob);

		List result = consulta.list();
		return result;
	}

	public SaldoConcilia getSaldoById(Integer nroConcilia, Integer gestion) {
		StringBuffer query = new StringBuffer();
		query = query.append("select ss ");
		query = query.append("from SaldoConcilia ss ");
		query = query.append("where ss.id.gestion = :gestion ");
		query = query.append("and ss.id.nroConcilia = :nroConcilia ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("gestion", gestion);
		consulta.setParameter("nroConcilia", nroConcilia);		
		
		log.info("Buscando GetSaldoC con el id: " + nroConcilia + " " + query.toString());
		List result = consulta.list();
		if (result.size() > 0)
			return (SaldoConcilia) result.get(0); 
		return null;
	}

	public SaldoConcilia findMax(Integer gestion) {
		StringBuffer query = new StringBuffer();
		query = query.append("select re ");
		query = query.append("from SaldoConcilia re ");
		query = query.append("where re.id.gestion = :gestion ");		
		query = query.append("and re.id.nroConcilia = (select max(r1.id.nroConcilia) from SaldoConcilia r1 where r1.id.gestion = re.id.gestion) ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("gestion", gestion);
		
		List lista = consulta.list();
		if (lista.size() > 0) {
			return (SaldoConcilia) lista.get(0);
		}
		return null;
	}
	public Integer getCodigo(Integer gestion) {
		SaldoConcilia loader = findMax(gestion);
		if (loader == null){
			logger.info("NroConcilia 1");			
			return 1;
		}
 
		Integer codigo = loader.getId().getNroConcilia() + 1;
		logger.info("NroConcilia : " + codigo);		
		return codigo;

	}
	
	public Integer CrearSaldoConcilia(BigDecimal monto) {
		int corr = getCodigo(Integer.parseInt(Servicios.obtGestion()));

		SaldoConcilia concilia = new SaldoConcilia(new SaldoConciliaId(corr, Integer.parseInt(Servicios.obtGestion())), ACREE, 'H', monto,
				(String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
				(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		this.getHibernateTemplate().saveOrUpdate(concilia);

		log.info("Saldo Concilia creado: " + concilia.toString());

		return corr;
	}

	public SaldoConcilia crearSaldoConcilia(BigDecimal monto, Character cveNaturalezaCta, String ctaAfectableAcreedores, Integer gestion) {
		int corr = getCodigo(gestion);

		SaldoConcilia concilia = new SaldoConcilia(new SaldoConciliaId(corr, gestion), ctaAfectableAcreedores,
				cveNaturalezaCta, monto, (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
				(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

		this.getHibernateTemplate().saveOrUpdate(concilia);

		log.info("Saldo Concilia creado: " + concilia.toString());

		return concilia;
	}
}
