/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Embeddable
public class FactorConvMnId implements Serializable
{
  @Basic(optional = false)
  @Column(name = "cod_moneda")
  private String codMoneda;
  @Basic(optional = false)
  @Column(name = "fecha_dia")
  @Temporal(TemporalType.DATE)
  private Date fechaDia;

  public FactorConvMnId()
  {
  }

  public FactorConvMnId(String codMoneda, Date fechaDia)
  {
    this.codMoneda = codMoneda;
    this.fechaDia = fechaDia;
  }

  public String getCodMoneda()
  {
    return codMoneda;
  }

  public void setCodMoneda(String codMoneda)
  {
    this.codMoneda = codMoneda;
  }

  public Date getFechaDia()
  {
    return fechaDia;
  }

  public void setFechaDia(Date fechaDia)
  {
    this.fechaDia = fechaDia;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (codMoneda != null ? codMoneda.hashCode() : 0);
    hash += (fechaDia != null ? fechaDia.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof FactorConvMnId))
    {
      return false;
    }
    FactorConvMnId other = (FactorConvMnId) object;
    if ((this.codMoneda == null && other.codMoneda != null) || (this.codMoneda != null && !this.codMoneda.equals(other.codMoneda)))
    {
      return false;
    }
    if ((this.fechaDia == null && other.fechaDia != null) || (this.fechaDia != null && !this.fechaDia.equals(other.fechaDia)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.FactorConvMnId[codMoneda=" + codMoneda + ", fechaDia=" + fechaDia + "]";
  }

}
