/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * 
 * @author faflores
 */
@Embeddable
public class SaldoConciliaId implements Serializable
{
  @Basic(optional = false)
  @Column(name = "nro_concilia")
  private int nroConcilia;
  @Basic(optional = false)
  @Column(name = "gestion")
  private int gestion;

  public SaldoConciliaId()
  {
  }

  public SaldoConciliaId(int nroConcilia, int gestion)
  {
    this.nroConcilia = nroConcilia;
    this.gestion = gestion;
  }

  public int getNroConcilia()
  {
    return nroConcilia;
  }

  public void setNroConcilia(int nroConcilia)
  {
    this.nroConcilia = nroConcilia;
  }

  public int getGestion()
  {
    return gestion;
  }

  public void setGestion(int gestion)
  {
    this.gestion = gestion;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (int) nroConcilia;
    hash += (int) gestion;
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof SaldoConciliaId))
    {
      return false;
    }
    SaldoConciliaId other = (SaldoConciliaId) object;
    if (this.nroConcilia != other.nroConcilia)
    {
      return false;
    }
    if (this.gestion != other.gestion)
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioTres.model.SaldoConciliaId[nroConcilia=" + nroConcilia + ", gestion=" + gestion + "]";
  }

}
