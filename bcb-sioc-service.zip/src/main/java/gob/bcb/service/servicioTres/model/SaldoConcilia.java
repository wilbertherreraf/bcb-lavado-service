/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import gob.bcb.core.infra.datastore.BcbEntity;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "saldo_concilia")
@NamedQueries({ @NamedQuery(name = "SaldoConcilia.findAll", query = "SELECT s FROM SaldoConcilia s") })
public class SaldoConcilia extends BcbEntity {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	protected SaldoConciliaId id;
	@Basic(optional = false)
	@Column(name = "nro_afectable")
	private String nroAfectable;
	@Basic(optional = false)
	@Column(name = "cve_naturaleza_cta")
	private char cveNaturalezaCta;
	@Basic(optional = false)
	@Column(name = "saldo")
	private BigDecimal saldo;
	@Basic(optional = false)
	@Column(name = "cod_usuario")
	private String codUsuario;
	@Basic(optional = false)
	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Basic(optional = false)
	@Column(name = "estacion")
	private String estacion;
//	@OneToMany(cascade = CascadeType.ALL, mappedBy = "saldoConcilia")
//	private List<RengConcilia> rengConciliaList;

	public SaldoConcilia() {
	}

	public SaldoConcilia(SaldoConciliaId id) {
		this.id = id;
	}

	public SaldoConcilia(SaldoConciliaId id, String nroAfectable, char cveNaturalezaCta, BigDecimal saldo, String codUsuario, Date fechaHora,
			String estacion) {
		this.id = id;
		this.nroAfectable = nroAfectable;
		this.cveNaturalezaCta = cveNaturalezaCta;
		this.saldo = saldo;
		this.codUsuario = codUsuario;
		this.fechaHora = fechaHora;
		this.estacion = estacion;
	}

	public SaldoConcilia(int nroConcilia, int gestion) {
		this.id = new SaldoConciliaId(nroConcilia, gestion);
	}

	public SaldoConciliaId getId() {
		return id;
	}

	public void setId(SaldoConciliaId id) {
		this.id = id;
	}

	public String getNroAfectable() {
		return nroAfectable;
	}

	public void setNroAfectable(String nroAfectable) {
		this.nroAfectable = nroAfectable;
	}

	public char getCveNaturalezaCta() {
		return cveNaturalezaCta;
	}

	public void setCveNaturalezaCta(char cveNaturalezaCta) {
		this.cveNaturalezaCta = cveNaturalezaCta;
	}

	public BigDecimal getSaldo() {
		return saldo;
	}

	public void setSaldo(BigDecimal saldo) {
		this.saldo = saldo;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

//	public List<RengConcilia> getRengConciliaList() {
//		return rengConciliaList;
//	}
//
//	public void setRengConciliaList(List<RengConcilia> rengConciliaList) {
//		this.rengConciliaList = rengConciliaList;
//	}

	
	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not
		// set
		if (!(object instanceof SaldoConcilia)) {
			return false;
		}
		SaldoConcilia other = (SaldoConcilia) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	
	public String toString() {
		return "SaldoConcilia [id=" + id + ", nroAfectable=" + nroAfectable + ", cveNaturalezaCta=" + cveNaturalezaCta + ", saldo=" + saldo
				+ ", codUsuario=" + codUsuario + ", fechaHora=" + fechaHora + ", estacion=" + estacion + "]";
	}

}
