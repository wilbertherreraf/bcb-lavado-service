/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author wherrera
 * 
 */
public class RengConciliaDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(RengConciliaDao.class);

	public List<RengConcilia> findRengConciliaByAfecNroComprob(String nroAfectable, String nroComprob, Integer gestion) {
		StringBuffer query = new StringBuffer();
		query = query.append("select rco ");
		query = query.append("from SaldoConcilia sco, RengConcilia rco ");
		query = query.append("where sco.id.nroConcilia = rco.id.nroConcilia ");
		query = query.append("and sco.id.gestion = rco.id.gestion ");
		query = query.append("and sco.nroAfectable = :nroAfectable ");
		query = query.append("and sco.saldo != 0 ");

		if (!StringUtils.isBlank(nroComprob)) {
			query = query.append("and rco.nroComprob = :nroComprob ");
		}
		if (gestion != null)
			query = query.append("and rco.id.gestion = :gestion ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("nroAfectable", nroAfectable);
		if (!StringUtils.isBlank(nroComprob))
			consulta.setParameter("nroComprob", nroComprob);
		if (gestion != null)
			consulta.setParameter("gestion", gestion);

		List result = consulta.list();
		log.debug("Renglones conciliables: " + result.size());
		return result;
	}

	public RengConcilia findRengConciliaById(Integer nroConcilia, Integer gestion, Integer secRengConcilia, String nroComprob) {
		StringBuffer query = new StringBuffer();
		query = query.append("select rco ");
		query = query.append("from RengConcilia rco ");
		query = query.append("where rco.id.nroConcilia = :nroConcilia ");

		if (gestion != null)
			query = query.append("and rco.id.gestion = :gestion ");

		if (secRengConcilia != null)
			query = query.append("and rco.id.secRengConcilia = :secRengConcilia ");

		if (!StringUtils.isBlank(nroComprob)) {
			query = query.append("and rco.nroComprob = :nroComprob ");
		}

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("nroConcilia", nroConcilia);

		if (gestion != null)
			consulta.setParameter("gestion", gestion);
		if (secRengConcilia != null)
			consulta.setParameter("secRengConcilia", secRengConcilia);

		if (!StringUtils.isBlank(nroComprob))
			consulta.setParameter("nroComprob", nroComprob);

		List result = consulta.list();
		if (result.size() > 0)
			return (RengConcilia) result.get(0);
		return null;
	}

	public RengConcilia findRengConciliaById(Integer nroConcilia, Integer gestion) {
		StringBuffer query = new StringBuffer();
		query = query.append("select rco ");
		query = query.append("from RengConcilia rco ");
		query = query.append("where rco.id.nroConcilia = :nroConcilia ");
		query = query.append("and rco.id.gestion = :gestion ");
		query = query.append("and rco.id.secRengConcilia = (select max(rco1.id.secRengConcilia) ");
		query = query.append("from RengConcilia rco1 ");
		query = query.append("where rco1.id.nroConcilia = rco.id.nroConcilia ");
		query = query.append("and rco1.id.gestion = rco.id.gestion) ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("nroConcilia", nroConcilia);
		consulta.setParameter("gestion", gestion);

		List result = consulta.list();
		if (result.size() > 0)
			return (RengConcilia) result.get(0);
		return null;
	}

	public SaldoConcilia actualizaSaldoConcilia(Comprobante comprobante, RengComprob reng, Integer nroConcilia, Integer gestion) {
		log.info("Ingresando a Crear Saldo conciliable " + reng.getId().getNroComprob());

		SaldoConciliaDao saldoDao = new SaldoConciliaDao();
		saldoDao.setSessionFactory(getSessionFactory());

		SaldoConcilia saldoConcilia = saldoDao.getSaldoById(nroConcilia, gestion);
		if (saldoConcilia == null) {
			log.error("No se logro encontrar SaldoConciliable para nroConcilia " + nroConcilia + " - " + gestion);
			throw new BusinessException("No se logro encontrar SaldoConciliable para nroConcilia " + nroConcilia + " - " + gestion);
		}

		if (saldoConcilia.getSaldo().compareTo(BigDecimal.ZERO) == 0) {
			throw new BusinessException("SaldoConciliable con saldo CERO revise los datos " + nroConcilia + " - " + gestion);
		}

		RengConcilia conciliaMax = findRengConciliaById(nroConcilia, gestion);
		Integer secConcilia = 0;
		if (conciliaMax != null)
			secConcilia = conciliaMax.getId().getSecRengConcilia();
		secConcilia++;

		RengConcilia concilia = new RengConcilia(new RengConciliaId(nroConcilia, gestion, secConcilia),
				new RengComprob(new RengComprobId(reng.getId().getNroCentro(), reng.getId().getCveTipoComprob(), reng.getId().getNroComprob(),
						reng.getId().getNroReng())),
				reng.getGlosaReng(), new Date(), 'R', reng.getMontoMo().multiply(BigDecimal.valueOf(-1)), 'A', comprobante.getCodUsuario(),
				new Date(), comprobante.getEstacion());

		this.getHibernateTemplate().saveOrUpdate(concilia);
		log.info("Concilia guardada: " + concilia.toString());

		BigDecimal monto = saldoConcilia.getSaldo();
		saldoConcilia.setSaldo(monto.add(concilia.getImporte()));

		this.getHibernateTemplate().saveOrUpdate(saldoConcilia);
		log.info("Saldo Concilia atualizada: " + saldoConcilia.toString());
		return saldoConcilia;
	}

	public RengConcilia nuevoRengConcilia(Comprobante comprobante, RengComprob reng) {
		log.info("Ingresando a Crear Saldo conciliable " + reng.getId().getNroComprob());

		SaldoConciliaDao saldoDao = new SaldoConciliaDao();
		saldoDao.setSessionFactory(getSessionFactory());

		SaldoConcilia saldoConcilia = saldoDao.crearSaldoConcilia(reng.getMontoMo(), reng.getCveDebeHaber(), reng.getNroAfectable(),
				comprobante.getGestion());

		String glosa = getFormatoCodConcilia(saldoConcilia.getId().getNroConcilia(), saldoConcilia.getId().getGestion()) + " "
				+ comprobante.getGlosaComprob();

		RengConcilia concilia = new RengConcilia(new RengConciliaId(saldoConcilia.getId().getNroConcilia(), saldoConcilia.getId().getGestion(), 1),
				new RengComprob(new RengComprobId(reng.getId().getNroCentro(), reng.getId().getCveTipoComprob(), reng.getId().getNroComprob(),
						reng.getId().getNroReng())),
				glosa, new Date(), 'C', reng.getMontoMo(), 'A', comprobante.getCodUsuario(), new Date(), comprobante.getEstacion());

		this.getHibernateTemplate().saveOrUpdate(concilia);
		log.info("Renglon Concilia guardada: " + concilia.toString());
		return concilia;
	}

	public SaldoConcilia crearSaldoConcilia(Comprobante comprobante, RengComprob reng) {
		log.info("Ingresando a Crear Saldo conciliable " + reng.getId().getNroComprob());
		RengConcilia concilia;
		int corr = 0;
		SaldoConciliaDao saldoDao = new SaldoConciliaDao();
		saldoDao.setSessionFactory(getSessionFactory());
		SaldoConcilia saldoConcilia = null;
		if (reng.getId().getNroReng() == 1) {
			String corrS = reng.getGlosaReng().substring(6, 13);
			corr = Integer.parseInt(corrS);

			concilia = new RengConcilia(new RengConciliaId(corr, Integer.parseInt(Servicios.obtGestion()), 2),
					new RengComprob(new RengComprobId(reng.getId().getNroCentro(), reng.getId().getCveTipoComprob(), reng.getId().getNroComprob(),
							reng.getId().getNroReng())),
					reng.getGlosaReng(), new Date(), 'R', reng.getMontoMo().multiply(BigDecimal.valueOf(-1)), 'A',
					(String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
					(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

			this.getHibernateTemplate().saveOrUpdate(concilia);
			log.info("Concilia guardada: " + concilia.toString());

			saldoConcilia = saldoDao.getSaldoById(corr, Integer.parseInt(Servicios.obtGestion()));
			if (saldoConcilia == null) {
				log.error("No se logro encontrar SaldoConciliable para nroConcilia " + corr);
				throw new RuntimeException("No se logro encontrar SaldoConciliable para nroConcilia " + corr);
			}

			BigDecimal monto = saldoConcilia.getSaldo();
			saldoConcilia.setSaldo(monto.add(concilia.getImporte()));

			this.getHibernateTemplate().saveOrUpdate(saldoConcilia);
			log.info("Saldo Concilia atualizada: " + saldoConcilia.toString());
		} else {
			saldoConcilia = saldoDao.crearSaldoConcilia(reng.getMontoMo(), reng.getCveDebeHaber(), reng.getNroAfectable(), comprobante.getGestion());

			String glosa = comprobante.getGlosaComprob();
			String conc = String.format("%07d", saldoConcilia.getId().getNroConcilia());
			glosa = "(CC:H-" + conc + "-" + saldoConcilia.getId().getGestion() + ") " + glosa;

			concilia = new RengConcilia(new RengConciliaId(saldoConcilia.getId().getNroConcilia(), saldoConcilia.getId().getGestion(), 1),
					new RengComprob(new RengComprobId(reng.getId().getNroCentro(), reng.getId().getCveTipoComprob(), reng.getId().getNroComprob(),
							reng.getId().getNroReng())),
					glosa, new Date(), 'C', reng.getMontoMo(), 'A', (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
					(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

			this.getHibernateTemplate().saveOrUpdate(concilia);
			log.info("Renglon Concilia guardada: " + concilia.toString());
		}
		return saldoConcilia;
	}

	public Integer CrearConcilia(RengComprob reng) {
		log.info("Ingresando a Crear conciliable " + reng.getId().getNroComprob());
		RengConcilia concilia;
		int corr = 0;

		if (reng.getId().getNroReng() == 1) {
			String corrS = reng.getGlosaReng().substring(6, 13);
			corr = Integer.parseInt(corrS);

			concilia = new RengConcilia(new RengConciliaId(corr, Integer.parseInt(Servicios.obtGestion()), 2),
					new RengComprob(new RengComprobId(1, 'G', reng.getId().getNroComprob(), reng.getId().getNroReng())), reng.getGlosaReng(),
					new Date(), 'R', reng.getMontoMo().multiply(BigDecimal.valueOf(-1)), 'A',
					(String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
					(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

			this.getHibernateTemplate().saveOrUpdate(concilia);

			SaldoConciliaDao saldoDao = new SaldoConciliaDao();
			saldoDao.setSessionFactory(getSessionFactory());

			SaldoConcilia saldo = saldoDao.getSaldoById(corr, Integer.parseInt(Servicios.obtGestion()));
			if (saldo == null) {
				log.error("No se logro encontrar SaldoConciliable para nroConcilia " + corr);
				throw new RuntimeException("No se logro encontrar SaldoConciliable para nroConcilia " + corr);
			}

			BigDecimal monto = saldo.getSaldo();
			saldo.setSaldo(monto.add(reng.getMontoMo().multiply(BigDecimal.valueOf(-1))));

			this.getHibernateTemplate().saveOrUpdate(saldo);
		} else {
			// SaldoConciliaDao saldoDao = (SaldoConciliaDao)
			// SiocCoinService.factoryDao.getDao("SaldoConciliaDao");
			SaldoConciliaDao saldoDao = new SaldoConciliaDao();
			saldoDao.setSessionFactory(getSessionFactory());
			corr = saldoDao.CrearSaldoConcilia(reng.getMontoMo());
			String glosa = Servicios.getGlosa(reng.getId().getNroComprob());
			String conc = String.format("%07d", corr);
			glosa = "(CC:H-" + conc + "-" + Servicios.obtGestion() + ") " + glosa;

			concilia = new RengConcilia(new RengConciliaId(corr, Integer.parseInt(Servicios.obtGestion()), 1),
					new RengComprob(new RengComprobId(1, 'G', reng.getId().getNroComprob(), reng.getId().getNroReng())), glosa, new Date(), 'C',
					reng.getMontoMo(), 'A', (String) UserSessionHolder.get(Constants.AUDIT_USER_SESSION_ID), new Date(),
					(String) UserSessionHolder.get(Constants.AUDIT_USER_ESTACION));

			this.getHibernateTemplate().saveOrUpdate(concilia);
		}

		log.info("Concilia guardada: " + concilia.toString());

		return corr;
	}

	public static String getFormatoCodConcilia(Integer nroConcilia, Integer gestion) {
		String conc = String.format("%07d", nroConcilia);
		return "(CC:H-" + conc + "-" + gestion + ")";
	}
}
