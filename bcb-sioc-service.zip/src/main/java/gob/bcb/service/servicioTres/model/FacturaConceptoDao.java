/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * Pagos-TGN
 * gob.bcb.service.pagostgn.model.OperSptDao.java
 * 23/07/2010 - 14:07:17
 * Created by Angel Arenas
 */
package gob.bcb.service.servicioTres.model;

import gob.bcb.core.infra.datastore.BcbDao;
import gob.bcb.core.infra.datastore.BcbEntity;

import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author parenas
 * 
 */
public class FacturaConceptoDao extends HibernateDaoSupport implements BcbDao
{
  private static final Log log = LogFactory.getLog(FacturaConceptoDao.class);


  /*
   * (non-Javadoc)
   * @see
   * gob.bcb.service.pruebaCU.model.SolicitudDao#saveOrUpdate(gob.bcb.service.pruebaCU
   * .model.Solicitud)
   */
  
  public void saveOrUpdate(BcbEntity pm)
  {
    log.debug("Saving or updating " + pm);
    this.getHibernateTemplate().saveOrUpdate(pm);
  }

  /*
   * (non-Javadoc)
   * @see gob.bcb.core.infra.datastore.BcbDao#find(java.lang.Long)
   */
  
  public BcbEntity find(Long id)
  { // PENDIENTE [Arenas: 24-07-2010]
    return null;
  }
  
}
