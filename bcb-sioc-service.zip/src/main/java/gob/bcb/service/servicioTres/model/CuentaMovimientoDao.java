package gob.bcb.service.servicioTres.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class CuentaMovimientoDao extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(CuentaMovimientoDao.class);

	public CuentaMovimiento getCuentaMovimiento(String codMovimiento) {
		log.info("COIN:getCuentaMovimiento Entre a buscar el objeto con el codMovimiento: "
				+ codMovimiento);

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from CuentaMovimiento cp ");
		query = query.append("where cp.codMovimiento = :codMovimiento ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMovimiento) lista.get(0);
		}
		
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");
		throw new RuntimeException("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");
	}

	public CuentaMovimiento findCuentaMovimiento(String codMovimiento) {
		log.info("COIN:getCuentaMovimiento Entre a buscar el objeto con el codMovimiento: "
				+ codMovimiento);

		StringBuffer query = new StringBuffer();
		query = query.append("select cp ");
		query = query.append("from CuentaMovimiento cp ");
		query = query.append("where cp.codMovimiento = :codMovimiento ");

		Query consulta = getSession().createQuery(query.toString());
		consulta.setParameter("codMovimiento", codMovimiento);

		List lista = consulta.list();

		if (lista.size() > 0) {
			return (CuentaMovimiento) lista.get(0);
		}
		log.error("Cuenta movimiento : " + codMovimiento
				+ " inexistente en base CONTBCB.Cuenta_Movimiento");		
		return null;
	}
	
	public Boolean IsAfectableSigma(String cuenta) {
		Boolean afectable = false;
		// int sigma = 0;

		String query = "select count(nro_afectable) as sigma ";
		query = query.concat("from afectable_sigma ");
		query = query.concat("where nro_afectable = :cuenta ");
		query = query.concat("and cve_vigente = 'V' ");

		Query consulta = getSession().createSQLQuery(query);
		consulta.setParameter("cuenta", cuenta);

		Long codigo = Long.valueOf(0);

		BigDecimal maxi = BigDecimal.ZERO;
		List result = consulta.list();
		if (result.size() > 0)
			maxi = (BigDecimal) result.get(0);

		if (maxi != null) {
			codigo = Long.valueOf(maxi.toPlainString());
		} else {
			codigo = Long.valueOf(0);
		}

		return codigo.compareTo(Long.valueOf(1)) >= 0;
	}

	public List<String> partidaPresup(String cuenta) {
		log.info("Buscando partida presup " + cuenta);
		List<String> result = new ArrayList<String>();
		try {

			String query = "select cod_partida ";
			query = query.concat("from afectable_partida ");
			query = query.concat("where nro_afectable = :cuenta ");
			query = query.concat("and cve_vigente = 'V' ");

			Query consulta = getSession().createSQLQuery(query);
			consulta.setParameter("cuenta", cuenta);

			result = consulta.list();

			if (result != null && result.size() > 0){
				log.info("PPTO :: afect: " + result.size());
				log.info("PPTO :: afect: " + cuenta + " partidita :: "
						+ result.get(0) + " " + query);				
			}
		} catch (Exception e) {
			throw new RuntimeException("Error al obtener Codigo Part Presup: "
					+ e.getMessage(), e);
		}

		return result;
	}

}
