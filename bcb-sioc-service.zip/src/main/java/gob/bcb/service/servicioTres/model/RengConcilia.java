/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioTres.model;

import gob.bcb.core.infra.datastore.BcbEntity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "reng_concilia")
@NamedQueries({ @NamedQuery(name = "RengConcilia.findAll", query = "SELECT r FROM RengConcilia r") })
public class RengConcilia extends BcbEntity {
	private static final long serialVersionUID = 1L;
	@EmbeddedId
	protected RengConciliaId id;

	@Column(name = "nro_centro")
	private int nroCentro;
	@Basic(optional = false)
	@Column(name = "cve_tipo_comprob")
	private char cveTipoComprob;
	@Basic(optional = false)
	@Column(name = "nro_comprob")
	private String nroComprob;
	@Basic(optional = false)
	@Column(name = "nro_reng")
	private int nroReng;

	@Column(name = "glosa")
	private String glosa;
	@Column(name = "fecha_concilia")
	@Temporal(TemporalType.DATE)
	private Date fechaConcilia;
	@Basic(optional = false)
	@Column(name = "cve_ope_concilia")
	private char cveOpeConcilia;
	@Basic(optional = false)
	@Column(name = "importe")
	private BigDecimal importe;
	@Basic(optional = false)
	@Column(name = "cve_est_concilia")
	private char cveEstConcilia;
	@Basic(optional = false)
	@Column(name = "cod_usuario")
	private String codUsuario;
	@Basic(optional = false)
	@Column(name = "fecha_hora")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaHora;
	@Basic(optional = false)
	@Column(name = "estacion")
	private String estacion;

	public RengConcilia() {
	}

	public RengConcilia(RengConciliaId id) {
		this.id = id;
	}

	public RengConcilia(RengConciliaId id, RengComprob rengComprob, String glosa, Date fechaConcilia, char cveOpeConcilia, BigDecimal importe,
			char cveEstConcilia, String codUsuario, Date fechaHora, String estacion) {
		this.id = id;
		this.nroCentro = rengComprob.getId().getNroCentro();
		this.cveTipoComprob = rengComprob.getId().getCveTipoComprob();
		this.nroComprob = rengComprob.getId().getNroComprob();
		this.nroReng = rengComprob.getId().getNroReng();		
		this.glosa = glosa;
		this.fechaConcilia = fechaConcilia;
		this.cveOpeConcilia = cveOpeConcilia;
		this.importe = importe;
		this.cveEstConcilia = cveEstConcilia;
		this.codUsuario = codUsuario;
		this.fechaHora = fechaHora;
		this.estacion = estacion;
	}

	public RengConcilia(int nroConcilia, int gestion, int secRengConcilia) {
		this.id = new RengConciliaId(nroConcilia, gestion, secRengConcilia);
	}

	public RengConciliaId getId() {
		return id;
	}

	public void setId(RengConciliaId id) {
		this.id = id;
	}

	public int getNroCentro() {
		return nroCentro;
	}

	public void setNroCentro(int nroCentro) {
		this.nroCentro = nroCentro;
	}

	public char getCveTipoComprob() {
		return cveTipoComprob;
	}

	public void setCveTipoComprob(char cveTipoComprob) {
		this.cveTipoComprob = cveTipoComprob;
	}

	public String getNroComprob() {
		return nroComprob;
	}

	public void setNroComprob(String nroComprob) {
		this.nroComprob = nroComprob;
	}

	public int getNroReng() {
		return nroReng;
	}

	public void setNroReng(int nroReng) {
		this.nroReng = nroReng;
	}
	
	public String getGlosa() {
		return glosa;
	}

	public void setGlosa(String glosa) {
		this.glosa = glosa;
	}

	public Date getFechaConcilia() {
		return fechaConcilia;
	}

	public void setFechaConcilia(Date fechaConcilia) {
		this.fechaConcilia = fechaConcilia;
	}

	public char getCveOpeConcilia() {
		return cveOpeConcilia;
	}

	public void setCveOpeConcilia(char cveOpeConcilia) {
		this.cveOpeConcilia = cveOpeConcilia;
	}

	public BigDecimal getImporte() {
		return importe;
	}

	public void setImporte(BigDecimal importe) {
		this.importe = importe;
	}

	public char getCveEstConcilia() {
		return cveEstConcilia;
	}

	public void setCveEstConcilia(char cveEstConcilia) {
		this.cveEstConcilia = cveEstConcilia;
	}

	public String getCodUsuario() {
		return codUsuario;
	}

	public void setCodUsuario(String codUsuario) {
		this.codUsuario = codUsuario;
	}

	public Date getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(Date fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getEstacion() {
		return estacion;
	}

	public void setEstacion(String estacion) {
		this.estacion = estacion;
	}

	public int hashCode() {
		int hash = 0;
		hash += (id != null ? id.hashCode() : 0);
		return hash;
	}

	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are
		// not
		// set
		if (!(object instanceof RengConcilia)) {
			return false;
		}
		RengConcilia other = (RengConcilia) object;
		if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
			return false;
		}
		return true;
	}

	public String toString() {
		return "gob.bcb.service.servicioTres.model.RengConcilia[id=" + id + "]";
	}

}
