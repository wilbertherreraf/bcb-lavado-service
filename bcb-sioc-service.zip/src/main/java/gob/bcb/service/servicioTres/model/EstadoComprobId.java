package gob.bcb.service.servicioTres.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class EstadoComprobId implements Serializable {
	@Basic(optional = false)
	@Column(name = "nro_centro")
	private Integer nroCentro;
	@Basic(optional = false)
	@Column(name = "cve_tipo_comprob")
	private char cveTipoComprob;
	@Basic(optional = false)
	@Column(name = "nro_comprob")
	private String nroComprob;

	@Basic(optional = false)
	@Column(name = "cve_estado_comprob")
	private String cveEstadoComprob;

	public EstadoComprobId() {
	}

	public EstadoComprobId(Integer nroCentro, char cveTipoComprob, String nroComprob, String cveEstadoComprob) {
		this.nroCentro = nroCentro;
		this.cveTipoComprob = cveTipoComprob;
		this.nroComprob = nroComprob;
		this.cveEstadoComprob = cveEstadoComprob;
	}

	public Integer getNroCentro() {
		return nroCentro;
	}

	public void setNroCentro(Integer nroCentro) {
		this.nroCentro = nroCentro;
	}

	public char getCveTipoComprob() {
		return cveTipoComprob;
	}

	public void setCveTipoComprob(char cveTipoComprob) {
		this.cveTipoComprob = cveTipoComprob;
	}

	public String getNroComprob() {
		return nroComprob;
	}

	public void setNroComprob(String nroComprob) {
		this.nroComprob = nroComprob;
	}

	public void setCveEstadoComprob(String cveEstadoComprob) {
		this.cveEstadoComprob = cveEstadoComprob;
	}

	public String getCveEstadoComprob() {
		return cveEstadoComprob;
	}

	
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cveEstadoComprob == null) ? 0 : cveEstadoComprob.hashCode());
		result = prime * result + cveTipoComprob;
		result = prime * result + ((nroCentro == null) ? 0 : nroCentro.hashCode());
		result = prime * result + ((nroComprob == null) ? 0 : nroComprob.hashCode());
		return result;
	}

	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EstadoComprobId other = (EstadoComprobId) obj;
		if (cveEstadoComprob == null) {
			if (other.cveEstadoComprob != null)
				return false;
		} else if (!cveEstadoComprob.equals(other.cveEstadoComprob))
			return false;
		if (cveTipoComprob != other.cveTipoComprob)
			return false;
		if (nroCentro == null) {
			if (other.nroCentro != null)
				return false;
		} else if (!nroCentro.equals(other.nroCentro))
			return false;
		if (nroComprob == null) {
			if (other.nroComprob != null)
				return false;
		} else if (!nroComprob.equals(other.nroComprob))
			return false;
		return true;
	}

}
