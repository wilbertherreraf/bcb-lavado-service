package gob.bcb.service.exception;

import gob.bcb.core.exception.MsgManager;
import gob.bcb.core.exception.UncheckedException;

import java.util.ResourceBundle;

import javax.xml.namespace.QName;

import org.apache.log4j.Logger;

/**
 * This exception is used to mark business rule violations.
 * 
 * @author Christian Bauer <christian@hibernate.org>
 */
public class BusinessException extends UncheckedException {

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje de la excepcion
	 * @param ex
	 *            La excpecion como tal
	 */
	public BusinessException(String msg, Throwable t) {
		super(msg, t);
		//this(msg, BUNDLE, t);
	}

	/**
	 * Constructor
	 * 
	 * @param message
	 *            Mensaje para crear la nueva excepcion
	 */

	public BusinessException(String message) {
		super(message);
		// this(new MsgManager(message, BUNDLE));
		// whf ojooo eliminar cuando todas las excepciones esten codificadas
		// mensaje personalizado si el codigo no existe en la configuracion lo
		// setea a

//		this(BUNDLE.containsKey(message) ? (new MsgManager(message, BUNDLE)) : (new MsgManager("BERROR", BUNDLE,
//				new Object[] { message })));
	}

	public BusinessException(MsgManager message, Throwable throwable) {
		super(message, throwable);
		// code = FAULT_CODE_SERVER;
	}

	public BusinessException(MsgManager message) {
		super(message);
		// code = FAULT_CODE_SERVER;
	}

	public BusinessException(String message, Logger log) {
		this(new MsgManager(message, log));
	}

	public BusinessException(String message, ResourceBundle b) {
		this(new MsgManager(message, b));
	}

	public BusinessException(String message, Logger log, Throwable t) {
		this(new MsgManager(message, log), t);
	}

	public BusinessException(String message, ResourceBundle b, Throwable t) {
		this(new MsgManager(message, b), t);
	}

	public BusinessException(String message, Logger log, Throwable t, Object... params) {
		this(new MsgManager(message, log, params), t);
	}

	public BusinessException(String message, ResourceBundle b, Throwable t, Object... params) {
		this(new MsgManager(message, b, params), t);
	}

	public BusinessException(Throwable t) {
		super(t);
		// code = FAULT_CODE_SERVER;
	}

	public BusinessException(MsgManager message, Throwable throwable, QName fc) {
		super(message, throwable);
	}

	public BusinessException(MsgManager message, QName fc) {
		super(message);
	}

	public BusinessException(Throwable t, QName fc) {
		super(t);
	}

}
