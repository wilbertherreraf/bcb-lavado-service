package gob.bcb.service.commons;

/**
 *
 * @author wilherrera
 */
import gob.bcb.core.utils.UtilsGeneric;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CorreoUtils {
	private static final Log log = LogFactory.getLog(CorreoUtils.class);
	private Properties props;
	private String smtpHost = "10.2.11.27";
	private int smtpPort = 25;

	public CorreoUtils() {
	}

	public CorreoUtils(String smtpHost, int smtpPort) {
		this.smtpHost = smtpHost;
		this.smtpPort = smtpPort;
	}

	public void enviaAlServidorSMTP(String from, String to, String subject, String content) {
		String[] mails = to.split(",");
		enviaAlServidorSMTP(from, mails, subject, content) ;
	}
	public void enviaAlServidorSMTP(String from, String[] to, String subject, String content) {
		List recipients = new ArrayList();		
		for (int i = 0; i < to.length; i++) {
			recipients.add(to[i]);			
		}
		
		enviaAlServidorSMTP(from, recipients, subject, content) ;
	}	
	public void enviaAlServidorSMTP(String from, List to, String subject, String content) {
		log.info("en enviaAlServidorSMTP " + to.toString());		
		try {
			initProperties();
			Session session = Session.getInstance(props);

			// Construct the message
			MimeMessage msg = new MimeMessage(session);
			msg.addHeader("Content-type", "text/plain");
			msg.addHeader("Content-type", "text/html");
			msg.setFrom(new InternetAddress(from));
			
			for (Iterator it = to.iterator(); it.hasNext();) {
				String email = (String)it.next();
				if (StringUtils.isBlank(email)){
					continue;
				}
				UtilsGeneric.validarEmail(email);
				msg.addRecipients(Message.RecipientType.TO, email);
			}
			
			msg.setSubject(subject);
			msg.setText(content);

			msg.setSentDate( new Date() );
			// Send the message
			// whf para prod borrar 
//			if (!ConfigurationServ.getConfigurationHome().startsWith("e:/")) {
				Transport.send(msg);				
//			}
			log.info("correos enviados a " + ArrayUtils.toString(msg.getAllRecipients()));
		} catch (AddressException add) {
			log.error("Error en enviaAlServidorSMTP " + add.getMessage(), add);
		} catch (MessagingException mes) {
			log.error("Error en mensaje SMTP " + mes.getMessage(), mes);
		} catch (Exception mes) {
			log.error("Error Generico en mensaje SMTP " + mes.getMessage(), mes);			
		}
	}

	private void initProperties() {
		// Create a mail session
		props = new Properties();
		props.put("mail.smtp.host", smtpHost);
		props.put("mail.smtp.port", "" + smtpPort);
		
		//para pop
        //place the authentication info in
        //props.put("mail.pop3.host",host);
	}

	/**
	 * @return the smtpHost
	 */
	public String getSmtpHost() {
		return smtpHost;
	}

	/**
	 * @param smtpHost
	 *            the smtpHost to set
	 */
	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}

	/**
	 * @return the smtpPort
	 */
	public int getSmtpPort() {
		return smtpPort;
	}

	/**
	 * @param smtpPort
	 *            the smtpPort to set
	 */
	public void setSmtpPort(int smtpPort) {
		this.smtpPort = smtpPort;
	}
	public static void main(String[] args) {
		String [] a = {"a","b"};
		List recipients = new ArrayList();		
		for (int i = 0; i < a.length; i++) {
			recipients.add(a[i]);			
		}
		for (Iterator it = recipients.iterator(); it.hasNext();) {
			String email = (String)it.next();
			System.out.println(email);
		}
	}
}
