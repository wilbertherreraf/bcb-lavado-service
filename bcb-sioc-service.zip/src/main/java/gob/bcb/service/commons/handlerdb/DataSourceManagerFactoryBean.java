package gob.bcb.service.commons.handlerdb;

import gob.bcb.core.utils.UtilsPersist;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class DataSourceManagerFactoryBean {
	private static Logger log = Logger.getLogger(DataSourceManagerFactoryBean.class);	
    String unitName;
    String pathFile;
    String persistenceUnit;
    EntityManagerFactory emf;

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }
    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }
    public void setPersistenceUnit(String persistenceUnit) {
        this.persistenceUnit = persistenceUnit;
    }    
    
    public EntityManagerFactory createEntityManagerFactory() {
        if (emf == null) {
    		log.info("Creando nuevo EntityManagerFactory pathFile:" + pathFile + " unitName:" + unitName + " persistenceUnit:" +  persistenceUnit);        	
        	emf = UtilsPersist.createEntityManagerFactory2(pathFile, unitName, persistenceUnit);        	
        }
        log.info("Reotornando EntityManager pathFile:" + pathFile + " unitName:" + unitName + " persistenceUnit:" +  persistenceUnit);
        return emf;
    }

    public DataSource createDataSource(){
    	return DBSourceHandlerFactory.Factory.newInstance(unitName).getHandler().getDataSource();
    }
    public DataSource createDataSource2(){
    	log.info("creating DataSource2 pathFile:" + pathFile + " unitName:" + unitName );
    	return DBSourceHandlerFactory.Factory.newInstance(pathFile, unitName).getHandler().getDataSource();
    }
    
    public void destroy() {
        if (emf != null) {
            emf.close();
        }
    }    
}
