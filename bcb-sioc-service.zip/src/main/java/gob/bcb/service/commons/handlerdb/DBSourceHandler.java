package gob.bcb.service.commons.handlerdb;

import java.sql.Connection;

import javax.sql.DataSource;

/**
 * Handle session state across requests and instances.
 * 
 * <p>Due to SOAP Logout, it is not possible to store all state in the HTTP session. Instead, implementations of this interface handle session state,
 * primarily based on the HTTP session.<p> 
 * 
 * <p>Implementations are expected to be thread-safe, and should not store any instance state, as a new instance will be created for
 * every request.</p>
 * 
 * @see DBSourceHandlerFactory
 */
/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface DBSourceHandler {
	public Connection getConnection();
	public void closeConnection(Connection connection);
	public DataSource getDataSource();
}
