package gob.bcb.service.commons.handlerdb;

import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.Logger;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class JdbcDBSourceHandler implements DBSourceHandler {
	private static final Log log = LogFactory.getLog(JdbcDBSourceHandler.class);

	private final DataSource ds;

	public JdbcDBSourceHandler(DataSource ds) {
		this.ds = ds;
		if (log.isInfoEnabled()) {
			log.info("Using DataSource [" + ds + "] for JdbcDBSourceHandler");
			}		
	}

	
	public Connection getConnection() {
		try {
			Connection c = ds.getConnection();
			c.setAutoCommit(false);
			return c;
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	
	public void closeConnection(Connection connection) {
		if (connection == null)
			return;
		try {
			connection.close();
		} catch (SQLException e) {
			log.error("Unable to close connection", e);
		}
	}
	public DataSource getDataSource(){
		return ds;
	}

}
