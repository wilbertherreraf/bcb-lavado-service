package gob.bcb.service.commons.handlerdb;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class QNatives {
	private String idDBSource;
	private Connection conn;
	
	public QNatives(String idDBSource) {
		this.idDBSource = idDBSource;
		DBSourceHandlerFactory dbSf = DBSourceHandlerFactory.Factory.newInstance(idDBSource);
		DBSourceHandler dBSourceHandler = dbSf.getHandler();
		conn = dBSourceHandler.getConnection();
	}

	public Connection getConnection() {
		try {
			if (conn.isClosed()){
				DBSourceHandlerFactory dbSf = DBSourceHandlerFactory.Factory.newInstance(idDBSource);
				DBSourceHandler dBSourceHandler = dbSf.getHandler();				
				conn = dBSourceHandler.getConnection();
				if (conn.isClosed()){
					throw new RuntimeException("ERROR_DE_SISTEMA: Error de conexion a base de datos " + idDBSource);					
				}
			}
		} catch (SQLException e) {
			throw new RuntimeException("ERROR_DE_SISTEMA: Error al verificar conexion a BDD " + e.getMessage());
		}
	
		return conn;
	}
	public void closeConnection() {
		DBSourceHandlerFactory dbSf = DBSourceHandlerFactory.Factory.newInstance(idDBSource);
		DBSourceHandler dBSourceHandler = dbSf.getHandler();
		dBSourceHandler.closeConnection(conn);
	}
	public static Connection getConnection(String idDBSource) {
		DBSourceHandlerFactory dbSf = DBSourceHandlerFactory.Factory.newInstance(idDBSource);
		DBSourceHandler dBSourceHandler = dbSf.getHandler();
		Connection conn = dBSourceHandler.getConnection();
		return conn;
	}
}
