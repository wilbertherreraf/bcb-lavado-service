package gob.bcb.service.commons;

public interface Constants {
	// ########## INICIO: CONSTANTES DE ACCESO A DATOS DE BASES DE DATOS ########//
	static final String PROP_DB_JDBC_DRIVER = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcdriver";
	static final String PROP_DB_JDBC_URL = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcurl";
	static final String PROP_DB_JDBC_USER = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcuser";
	static final String PROP_DB_JDBC_PASSWORD = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcpassword";
	static final String PROP_DB_JNDI = "repositorio/configdb/database[@id='ID-DATABASE']/jndi";
	static final String PROP_DB_HANDLER_FACTORY = "repositorio/configdb/database[@id='ID-DATABASE']/handlerfactory";
	// ########## FIN: CONSTANTES DE ACCESO A DATOS DE BASES DE DATOS ########//
	/**
	 * valor del contexto de persistencia para la base de datos 
	 */
	static final String PROP_PERSISTENCE_UNIT_NAME = "repositorio/servicios/servicio[@name='ID-SERVICENAME']/persistenceUnitName";
	static final String PROP_ID_DB_CONFIG_NAME_DEFAULT = "repositorio/servicios/servicio[@name='ID-SERVICENAME']/idDBConfigDefault";	
	static final String ATTRIBUTE_ERROR = "error";
	static final String ATTRIBUTE_EXCEPTION = "exception";
	static final String DESCRIP_PARAM_STATUS_NAME = "status";
	/**
	 * Formato fecha en la base de datos
	 */
	static final String FORMAT_DATE_DB = "dd/MM/yyyy";
	
	/**
	 * Formato de fecha hora para datos que requieran hora
	 */
	static final String FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss:SSS";

}
