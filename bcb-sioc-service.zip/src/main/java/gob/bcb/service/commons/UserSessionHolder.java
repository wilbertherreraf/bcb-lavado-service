package gob.bcb.service.commons;

import java.util.HashMap;
import java.util.Map;

public class UserSessionHolder {
	// ojooo control de que estos variables no colisionen
	private static final ThreadLocal<Map> sessionMap = new ThreadLocal<Map>();
	/*
	 * { protected HashMap initialValue() { return new HashMap(); } };
	 */
	public static Object get(String attribute) {
		initSession();
		Map map = sessionMap.get();
		return map.get(attribute);
	}

	public static void set(String attribute, Object value) {
		if (attribute == null){
			Map map = sessionMap.get();
			if (map != null)
				map.clear();
			UserSessionHolder.sessionMap.set(null);
		} else{
			initSession();
			if (value != null)
				sessionMap.get().put(attribute, value);
		}
	}

	private static void initSession() {
		if (sessionMap.get() == null) {
			Map prefMap = new HashMap();
			sessionMap.set(prefMap);
		}
	}
}
