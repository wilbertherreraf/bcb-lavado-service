package gob.bcb.service.servicioSioc.logic;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.joda.time.DateTime;

import gob.bcb.bpm.pruebaCU.FactoryDao;
import gob.bcb.bpm.pruebaCU.Glosa;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.bpm.pruebaCU.SocComprobante;
import gob.bcb.bpm.pruebaCU.SocComprobanteDao;
import gob.bcb.bpm.pruebaCU.SocDetallesope;
import gob.bcb.bpm.pruebaCU.SocDetallesopeDao;
import gob.bcb.bpm.pruebaCU.SocDetallesopeId;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocFacturasDao;
import gob.bcb.bpm.pruebaCU.SocFacturasId;
import gob.bcb.bpm.pruebaCU.SocInstrumento;
import gob.bcb.bpm.pruebaCU.SocInstrumentoDao;
import gob.bcb.bpm.pruebaCU.SocOperaciones;
import gob.bcb.bpm.pruebaCU.SocOperacionesDao;
import gob.bcb.bpm.pruebaCU.SocRengscompDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class VentaDivisas {
	private static final Log log = LogFactory.getLog(VentaDivisas.class);

	/**
	 * Venta con descuento del monto de la transaccion, crea dos comprobantes el
	 * primero de la venta y el segundo de la transacción
	 * 
	 * @param factoryDao
	 * @param solicitud
	 * @param listaDetalle
	 * @param fechaValor
	 */
	public SocOperaciones ventaConDescuento(FactoryDao factoryDao, SocSolicitudes solicitud, Date fechaValor, String tipoOpcion) {
		log.info("XXX: VentaVentaVentaVentaVenta");
		SocOperacionesDao socOperacionesDao = (SocOperacionesDao) factoryDao.getDao("socOperacionesDao");
		SocOperaciones socOperaciones = socOperacionesDao.crearOperacion(solicitud, fechaValor);

		String moneda = solicitud.getMonedaT();

		int mon = Servicios.getMoneda(moneda);
		BigDecimal tcUS = QueryProcessor.getTipoCambio(mon, new Date());

		SocDetallessolDao socDetallessolDao = (SocDetallessolDao) factoryDao.getDao("socDetallessolDao");
		List<SocDetallessol> detalles = socDetallessolDao.getDetalles(solicitud.getSocCodigo());

		String codOperacion = socOperaciones.getOpeCodigo();
		int i = 1;
		String concepto = "";
		for (SocDetallessol det : detalles) {
			Date hoy1 = new Date();
			String codInst = Long.toString(hoy1.getTime());
			SocDetallesope detOpe = new SocDetallesope();
			SocDetallesopeId id = new SocDetallesopeId(codOperacion, i);
			detOpe.setId(id);
			detOpe.setBenCodigo(det.getBenCodigo());
			detOpe.setDetMonto(det.getDetMonto());
			detOpe.setDetMontoOrd(det.getDetMontoord());
			detOpe.setMoneda(mon);
			Integer cta = det.getDetCtabenef();
			detOpe.setDetCtabenef(Integer.toString(cta));
			detOpe.setDetConcepto(det.getDetConcepto());
			detOpe.setDetInfo(det.getDetInfo());
			detOpe.setInsCodigo(codInst);
			detOpe.setDetFacturas(det.getDetFacturas());
			// el concepto del comprobante en
			concepto = det.getDetConcepto();

			SocDetallesopeDao socDetallesopeDao = (SocDetallesopeDao) factoryDao.getDao("socDetallesopeDao");
			socDetallesopeDao.saveOrUpdate(detOpe);
			log.info("Detalle generado: ");

			SocInstrumento instrumento = new SocInstrumento(codInst, 1, detOpe.getDetMonto(), mon, det.getDetConcepto());
			SocInstrumentoDao socInstrumentoDao = (SocInstrumentoDao) factoryDao.getDao("socInstrumentoDao");
			socInstrumentoDao.saveOrUpdate(instrumento);
			log.info("Instrumento generado: ");

			QueryProcessor.generarSwift(factoryDao, codInst, fechaValor, solicitud, detOpe);
			log.info("Instrumento actualizado");
			QueryProcessor.flush();
			i++;
		}
		log.info("XXX: =$$$$$$$$$$ " + solicitud.getSocCodigo());
		QueryProcessor.flush();

		String subTipo = "";

		DateTime hoyT = new DateTime(fechaValor);
		Date hoy2 = new Date();
		// CCUH SIOC V.2
		// Generar comprobante sólo si la fecha valor es igual a la fecha de
		// registro
		// 26-07-2013
		if (hoyT.getDayOfMonth() == hoy2.getDate()) {
			moneda = solicitud.getMonedaT();
			mon = Servicios.getMoneda(moneda);
			BigDecimal tipo = QueryProcessor.getTipoCambio(mon, hoy2);
			if (mon == 34) {
				QueryProcessor.generarComisiones(factoryDao, codOperacion, solicitud, tipo, detalles.size());
			} else {
				QueryProcessor.generarComisionesOM(factoryDao, codOperacion, solicitud, tipo, detalles.size());
			}

			// cuenta 5 ES SIGMA en la tabla soc_parametros @cprovb
			if (solicitud.getSocCuentad() == 5) {
				if ((solicitud.getSocMontoord() != null && solicitud.getSocMontoord().compareTo(BigDecimal.ZERO) > 0)) {
					// si es SIGMA y con descuento(si el montoordenado
					// es
					// diferente de cero queire decir que3 es con
					// descuento)
					subTipo = "VESD";
				} else {
					// si es SIGMA y SIN descuento
					subTipo = "TEI";
				}
			} else {
				if ((solicitud.getSocMontoord() != null && solicitud.getSocMontoord().compareTo(BigDecimal.ZERO) > 0)) {
					// si no es SIGMA y es con descuento
					// esquema nuevo
					subTipo = "TEID";
					// SI la operacion es externa se realizo anteriormente la
					// solicitud
					if (tipoOpcion.equals("operacionV")) {
						throw new RuntimeException("Operación venta de divisas OTROS CON descuento no tiene esquema");
					}
				} else {
					// si no es SIGMA y no es con descuento
					subTipo = "TECI";
					// SI la operacion es externa se realizo anteriormente la
					// solicitud
					if (tipoOpcion.equals("operacionV")) {
						throw new RuntimeException("Operación venta de divisas OTROS CON descuento no tiene esquema");
					}
				}
			}

			String codComprobante = Long.toString(hoy2.getTime());
			SocComprobante comprobante = new SocComprobante(codComprobante, codOperacion, hoyT.getYear(), hoyT.getMonthOfYear(),
					hoyT.getDayOfMonth(), tcUS, Glosa.crearGlosa(solicitud.getClaTipo(), solicitud, concepto));

			SocComprobanteDao comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
			comprobanteDao.saveOrUpdate(comprobante);
			log.info("Comprobante en SIOC guardado: ");

			String tipoOperacion = solicitud.getClaTipo();
			List<Map<String, Object>> resultado1 = Servicios.obtenerEsquema(tipoOperacion, subTipo);

			SocRengscompDao rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
			rengsCompDao.CrearRenglones(codComprobante, resultado1, solicitud, detalles);
			QueryProcessor.flush();

			log.info("XXX: subTiposubTiposubTiposubTipo " + subTipo);
			// /////////////////////////////////////////
			// se crear un segundo comprobante de transferencia de divisas

			if (subTipo.equalsIgnoreCase("VESD")) {
				// facturita sin credito
				// PARA VENTAS CON DESCUENTO: para el 1er comprob genera solo
				// sin credito
				// para el 2do solo la primera parte (con credito)
				String nombre = Servicios.getSolicitante(solicitud.getSolCodigo());

				SocFacturasDao socFacturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");
				Map<String, Object> mapaResultado = socFacturasDao.getDatosFactura(solicitud.getSolCodigo());
				String nit = (String) mapaResultado.get("nit");
				i = 1;
				SocFacturasId id = new SocFacturasId(codComprobante, 0, i);
				socFacturasDao.crearFacturaSinCredito(id, nit, nombre, 'P', socOperaciones.getOpeCodigo());

				// si es venta de divisas al exterior con descuento
				// se genera un 2do comprbante de transferencia de divisas al
				// exterior
				hoy2 = new Date();
				codComprobante = Long.toString(hoy2.getTime());
				String glosa = Glosa.crearGlosa("TESD", solicitud, concepto);
				comprobante = new SocComprobante(codComprobante, codOperacion, hoyT.getYear(), hoyT.getMonthOfYear(), hoyT.getDayOfMonth(), tcUS,
						glosa);

				comprobanteDao = (SocComprobanteDao) factoryDao.getDao("socComprobanteDao");
				comprobanteDao.saveOrUpdate(comprobante);
				log.info("Comprobante en SIOC guardado: " + comprobante.getCpbCodigo());

				tipoOperacion = "VE";
				subTipo = "TESD";
				resultado1 = Servicios.obtenerEsquema(tipoOperacion, subTipo);

				rengsCompDao = (SocRengscompDao) factoryDao.getDao("socRengscompDao");
				rengsCompDao.CrearRenglones(codComprobante, resultado1, solicitud, detalles);
				QueryProcessor.flush();
			}
			// ///////////////////////////////////////////
			// 001564 es el renglon de IVA
			String query = "select ren_codigo " + "from soc_rengscomp " + "where cpb_codigo = '" + codComprobante + "' "
					+ "and ren_afectable = '001564'";

			List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query, "ren_codigo".split(","));
			if (resultado.size() == 1) {
				for (Map<String, Object> res : resultado) {
					// log.info("resultado" + res.toString());
					Integer nro = (Integer) res.get("ren_codigo");
					SocFacturasDao facturasDao = (SocFacturasDao) factoryDao.getDao("socFacturasDao");

					// la factura sin credito no será creada para la operación
					// de venta con descuento
					boolean crearFacturaSinCredito = !subTipo.equalsIgnoreCase("TESD");
					if (solicitud.getSocMontoord() != null && solicitud.getSocMontoord().compareTo(BigDecimal.valueOf(0.00)) == 0) {
						facturasDao.crearFactura(codComprobante, nro, solicitud.getSolCodigo());
					} else {
						for (SocDetallessol det : detalles) {
							String ben = det.getBenCodigo();
							facturasDao.crearFactura(codComprobante, nro, ben, solicitud.getSolCodigo(), crearFacturaSinCredito);
						}
					}
				}
			}
			QueryProcessor.flush();
		}
		// ///////////////////////

		SocSolicitudesDao socSolicitudesDao = (SocSolicitudesDao) factoryDao.getDao("socSolicitudesDao");
		solicitud.setClaEstado('O');
		socSolicitudesDao.saveOrUpdate(solicitud);

		return socOperaciones;
	}
}
