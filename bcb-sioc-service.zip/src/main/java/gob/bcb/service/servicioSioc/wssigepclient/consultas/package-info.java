@javax.xml.bind.annotation.XmlSchema(namespace = "http://mefp.gob.bo/itg")
package gob.bcb.service.servicioSioc.wssigepclient.consultas;
