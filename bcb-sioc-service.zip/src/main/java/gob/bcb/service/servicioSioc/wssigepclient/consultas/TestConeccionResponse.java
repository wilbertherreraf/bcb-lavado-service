
package gob.bcb.service.servicioSioc.wssigepclient.consultas;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TestConeccionResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TestConeccionResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="TestConeccionResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TestConeccionResponse", propOrder = {
    "testConeccionResult"
})
public class TestConeccionResponse {

    @XmlElement(name = "TestConeccionResult")
    protected String testConeccionResult;

    /**
     * Gets the value of the testConeccionResult property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTestConeccionResult() {
        return testConeccionResult;
    }

    /**
     * Sets the value of the testConeccionResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTestConeccionResult(String value) {
        this.testConeccionResult = value;
    }

}
