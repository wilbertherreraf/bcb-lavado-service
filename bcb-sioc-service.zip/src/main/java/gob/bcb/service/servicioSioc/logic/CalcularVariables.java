package gob.bcb.service.servicioSioc.logic;

import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocComitipoope;
import gob.bcb.bpm.pruebaCU.SocComitipoopeDao;
import gob.bcb.bpm.pruebaCU.SocCuentassolDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocDetallessolDao;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocEsquemasDao;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocOpecomiDao;
import gob.bcb.bpm.pruebaCU.SocOpecomiId;
import gob.bcb.bpm.pruebaCU.SocParametros;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.bpm.pruebaCU.SocRengesq;
import gob.bcb.bpm.pruebaCU.SocRengesqDao;
import gob.bcb.bpm.pruebaCU.SocSolicitanteDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.SocSolicitudctasDao;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.SocSolicitudesDao;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.bpm.pruebaCU.UtilsSioc;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.service.exception.BusinessException;
import gob.bcb.service.servicioSioc.common.Constants;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;

/**
 * @author wherrera
 * 
 */
public class CalcularVariables {
	private static final Log log = LogFactory.getLog(CalcularVariables.class);

	private SessionFactory sessionFactory;

	private SocComitipoopeDao socComitipoopeDao = new SocComitipoopeDao();
	private SocOpecomiDao socOpecomiDao = new SocOpecomiDao();
	private Map<String, SocOpecomi> socOpecomiMap = new HashMap<String, SocOpecomi>();

	public CalcularVariables() {
	}

	public CalcularVariables(SessionFactory sessionFactor) {
		setSessionFactory(sessionFactor);
		socComitipoopeDao.setSessionFactory(getSessionFactory());
		socOpecomiDao.setSessionFactory(getSessionFactory());
	}

	private void crearRegistro(String opeCodigo, Integer detCodigo, String claComision, BigDecimal ocoMonto, BigDecimal montoMo,
			BigDecimal montoimpt, Integer codMoneda, String claEstadovar, BigDecimal tipoCambio, String nit, String razon, String nroCuenta) {

		String codVaria = String.valueOf(detCodigo).concat(claComision);
		SocOpecomi socOpecomiOld = socOpecomiMap.get(codVaria);

		if (socOpecomiOld == null) {
			// encontrado
			SocOpecomiId socOpecomiId = new SocOpecomiId(claComision, opeCodigo, detCodigo);

			socOpecomiOld = new SocOpecomi();
			socOpecomiOld.setId(socOpecomiId);

			socOpecomiOld.setClaEstadovar(claEstadovar);// registrado
			socOpecomiOld.setOcoMonto(ocoMonto);
			socOpecomiOld.setMontoMo(montoMo);
			socOpecomiOld.setOcoMontoimpt(montoimpt);
			socOpecomiOld.setCodMoneda(codMoneda);
			socOpecomiOld.setTipoCambio((tipoCambio != null ? tipoCambio.setScale(7, BigDecimal.ROUND_HALF_UP) : tipoCambio));
			socOpecomiOld.setCveTipocomis("V");
			socOpecomiOld.setNit(nit);
			socOpecomiOld.setFactura(razon);
			socOpecomiOld.setNroCuenta(nroCuenta);

		} else {
			// si ya esta registrado verificar su estado
			if (StringUtils.isBlank(socOpecomiOld.getClaEstadovar()) || !socOpecomiOld.getClaEstadovar().equals("C")) {
				// no esta registrado se actualiza el valor
				socOpecomiOld.setClaEstadovar(claEstadovar);// registrado
				socOpecomiOld.setOcoMonto(ocoMonto);
				socOpecomiOld.setOcoMontoimpt(montoimpt);
				socOpecomiOld.setMontoMo(montoMo);
				socOpecomiOld.setCodMoneda(codMoneda);
				socOpecomiOld.setTipoCambio((tipoCambio != null ? tipoCambio.setScale(7, BigDecimal.ROUND_HALF_UP) : tipoCambio));
				socOpecomiOld.setCveTipocomis("V");
				socOpecomiOld.setNit(nit);
				socOpecomiOld.setFactura(razon);
				socOpecomiOld.setNroCuenta(nroCuenta);
			}
		}

		socOpecomiMap.put(codVaria, socOpecomiOld);
	}

	private List<SocOpecomi> crearRegistro(List<SocOpecomi> lista, String opeCodigo, Integer detCodigo, String claComision, BigDecimal ocoMonto,
			BigDecimal montoMo, Integer codMoneda, String claEstadovar, BigDecimal tipoCambio) {

		crearRegistro(opeCodigo, detCodigo, claComision, ocoMonto, montoMo, BigDecimal.ZERO, codMoneda, "R", tipoCambio, null, null, null);
		return lista;
	}

	public SocOpecomi buscarClaComision(String claComision, Integer detComision) {
		String codVaria = String.valueOf(detComision).concat(claComision);

		SocOpecomi socOpecomiResp = socOpecomiMap.get(codVaria);
		return socOpecomiResp;
	}

	private List<SocOpecomi> calculoVariables(SocSolicitudes socSolicitudes, SocEsquemas socEsquemas, List<SocDetallessol> socDetallesopeLista,
			SocComitipoope socComitipoope, List<SocOpecomi> socOpecomiLista, Map<String, SocSolicitudctas> socSolicitudctasLista, Date fechaTc,
			BigDecimal montoOrdenado, Integer codMonedaOrdenado, Integer detCodigo) {

		socOpecomiLista = calculoTotalProvision(socSolicitudes, socEsquemas, socOpecomiLista, socSolicitudctasLista, fechaTc,
				socSolicitudes.getSocMontome(), socSolicitudes.getCodMoneda());

		log.info("Calculando calculoVariables: [" + socSolicitudes.getSocCodigo() + "]: montoOrdenado " + montoOrdenado + " codMonedaOrdenado: "
				+ codMonedaOrdenado);
		// /////////////////////////////////////////////////////////////
		socOpecomiLista = calculoComisionesFijos(socSolicitudes, socEsquemas, socOpecomiLista, socDetallesopeLista, socSolicitudctasLista, fechaTc, 0);

		socOpecomiLista = montoATransferirConDescuento(socSolicitudes, socEsquemas, socDetallesopeLista, socOpecomiLista, socComitipoope,
				montoOrdenado, codMonedaOrdenado, socSolicitudctasLista, fechaTc, 0);

		socOpecomiLista = calculoMontosDetalleTransfer(socSolicitudes, socEsquemas, socDetallesopeLista, socOpecomiLista, socComitipoope,
				socSolicitudctasLista, fechaTc);

		return socOpecomiLista;
	}

	private List<SocOpecomi> calculoTotalProvision(SocSolicitudes socSolicitudes, SocEsquemas socEsquemas, List<SocOpecomi> socOpecomiLista,
			Map<String, SocSolicitudctas> socSolicitudctasLista, Date fechaTc, BigDecimal montoOrdenado, Integer codMonedaOrdenado) {
		// el montoordenado es el monto base que el solicitante registra en la
		// solicitud
		SocOpecomi socOpecomiTOTTRANS = buscarClaComision("TOTALPROV", 0);

		if (socOpecomiTOTTRANS == null || StringUtils.isBlank(socOpecomiTOTTRANS.getClaEstadovar())
				|| !socOpecomiTOTTRANS.getClaEstadovar().equals("C")) {

			log.debug("Calculando calculoTotalProvision: " + socSolicitudes.getSocCodigo() + " " + socSolicitudes.getSocCodigo() + " "
					+ UtilsDate.stringFromDate(fechaTc, "dd/MM/yyy"));
			Integer codMonedaCtaDebito = socSolicitudctasLista.get(Constants.COD_CLAVE_MOVPROVISION).getCodMoneda();

			Map<String, Object> montoConvertido = UtilsSioc.conversion(montoOrdenado, codMonedaOrdenado, codMonedaCtaDebito, fechaTc, null,
					((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

			BigDecimal montoBS = (BigDecimal) montoConvertido.get("montobs");
			BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
			BigDecimal tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
			BigDecimal montoADebitarSUS = (BigDecimal) montoConvertido.get("montosus");

			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, "TOTALPROV", montoBS, montoMO, codMonedaCtaDebito, "R", tipocambiomoxbs);

			if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
				// la transferencia se realiza de manera manual por
				// el area
				// compran la moneda en el exterior pero
				// contablemente se transfiere dolares

				crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, "TOTNEGOCIA", montoBS, montoADebitarSUS, Constants.COD_MONEDA_USD,
						"R", tipocambiomoxbs);
			}
		}

		return socOpecomiLista;
	}

	private List<SocOpecomi> montoATransferirConDescuento(SocSolicitudes socSolicitudes, SocEsquemas socEsquemas,
			List<SocDetallessol> socDetallesopeLista, List<SocOpecomi> socOpecomiList, SocComitipoope socComitipoope, BigDecimal montoADescontar,
			Integer monedaDeDescento, Map<String, SocSolicitudctas> socSolicitudctasLista, Date fechaTc, Integer detCodigo) {
		// metodo de solo calcuo del monto de la transferencia

		// *************************************************************
		if (socComitipoope != null) {
			if (socSolicitudes.getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				log.info("Entrado a montoATransferirConDescuento: [" + socSolicitudes.getSocCodigo() + " - " + detCodigo + "]: montoADescontar "
						+ montoADescontar + " monedaDeDescento: " + monedaDeDescento);

				Map<String, Object> montoConvertido = null;
				// calculamos el monto a transferir al benefiario

				// 0000000 montome 00000000000
				BigDecimal montoBS = BigDecimal.ZERO;
				BigDecimal montoMO = BigDecimal.ZERO;
				BigDecimal montoADebitarSUS = BigDecimal.ZERO;
				BigDecimal tipocambiomoxbs = BigDecimal.ZERO;

				if (socDetallesopeLista != null && socDetallesopeLista.size() != 1) {
					throw new BusinessException("Operacion con Descuento solo se permite un {" + socDetallesopeLista.size()
							+ "} beneficiario para solicitud " + socSolicitudes.getSocCodigo());
				}
				// calculamos el monto ordenado
				// monto a debitar de la cuenta de operacion
				log.info("Operacion CON descuento: " + socSolicitudes.toString());

				// verificamos si es al beneficiario las comisiones
				SocSolicitudctas socSolicitudctasMOVPROVISION = socSolicitudctasLista.get(Constants.COD_CLAVE_MOVPROVISION);
				SocSolicitudctas socSolicitudctasCOMGADM = socSolicitudctasLista.get(Constants.COD_CLAVE_COMGADM);
				SocSolicitudctas socSolicitudctasCOMCTRA = socSolicitudctasLista.get(Constants.COD_CLAVE_COMCTRA);

				// monto total de comisiones = comis transf + comis util + comis
				// swift
				BigDecimal montoTotalComisSUS = BigDecimal.ZERO;
				Integer monedaDeTransferencia = socSolicitudes.getCodMonedat();

				if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
					// la solicitud es en monedas mayor al limite o en monedas
					// de negociacion
					// el monto a descontar sera el monto negociado en teori en
					// USD
					// los datos de la variable MONTOD debería ser ingresado por
					// el usuario
					SocSolicitudctas socSolicitudctasBENEFMT = socSolicitudctasLista.get(Constants.COD_CLAVE_BENEFMT);
					if (socSolicitudctasBENEFMT != null) {
						// la moneda de transferencia sera la moneda que fue
						// negociada en teroria en USD

						monedaDeTransferencia = socSolicitudctasBENEFMT.getCodMoneda();
					}
				}

				// recuperamos el monto total debitado en dolares
				montoConvertido = UtilsSioc.conversion(montoADescontar, monedaDeDescento, Constants.COD_MONEDA_BS, fechaTc, null,
						((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

				montoADebitarSUS = (BigDecimal) montoConvertido.get("montosus");
				montoBS = (BigDecimal) montoConvertido.get("montobs");
				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

				// primero suponemos que no hay desc en la transferencia
				BigDecimal montoTransferenciaUSD = montoADebitarSUS;

				// sera descuento parcial si las comisiones de util o swift son
				// al solicitnte

				if (socSolicitudctasCOMGADM != null && (socSolicitudctasCOMGADM.getCveTipocomis() != null && socSolicitudctasCOMGADM.getCveTipocomis().equals(
						Constants.CLAVE_TIPOCOMIS_BENEF))
						&& socSolicitudctasMOVPROVISION.getNroCuenta().equals(socSolicitudctasCOMGADM.getNroCuenta())
						&& socSolicitudctasMOVPROVISION.getCodMoneda().compareTo(socSolicitudctasCOMGADM.getCodMoneda()) == 0) {
					// si las comisiones de util y swf lo asume el beneficiario
					// y las cuentas son iguales
					// (desc. gastos adm)

					BigDecimal sumaComisGAdmBS = BigDecimal.valueOf(0.00);

					// por ser con descuento la moneda de comision es la misma
					// del
					// debito

					SocOpecomi socOpecomiCOMGADM = buscarClaComision(Constants.COD_CLAVE_COMGADM, 0);
					if (socOpecomiCOMGADM != null)
						sumaComisGAdmBS = socOpecomiCOMGADM.getOcoMonto();

					montoConvertido = UtilsSioc.conversion(sumaComisGAdmBS, Constants.COD_MONEDA_BS, Constants.COD_MONEDA_USD, fechaTc, null, "C");

					BigDecimal montoComisUtilSwftSUS = (BigDecimal) montoConvertido.get("montosus");

					montoTransferenciaUSD = montoTransferenciaUSD.subtract(montoComisUtilSwftSUS);
					montoTotalComisSUS = montoComisUtilSwftSUS;
					log.info("Operacion con descuento CGADM " + montoComisUtilSwftSUS);
				}

				// //////////////////////////
				// de la formula de valor futuro VF = VP / (i + 1)
				BigDecimal comiPorc = socComitipoope.getValor().divide(BigDecimal.valueOf(100.00));

				montoTransferenciaUSD = (montoTransferenciaUSD).divide(comiPorc.add(BigDecimal.valueOf(1)), 2, RoundingMode.HALF_UP);

				if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
					SocOpecomi socOpecomiTOTTRANSMT = buscarClaComision(Constants.COD_VAR_TOTTRANSMT, 0);
					if (socOpecomiTOTTRANSMT != null) {

						montoConvertido = UtilsSioc.conversion(socOpecomiTOTTRANSMT.getMontoMo(), socOpecomiTOTTRANSMT.getCodMoneda(),
								Constants.COD_MONEDA_USD, fechaTc, null, "C");

						montoTransferenciaUSD = (BigDecimal) montoConvertido.get("montosus");
					}
				}

				BigDecimal montoComsionPorTransferenciaUSD = montoTransferenciaUSD.multiply(comiPorc).setScale(2, BigDecimal.ROUND_HALF_UP);

				// //////////////////////////

				if ((socSolicitudctasCOMCTRA.getCveTipocomis() != null && socSolicitudctasCOMCTRA.getCveTipocomis().equals(
						Constants.CLAVE_TIPOCOMIS_BENEF))
						&& socSolicitudctasMOVPROVISION.getNroCuenta().equals(socSolicitudctasCOMCTRA.getNroCuenta())
						&& socSolicitudctasMOVPROVISION.getCodMoneda().compareTo(socSolicitudctasCOMCTRA.getCodMoneda()) == 0) {
					// si las comisiones de transferencia lo asume el
					// beneficiario y las cuentas son iguales
					// se desc la comision por transfrencia
					montoTotalComisSUS = montoTotalComisSUS.add(montoComsionPorTransferenciaUSD);
					log.info("Operacion con descuento CTRA " + montoComsionPorTransferenciaUSD);
				}

				if (montoTotalComisSUS.compareTo(BigDecimal.ZERO) <= 0) {
					throw new BusinessException(
							"Operacion con Descuento pero con comisiones a descontar menor o igual a cero, revise ctas CTRA y GADM");
				}

				// la moneda de comisiones sera la de provision ya que es con
				// descuento
				Integer codMonedaCtaComision = socSolicitudctasMOVPROVISION.getCodMoneda();

				// registramos el monto total de comisiones del monto solicitado
				// util solo para esquemas con descuento
				montoConvertido = UtilsSioc.conversion(montoTotalComisSUS, Constants.COD_MONEDA_USD, codMonedaCtaComision, fechaTc, null, "C");

				montoBS = (BigDecimal) montoConvertido.get("montobs");
				montoMO = (BigDecimal) montoConvertido.get("montomo");
				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "TOTCOMISPROV", montoBS, montoMO, codMonedaCtaComision, "R",
						tipocambiomoxbs);

				BigDecimal totalMontoADebitarSUS = montoTransferenciaUSD.add(montoTotalComisSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
					// se suma el monto transferido + las comisiones para que no
					// haaya modificacion por diff
					montoADebitarSUS = totalMontoADebitarSUS;
				}

				// monto total debitado en usd menos monto total calculado
				BigDecimal diff = montoADebitarSUS.subtract(totalMontoADebitarSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				log.info("AJUSTE!! Operacion CON descuento sumaComisBS[" + montoBS + "], DEBITOUSD en USD[" + montoADebitarSUS
						+ "], montoTotalComisSUS [" + montoTotalComisSUS + "], montoComsionUSDDescuento[" + montoComsionPorTransferenciaUSD
						+ "], montoTransferUSDDescuento[" + montoTransferenciaUSD + "], totalMontoADebitarSUS=[" + totalMontoADebitarSUS + "] "
						+ ", diferencia=" + diff);

				if (diff.abs().compareTo(BigDecimal.valueOf(0.00)) != 0) {
					log.info("Diferencia en calculo de operacion con descuento --->[(totalMontoADebitarSUS)" + totalMontoADebitarSUS
							+ " - (montoOrdSUS)" + montoADebitarSUS + "] " + diff);
					montoTransferenciaUSD = montoTransferenciaUSD.add(diff).divide(BigDecimal.valueOf(1), 2, RoundingMode.HALF_UP);
				}

				totalMontoADebitarSUS = montoTransferenciaUSD.add(montoTotalComisSUS).setScale(2, BigDecimal.ROUND_HALF_UP);

				montoConvertido = UtilsSioc.conversion(montoTransferenciaUSD, Constants.COD_MONEDA_USD, monedaDeTransferencia, fechaTc, null, "C");

				montoBS = (BigDecimal) montoConvertido.get("montobs");
				montoMO = (BigDecimal) montoConvertido.get("montomo");
				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
				// este es el monto a transferir al beneficiario ya sea en
				// el
				// momento de la transferencia

				if (montoMO.compareTo(BigDecimal.ZERO) <= 0) {
					throw new BusinessException("Operacion con Descuento con monto de transferencia [" + montoMO + "] menor o igual a cero");
				}

				// *******##########**********//
				// monto a transferir
				socDetallesopeLista.get(0).setDetMontotrans(montoMO);

				/****************/
				// calculo del monto a transferir en la provision en moneda
				// de
				// la cta de provision
				Integer codMonedaCtaDebito = socSolicitudctasMOVPROVISION.getCodMoneda();

				montoConvertido = UtilsSioc.conversion(montoTransferenciaUSD, Constants.COD_MONEDA_USD, codMonedaCtaDebito, fechaTc, null, "C");

				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
				montoBS = (BigDecimal) montoConvertido.get("montobs");
				montoMO = (BigDecimal) montoConvertido.get("montomo");

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "TOTTRANSPROV", montoBS, montoMO, codMonedaCtaDebito, "R",
						tipocambiomoxbs);

				// calculo del monto ordenado en moneda de la transferencia
				montoConvertido = UtilsSioc.conversion(montoADebitarSUS, Constants.COD_MONEDA_USD, monedaDeTransferencia, fechaTc, null, "C");

				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
				montoBS = (BigDecimal) montoConvertido.get("montobs");
				montoMO = (BigDecimal) montoConvertido.get("montomo");

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "MONTOORD", montoBS, montoMO, monedaDeTransferencia, "R",
						tipocambiomoxbs);

				montoConvertido = UtilsSioc.conversion(montoTotalComisSUS, Constants.COD_MONEDA_USD, monedaDeTransferencia, fechaTc, null, "C");
				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
				montoBS = (BigDecimal) montoConvertido.get("montobs");
				montoMO = (BigDecimal) montoConvertido.get("montomo");

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "MONTOORDCOMIS", montoBS, montoMO, monedaDeTransferencia,
						"R", tipocambiomoxbs);

				// calculamos el total del debito a la fecha
				montoConvertido = UtilsSioc.conversion(totalMontoADebitarSUS, Constants.COD_MONEDA_USD, codMonedaCtaDebito, fechaTc, null,
						((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");
				montoBS = (BigDecimal) montoConvertido.get("montobs");
				montoMO = (BigDecimal) montoConvertido.get("montomo");

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_TOTDEBITO, montoBS, montoMO, codMonedaCtaDebito, "R",
						tipocambiomoxbs);

				// SI HAY venta los dolares seran el monto total a debitar
				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "TOTDEBITOUSD", montoBS, totalMontoADebitarSUS,
						Constants.COD_MONEDA_USD, "R", tipocambiomoxbs);

				return socOpecomiList;
			} // Tipo Retencion con descu
		} // if (socComitipoope != null)
		return socOpecomiList;
	}

	private List<SocOpecomi> calculoMontosDetalleTransfer(SocSolicitudes socSolicitudes, SocEsquemas socEsquemas,
			List<SocDetallessol> socDetallesopeLista, List<SocOpecomi> socOpecomiLista, SocComitipoope socComitipoope,
			Map<String, SocSolicitudctas> socSolicitudctasLista, Date fechaTc) {
		// //////////////////////
		// guardamos los montos del detalle de la operacion
		SocCuentassolDao socCuentassolDao = new SocCuentassolDao();
		socCuentassolDao.setSessionFactory(getSessionFactory());

		log.info("Ingresando a registroMontoDetalle para registro de detalle: " + socSolicitudes.toString());

		Map<String, Object> montoConvertido = null;

		BigDecimal sumaMontoBenefMO = BigDecimal.valueOf(0.00);
		BigDecimal tipocambiomoxbs = BigDecimal.valueOf(0.00);
		BigDecimal tipocambiosus = BigDecimal.valueOf(0.00);
		BigDecimal montoBS = BigDecimal.ZERO;

		// la moneda de la cta de beneficiario es la moneda de transferencia
		Integer codMonedaCtaCtrl = null;

		int cont = 0;

		Integer codMonedaCtaDebito = socSolicitudctasLista.get(Constants.COD_CLAVE_MOVPROVISION).getCodMoneda();
		Integer monedaMonTrans = socSolicitudes.getCodMonedat();

		if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
			// calculamos el monto a abonar
			SocSolicitudctas socSolicitudctasBENEFMT = socSolicitudctasLista.get(Constants.COD_CLAVE_BENEFMT);
			if (socSolicitudctasBENEFMT != null) {
				monedaMonTrans = socSolicitudctasBENEFMT.getCodMoneda();
			}
		}

		for (SocDetallessol socDetallesope : socDetallesopeLista) {
			cont++;
			if (cont > 1) {
				if (codMonedaCtaCtrl.compareTo(socDetallesope.getCodMoneda()) != 0) {
					log.error("Operacion con mas de una moneda diferente en detalle, cod detalle [" + socDetallesope.getId().getDetCodigo()
							+ "] con moneda " + socDetallesope.getCodMoneda());
					throw new BusinessException("Operacion con mas de una moneda diferente en detalle, cod detalle ["
							+ socDetallesope.getId().getDetCodigo() + "] con moneda " + socDetallesope.getCodMoneda());
				}
			}

			BigDecimal montoTrans = BigDecimal.ZERO;

			socOpecomiLista = calculoComisionesFijos(socSolicitudes, socEsquemas, socOpecomiLista, socDetallesopeLista, socSolicitudctasLista,
					fechaTc, socDetallesope.getId().getDetCodigo());

			if (socSolicitudes.getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				montoTrans = socDetallesopeLista.get(0).getDetMontotrans();
			} else {
				// sin descuento
				BigDecimal detMonto = socDetallesope.getDetMonto();
				Integer detCodMoneda = socDetallesope.getCodMoneda();
				if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_OPER)) {
					// el monto a abonar sera el ingresado por el usuario
					SocOpecomi socOpecomiMONTOD = buscarClaComision(Constants.COD_VAR_TOTTRANSMT, 0);

					if (socOpecomiMONTOD != null) {
						if (socDetallesopeLista.size() == 1) {
							detMonto = socOpecomiMONTOD.getMontoMo();
							detCodMoneda = socOpecomiMONTOD.getCodMoneda();
						} else {
							// si hay mas de un beneficiario se extrae el monto
							// registrado por el usuario
							if (socDetallesope.getDetMontotrans() != null && socDetallesope.getCodMonedatdet() != null) {
								detMonto = socDetallesope.getDetMontotrans();
								detCodMoneda = socDetallesope.getCodMonedatdet();
							}
						}

						// control de la moneda detalle y la moneda de
						// transferencia deben ser identicas
						if (detCodMoneda.compareTo(monedaMonTrans) != 0) {
							throw new BusinessException("Operacion de transferencia con monedas de Cuenta de transferencia[" + monedaMonTrans
									+ "] y moneda detalle beneficiario [" + detCodMoneda + "] diferentes, solicitud: "
									+ socSolicitudes.getSocCodigo() + " detalle: " + socDetallesope.getId().getDetCodigo());
						}
					}
				}

				montoConvertido = UtilsSioc.conversion(detMonto, detCodMoneda, monedaMonTrans, fechaTc, null,
						((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

				montoTrans = (BigDecimal) montoConvertido.get("montomo");
				montoBS = (BigDecimal) montoConvertido.get("montobs");
				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

				if (montoTrans.compareTo(BigDecimal.ZERO) <= 0) {
					throw new BusinessException("Operacion con monto de transferencia [" + montoTrans + "] menor o igual a cero  "
							+ socSolicitudes.getSocCodigo() + " detalle: " + socDetallesope.getId().getDetCodigo());
				}

			} // sin descuento

			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), socDetallesope.getId().getDetCodigo(), Constants.COD_VAR_MONTOD, montoBS,
					montoTrans, monedaMonTrans, "R", tipocambiomoxbs);

			// ** monto transferido en moneda de la cta de provision
			montoConvertido = UtilsSioc.conversion(montoTrans, monedaMonTrans, codMonedaCtaDebito, fechaTc, null,
					((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

			montoBS = (BigDecimal) montoConvertido.get("montobs");
			// monto a debitar real: valor real de la conversion
			BigDecimal montoADebitar = (BigDecimal) montoConvertido.get("montomo");
			tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

			// MONTOTRANS es el total del monto transferido al beneficiario
			// en moeda del debito

			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), socDetallesope.getId().getDetCodigo(), "MONTOTRANS", montoBS,
					montoADebitar, codMonedaCtaDebito, "R", tipocambiomoxbs);

			// actualizamos el monto detalle a transferir
			socDetallesope.setDetMontotrans(montoTrans);
			socDetallesope.setCodMonedatdet(monedaMonTrans);

			codMonedaCtaCtrl = socDetallesope.getCodMoneda();

			socOpecomiLista = calculoComisionPorTransferencia(socSolicitudes, socEsquemas, socDetallesopeLista, socOpecomiLista, socComitipoope,
					socSolicitudctasLista, fechaTc, montoTrans, monedaMonTrans, socDetallesope.getId().getDetCodigo());

		}// fin for detalles

		// inicio calculo totales solicitud

		BigDecimal montoSUS = BigDecimal.ZERO;
		BigDecimal montoADebitar = BigDecimal.ZERO;
		BigDecimal diffCambiario = BigDecimal.ZERO;
		BigDecimal ventasusexpenbs = BigDecimal.ZERO;
		BigDecimal montoTOTTRansferencia = BigDecimal.ZERO;
		sumaMontoBenefMO = BigDecimal.valueOf(0.00);

		SocOpecomi socOpecomiTOTTRANS = buscarClaComision("TOTALPROV", 0);
		if (socOpecomiTOTTRANS != null)
			montoTOTTRansferencia = socOpecomiTOTTRANS.getMontoMo();

		BigDecimal diferxtcMonDebito = BigDecimal.ZERO;
		BigDecimal sumVentaSus = BigDecimal.ZERO;

		for (SocDetallessol socDetallesope : socDetallesopeLista) {
			SocOpecomi socOpecomiMONTOD = buscarClaComision(Constants.COD_VAR_MONTOD, socDetallesope.getId().getDetCodigo());
			if (socOpecomiMONTOD != null) {
				sumaMontoBenefMO = sumaMontoBenefMO.add(socOpecomiMONTOD.getMontoMo());
			}
		}
		// total monto abonar en ctas del beneficiario
		montoConvertido = UtilsSioc.conversion(sumaMontoBenefMO, monedaMonTrans, Constants.COD_MONEDA_BS, fechaTc, null,
				((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

		montoBS = (BigDecimal) montoConvertido.get("montobs");
		tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomo");

		crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, Constants.COD_VAR_TOTTRANSMT, montoBS, sumaMontoBenefMO, monedaMonTrans,
				"R", tipocambiomoxbs);

		// buscamos el monto transferido para asegurarnos que el mismo no este
		// contabilizado
		SocOpecomi socOpecomiTOTTRANSMT = buscarClaComision(Constants.COD_VAR_TOTTRANSMT, 0);
		sumaMontoBenefMO = socOpecomiTOTTRANSMT.getMontoMo();

		Integer codMonedaVenta = null;
		if (socSolicitudes.getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
			// si es con descuento el monto a debitar sera el de la variable
			// tottrans
			SocOpecomi socOpecomi = buscarClaComision(Constants.COD_VAR_TOTDEBITO, 0);
			montoADebitar = socOpecomi.getMontoMo();
			montoBS = socOpecomi.getOcoMonto();

			socOpecomi = buscarClaComision("TOTDEBITOUSD", 0);
			sumVentaSus = socOpecomi.getMontoMo();
			codMonedaVenta = Constants.COD_MONEDA_USD;
		} else {
			// sino sera la suma de los montos transferidos en la moneda de
			// transferencia
			montoConvertido = UtilsSioc.conversion(sumaMontoBenefMO, monedaMonTrans, codMonedaCtaDebito, fechaTc, null,
					((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

			montoADebitar = (BigDecimal) montoConvertido.get("montomo");
			montoBS = (BigDecimal) montoConvertido.get("montobs");
			tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

			sumVentaSus = sumaMontoBenefMO;

			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, Constants.COD_VAR_TOTDEBITO, montoBS, montoADebitar, codMonedaCtaDebito, "R",
					tipocambiomoxbs);

			codMonedaVenta = monedaMonTrans;

			// registramos el monto total a debitar del la cuenta de provision
			// en
			// USD
			montoConvertido = UtilsSioc.conversion(sumaMontoBenefMO, monedaMonTrans, Constants.COD_MONEDA_USD, fechaTc, null,
					((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));
			montoSUS = (BigDecimal) montoConvertido.get("montomo");
			montoBS = (BigDecimal) montoConvertido.get("montobs");
			tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, "TOTDEBITOUSD", montoBS, montoSUS, Constants.COD_MONEDA_USD, "R",
					tipocambiomoxbs);

		}

		socOpecomiLista = calculoComisionPorTransferencia(socSolicitudes, socEsquemas, socDetallesopeLista, socOpecomiLista, socComitipoope,
				socSolicitudctasLista, fechaTc, sumaMontoBenefMO, monedaMonTrans, 0);

		if (socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) {
			// es a tc de compra pues ya fue comprado
			montoConvertido = UtilsSioc.conversion(sumVentaSus, codMonedaVenta, Constants.COD_MONEDA_BS, fechaTc, null, "V");

			montoSUS = (BigDecimal) montoConvertido.get("montosus");
			BigDecimal tipocambiomdest = (BigDecimal) montoConvertido.get("tipocambiomdest");
			tipocambiosus = (BigDecimal) montoConvertido.get("tipocambiosus");
			diffCambiario = (BigDecimal) montoConvertido.get("difventasus");
			ventasusexpenbs = (BigDecimal) montoConvertido.get("ventasusexpenbs");

			SocOpecomi socOpecomiTIPOFACT_ADM = socOpecomiDao.getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), 0,
					Constants.CLAVE_TIPOFACT_VDD);
			if (socOpecomiTIPOFACT_ADM != null) {
				crearRegistro(socSolicitudes.getSocCodigo(), 0, Constants.COD_VAR_MONTODIFCAMBVENDIV, ventasusexpenbs, diffCambiario,
						BigDecimal.ZERO, Constants.COD_MONEDA_BS, "R", tipocambiosus, socOpecomiTIPOFACT_ADM.getNit(),
						socOpecomiTIPOFACT_ADM.getFactura(), socOpecomiTIPOFACT_ADM.getNroCuenta());
			} else {
				crearRegistro(socSolicitudes.getSocCodigo(), 0, Constants.COD_VAR_MONTODIFCAMBVENDIV, ventasusexpenbs, diffCambiario,
						BigDecimal.ZERO, Constants.COD_MONEDA_BS, "R", tipocambiosus, null, null, null);
			}

			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, "MONTOVENTAUSD", ventasusexpenbs, ventasusexpenbs,
					Constants.COD_MONEDA_BS, "R", tipocambiomdest);

			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, Constants.COD_VAR_VENTAUSD, ventasusexpenbs, montoSUS,
					Constants.COD_MONEDA_USD, "R", tipocambiomdest);
		}

		calculoComisiones(socSolicitudes, socEsquemas, socDetallesopeLista, socComitipoope, socOpecomiLista, socSolicitudctasLista, fechaTc, 0);

		// para el control global del DC por ajuste sera el monto
		// provisinado menos el monto
		// transferido mas el diferencial

		// suma de diferenciales de detalles
		// diferencial total para el comprob global lo que efectivamente se
		// debitara o abonara

		diferxtcMonDebito = montoTOTTRansferencia.subtract(montoADebitar);

		diferxtcMonDebito = diferxtcMonDebito.setScale(2, BigDecimal.ROUND_HALF_UP);

		montoConvertido = UtilsSioc.conversion(diferxtcMonDebito.abs(), codMonedaCtaDebito, Constants.COD_MONEDA_BS, fechaTc, null, "C");
		BigDecimal diferxtcbs = (BigDecimal) montoConvertido.get("montomo");
		tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomo");

		diferxtcbs = diferxtcbs.multiply(BigDecimal.valueOf(diferxtcMonDebito.signum()));

		SocParametrosDao socParametrosDao = new SocParametrosDao();
		socParametrosDao.setSessionFactory(getSessionFactory());

		SocParametros socParametros = socParametrosDao.getByCodigo("ctvs-lim");

		String ctvsLim = socParametros.getParValor();
		BigDecimal ctvsLimConvert = UtilsGeneric.bigDecimalFromString(ctvsLim.trim());

		if (diferxtcbs.abs().compareTo(BigDecimal.valueOf(0.00)) > 0) {
			if ((diferxtcbs.abs().compareTo(ctvsLimConvert) <= 0)) {
				// si se controla dif este diferencial lo asume el BCB
				diferxtcMonDebito = BigDecimal.ZERO;
			}
		}
		if (diferxtcMonDebito.abs().compareTo(BigDecimal.valueOf(0.00)) > 0) {
			// diferencial para el comprobante general
			log.info("$$Diferencial Cambiario$$ [diferxtcMonDebito : " + diferxtcMonDebito + "] montoTOTTRansferencia: " + montoTOTTRansferencia
					+ " montoADebitar:" + montoADebitar);
			crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), 0, "DIFERTC", diferxtcMonDebito, diferxtcMonDebito.abs(),
					codMonedaCtaDebito, "R", tipocambiomoxbs);

		}

		return socOpecomiLista;
	}

	private List<SocOpecomi> calculoComisionesFijos(SocSolicitudes socSolicitudes, SocEsquemas socEsquemas, List<SocOpecomi> socOpecomiList,
			List<SocDetallessol> socDetallesopeLista, Map<String, SocSolicitudctas> socSolicitudctasLista, Date fechaTc, Integer detCodigo) {

		Map<String, Object> montoConvertido = null;

		BigDecimal montoMO = BigDecimal.ZERO;
		BigDecimal tipocambiomoxbs = BigDecimal.ZERO;

		SocParametrosDao socParametrosDao = new SocParametrosDao();
		socParametrosDao.setSessionFactory(getSessionFactory());

		SocParametros socParametros = socParametrosDao.getByCodigo("@iva");

		String ivastr = socParametros.getParValor();
		BigDecimal iva = new BigDecimal(ivastr.replace(",", "."));

		BigDecimal comiPagoIVA = BigDecimal.ZERO;
		BigDecimal comiPagoRet = BigDecimal.ZERO;
		BigDecimal comiGAdm = BigDecimal.ZERO;
		BigDecimal comiGAdmBs = BigDecimal.ZERO;

		if (socEsquemas == null) {
			return socOpecomiList;
		}

		SocSolicitudctas socSolicitudctasCOMGADM = socSolicitudctasLista.get(Constants.COD_CLAVE_COMGADM);
		Integer codMonedaCtaComision = null;
		if (socSolicitudctasCOMGADM != null)
			codMonedaCtaComision = socSolicitudctasCOMGADM.getCodMoneda();

		SocComitipoope socComitipoopeSWIFT = socComitipoopeDao.comisionByCodCargoTipoComis(socEsquemas.getCodCargo(),
				Constants.CLAVE_CARGOTIPOCOMIS_SWFT);
		if (socComitipoopeSWIFT != null) {
			if (codMonedaCtaComision == null)
				throw new BusinessException("CodMoneda cuenta COMGADM nulo");
			// si es nulo se considera que es por el total
			BigDecimal montoTotalFactBS = socComitipoopeSWIFT.getValor();

			if (detCodigo.compareTo(Integer.valueOf(0)) == 0) {
				montoTotalFactBS = montoTotalFactBS.multiply(BigDecimal.valueOf(socDetallesopeLista.size())).setScale(2, BigDecimal.ROUND_HALF_UP);
			}
			montoTotalFactBS = montoTotalFactBS.setScale(2, BigDecimal.ROUND_HALF_UP);

			// por el tipo de cambio de venta
			montoConvertido = UtilsSioc.conversion(montoTotalFactBS, Constants.COD_MONEDA_BS, codMonedaCtaComision, fechaTc, null,
					((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

			montoMO = (BigDecimal) montoConvertido.get("montomo");
			tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

			crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_COMSWIFT, montoTotalFactBS, montoMO,
					codMonedaCtaComision, "R", tipocambiomoxbs);

			comiGAdm = comiGAdm.add(montoMO);
			comiGAdmBs = comiGAdmBs.add(montoTotalFactBS);

			if (detCodigo.compareTo(Integer.valueOf(0)) == 0) {

				// swift con descuento del iva
				// los calculos se realizan en bs ya que la cuenta a abonar es
				// en
				// bolivianos
				comiPagoIVA = montoTotalFactBS.multiply(iva).divide(BigDecimal.valueOf(100));
				comiPagoIVA = comiPagoIVA.setScale(2, BigDecimal.ROUND_HALF_UP);
				comiPagoRet = montoTotalFactBS.subtract(comiPagoIVA);

				SocOpecomi socOpecomiTIPOFACT_ADM = socOpecomiDao.getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), detCodigo,
						Constants.CLAVE_TIPOFACT_ADM);
				if (socOpecomiTIPOFACT_ADM != null) {
					crearRegistro(socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_MONTOGASTOCOM, montoTotalFactBS, comiPagoRet,
							comiPagoIVA, Constants.COD_MONEDA_BS, "R", BigDecimal.ONE, socOpecomiTIPOFACT_ADM.getNit(),
							socOpecomiTIPOFACT_ADM.getFactura(), socOpecomiTIPOFACT_ADM.getNroCuenta());
				} else {
					crearRegistro(socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_MONTOGASTOCOM, montoTotalFactBS, comiPagoRet,
							comiPagoIVA, Constants.COD_MONEDA_BS, "R", BigDecimal.ONE, null, null, null);
				}

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "MONTOGASTOCOMIVA", comiPagoIVA, comiPagoIVA,
						Constants.COD_MONEDA_BS, "R", BigDecimal.ONE);
			}
		}

		if (detCodigo.compareTo(Integer.valueOf(0)) == 0) {
			SocComitipoope socComitipoopeUTIL = socComitipoopeDao.comisionByCodCargoTipoComis(socEsquemas.getCodCargo(),
					Constants.CLAVE_CARGOTIPOCOMIS_UTIL);

			if (socComitipoopeUTIL != null) {
				// solo se cobra por un solo comprobante por una solicitud
				BigDecimal montoTotalFactBS = socComitipoopeUTIL.getValor();

				montoTotalFactBS = montoTotalFactBS.setScale(2, BigDecimal.ROUND_HALF_UP);

				montoConvertido = UtilsSioc.conversion(montoTotalFactBS, Constants.COD_MONEDA_BS, codMonedaCtaComision, fechaTc, null,
						((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

				montoMO = (BigDecimal) montoConvertido.get("montomo");
				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_COMUTIL, montoTotalFactBS, montoMO,
						codMonedaCtaComision, "R", tipocambiomoxbs);

				comiGAdm = comiGAdm.add(montoMO);
				comiGAdmBs = comiGAdmBs.add(montoTotalFactBS);
				// util con descuento del iva
				// los calculos se realizan en bs ya que la cuenta a abonar
				// es
				// en
				// bolivianos
				comiPagoIVA = montoTotalFactBS.multiply(iva).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
				comiPagoRet = montoTotalFactBS.subtract(comiPagoIVA);

				SocOpecomi socOpecomiTIPOFACT_ADM = socOpecomiDao.getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), detCodigo,
						Constants.CLAVE_TIPOFACT_ADM);
				if (socOpecomiTIPOFACT_ADM != null) {
					crearRegistro(socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_MONTOGASTOADM, montoTotalFactBS, comiPagoRet,
							comiPagoIVA, Constants.COD_MONEDA_BS, "R", BigDecimal.ONE, socOpecomiTIPOFACT_ADM.getNit(),
							socOpecomiTIPOFACT_ADM.getFactura(), socOpecomiTIPOFACT_ADM.getNroCuenta());
				} else {
					crearRegistro(socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_MONTOGASTOADM, montoTotalFactBS, comiPagoRet,
							comiPagoIVA, Constants.COD_MONEDA_BS, "R", BigDecimal.ONE, null, null, null);
				}

				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "MONTOGASTOADMIVA", comiPagoIVA, comiPagoIVA,
						Constants.COD_MONEDA_BS, "R", BigDecimal.ONE);
			}

			crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_CLAVE_COMGADM, comiGAdmBs, comiGAdm,
					codMonedaCtaComision, "R", BigDecimal.ONE);

			if (socSolicitudes.getTipoRetencion().equals(Constants.CLAVE_TIPORETENCION_CONDESC)) {
				// si es con descuento se determina si las cgadm se descuentan
				if (socSolicitudctasCOMGADM != null && socSolicitudctasCOMGADM.getCveTipocomis() != null
						&& socSolicitudctasCOMGADM.getCveTipocomis().equals(Constants.CLAVE_TIPOCOMIS_BENEF)) {
					// las comisiones son descontadas del monto solicitado

				} else {
					// las cgadm no son descontadas del monto solicitado son
					// comisiones parciales que se debita de la cta de cgadm
					montoConvertido = UtilsSioc.conversion(comiGAdmBs, Constants.COD_MONEDA_BS, codMonedaCtaComision, fechaTc, null, "C");

					montoMO = (BigDecimal) montoConvertido.get("montomo");
					tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

					crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "COMGADMPROV", comiGAdmBs, montoMO, codMonedaCtaComision,
							"R", tipocambiomoxbs);
				}
			}
		}

		return socOpecomiList;
	}

	private List<SocOpecomi> calculoComisionPorTransferencia(SocSolicitudes socSolicitudes, SocEsquemas socEsquemas,
			List<SocDetallessol> socDetallesopeLista, List<SocOpecomi> socOpecomiList, SocComitipoope socComitipoope,
			Map<String, SocSolicitudctas> socSolicitudctasLista, Date fechaTc, BigDecimal montoTransferencia, Integer codMonedaMonto,
			Integer detCodigo) {

		if (socComitipoope != null) {
			SocSolicitudctas socSolicitudctasCOMCTRA = socSolicitudctasLista.get(Constants.COD_CLAVE_COMCTRA);
			if (socSolicitudctasCOMCTRA != null && socSolicitudctasCOMCTRA.getCodMoneda() != null) {
				Integer codMonedaCtaComision = socSolicitudctasCOMCTRA.getCodMoneda();

				// comisiones por transferencia al exterior, se debe determinar
				// el
				// monto
				// a transferir ya que el mismo depende del tipo de cambio

				BigDecimal comiPorc = socComitipoope.getValor().divide(BigDecimal.valueOf(100));

				// convertimos el monto de la moneda a transferir en dolares
				// expresado
				// en la moneda a debitar
				BigDecimal montoComsionUSD = BigDecimal.ZERO;

				// convertimos la moneda en dolares esto por el tc q debe ser el
				// de
				// compra
				Map<String, Object> montoConvertido = UtilsSioc.conversion(montoTransferencia, codMonedaMonto, Constants.COD_MONEDA_USD, fechaTc,
						null, "C");

				BigDecimal montoSUS = (BigDecimal) montoConvertido.get("montomo");

				montoComsionUSD = montoSUS.multiply(comiPorc).setScale(2, BigDecimal.ROUND_HALF_UP);
				log.info("comision por {montoSUS: " + montoSUS + " - USD} (" + comiPorc + " %) : " + montoComsionUSD);

				// convertimos la comision en dolares a la moneda de la cuenta
				// de
				// comisiones,
				montoConvertido = UtilsSioc.conversion(montoComsionUSD, Constants.COD_MONEDA_USD, codMonedaCtaComision, fechaTc, null, "C");

				BigDecimal montoTotalFactBS = (BigDecimal) montoConvertido.get("montobs");
				BigDecimal montoMO = (BigDecimal) montoConvertido.get("montomo");
				BigDecimal tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

				// el campo en ocomonto es usado para la factura en BS
				crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_COMTRANSF, montoTotalFactBS, montoMO,
						codMonedaCtaComision, "R", tipocambiomoxbs);

				// actualizamos el registro de la factura en la tabla variables
				if (detCodigo.compareTo(Integer.valueOf(0)) == 0) {

					// calculamos la comision por transferencia sin iva

					SocParametrosDao socParametrosDao = new SocParametrosDao();
					socParametrosDao.setSessionFactory(getSessionFactory());

					SocParametros socParametros = socParametrosDao.getByCodigo("@iva");

					String ivastr = socParametros.getParValor();

					BigDecimal iva = new BigDecimal(ivastr.replace(",", "."));

					// convertimos a bolivianos pero al tc de compra
					montoConvertido = UtilsSioc.conversion(montoComsionUSD, Constants.COD_MONEDA_USD, Constants.COD_MONEDA_BS, fechaTc, null, "C");
					montoTotalFactBS = (BigDecimal) montoConvertido.get("montomo");

					iva = (iva).divide(BigDecimal.valueOf(100.00));
					BigDecimal comiPagoIVA = montoTotalFactBS.multiply(iva).setScale(2, BigDecimal.ROUND_HALF_UP);
					BigDecimal comiPagoRet = montoTotalFactBS.subtract(comiPagoIVA);

					// en oco monto esta el 13% iva y en montomo el monto total
					// comiPagoRet + comiPagoIVA = montoTotalFactBS (total
					// importe)

					SocOpecomi socOpecomiTIPOFACT_CTRA = socOpecomiDao.getOpeComisByDetCodClaCom(socSolicitudes.getSocCodigo(), detCodigo,
							Constants.CLAVE_TIPOFACT_CTRA);

					if (socOpecomiTIPOFACT_CTRA != null) {
						crearRegistro(socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_MONTOCOMTRANSEXT, montoTotalFactBS, comiPagoRet,
								comiPagoIVA, Constants.COD_MONEDA_BS, "R", BigDecimal.ONE, socOpecomiTIPOFACT_CTRA.getNit(),
								socOpecomiTIPOFACT_CTRA.getFactura(), socOpecomiTIPOFACT_CTRA.getNroCuenta());
					} else {
						crearRegistro(socSolicitudes.getSocCodigo(), detCodigo, Constants.COD_VAR_MONTOCOMTRANSEXT, montoTotalFactBS, comiPagoRet,
								comiPagoIVA, Constants.COD_MONEDA_BS, "R", BigDecimal.ONE, null, null, null);
					}

					crearRegistro(socOpecomiList, socSolicitudes.getSocCodigo(), detCodigo, "MONTOCOMTRANSEXTIVA", comiPagoIVA, comiPagoIVA,
							Constants.COD_MONEDA_BS, "R", BigDecimal.ONE);
				}
			}
		}

		return socOpecomiList;

	}

	private List<SocOpecomi> calculoComisiones(SocSolicitudes socSolicitudes, SocEsquemas socEsquemas, List<SocDetallessol> socDetallesopeLista,
			SocComitipoope socComitipoope, List<SocOpecomi> socOpecomiLista, Map<String, SocSolicitudctas> socSolicitudctasLista, Date fechaTc,
			Integer detCodigo) {

		// comisiones por transferencia al exterior, se debe determinar el
		// monto
		// a transferir ya que el mismo depende del tipo de cambio
		BigDecimal montoTotalComisionesBS = BigDecimal.ZERO;
		BigDecimal montoBS = BigDecimal.ZERO;
		BigDecimal montoMO = BigDecimal.ZERO;
		BigDecimal tipocambiomoxbs = BigDecimal.ZERO;
		BigDecimal ivaTotal = BigDecimal.ZERO;
		// si es sin descuento el monto se calcula sino este ya fue calculado en
		// descuento

		SocOpecomi socOpecomiMONTOGASTOADMIVA = buscarClaComision("MONTOGASTOADMIVA", detCodigo);
		if (socOpecomiMONTOGASTOADMIVA != null)
			ivaTotal = socOpecomiMONTOGASTOADMIVA.getMontoMo();

		SocOpecomi socOpecomiMONTOGASTOCOMIVA = buscarClaComision("MONTOGASTOCOMIVA", detCodigo);
		if (socOpecomiMONTOGASTOCOMIVA != null)
			ivaTotal = ivaTotal.add(socOpecomiMONTOGASTOCOMIVA.getMontoMo());

		SocOpecomi socOpecomiMONTOCOMTRANSEXTIVA = buscarClaComision("MONTOCOMTRANSEXTIVA", detCodigo);
		if (socOpecomiMONTOCOMTRANSEXTIVA != null)
			ivaTotal = ivaTotal.add(socOpecomiMONTOCOMTRANSEXTIVA.getMontoMo());

		crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), detCodigo, "MONTOCOMIVA", ivaTotal, ivaTotal, Constants.COD_MONEDA_BS, "R",
				BigDecimal.ONE);

		// se debe calcular el total del monto de comisiones

		SocOpecomi socOpecomiCOMGADM = buscarClaComision(Constants.COD_CLAVE_COMGADM, 0);
		SocOpecomi socOpecomiCOMTRANSF = buscarClaComision(Constants.COD_VAR_COMTRANSF, detCodigo);

		if (socOpecomiCOMGADM != null)
			montoTotalComisionesBS = socOpecomiCOMGADM.getOcoMonto();

		if (socOpecomiCOMTRANSF != null)
			montoTotalComisionesBS = montoTotalComisionesBS.add(socOpecomiCOMTRANSF.getOcoMonto());

		if (montoTotalComisionesBS.compareTo(BigDecimal.ZERO) != 0) {
			SocSolicitudctas socSolicitudctasCOMGADM = socSolicitudctasLista.get(Constants.COD_CLAVE_COMGADM);
			if (socSolicitudctasCOMGADM != null) {
				Map<String, Object> montoConvertido = UtilsSioc.conversion(montoTotalComisionesBS, Constants.COD_MONEDA_BS,
						socSolicitudctasCOMGADM.getCodMoneda(), fechaTc, null, "C");

				montoBS = (BigDecimal) montoConvertido.get("montobs");
				montoMO = (BigDecimal) montoConvertido.get("montomo");
				tipocambiomoxbs = (BigDecimal) montoConvertido.get("tipocambiomdest");

				// total comisiona a provisionar(transferir de la cta de
				// comisiones del solicitante o beneficiario)
				crearRegistro(socOpecomiLista, socSolicitudes.getSocCodigo(), detCodigo, "TOTCOMISION", montoBS, montoMO,
						socSolicitudctasCOMGADM.getCodMoneda(), "R", tipocambiomoxbs);
			}
		}

		return socOpecomiLista;
	}

	/**
	 * genera las comisiones de una operacion segun la techa del tipo cde cambio
	 * 
	 * @param operacion
	 * @param fechaTc
	 * @return
	 */
	public Solicitud guardarVariablesSolicitud(Solicitud solicitud, Date fechaTc) {
		// la fecha de actualizacion de variables siempre es a hoy ya que
		// depende del tipo de cambio
		fechaTc = new Date();
		log.info("==>> Inicio a ACT DE VARIABLES: " + solicitud.getSolicitud().getSocCodigo() + " a hoy " + fechaTc);
		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());

		SocSolicitudctasDao socSolicitudctasDao = new SocSolicitudctasDao();
		socSolicitudctasDao.setSessionFactory(getSessionFactory());

		SocDetallessolDao socDetallessolDao = new SocDetallessolDao();
		socDetallessolDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocSolicitudes socSolicitudes = socSolicitudesDao.getSolicitud(solicitud.getSolicitud().getSocCodigo());

		if (socSolicitudes.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_CONTAB)
				|| socSolicitudes.getClaEstado().equals(Constants.CLAVE_ESTSOLIC_ANULADO)) {
			throw new BusinessException("Solicitud con estado invalido[" + socSolicitudes.getClaEstado() + "] no puede continuar "
					+ socSolicitudes.getSocCodigo());
		}

		socSolicitudesDao.validarDatos(socSolicitudes);

		solicitud.setSolicitud(socSolicitudes);
		socOpecomiDao.eliminarRegs(solicitud.getSolicitud().getSocCodigo(), "V");
		List<SocOpecomi> socOpecomiLista = socOpecomiDao.getComis(solicitud.getSolicitud().getSocCodigo());

		solicitud.setSocOpecomiLista(socOpecomiLista);

		socOpecomiMap = new HashMap<String, SocOpecomi>();

		String codVaria = "";
		for (SocOpecomi socOpecomi : socOpecomiLista) {
			if (!StringUtils.isBlank(socOpecomi.getCveTipocomis()) && socOpecomi.getCveTipocomis().equals("V")) {
				// si es variable
				if (socOpecomi.getClaEstadovar() != null && socOpecomi.getClaEstadovar().equals("C")) {
					// solo se recupera los contabilizados
					codVaria = String.valueOf(socOpecomi.getId().getDetCodigo()).concat(socOpecomi.getId().getClaComision());
					socOpecomiMap.put(codVaria, socOpecomi);
				}
			}
		}
		// ////////////

		SocEsquemas socEsquemas = socEsquemasDao.esquemaByCod(solicitud.getSolicitud().getEsqCodigo());
		socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo());

		SocComitipoope socComitipoopeTranfer = null;

		List<SocRengesq> socRengesqLista = socRengesqDao.obtenerEsquemaByDefinicion(socSolicitudes.getEsqCodigo(), null, null, null,
				Constants.CLAVE_CLACTA_COMTRANS);

		if (socRengesqLista.size() > 0) {
			// la operacion tiene comisiones por transferencia
			socComitipoopeTranfer = socComitipoopeDao.comisionByCargo(socEsquemas.getCodCargo(), Constants.CLAVE_TIPOCARGO_TRANSFER);
		}

		List<SocDetallessol> socDetallesopeLista = socDetallessolDao.getDetalles(solicitud.getSolicitud().getSocCodigo());

		if (socDetallesopeLista.size() == 0) {
			log.error("Solicitud [" + solicitud.getSolicitud().getSocCodigo() + "] sin beneficiarios registrados");
			throw new BusinessException("Swift: Solicitud [" + solicitud.getSolicitud().getSocCodigo() + "] sin beneficiarios registrados");
		}

		SocSolicitudctas socSolicitudctasDEBITO = socSolicitudctasDao.getCuenta(solicitud.getSolicitud().getSocCodigo(),
				Constants.COD_CLAVE_MOVPROVISION, null, null, null, null);
		if (socSolicitudctasDEBITO == null) {
			throw new BusinessException("Cuenta CLAVE_MOVPROVISION inexistente en listacuentas");
		}

		SocSolicitudctas socSolicitudctasCOMGADM = socSolicitudctasDao.getCuenta(solicitud.getSolicitud().getSocCodigo(),
				Constants.COD_CLAVE_COMGADM, null, null, null, null);
		if (socSolicitudctasCOMGADM == null) {
			if (socSolicitudes.getCveSubtipooper().equals(Constants.CLAVE_SUBTIPOOPER_TRADELEXT)) {
				// no se controla ya que son operaciones internas
			} else 
				throw new BusinessException("Cuenta COMGADM inexistente en listacuentas");
		}

		List<SocSolicitudctas> socSolicitudctasLista = socSolicitudctasDao.getCuentas(solicitud.getSolicitud().getSocCodigo());
		solicitud.setSocSolicitudctasLista(socSolicitudctasLista);

		Map<String, SocSolicitudctas> socSolicitudctasMap = new HashMap<String, SocSolicitudctas>();

		for (SocSolicitudctas socSolicitudctas : socSolicitudctasLista) {
			socSolicitudctasMap.put(socSolicitudctas.getId().getTipoCuenta(), socSolicitudctas);
		}

		calculoVariables(socSolicitudes, socEsquemas, socDetallesopeLista, socComitipoopeTranfer, socOpecomiLista, socSolicitudctasMap, fechaTc,
				socSolicitudes.getSocMontome(), socSolicitudes.getCodMoneda(), 0);

		for (Map.Entry<?, ?> entry : socOpecomiMap.entrySet()) {
			SocOpecomi socOpecomi = (SocOpecomi) entry.getValue();
			if (socOpecomi.getMontoMo() != null && socOpecomi.getMontoMo().compareTo(BigDecimal.ZERO) != 0) {
				if (socOpecomi.getClaEstadovar() != null && !socOpecomi.getClaEstadovar().equals(Constants.CLAVE_ESTCOMP_CONTAB)) {
					socOpecomi.setFechaHora(new Date());
					socOpecomi.setUsrCodigo(solicitud.getCodUsuarioAudit());
					socOpecomi.setEstacion(solicitud.getCodEstacionAudit());
					socOpecomiDao.saveOrUpdate(socOpecomi);
				}
			}
		}

		for (SocDetallessol socDetallessol : socDetallesopeLista) {
			socDetallessolDao.saveOrUpdate(socDetallessol);
		}

		// /////////////
		if (socSolicitudes.getSocTipnegociacion().equals(Constants.CLAVE_TIPNEGOCIA_NORMAL)) {
			Map<String, Object> montoConvertido = UtilsSioc
					.conversion(socSolicitudes.getSocMontome(), socSolicitudes.getCodMoneda(), socSolicitudes.getCodMonedat(), fechaTc, null,
							((socSolicitudes.getClaTipo().equals(Constants.CLAVE_TIPOOPER_VENTA)) ? "V" : "C"));

			BigDecimal tipocambiomdest = (BigDecimal) montoConvertido.get("tipocambiomdest");
			// actualizamos la fecha del tipo de cambio
			log.info("Variables actualizadas: " + socSolicitudes.getSocCodigo() + " para fecha " + UtilsDate.stringFromDate(fechaTc, "dd/MM/yyyy")
					+ " [" + socSolicitudes.getCodMonedat() + "] tipo Cambio: " + tipocambiomdest);

			socSolicitudes.setSocTipoc(tipocambiomdest);
		}

		socSolicitudes.setFecha(fechaTc);
		// salvamos la solicitud si tuviera cambios y los detalles
		socSolicitudesDao.getHibernateTemplate().saveOrUpdate(socSolicitudes);
		socSolicitudes = socSolicitudesDao.getSolicitud(solicitud.getSolicitud().getSocCodigo());

		solicitud.setSolicitud(socSolicitudes);
		
		log.info("Fin calcular variables...");
		return solicitud;
	}

	public void calcularVariablesSolicitud(SocSolicitudes socSolicitudes, List<SocDetallessol> socDetallesopeLista,
			List<SocSolicitudctas> socSolicitudctasLista) {
		// la fecha de actualizacion de variables siempre es a hoy ya que
		// depende del tipo de cambio
		Date fechaTc = new Date();
		log.info("==>> Inicio a CALCULO DE VARIABLES: " + fechaTc);

		SocRengesqDao socRengesqDao = new SocRengesqDao();
		socRengesqDao.setSessionFactory(getSessionFactory());

		SocSolicitudesDao socSolicitudesDao = new SocSolicitudesDao();
		socSolicitudesDao.setSessionFactory(getSessionFactory());

		SocSolicitanteDao socSolicitanteDao = new SocSolicitanteDao();
		socSolicitanteDao.setSessionFactory(getSessionFactory());

		SocEsquemasDao socEsquemasDao = new SocEsquemasDao();
		socEsquemasDao.setSessionFactory(getSessionFactory());

		socOpecomiMap = new HashMap<String, SocOpecomi>();

		SocComitipoope socComitipoopeTranfer = null;
		SocEsquemas socEsquemas = null;

		if (socSolicitudes.getEsqCodigo() != null) {
			socEsquemas = socEsquemasDao.esquemaByCod(socSolicitudes.getEsqCodigo());

			socSolicitanteDao.solicitanteByCod(socSolicitudes.getSolCodigo());

			List<SocRengesq> socRengesqLista = socRengesqDao.obtenerEsquemaByDefinicion(socSolicitudes.getEsqCodigo(), null, null, null,
					Constants.CLAVE_CLACTA_COMTRANS);

			if (socRengesqLista.size() > 0) {
				// la operacion tiene comisiones por transferencia
				socComitipoopeTranfer = socComitipoopeDao.comisionByCargo(socEsquemas.getCodCargo(), Constants.CLAVE_TIPOCARGO_TRANSFER);
			}
		}
		Map<String, SocSolicitudctas> socSolicitudctasMap = new HashMap<String, SocSolicitudctas>();

		for (SocSolicitudctas socSolicitudctas : socSolicitudctasLista) {
			socSolicitudctasMap.put(socSolicitudctas.getId().getTipoCuenta(), socSolicitudctas);
		}

		SocSolicitudctas socSolicitudctasMOVPROVISION = socSolicitudctasMap.get(Constants.COD_CLAVE_MOVPROVISION);
		SocSolicitudctas socSolicitudctasCOMGADM = socSolicitudctasMap.get(Constants.COD_CLAVE_COMGADM);
		SocSolicitudctas socSolicitudctasCOMCTRA = socSolicitudctasMap.get(Constants.COD_CLAVE_COMCTRA);

		if (socSolicitudctasMOVPROVISION == null || socSolicitudctasMOVPROVISION.getCodMoneda() == null) {
			return;
		}

		calculoTotalProvision(socSolicitudes, socEsquemas, null, socSolicitudctasMap, fechaTc, socSolicitudes.getSocMontome(),
				socSolicitudes.getCodMoneda());

		if (socDetallesopeLista.size() > 0) {
			if (socSolicitudctasCOMGADM != null && socSolicitudctasCOMGADM.getCodMoneda() != null
					&& socSolicitudctasCOMGADM.getCveTipocomis() != null) {
				calculoComisionesFijos(socSolicitudes, socEsquemas, null, socDetallesopeLista, socSolicitudctasMap, fechaTc, 0);

				if (socSolicitudctasCOMCTRA != null && socSolicitudctasCOMCTRA.getCodMoneda() != null
						&& socSolicitudctasCOMCTRA.getNroCuenta() != null && socSolicitudctasCOMCTRA.getCveTipocomis() != null) {

					montoATransferirConDescuento(socSolicitudes, socEsquemas, socDetallesopeLista, null, socComitipoopeTranfer,
							socSolicitudes.getSocMontome(), socSolicitudes.getCodMoneda(), socSolicitudctasMap, fechaTc, 0);
				}

				calculoMontosDetalleTransfer(socSolicitudes, socEsquemas, socDetallesopeLista, null, socComitipoopeTranfer, socSolicitudctasMap,
						fechaTc);

			}
		}
		GenMonedaDao genMonedaDao = new GenMonedaDao();
		genMonedaDao.setSessionFactory(getSessionFactory());

		for (Map.Entry<?, ?> entry : socOpecomiMap.entrySet()) {
			SocOpecomi socOpecomi = (SocOpecomi) entry.getValue();
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socOpecomi.getCodMoneda());
			socOpecomi.setGenMoneda(genMoneda);
		}
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static void main(String[] args) {
		BigDecimal a = new BigDecimal("100");
		BigDecimal b = a;
		BigDecimal c = BigDecimal.valueOf(100);

		System.out.println(a + " " + b);
		System.out.println(a.toString() + " " + b.toString());
		a = a.add(c);
		System.out.println(a + " " + b);

	}

}
