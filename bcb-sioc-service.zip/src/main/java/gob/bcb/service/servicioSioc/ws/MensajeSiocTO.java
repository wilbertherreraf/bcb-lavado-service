package gob.bcb.service.servicioSioc.ws;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;

import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.JAXBHelper;
import gob.bcb.core.utils.StringFormat;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.core.utils.XmlUtils;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.Beneficiario;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.Beneficiarios;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.CabeceraRespuesta;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.CuentaBeneficiario;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.CuentasBeneficiario;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.DatosOperacion;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.RespuestaOperacion;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.RespuestaSioc;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.ServicioSioc;
import gob.bcb.service.servicioSioc.ws.xml.consultasolic.SolicitudRespuesta;

public class MensajeSiocTO {
	private static final Log log = LogFactory.getLog(MensajeSiocTO.class);
	private Object mensajeBCBJAXB;
	private RespuestaSioc respuestaSioc;
	private final static JAXBContext jAXBContext;
	static {
		try {
			jAXBContext = JAXBContext.newInstance("gob.bcb.service.servicioSioc.ws.xml.consultasolic");
			log.info("Contexto objetos JAXB iniciado");
		} catch (JAXBException e) {
			log.error("Error al inicializar contexto JAXB " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}
	private final static Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();
	private static DocumentBuilderFactory documentBuilderFactory;

	public MensajeSiocTO() {
		CabeceraRespuesta cabeceraRespuesta = new CabeceraRespuesta();
		DatosOperacion datosOperacion = new DatosOperacion();
		datosOperacion.setCodEstadoResp("00000");
		datosOperacion.setDescEstadoResp("Consulta sin procesar. Avise a Sistemas");

		respuestaSioc = new RespuestaSioc();

		respuestaSioc.setCabeceraRespuesta(cabeceraRespuesta);
		respuestaSioc.setDatosOperacion(datosOperacion);
	}

	public Object transformaXML(String mensajeXML) {

		Object mensajeJAXB = null;
		try {
			byte[] b = mensajeXML.getBytes("ISO-8859-1");// UtilsGeneric.newStringFromString(mensajeXML);
			mensajeXML = new String(b, "ISO-8859-1");
			//mensajeXML = StringUtils.replaceChars(mensajeXML, "ÁÉÍÓÚÑáéíóúñ()?+\'", "AEIOUNaeioun     ");
			log.info("=======> inicio mensaje XML <========");
			log.info(mensajeXML);
			log.info("=======> fin mensaje XML <========");

			// verificamos si existe alguna cadena contiene >null<
			if (mensajeXML.contains(">null<")) {
				throw new RuntimeException("mensaje contiene valores 'null'");
			}
			JAXBContext context = JAXBContext.newInstance(ServicioSioc.class);
			mensajeJAXB = JAXBHelper.convertXMLToMsgBcb((String) mensajeXML, context);
			mensajeBCBJAXB = mensajeJAXB;

			actualizarCabeceraRespuesta();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new RuntimeException(e);
		}

		return mensajeXML;
	}

	public String transformaXML() {
		String mensajeXML = null;
		try {

			JAXBContext context = JAXBContext.newInstance(RespuestaSioc.class);
			Document doc = JAXBHelper.toDocument(respuestaSioc, documentBuilderFactory, context);
			mensajeXML = XmlUtils.getStringFromDom(doc);

		} catch (JAXBException e) {
			throw new RuntimeException(e);
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		} catch (TransformerException e) {
			throw new RuntimeException(e);
		}

		return mensajeXML;
	}

	public String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		Document doc = JAXBHelper.toDocument(value, documentBuilderFactory, getJaxbcontext());
		return XmlUtils.getStringFromDom(doc);

	}

	public static JAXBContext getJaxbcontext() {
		return jAXBContext;
	}

	public Object getMensajeBCBJAXB() {
		return mensajeBCBJAXB;
	}

	public void setMensajeBCBJAXB(Object mensajeBCBJAXB) {
		this.mensajeBCBJAXB = mensajeBCBJAXB;
	}

	public RespuestaSioc getRespuestaSioc() {
		return respuestaSioc;
	}

	public void setRespuestaSioc(RespuestaSioc respuestaSioc) {
		this.respuestaSioc = respuestaSioc;
	}

	public void actualizarCabeceraRespuesta() {
		if (mensajeBCBJAXB != null) {
			ServicioSioc servicioSioc = (ServicioSioc) mensajeBCBJAXB;

			respuestaSioc.getCabeceraRespuesta().setCodTipoOperacion(servicioSioc.getCabeceraMensaje().getCodTipoOperacion());
			respuestaSioc.getCabeceraRespuesta().setFechaRecep(servicioSioc.getCabeceraMensaje().getFecha());
			respuestaSioc.getCabeceraRespuesta().setFechaResp(UtilsDate.stringFromDate(new Date(), "dd-MM-yyyy hh:mm:ss"));
			respuestaSioc.getCabeceraRespuesta().setIdMensaje(servicioSioc.getCabeceraMensaje().getIdMensaje());
			respuestaSioc.getCabeceraRespuesta().setIdMensajeResp(
					UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + UtilsGeneric.generateUUID().replace("-", ""));

		} else {

			respuestaSioc.getCabeceraRespuesta().setCodTipoOperacion("0000");
			respuestaSioc.getCabeceraRespuesta().setFechaRecep(UtilsDate.stringFromDate(new Date(), "dd-MM-yyyy hh:mm:ss"));
			respuestaSioc.getCabeceraRespuesta().setFechaResp(UtilsDate.stringFromDate(new Date(), "dd-MM-yyyy hh:mm:ss"));
			respuestaSioc.getCabeceraRespuesta().setIdMensaje("0000");
			respuestaSioc.getCabeceraRespuesta().setIdMensajeResp(
					UtilsDate.stringFromDate(new Date(), "yyyyMMdd") + UtilsGeneric.generateUUID().replace("-", ""));

		}

	}

	public void actualizarRespuestaOperacion(Solicitud solicitud) {
		RespuestaOperacion respuestaOperacion = new RespuestaOperacion();
		respuestaOperacion.setCodEntidad(solicitud.getSocSolicitante().getSolCodsigep());
		respuestaOperacion.setNomSolicitante(solicitud.getSocSolicitante().getSolPersona());

		Beneficiarios beneficiarios = new Beneficiarios();

		List<gob.bcb.bpm.pruebaCU.Beneficiario> beneficiariosLista = solicitud.getBeneficiarioLista();

		for (gob.bcb.bpm.pruebaCU.Beneficiario beneficiario : beneficiariosLista) {
			Beneficiario benef = new Beneficiario();

			benef.setCodBeneficiario(beneficiario.getBenCodigo());
			benef.setNomBeneficiario(beneficiario.getBenNombre());
			benef.setDireccion(beneficiario.getBenDireccion());
			benef.setPlaza(beneficiario.getBenPlaza());			

			List<CuentasBen> listaCuentasB = beneficiario.getCuentasBenLista();

			if (listaCuentasB.size() == 0) {
				continue;
			}
			CuentasBeneficiario cuentasBeneficiario = new CuentasBeneficiario();

			for (CuentasBen cuentasBen : listaCuentasB) {
				CuentaBeneficiario cuentaBeneficiario = new CuentaBeneficiario();

				cuentaBeneficiario.setCodCuentaBenef(String.valueOf(cuentasBen.getCtaCodigo()));
				cuentaBeneficiario.setCodMoneda(String.valueOf(cuentasBen.getMoneda()));
				cuentaBeneficiario.setNroCuenta(cuentasBen.getCtaNroCuenta());
				cuentaBeneficiario.setCodBanco(cuentasBen.getCodBancoSigep());
				cuentaBeneficiario.setBic(cuentasBen.getPlaBic());
				cuentaBeneficiario.setNomBanco(cuentasBen.getBcoNombre());
				cuentaBeneficiario.setNomPlaza(cuentasBen.getPlaNombre());
				cuentaBeneficiario.setNroCuentaIntermediario(cuentasBen.getPlaNroCuenta());
				cuentaBeneficiario.setBicBcoIntermediario(cuentasBen.getPlaIntermediario());
				cuentaBeneficiario.setNomBcoIntermediario(cuentasBen.getBcoNombreI());
				cuentaBeneficiario.setInfoAdicional(cuentasBen.getCtaInfo());

				cuentasBeneficiario.getCuentaBeneficiario().add(cuentaBeneficiario);

			}

			benef.getCuentasBeneficiario().add(cuentasBeneficiario);
			beneficiarios.getBeneficiario().add(benef);
		}

		respuestaOperacion.setBeneficiarios(beneficiarios);

		respuestaSioc.getDatosOperacion().setRespuestaOperacion(respuestaOperacion);

	}

	public void actualizarSolicitudRespuesta(Solicitud solicitud, SocSolicitudctas socSolicitudctasMOVPROVISION) {

		SolicitudRespuesta solicitudRespuesta = new SolicitudRespuesta();

		solicitudRespuesta.setCodSolicitudBcb(solicitud.getSocCodigo());
		solicitudRespuesta.setCodSolicitudOrigen(solicitud.getSolicitud().getCodSolicitudorig());
		solicitudRespuesta.setFechaProceso(UtilsDate.stringFromDate(solicitud.getSolicitud().getFechaReg(), "dd-MM-yyyy hh:mm:ss"));
		solicitudRespuesta.setEstadoSolicitud(solicitud.getSolicitud().getClaEstadows());

		solicitudRespuesta.setCuentaOrigen(socSolicitudctasMOVPROVISION.getNroCuenta());
		solicitudRespuesta.setCodMoneda(String.valueOf((socSolicitudctasMOVPROVISION.getCodMoneda())));

		SocOpecomi socOpecomiTOTDEBITO = solicitud.buscarClaComision("TOTALPROV", 0);

		solicitudRespuesta.setMonto(socOpecomiTOTDEBITO.getMontoMo());

		respuestaSioc.getDatosOperacion().setSolicitudRespuesta(solicitudRespuesta);
	}

	public void actualizarRespuesta(String statusCode, String consent) {
		actualizarCabeceraRespuesta();

		respuestaSioc.getDatosOperacion().setCodEstadoResp(statusCode);
		respuestaSioc.getDatosOperacion().setDescEstadoResp(consent);

	}

	public String respuestaErrorXML(String statusCode, String consent) {
		log.info("Actualizando error!! respuestaErrorXML : " + statusCode + " y descripci�n: " + consent);
		actualizarRespuesta(statusCode, consent);

		SolicitudRespuesta solicitudRespuesta = new SolicitudRespuesta();

		ServicioSioc servicioSioc = (ServicioSioc) mensajeBCBJAXB;
		if (servicioSioc != null) {
			if (servicioSioc.getDatosOperacion() != null && servicioSioc.getDatosOperacion().getSolicitud() != null && servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen()!= null)
				solicitudRespuesta.setCodSolicitudOrigen(servicioSioc.getDatosOperacion().getSolicitud().getCodSolicitudOrigen());
			else
				solicitudRespuesta.setCodSolicitudOrigen(servicioSioc.getCabeceraMensaje().getCodTipoOperacion());
		} else
			solicitudRespuesta.setCodSolicitudOrigen("0");

		respuestaSioc.getDatosOperacion().setSolicitudRespuesta(solicitudRespuesta);

		String mensajeXML = null;
		try {

			JAXBContext context = JAXBContext.newInstance(RespuestaSioc.class);
			Document doc = JAXBHelper.toDocument(respuestaSioc, documentBuilderFactory, context);
			mensajeXML = XmlUtils.getStringFromDom(doc);

		} catch (Exception e) {
			mensajeXML = "<error>" + e.getMessage() + "</error>";
		}

		return mensajeXML;

	}

	public static void main(String[] args) throws UnsupportedEncodingException {
		String mensajeXML = "ÁáAc� hola mundo cruel niño m'\'a(aÁÑ(?";
		byte[] b = mensajeXML.getBytes("ISO-8859-1");// UtilsGeneric.newStringFromString(mensajeXML);
		mensajeXML = new String(b, "ISO-8859-1");
		String mensajeXML2 = new String(b, "UTF-8");
		log.info(mensajeXML);
		log.info(mensajeXML2);
		String n = StringFormat.replaceInString(mensajeXML, "Ah", "XZ");
		System.out.println(n);

		Pattern mask = null;

		mask = Pattern.compile("\\w+");
		Matcher matcher = mask.matcher("asdf@");
		System.out.println(matcher.find());
		mask = Pattern.compile("[\\W|^\\s]");
		matcher = mask.matcher("asdf asdf%$Ñ�");
		//System.out.println(matcher.find());

		String r = StringUtils.replaceChars(mensajeXML, "ÁÉÍÓÚÑáéíóúñ()?+\'", "AEIOUNaeioun     ");
		System.out.println(r);
		String match = null;
		matcher = mask.matcher("asdf a sdf%$Ñ�");
		while (matcher.find()) {
			match = matcher.group();
			System.out.println("MATCH: " + match);
		} // end while

		if (match == null) {
			System.out.println("There were no matches.");
		} // end if

		System.out.println(matcher.find());
	}
}
