package gob.bcb.service.servicioSioc.job;

import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.Utils;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioSioc.common.Constants;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;

public final class GenerateTasks implements Job {
	private static Logger log = Logger.getLogger(GenerateTasks.class);

	public static final String NAME_TASK = "name_task";
	public static final String TIPO_OPERACION = "tipo_operacion";

	public GenerateTasks() {
		log.info("Objeto GenerateTasks creado ...");
	}

	
	public void execute(JobExecutionContext context) throws JobExecutionException {
		JobDataMap data = context.getJobDetail().getJobDataMap();
		JobKey jobKey = context.getJobDetail().getKey();
		String codTipoOperacion = data.getString(TIPO_OPERACION);

		log.info("$$$$$$INICIO tarea periodica " + jobKey + " tipo de operacion " + codTipoOperacion);
		String usuarioTask = Servicios.getParam(Constants.PARAM_USUARIO_TASK);

		Map<String, Object> parametros = new HashMap<String, Object>();

		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(gob.bcb.core.jms.Constants.getUrlBroker());
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();
		parametrosMsg.put("opcion", codTipoOperacion);
		parametrosMsg.put("tipoejecucion", "automatica");
		BcbRequestImpl bcbRequestImpl = null;
		try {
			MessageObjectBean messageObjectBean = new MessageObjectBean();
			messageObjectBean.setTransformedMessage(parametrosMsg);

			parametros.put("BCBAddress", "localhost");
			parametros.put("BCBIdemisor", "SIOCJOB");
			parametros.put("BCBIddestinatario", ConfigurationServ.getParamsSystem().get("siocQUEUE"));
			parametros.put("BCBIdusuario", usuarioTask);
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOCJOB");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			String uuid = Utils.generateUUID().replace("-", "");
			log.info("=>> ID: " + uuid);			
			bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					uuid, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			bcbRequestImpl.setDisableReplyTo(true);
			bcbRequestImpl.sendMessage();
		} catch (Exception e) {
			log.error(
					"Error en tarea periodica  " + jobKey + " para tipo de operacion " + bcbRequestImpl.getIdTipoOperacion() + " " + e.getMessage(),
					e);
		} finally {
			jMSConnectionHandler.close();
		}
		log.info("$$$$$$FIN tarea periodica " + jobKey + " enviada para su proceso, tipo de operacion " + codTipoOperacion);
	}

}
