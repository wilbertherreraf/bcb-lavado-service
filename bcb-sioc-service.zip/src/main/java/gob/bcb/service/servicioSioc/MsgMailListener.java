package gob.bcb.service.servicioSioc;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.listener.SessionAwareMessageListener;

import gob.bcb.bpm.pruebaCU.Servicios;
import gob.bcb.core.jms.Constants;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.commons.CorreoUtils;
import gob.bcb.service.commons.EmailDetalle;

public class MsgMailListener implements SessionAwareMessageListener {
	private static final Log log = LogFactory.getLog(MsgMailListener.class);
	// private static JMSConnectionHandler jMSConnectionHandler;
	private static MessageProducer producerT = null;
	private static boolean initialized = false;
	private static final String topicMail = "BCB.SUSTANTIVO.BPM.SIOC.MAIL";
	public static String IP_SMTP = null;
	public static int PORT_SMTP;

	public final void init() {
		if (!initialized) {

			if (!ConfigurationServ.isConfigured()) {
				throw new RuntimeException("Objeto ConfigurationServ no fue inicializado ");
			}
			String ipCorreo = Servicios.getParam("ip-correo");
			if (ipCorreo != null) {
				String[] configMails = ipCorreo.split(" ");
				IP_SMTP = configMails[0];
				try {
					PORT_SMTP = Integer.valueOf(configMails[1]);
				} catch (Exception e) {
					PORT_SMTP = 25;
				}
			}

			String correoremitente = Servicios.getParam("correoremitente");
			ConfigurationServ.setParamsSystem("correoremitente", correoremitente);
			initialized = true;
			log.info("Iniciado Configuracion MsgMailListener ... hecho");
		}
	}

	public void onMessage(Message message, Session session) throws JMSException {
		log.info("Mensaje recibido en MsgMailListener ...");
		init();
		if (message instanceof MapMessage) {
			CorreoUtils correoUtils = new CorreoUtils(IP_SMTP, PORT_SMTP);

			MapMessage mapMessage = (MapMessage) message;

			String from = mapMessage.getString("from");
			String to = mapMessage.getString("to");
			String subject = mapMessage.getString("subject");
			String content = mapMessage.getString("content");

			correoUtils.enviaAlServidorSMTP(from, to, subject, content);
		}
	}

	public static void enviar(EmailDetalle emailDetalle) {
		if (emailDetalle.getTo() == null || emailDetalle.getTo().length == 0) {
			log.warn("Correo " + emailDetalle.getSubject() + " sin destinatarios");
			return;
		}

		String ttto = ArrayUtils.toString(emailDetalle.getTo()).replace("{", "").replace("}", "");
		log.info("Correo: TO " + ttto);
		log.info("Correo: SUBJECT " + emailDetalle.getSubject());
		log.info(emailDetalle.getContent());
		log.info("==============");
//		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler();

		Session session = null;
		MessageProducer producer = null;
		Connection connection = null;
		try {
			String connectionUri = "tcp://localhost:61616";
			String brokerURL = Constants.getUrlBroker();			
			log.info("BROOOOOOOOOOOOOOOOOO " + brokerURL);
			ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerURL);
			connection = connectionFactory.createConnection();
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Destination destination = session.createQueue("BCB.SUSTANTIVO.BPM.SIOC.MAIL");
		
			producer = session.createProducer(destination);
			MapMessage messageT = session.createMapMessage();			
			messageT.setString("from", emailDetalle.getFrom());
			messageT.setString("to", ttto);
			messageT.setString("subject", emailDetalle.getSubject());
			messageT.setString("content", emailDetalle.getContent());
			
			producer.send(messageT);
			log.info("FIN servicio mailes " + ttto + " " + emailDetalle.getSubject());			
			
//			session = jMSConnectionHandler.getSession();
//			Destination destinationT = null;
//			// destinationT = session.createTopic(topicMail);
//			destinationT = session.createQueue(topicMail);
//			MapMessage messageT = session.createMapMessage();
//			messageT.setString("from", emailDetalle.getFrom());
//
//			messageT.setString("to", ttto);
//			messageT.setString("subject", emailDetalle.getSubject());
//			messageT.setString("content", emailDetalle.getContent());
//
//			producerT = session.createProducer(null);
//			log.info("<<<<<<<<<<<<<<<<<<<<<<<<");
//			log.info(messageT);
//			log.info("<<<<<<<<<<<<<<<<<<<<<<<<");
//			producerT.send(destinationT, messageT);
//			log.info("FIN servicio mailes " + ttto + " " + emailDetalle.getSubject());
		} catch (JMSException e) {
			log.error("Ocurrio un error en el proceso de envio/recepcion del mensaje." + e.getMessage(), e);
		} finally {
			try {
				if (producer != null)				
					producer.close();
				if (session != null)
					session.close();
				if (connection != null ){
					log.info("cerrando conexion JMS mail.....");
					connection.close();
				}
			} catch (Exception e) {
				log.error("error al cerrar coneccion a JMS ", e);
			}
		}
	}
}
