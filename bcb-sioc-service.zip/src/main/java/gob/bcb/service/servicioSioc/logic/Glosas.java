package gob.bcb.service.servicioSioc.logic;

import gob.bcb.bpm.pruebaCU.Beneficiario;
import gob.bcb.bpm.pruebaCU.CuentasBen;
import gob.bcb.bpm.pruebaCU.GenMoneda;
import gob.bcb.bpm.pruebaCU.GenMonedaDao;
import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocBenefsDao;
import gob.bcb.bpm.pruebaCU.SocDetallessol;
import gob.bcb.bpm.pruebaCU.SocEsquemas;
import gob.bcb.bpm.pruebaCU.SocOpecomi;
import gob.bcb.bpm.pruebaCU.SocSolicitudctas;
import gob.bcb.bpm.pruebaCU.Solicitud;
import gob.bcb.core.utils.UtilsDate;
import gob.bcb.core.utils.UtilsGeneric;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;

public class Glosas {
	private static final Log log = LogFactory.getLog(Glosas.class);
	private SessionFactory sessionFactory;

	public String generarGlosa0(Solicitud solicitud, String glosaDefinicion, SocDetallessol socDetallessol, Integer detCodigo, Map<String, Object> paramsGlosa) {

		if (StringUtils.isBlank(glosaDefinicion)) {
			return glosaDefinicion;
		}
		String glosaGenerada = glosaDefinicion;
		Map<String, String> params = UtilsGeneric.valoresVar(glosaDefinicion);
		for (Iterator<?> i = params.keySet().iterator(); i.hasNext();) {
			String key = (String) i.next();
			String valorVar = valorVariable(solicitud, key, socDetallessol, detCodigo);
			params.put(key, valorVar);
			glosaGenerada = glosaGenerada.replaceAll(key, valorVar);
		}
		log.debug("Glosa Renglon Definicion: " + glosaDefinicion + " = > " + glosaGenerada);
		return glosaGenerada;
	}

	private String valorVariable(Solicitud solicitud, String var, SocDetallessol socDetallessol, Integer codDetalle) {
		String valor = "";

		SocBenefsDao socBenefsDao = new SocBenefsDao();
		socBenefsDao.setSessionFactory(getSessionFactory());

		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		if (var.equalsIgnoreCase("@montoprovision")) {
			valor = UtilsGeneric.formatearMonto(solicitud.getSolicitud().getSocMontome());
		} else if (var.equalsIgnoreCase("@correlativo")) {
			valor = solicitud.getSolicitud().getSocCorrelativo();			
		} else if (var.equalsIgnoreCase("@monedaprovision")) {
			GenMonedaDao genMonedaDao = new GenMonedaDao();
			genMonedaDao.setSessionFactory(getSessionFactory());
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(solicitud.getSolicitud().getCodMoneda());
			valor = genMoneda.getMonSigla();
		} else if (var.equalsIgnoreCase("@sol")) {
			valor = solicitud.getSocSolicitante().getSolPersona();
		} else if (var.equalsIgnoreCase("@PORCITF")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("PORCITF", codDetalle);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@ITFDEMONTO")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("ITFDEMONTO", codDetalle);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@ITF")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("ITF", codDetalle);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@ventausd")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("VENTAUSD", 0);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@tottrans")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("TOTTRANS", 0);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@TOTDETMT")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("TOTDETMT", 0);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@TOTALPROV")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("TOTALPROV", 0);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@DIFERTC")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("DIFERTC", 0);
			valor = UtilsGeneric.formatearMonto(socOpecomi.getMontoMo());
		} else if (var.equalsIgnoreCase("@ref")) {
			String ref = solicitud.getSolicitud().getDetConcepto();
			valor = ref;
		} else if (var.equalsIgnoreCase("@facturas")) {
			String ref = solicitud.getSolicitud().getDetFacturas();
			valor = ref;
		} else if (var.equalsIgnoreCase("@fecha")) {
			valor = UtilsDate.stringFromDate(solicitud.getSolicitud().getFecha(), "dd/MM/yyyy");
		} else if (var.equalsIgnoreCase("@benef")) {
			Beneficiario beneficiario = socBenefsDao.recuperarBeneficiario(solicitud.getSolicitud(), socDetallessol);
			if (beneficiario != null)
				valor = beneficiario.getBenNombre();
		} else if (var.equalsIgnoreCase("@monedatrans")) {
			GenMonedaDao genMonedaDao = new GenMonedaDao();
			genMonedaDao.setSessionFactory(getSessionFactory());
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(solicitud.getSolicitud().getCodMonedat());
			valor = genMoneda.getMonSigla();

		} else if (var.equalsIgnoreCase("@monedadet")) {
			GenMonedaDao genMonedaDao = new GenMonedaDao();
			genMonedaDao.setSessionFactory(getSessionFactory());
			
			GenMoneda genMoneda = genMonedaDao.findByCodMoneda(socDetallessol.getCodMoneda());
			valor = genMoneda.getMonSigla();

		} else if (var.equalsIgnoreCase("@cuentaben")) {
			valor = socDetallessol.getNroCuentabco();

		} else if (var.equalsIgnoreCase("@banco")) {

			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(socDetallessol.getCodBanco());
			if (solicitud.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
				if (bancoPlaza == null) {
					throw new RuntimeException("Datos de banco inexistente: " + socDetallessol.getCodBanco() + ", detalle: " + socDetallessol.getId().getDetCodigo());
				}

				valor = bancoPlaza.getBcoNombre();
			}
		} else if (var.equalsIgnoreCase("@plaza")) {
			BancoPlaza bancoPlaza = socBancosDao.bancoPlazaByCod(socDetallessol.getCodBanco());
			if (solicitud.getSolicitud().getClaTipo().equals(Constants.CLAVE_SUBTIPOOPER_TRAEXT)) {
				if (bancoPlaza == null) {
					throw new RuntimeException("Datos de banco inexistente: " + socDetallessol.getCodBanco() + ", detalle: " + socDetallessol.getId().getDetCodigo());
				}

				valor = bancoPlaza.getPlaNombre();
			}
		} else if (var.equalsIgnoreCase("@soli")) {
			valor = solicitud.getSocSolicitante().getSolPersona();
//		} else if (var.equalsIgnoreCase("@nroctalibgadm")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_COMGADM);
//			valor = socSolicitudctas.getNroLibreta();
//		} else if (var.equalsIgnoreCase("@nroctalibdebito")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_MOVPROVISION);
//			valor = socSolicitudctas.getNroLibreta();
//		} else if (var.equalsIgnoreCase("@nroctalibdifcam")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_DIFCAMB);
//			valor = socSolicitudctas.getNroLibreta();
//		} else if (var.equalsIgnoreCase("@nroctalibcomtra")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_COMCTRA);
//			valor = socSolicitudctas.getNroLibreta();
//		} else if (var.equalsIgnoreCase("@desctalibgadm")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_COMGADM);
//			valor = socSolicitudctas.getDescripLibreta();
//		} else if (var.equalsIgnoreCase("@desctalibdebito")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_MOVPROVISION);
//			valor = socSolicitudctas.getDescripLibreta();
//		} else if (var.equalsIgnoreCase("@desctalibdifcam")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_DIFCAMB);
//			valor = socSolicitudctas.getDescripLibreta();
//		} else if (var.equalsIgnoreCase("@desctalibcomtra")) {
//			SocSolicitudctas socSolicitudctas = solicitud.getSocSolicitudctas().get(Constants.COD_CLAVE_COMCTRA);
//			valor = socSolicitudctas.getDescripLibreta();
		} else if (var.equalsIgnoreCase("@ctaexp")) {
			// valor = getExportador(det.getBenCodigo(), det.getDetCtabenef());
		} else if (var.equalsIgnoreCase("@ctaexpc")) {
			// valor = getExportadorC(det.getBenCodigo(), det.getDetCtabenef());
		} else if (var.equalsIgnoreCase("@nitctra")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("CTRA", 0);
			valor = socOpecomi.getNit();
		} else if (var.equalsIgnoreCase("@factctra")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("CTRA", 0);
			valor = socOpecomi.getFactura();
		} else if (var.equalsIgnoreCase("@nitadm") || var.equalsIgnoreCase("@nitswift") || var.equalsIgnoreCase("@nitutil")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("ADM", 0);
			valor = socOpecomi.getNit();
		} else if (var.equalsIgnoreCase("@factadm") || var.equalsIgnoreCase("@factswift") || var.equalsIgnoreCase("@factutil")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("ADM", 0);
			valor = socOpecomi.getFactura();
		} else if (var.equalsIgnoreCase("@nitvdd")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("VDD", 0);
			valor = socOpecomi.getNit();
		} else if (var.equalsIgnoreCase("@factvdd")) {
			SocOpecomi socOpecomi = solicitud.buscarClaComision("VDD", 0);
			valor = socOpecomi.getFactura();
		} else if (var.equalsIgnoreCase("@nrosolicorig")) {
			valor = solicitud.getSolicitud().getCodSolicitudorig();
		}

		valor = (StringUtils.isBlank(valor) ? "" : valor);
		Pattern pattern = Pattern.compile("(" + '\r' + '\n' + "|" + '\n' + ")");
		Matcher matcher = pattern.matcher(valor);
		valor = matcher.replaceAll(" ");

		return valor;

	}


	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

}
