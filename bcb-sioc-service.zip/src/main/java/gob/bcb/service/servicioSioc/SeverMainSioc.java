package gob.bcb.service.servicioSioc;

import java.io.File;
import java.util.Properties;

import javax.annotation.PreDestroy;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.util.StringUtils;

import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.core.jms.server.Server;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;
import gob.bcb.service.servicioPortiaSwift.PortiaService;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.service.servicioSiocCoin.SiocCoinService;

public class SeverMainSioc {

	private static final Log log = LogFactory.getLog(SeverMainSioc.class);
	private final Server serverService;
	private static SeverMainSioc instance;
	public SeverMainSioc() {
		log.info("creando servicio principal SeverMainSioc de SIOC");
		this.serverService = new Server();
	}

	public Server getServerService() {
		return serverService;
	}

	public static void main(String[] args) {
		log.info("Iniciando servicio ...");
		instance = new SeverMainSioc();
		
		ApplicationContext applicationContext = null;
		initConfig();

		String[] appContextList = { "classpath:applicationcontextSioc.xml", "classpath:applicationcontextSiocCoin.xml",
				"classpath:applicationcontextPortia.xml" };

		try {
			applicationContext = instance.serverService.runServer(appContextList);
			String siocQUEUE = (String) applicationContext.getBean("siocQUEUE");
			log.info("Nombre de cola configurada : " + siocQUEUE);
			ConfigurationServ.setParamsSystem("siocQUEUE", siocQUEUE);
			//////////////////////////////////////////////////////////
			SessionFactory sessionFactorySioc = (SessionFactory) applicationContext.getBean("sessionFactoryBean");
			SessionFactory sessionFactoryBeanSiocCoin = (SessionFactory) applicationContext
					.getBean("sessionFactoryBeanSiocCoin");
			SessionFactory sessionFactoryBeanPortia = (SessionFactory) applicationContext
					.getBean("sessionFactoryBeanPortia");
			QueryProcessor.setSessionFactory(sessionFactorySioc);
			QueryProcessor.setNameSessionFactory(Constants.PROP_ALIAS_SIOC);
			SiocCoinService.setSessionFactory(sessionFactoryBeanSiocCoin);
			SiocCoinService.setNameSessionFactory(Constants.PROP_ALIAS_COIN);
			PortiaService.setSessionFactory(sessionFactoryBeanPortia);
			PortiaService.setNameSessionFactory(Constants.PROP_ALIAS_PORTIA);
			//////////////////////////////////////////////////////////
			log.info("antes de la inicializaci n de la colita 'ServiceListener' JMS");
			ServicioSiocListener servicioSiocListener = (ServicioSiocListener) applicationContext
					.getBean("ServiceListener");
			servicioSiocListener.init();

			MsgMailListener msgMailListener = (MsgMailListener) applicationContext.getBean("MailListener");
			msgMailListener.init();
			log.info("===============oo000OOOOO000oo===============");
			log.info("~~~~Servicio iniciado a la espera de mensajes~~~~");
			//instance.serverService.stop();
		} catch (Exception e) {
			log.error("ERROR al iniciar servicio " + e.getMessage(), e);
		} finally{
			log.info("Finallyyyyyyyyyyyyyyyy");
		}
	}

	public static SeverMainSioc getInstance() {
		return instance;
	}
	
    @PreDestroy
    public void destroy() {
        System.out.println("Destroying Bean");
    }
    
    public static void initConfig(){
    	if (ConfigurationServ.isConfigured()){
    		log.info("Iniciando configuracion ya fue configurada");
    		return;
    	}
    	log.info("Iniciando seteo configuracion");
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		ConfigurationServ.setServiceName(properties.getProperty("service.name"));
		if (pathHome == null) {
			throw new RuntimeException("Parametro [path.home] requerido no esta definido");
		}
		File f = new File(pathHome, ConfigurationServ.CONFIG_PROPERTIES);
		if (!f.exists()) {
			throw new RuntimeException(
					"Archivo " + ConfigurationServ.CONFIG_PROPERTIES + " inexistente " + f.getAbsolutePath());
		}
		pathHome = StringUtils.cleanPath(f.getParent());
		log.info("pathHome: " + pathHome);

		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);

		String urlBroker = ConfigurationServ.getConfigProperty("jms.broker.url");

		if (urlBroker == null) {
			throw new RuntimeException("Par metro [jms.broker.url] requerido no est  definido");
		}
		gob.bcb.core.jms.Constants.setUrlBroker(urlBroker);
    }
}
