/**
 * Banco Central De Bolivia
 * La Paz - Bolivia
 * bcb-portal-sirAladi
 * gob.bcb.portal.sirAladi.commons.Servicios
 * 26/07/2011 - 14:35:05
 * Creado por Gustavo Flores
 */
package gob.bcb.service.servicioBolsin.model;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import gob.bcb.service.commons.handlerdb.DBSourceHandlerFactory;
import gob.bcb.service.servicioSioc.common.Constants;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Clase que contiene los metodos para comunicarse con la capa de bpm y
 * servicios.
 * 
 * @author Gustavo Flores
 * 
 */
public class Servicios {
	private static final Log log = LogFactory.getLog(Servicios.class);

	public static List<Map<String, Object>> ejecutarQuery(String query) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		List<Map<String, Object>> resultado = null;
		log.info("Ejecutando el query: " + query);
		try {
			con = DBSourceHandlerFactory.Factory.newInstance(Constants.PROP_ALIAS_BOLSIN).getHandler().getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(query);
			int nroColumnas = rs.getMetaData().getColumnCount();
			ResultSetMetaData md = rs.getMetaData();
			resultado = new ArrayList<Map<String, Object>>();
			while (rs.next()) {
				Map<String, Object> fila = new LinkedHashMap<String, Object>();
				for (int i = 1; i <= nroColumnas; i++)
					fila.put(md.getColumnLabel(i), rs.getObject(i));
				resultado.add(fila);
			}
			log.info("Query ejecutado satisfactoriamente");
		} catch (Exception e) {
			log.error("Error al ejecutar el query: " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e1) {
				log.error("Error al cerrar la conexion a DB: " + e1.getMessage());
			}
			try {
				if (stmt != null)
					stmt.close();
			} catch (Exception e1) {
				log.error("Error al cerrar la conexion a DB: " + e1.getMessage());
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception e1) {
				log.error("Error al cerrar la conexion a DB: " + e1.getMessage());
			}
		}
		return resultado;
	}

	public static String getEstado(Date fecha) {
		char ee = 0;
		String rr = "1";

		String query = "select distinct cve_tabla from tabla_cotiz " + "where fecha_dia = '" + fecha + "' ";

		List<Map<String, Object>> resultado = Servicios.ejecutarQuery(query);
		if (resultado.size() == 1) {
			for (Map<String, Object> res : resultado) {
				ee = (Character) res.get("cve_tabla");
			}
			if (ee != 'A')
				rr = "-1";
		} else {
			rr = "-1";
		}

		return rr;
	}
}
