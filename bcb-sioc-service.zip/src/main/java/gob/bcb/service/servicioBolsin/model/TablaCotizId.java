/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioBolsin.model;

import gob.bcb.core.infra.datastore.BcbEntity;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Embeddable
public class TablaCotizId extends BcbEntity
{
  @Basic(optional = false)
  @Column(name = "cod_moneda")
  private String codMoneda;
  @Basic(optional = false)
  @Column(name = "fecha_dia")
  @Temporal(TemporalType.DATE)
  private Date fechaDia;
  @Basic(optional = false)
  @Column(name = "nro_seq")
  private String nroSeq;

  public TablaCotizId()
  {
  }

  public TablaCotizId(String codMoneda, Date fechaDia, String nroSeq)
  {
    this.codMoneda = codMoneda;
    this.fechaDia = fechaDia;
    this.nroSeq = nroSeq;
  }

  public String getCodMoneda()
  {
    return codMoneda;
  }

  public void setCodMoneda(String codMoneda)
  {
    this.codMoneda = codMoneda;
  }

  public Date getFechaDia()
  {
    return fechaDia;
  }

  public void setFechaDia(Date fechaDia)
  {
    this.fechaDia = fechaDia;
  }

  public String getNroSeq()
  {
    return nroSeq;
  }

  public void setNroSeq(String nroSeq)
  {
    this.nroSeq = nroSeq;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (codMoneda != null ? codMoneda.hashCode() : 0);
    hash += (fechaDia != null ? fechaDia.hashCode() : 0);
    hash += (nroSeq != null ? nroSeq.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof TablaCotizId))
    {
      return false;
    }
    TablaCotizId other = (TablaCotizId) object;
    if ((this.codMoneda == null && other.codMoneda != null) || (this.codMoneda != null && !this.codMoneda.equals(other.codMoneda)))
    {
      return false;
    }
    if ((this.fechaDia == null && other.fechaDia != null) || (this.fechaDia != null && !this.fechaDia.equals(other.fechaDia)))
    {
      return false;
    }
    if ((this.nroSeq == null && other.nroSeq != null) || (this.nroSeq != null && !this.nroSeq.equals(other.nroSeq)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioBolsin.model.TablaCotizId[codMoneda=" + codMoneda + ", fechaDia=" + fechaDia + ", nroSeq=" + nroSeq + "]";
  }

}
