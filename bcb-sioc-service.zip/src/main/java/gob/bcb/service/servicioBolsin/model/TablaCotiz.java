/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioBolsin.model;

import gob.bcb.core.infra.datastore.BcbEntity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "tabla_cotiz")
@NamedQueries({ @NamedQuery(name = "TablaCotiz.findAll", query = "SELECT t FROM TablaCotiz t") })
public class TablaCotiz extends BcbEntity
{
  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected TablaCotizId id;
  @Basic(optional = false)
  @Column(name = "grupo")
  private Integer grupo;
  @Basic(optional = false)
  @Column(name = "numero")
  private Integer numero;
  @Basic(optional = false)
  @Column(name = "literal_dia")
  private String literalDia;
  @Column(name = "pais")
  private String pais;
  @Basic(optional = false)
  @Column(name = "unidad_mon")
  private String unidadMon;
  @Basic(optional = false)
  @Column(name = "moneda")
  private String moneda;
  @Basic(optional = false)
  @Column(name = "tipo_camb_bs")
  private BigDecimal tipoCambioBs;
  @Basic(optional = false)
  @Column(name = "tipo_camb_me")
  private BigDecimal tipoCambioMe;
  @Basic(optional = false)
  @Column(name = "camb_me_ant")
  private BigDecimal cambMeAnt;
  @Basic(optional = false)
  @Column(name = "cod_usuario")
  private String usuario;
  @Basic(optional = false)
  @Column(name = "estacion")
  private String estacion;
  @Basic(optional = false)
  @Column(name = "fecha_hora")
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaHora;
  @Basic(optional = false)
  @Column(name = "cve_tabla")
  private Character cveTabla;

  public TablaCotiz()
  {
  }

  public TablaCotiz(TablaCotizId id)
  {
    this.id = id;
  }

  public TablaCotiz(TablaCotizId id, Integer grupo, Integer numero,
      String literalDia, String unidadMon, String moneda,
      BigDecimal tipoCambioBs, BigDecimal tipoCambioMe, BigDecimal cambMeAnt,
      String usuario, String estacion, Date fechaHora, char cveTabla)
  {
    this.id = id;
    this.grupo = grupo;
    this.numero = numero;
    this.literalDia = literalDia;
    this.unidadMon = unidadMon;
    this.moneda = moneda;
    this.tipoCambioBs = tipoCambioBs;
    this.tipoCambioMe = tipoCambioMe;
    this.cambMeAnt = cambMeAnt;
    this.usuario = usuario;
    this.estacion = estacion;
    this.fechaHora = fechaHora;
    this.cveTabla = cveTabla;
  }

  public TablaCotiz(String codMoneda, Date fechaDia, String nroSeq)
  {
    this.id = new TablaCotizId(codMoneda, fechaDia, nroSeq);
  }

  public TablaCotizId getId()
  {
    return id;
  }

  public void setId(TablaCotizId id)
  {
    this.id = id;
  }

  public Integer getGrupo()
  {
    return grupo;
  }

  public void setGrupo(Integer grupo)
  {
    this.grupo = grupo;
  }

  public Integer getNumero()
  {
    return numero;
  }

  public void setNumero(Integer numero)
  {
    this.numero = numero;
  }

  public String getLiteralDia()
  {
    return literalDia;
  }

  public void setLiteralDia(String literalDia)
  {
    this.literalDia = literalDia;
  }

  public String getPais()
  {
    return pais;
  }

  public void setPais(String pais)
  {
    this.pais = pais;
  }

  public String getUnidadMon()
  {
    return unidadMon;
  }

  public void setUnidadMon(String unidadMon)
  {
    this.unidadMon = unidadMon;
  }

  public String getMoneda()
  {
    return moneda;
  }

  public void setMoneda(String moneda)
  {
    this.moneda = moneda;
  }

  public BigDecimal getTipoCambioBs()
  {
    return tipoCambioBs;
  }

  public void setTipoCambioBs(BigDecimal tipoCambioBs)
  {
    this.tipoCambioBs = tipoCambioBs;
  }

  public BigDecimal getTipoCambioMe()
  {
    return tipoCambioMe;
  }

  public void setTipoCambioMe(BigDecimal tipoCambioMe)
  {
    this.tipoCambioMe = tipoCambioMe;
  }

  public BigDecimal getCambMeAnt()
  {
    return cambMeAnt;
  }

  public void setCambMeAnt(BigDecimal cambMeAnt)
  {
    this.cambMeAnt = cambMeAnt;
  }

  public String getUsuario()
  {
    return usuario;
  }

  public void setUsuario(String usuario)
  {
    this.usuario = usuario;
  }

  public String getEstacion()
  {
    return estacion;
  }

  public void setEstacion(String estacion)
  {
    this.estacion = estacion;
  }

  public Date getFechaHora()
  {
    return fechaHora;
  }

  public void setFechaHora(Date fechaHora)
  {
    this.fechaHora = fechaHora;
  }

  public char getCveTabla()
  {
    return cveTabla;
  }

  public void setCveTabla(char cveTabla)
  {
    this.cveTabla = cveTabla;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (id != null ? id.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof TablaCotiz))
    {
      return false;
    }
    TablaCotiz other = (TablaCotiz) object;
    if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioBolsin.model.TablaCotiz[tablaCotizPK=" + id + "]";
  }

}
