/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gob.bcb.service.servicioBolsin.model;

import gob.bcb.core.infra.datastore.BcbEntity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 
 * @author faflores
 */
@Entity
@Table(name = "cambio")
@NamedQueries({ @NamedQuery(name = "Cambio.findAll", query = "SELECT c FROM Cambio c") })
public class Cambio extends BcbEntity
{
  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @Column(name = "fecha")
  @Temporal(TemporalType.DATE)
  private Date fecha;
  @Basic(optional = false)
  @Column(name = "cotz_venta")
  private BigDecimal cotzVenta;
  @Basic(optional = false)
  @Column(name = "cotz_compra")
  private BigDecimal cotzCompra;
  @Basic(optional = false)
  @Column(name = "cotz_base")
  private BigDecimal cotzBase;
  @Basic(optional = false)
  @Column(name = "cant_disponible")
  private BigDecimal cantDisponible;
  @Basic(optional = false)
  @Column(name = "cant_vendida")
  private BigDecimal cantVendida;
  @Basic(optional = false)
  @Column(name = "solic_presentadas")
  private Integer solicPresentadas;
  @Basic(optional = false)
  @Column(name = "solic_aceptadas")
  private Integer solicAceptadas;
  @Basic(optional = false)
  @Column(name = "usuario")
  private String usuario;
  @Basic(optional = false)
  @Column(name = "estacion")
  private String estacion;
  @Basic(optional = false)
  @Column(name = "fecha_hora")
  @Temporal(TemporalType.TIMESTAMP)
  private Date fechaHora;
  @Basic(optional = false)
  @Column(name = "estado")
  private Character estado;

  public Cambio()
  {
  }

  public Cambio(Date fecha)
  {
    this.fecha = fecha;
  }

  public Cambio(Date fecha, BigDecimal cotzVenta, BigDecimal cotzCompra,
      BigDecimal cotzBase, BigDecimal cantDisponible, BigDecimal cantVendida,
      Integer solicPresentadas, Integer solicAceptadas, String usuario,
      String estacion, Date fechaHora, Character estado)
  {
    this.fecha = fecha;
    this.cotzVenta = cotzVenta;
    this.cotzCompra = cotzCompra;
    this.cotzBase = cotzBase;
    this.cantDisponible = cantDisponible;
    this.cantVendida = cantVendida;
    this.solicPresentadas = solicPresentadas;
    this.solicAceptadas = solicAceptadas;
    this.usuario = usuario;
    this.estacion = estacion;
    this.fechaHora = fechaHora;
    this.estado = estado;
  }

  public Date getFecha()
  {
    return fecha;
  }

  public void setFecha(Date fecha)
  {
    this.fecha = fecha;
  }

  public BigDecimal getCotzVenta()
  {
    return cotzVenta;
  }

  public void setCotzVenta(BigDecimal cotzVenta)
  {
    this.cotzVenta = cotzVenta;
  }

  public BigDecimal getCotzCompra()
  {
    return cotzCompra;
  }

  public void setCotzCompra(BigDecimal cotzCompra)
  {
    this.cotzCompra = cotzCompra;
  }

  public BigDecimal getCotzBase()
  {
    return cotzBase;
  }

  public void setCotzBase(BigDecimal cotzBase)
  {
    this.cotzBase = cotzBase;
  }

  public BigDecimal getCantDisponible()
  {
    return cantDisponible;
  }

  public void setCantDisponible(BigDecimal cantDisponible)
  {
    this.cantDisponible = cantDisponible;
  }

  public BigDecimal getCantVendida()
  {
    return cantVendida;
  }

  public void setCantVendida(BigDecimal cantVendida)
  {
    this.cantVendida = cantVendida;
  }

  public Integer getSolicPresentadas()
  {
    return solicPresentadas;
  }

  public void setSolicPresentadas(Integer solicPresentadas)
  {
    this.solicPresentadas = solicPresentadas;
  }

  public Integer getSolicAceptadas()
  {
    return solicAceptadas;
  }

  public void setSolicAceptadas(Integer solicAceptadas)
  {
    this.solicAceptadas = solicAceptadas;
  }

  public String getUsuario()
  {
    return usuario;
  }

  public void setUsuario(String usuario)
  {
    this.usuario = usuario;
  }

  public String getEstacion()
  {
    return estacion;
  }

  public void setEstacion(String estacion)
  {
    this.estacion = estacion;
  }

  public Date getFechaHora()
  {
    return fechaHora;
  }

  public void setFechaHora(Date fechaHora)
  {
    this.fechaHora = fechaHora;
  }

  public Character getEstado()
  {
    return estado;
  }

  public void setEstado(Character estado)
  {
    this.estado = estado;
  }

  
  public int hashCode()
  {
    int hash = 0;
    hash += (fecha != null ? fecha.hashCode() : 0);
    return hash;
  }

  
  public boolean equals(Object object)
  {
    // TODO: Warning - this method won't work in the case the id fields are not
    // set
    if (!(object instanceof Cambio))
    {
      return false;
    }
    Cambio other = (Cambio) object;
    if ((this.fecha == null && other.fecha != null) || (this.fecha != null && !this.fecha.equals(other.fecha)))
    {
      return false;
    }
    return true;
  }

  
  public String toString()
  {
    return "gob.bcb.service.servicioBolsin.model.Cambio[fecha=" + fecha + "]";
  }

}
