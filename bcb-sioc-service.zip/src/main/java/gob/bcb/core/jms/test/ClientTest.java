package gob.bcb.core.jms.test;
import gob.bcb.bpm.pruebaCU.QueryProcessor;
import gob.bcb.bpm.pruebaCU.SocBolsin;
import gob.bcb.bpm.pruebaCU.SocSolicitudes;
import gob.bcb.bpm.pruebaCU.Solicitud;

import java.sql.Types;
import gob.bcb.bpm.pruebaCU.SocCambio;
import gob.bcb.core.jms.BcbRequestImpl;
import gob.bcb.core.jms.BcbResponse;
import gob.bcb.core.jms.StatusResponse;
import gob.bcb.core.jms.client.JMSConnectionHandler;
import gob.bcb.core.jms.client.MessageObjectBean;
import gob.bcb.core.utils.UtilsProperties;
import gob.bcb.service.commons.ConfigurationServ;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.lang.ArrayUtils;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class ClientTest implements MessageListener {

	public String brokerUrl = "tcp://10.2.11.91:61616";
	//private String brokerUrl = "tcp://localhost:61616";	
	public String requestQueue = "BCB.SUSTANTIVO.BPM.SIOC.QUEUE";

	Connection connection;
	private Session session;
	private MessageProducer producer;
	private MessageConsumer consumer;

	private Destination tempDest;

	public void start() throws JMSException {
		
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(brokerUrl);
		connection = connectionFactory.createConnection();
		connection.start();
		session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination adminQueue = session.createQueue(requestQueue);

		producer = session.createProducer(adminQueue);
		producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
		// producer.setTimeToLive(10000);

		tempDest = session.createTemporaryQueue();
		consumer = session.createConsumer(tempDest);

		consumer.setMessageListener(this);
	}

	public void stop() throws JMSException {
		producer.close();
		consumer.close();
		session.close();
		connection.close();
	}

	public void request(String request) throws JMSException, IOException {
		System.out.println("CONSULTA INICIADA1: " + Types.CHAR);
		BytesMessage response = session.createBytesMessage();
		
	    byte[] a = request.getBytes();
	    System.out.println("finn " + ArrayUtils.toString(a));
		response.reset();	    
	    byte[] output1 = new byte[(int) response.getBodyLength()];
		ByteArrayOutputStream out1 = new ByteArrayOutputStream();

		response.readBytes(output1);
	    
		FileOutputStream fos1 = null;
		out1.write(output1);
		fos1 = new FileOutputStream("e:/reporte.pdf");
		fos1.write(out1.toByteArray());
		fos1.flush();
		
		System.out.println("finnnnnnnnnnnnnnnnnnnnnn");
		
		if (response != null){
			return;
		}
	
		TextMessage txtMessage = session.createTextMessage();
		txtMessage.setText(request);

		txtMessage.setStringProperty("recipient", "servicioBpmSirAladi");
		txtMessage.setStringProperty("responder", "responder");
		txtMessage.setStringProperty("IP_ORIGEN", "IP_ORIGEN");
		txtMessage.setJMSReplyTo(tempDest);

		String correlationId = UUID.randomUUID().toString();
		txtMessage.setJMSCorrelationID(correlationId);
		this.producer.send(txtMessage);
	}
	public void request1(String request) throws JMSException, IOException {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("a", "cadena");
		parametros.put("b", BigDecimal.valueOf(100L));
		ObjectMessage message = session.createObjectMessage((Serializable) parametros);
		message.setJMSReplyTo(tempDest);
		String correlationId = UUID.randomUUID().toString();
		message.setJMSCorrelationID(correlationId);
		this.producer.send(message);
	}
	public void request2(String request) throws JMSException, IOException {
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();
		SocCambio cambio = new SocCambio();
		cambio.setFecha(new Date());
		cambio.setVenta(BigDecimal.valueOf(6.98d));
		cambio.setCompra(BigDecimal.valueOf(6.90d));
		cambio.setBase(BigDecimal.valueOf(6.98d));
		cambio.setVend(BigDecimal.valueOf(152000d));
		cambio.setDisp(BigDecimal.valueOf(152000d));
		cambio.setPres(10);
		cambio.setAcep(10);
		cambio.setClaEstado("1");
		cambio.setUsrCodigo("qqq");
		cambio.setFechaHora(new Date());
		cambio.setEstacion("RBurgos");
		
		SocBolsin solicitudB = new SocBolsin(); 
		solicitudB.setSolCodigo("000001");
		solicitudB.setClaEstado('B');
		solicitudB.setCorr("900-00011-2013");
		solicitudB.setCuentaD(Integer.parseInt("12"));
		solicitudB.setMontoSol(BigDecimal.valueOf(1000.23d));
		solicitudB.setCotiz(BigDecimal.valueOf(6.98d));
		solicitudB.setEstacion("IpLogin()");
		solicitudB.setUsrCodigo("UsuarioLogin()");
		solicitudB.setClaTipsolic("E");
		
		parametrosMsg.put("a", "cadena");
		parametrosMsg.put("b", BigDecimal.valueOf(1000.23d));
		parametrosMsg.put("opcion", "pruebita");
		parametrosMsg.put("solicitud", solicitudB);
		parametrosMsg.put("cambio", cambio);
		
		MessageObjectBean messageObjectBean = new MessageObjectBean();
		messageObjectBean.setTransformedMessage(parametrosMsg);
		
		StatusResponse statusResponse = null;
		Map<String, Object> parametros = new HashMap<String, Object>();
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(brokerUrl);		
		try {
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWEB");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", "wherrera");
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOC");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					null, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
//			bcbRequestImpl.send();
//			Thread.sleep(500);
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();
			if (statusResponse.getResponse() instanceof MessageObjectBean){
				MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
				Map<String, Object> resultado = (Map<String, Object>) messageObjectBean1.getTransformedMessage();
				System.out.println(resultado);			
			}else
				System.out.println(statusResponse.getDescrip());

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}finally{				
			jMSConnectionHandler.close();
		}
	}
	public void request3(String request) throws JMSException, IOException {
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();
		
		parametrosMsg.put("a", "cadena");
		parametrosMsg.put("b", BigDecimal.valueOf(100.23d));
		parametrosMsg.put("opcion", "publicarpru");
		
		MessageObjectBean messageObjectBean = new MessageObjectBean();
		messageObjectBean.setTransformedMessage(parametrosMsg);
		
		StatusResponse statusResponse = null;
		Map<String, Object> parametros = new HashMap<String, Object>();
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler();		
		try {
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWEB");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", "visit.getUsuarioSession().getLogin()");
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOC");
			parametros.put("BCBIdoperacion", "parametrosMsg.get(opcion)");
			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					null, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();
			
			MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
			Map<String, Object> resultado = (Map<String, Object>) messageObjectBean1.getTransformedMessage();
			System.out.println(resultado);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}finally{
			jMSConnectionHandler.close();			
		}

	}
	public void requestSolicitud(String codSolicitud, String opcion) throws JMSException, IOException {
		Map<String, Object> parametrosMsg = new HashMap<String, Object>();
		
		SocSolicitudes socSolicitudes = new SocSolicitudes();
		socSolicitudes.setSocCodigo(codSolicitud);
		socSolicitudes.setFecha(new Date());
		
		Solicitud solicitud = new Solicitud();
		solicitud.setSolicitud(socSolicitudes);
		
		parametrosMsg.put("opcion", opcion);
		parametrosMsg.put("solicitud", solicitud);
		
		MessageObjectBean messageObjectBean = new MessageObjectBean();
		messageObjectBean.setTransformedMessage(parametrosMsg);
		
		StatusResponse statusResponse = null;
		Map<String, Object> parametros = new HashMap<String, Object>();
		JMSConnectionHandler jMSConnectionHandler = new JMSConnectionHandler(brokerUrl);		
		try {
			parametros.put("BCBAddress", "visit.getAddress()");
			parametros.put("BCBIdemisor", "SIOCWEB");
			parametros.put("BCBIddestinatario", requestQueue);
			parametros.put("BCBIdusuario", "190");
			parametros.put("BCBPasswmd5", ">>>1234<<<");
			parametros.put("BCBIdsistema", "SIOC");
			parametros.put("BCBIdoperacion", parametrosMsg.get("opcion"));
			BcbRequestImpl bcbRequestImpl = (BcbRequestImpl) BcbRequestImpl.newInstance((String) parametros.get("BCBAddress"),
					(String) parametros.get("BCBIdemisor"), (String) parametros.get("BCBIddestinatario"), (String) parametros.get("BCBIdsistema"),
					(String) parametros.get("BCBIdoperacion"), null, (String) parametros.get("BCBIdusuario"), (String) parametros.get("BCBPasswmd5"),
					null, null);
			bcbRequestImpl.setNameQueueTopic((String) parametros.get("BCBIddestinatario"));
			bcbRequestImpl.setBody(messageObjectBean);
			bcbRequestImpl.setJMSConnectionHandler(jMSConnectionHandler);
//			bcbRequestImpl.send();
//			Thread.sleep(500);
			statusResponse = (StatusResponse) bcbRequestImpl.sendMessage();
			if (statusResponse.getResponse() instanceof MessageObjectBean){
				MessageObjectBean messageObjectBean1 = (MessageObjectBean) statusResponse.getResponse();
				Map<String, Object> resultado = (Map<String, Object>) messageObjectBean1.getTransformedMessage();
				System.out.println(resultado);			
			}else
				System.out.println(statusResponse.getDescrip());

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}finally{				
			jMSConnectionHandler.close();
		}
	}
	
	
	public void onMessage(Message message) {
		System.out.println("CLIENTE MENSAJE RECIBIDO: ");
		String xml = null;
		BcbResponse respuestaResponse = null;

		try {
			if (message instanceof TextMessage){
				xml = ((TextMessage) message).getText();
				System.out.println(xml);				
			}
			if (message instanceof ObjectMessage){
				System.out.println("===========");
				Map<String, Object> parametros = new HashMap<String, Object>();
				ObjectMessage objectMessage = (ObjectMessage) message;

				//parametros = (Map<String, Object>) objectMessage;
				System.out.println(objectMessage);
			}

		} catch (JMSException e) {
			e.printStackTrace();
		}
/*
		Map<String, LinkedHashMap<String, Object>> mapa = respuestaResponse.getResult();
		StatusResponse status = (StatusResponse) mapa.get("status").get("status");
		System.out.println("========" + status.getCodResponse());
		Apertura apertura = (Apertura) mapa.get("apertura").get("apertura");
		System.out.println("========" + apertura.getNroMov() + " " + apertura.getIdentificador().getCodId());
		
		 * Registro registro = (Registro) mapa.get("registro").get("registro"); System.out.println("========" + registro.getNroMov());
		 */
		System.out.println("==========================FIN MENSAJE RECIBIDO==========================");
	}

	public static void main(String[] args) {
		Properties properties = UtilsProperties.loadFilePropertiesFromClass("service.properties");
		String pathHome = properties.getProperty("path.home");
		ConfigurationServ.setServiceName(properties.getProperty("service.name"));
		
		ConfigurationServ.setHomeProperty(pathHome);
		ConfigurationServ.init(pathHome);
		
		String urlBroker = ConfigurationServ.getConfigProperty("jms.broker.url");
		gob.bcb.core.jms.Constants.setUrlBroker(urlBroker);
		
		ClientTest client = new ClientTest();
		client.brokerUrl = urlBroker;
		 String[] appContextList = { "classpath:applicationcontextSioc.xml",
				 "classpath:applicationcontextBolsin.xml",
		 
				 "classpath:applicationcontextSiocCoin.xml",
				 "classpath:applicationcontextBdweb.xml" };

		FileSystemXmlApplicationContext appContext = new FileSystemXmlApplicationContext(appContextList);		
		try {
			ApplicationContext applicationContext =appContext;
			String siocQUEUE = (String) applicationContext.getBean("siocQUEUE");
			SessionFactory sessionFactorySioc = (SessionFactory) applicationContext.getBean("sessionFactoryBean");
			QueryProcessor.setSessionFactory(sessionFactorySioc);
			
			client.requestSolicitud("00000006", "generaopcontable");
			System.out.println("==========================FIN RECIBIDO==========================");		
		} catch (JMSException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//Thread.sleep(20000);
		//client.stop();
		System.out.println("==========================FIN MENSAJE RECIBIDO==========================");
	}
}
