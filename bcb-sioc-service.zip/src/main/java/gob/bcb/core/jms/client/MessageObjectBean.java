package gob.bcb.core.jms.client;

import java.io.Serializable;

public class MessageObjectBean implements Serializable {

	private Object transformedMessage;

	/**
	 * @return the transformedMessage
	 */
	public Object getTransformedMessage() {
		return transformedMessage;
	}

	/**
	 * @param transformedMessage
	 *            the transformedMessage to set
	 */
	public void setTransformedMessage(Object transformedMessage) {
		this.transformedMessage = transformedMessage;
	}

}
