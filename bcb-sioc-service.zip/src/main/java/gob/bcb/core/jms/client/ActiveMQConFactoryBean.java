package gob.bcb.core.jms.client;

import gob.bcb.core.jms.Constants;

import org.apache.activemq.ActiveMQConnectionFactory;

public class ActiveMQConFactoryBean {
	ActiveMQConnectionFactory activeMQConnectionFactory;
	public ActiveMQConnectionFactory createFromUrlBroker(String brokerURL){
		activeMQConnectionFactory = new ActiveMQConnectionFactory(brokerURL);
		activeMQConnectionFactory.getPrefetchPolicy().setQueuePrefetch(10);
		activeMQConnectionFactory.getPrefetchPolicy().setTopicPrefetch(50);
		activeMQConnectionFactory.setOptimizeAcknowledge(false);
		activeMQConnectionFactory.setCopyMessageOnSend(false);
		activeMQConnectionFactory.setAlwaysSessionAsync(false);
		activeMQConnectionFactory.setWatchTopicAdvisories(false);
		
		return activeMQConnectionFactory;
	}
	public ActiveMQConnectionFactory createFromUrlConfig(){
		String brokerURL = Constants.getUrlBroker();
		activeMQConnectionFactory = createFromUrlBroker(brokerURL);
		return activeMQConnectionFactory;
	}
}
 