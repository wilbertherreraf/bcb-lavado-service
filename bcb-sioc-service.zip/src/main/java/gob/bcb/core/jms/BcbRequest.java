package gob.bcb.core.jms;


import gob.bcb.core.jms.model.Msgbcb;

import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.jms.Message;
import javax.jms.Session;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

/**
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public interface BcbRequest {

	/**
	 * Este es el nombre del feature destino dentro del servicio de negocio o
	 * BPM
	 * 
	 * @return El nombre del feature del servicio destino al cual se est
	 *         invocando
	 */
	String getIdTipoOperacion();

	/**
	 * Obtiene los elementos request almacenados segn el tipo de su mtodo.
	 * 
	 * @return un {@link LinkedHashMap} cuyo contenido son los elementos
	 *         requests almacenados segn el tipo de su mtodo.
	 */
	Map<String, Object> getRequestElements();

	/**
	 * Establece los elementos request que este objecto {@link BcbRequest}
	 * contendr.
	 * 
	 * <code>NOTA</code>. Este mtodo sobreescribir cualquier otro contenido
	 * que este repositorio haya tenido.
	 * 
	 * @param requestElements
	 *            los elementos requests contenidos en un mapa ordenado
	 */
	void setRequestElements(Map<String, Object> requestElements);

	String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException;
	Msgbcb getMsgbcb();
	void setJmsMessage(Message jmsMessage);
	Message getJmsMessage();
	void setJmsSession(Session jmsSession);
	Session getJmsSession();
	
	public static final class Factory {
		public static BcbRequest createRequest(String ipOrigen, String requesterName, String idDestinatario, String serviceDestination,
				String idTipoOperacion, String requestId, String idUsuario, String password, String nroOperacion, Object tipoJAXBEleASubtituir) {
			return BcbRequestImpl.newInstance(ipOrigen, requesterName, idDestinatario, serviceDestination,
					idTipoOperacion, requestId, idUsuario, password, nroOperacion, tipoJAXBEleASubtituir);
		}
	}

}
