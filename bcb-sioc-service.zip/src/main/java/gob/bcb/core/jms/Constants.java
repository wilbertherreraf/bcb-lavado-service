package gob.bcb.core.jms;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Constants {
	/**
	 * Formato fecha en la base de datos
	 */
	public static final String FORMAT_DATE_DB = "dd/MM/yyyy";
	
	/**
	 * Formato de fecha hora para datos que requieran hora
	 */
	public static final String FORMAT_DATE_TIME = "yyyy-MM-dd HH:mm:ss:SSS";
	private static String urlBroker;
	private static Map<String, String> paramsConfig = new ConcurrentHashMap<String, String>();
	
	public static void setUrlBroker(String urlBroker) {
		Constants.urlBroker = urlBroker;
	}

	public static String getUrlBroker() {
		return urlBroker;
	}

	public static void setParamsConfig(String key, String value) {
		if (paramsConfig == null)
			paramsConfig = new ConcurrentHashMap<String, String>();
		getParamsConfig().put(key, value);
	}

	public static Map<String, String> getParamsConfig() {
		return paramsConfig;
	}
	
}
