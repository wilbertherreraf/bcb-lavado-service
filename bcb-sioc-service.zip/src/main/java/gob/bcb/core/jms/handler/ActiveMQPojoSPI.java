package gob.bcb.core.jms.handler;

import java.util.Properties;
import javax.jms.ConnectionFactory;
import org.apache.activemq.ActiveMQConnectionFactory;

public class ActiveMQPojoSPI {
    public static final String KEY_BROKER_URL        = "brokerUrl";
    public static final String KEY_USERNAME          = "username";
    public static final String KEY_PASSWORD          = "password";
    public static final String KEY_CLIENT_ID         = "clientID";

    public static final String KEY_ASYNC_SEND        = "asyncSend";
    public static final String KEY_ASYNC_DISPATCH    = "asyncDispatch";
    public static final String KEY_ASYNC_SESSION     = "asyncSession";
    public static final String KEY_CLOSE_TIMEOUT     = "closeTimeout";
    public static final String KEY_COPY_MSG_ON_SEND  = "copyMsgOnSend";
    public static final String KEY_DISABLE_TIMESTAMP = "disableTimestamp";
    public static final String KEY_DEFER_OBJ_SERIAL  = "deferObjSerial";
    public static final String KEY_OPTIM_ACK         = "optimAck";
    public static final String KEY_OPTIM_DISPATCH    = "optimDispatch";
    public static final String KEY_PREFETCH_QUEUE    = "prefetchQueue";
    public static final String KEY_PREFETCH_TOPIC    = "prefetchTopic";
    public static final String KEY_USE_COMPRESSION   = "useCompression";
    public static final String KEY_USE_RETROACTIVE   = "useRetroactive";

    public ConnectionFactory createConnectionFactory(Properties settings) throws Exception {
        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory();
        configureConnectionFactory(factory, settings);
        return factory;
    }

    public void configureConnectionFactory(ConnectionFactory jmsFactory, Properties settings) throws Exception {
        ActiveMQConnectionFactory factory = (ActiveMQConnectionFactory)jmsFactory;
        String setting;

        setting = settings.getProperty(KEY_BROKER_URL);
        if (setting != null && setting.length() > 0) {
            factory.setBrokerURL(setting);
        }

        setting = settings.getProperty(KEY_USERNAME);
        if (setting != null && setting.length() > 0) {
            factory.setUserName(setting);
        }

        setting = settings.getProperty(KEY_PASSWORD);
        if (setting != null && setting.length() > 0) {
            factory.setPassword(setting);
        }

        setting = settings.getProperty(KEY_CLIENT_ID);
        if (setting != null && setting.length() > 0) {
            factory.setClientID(setting);
        }

        setting = settings.getProperty(KEY_ASYNC_SEND);
        if (setting != null && setting.length() > 0) {
            factory.setUseAsyncSend(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_ASYNC_DISPATCH);
        if (setting != null && setting.length() > 0) {
            factory.setDispatchAsync(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_ASYNC_SESSION);
        if (setting != null && setting.length() > 0) {
            factory.setAlwaysSessionAsync(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_CLOSE_TIMEOUT);
        if (setting != null && setting.length() > 0) {
            factory.setCloseTimeout(Integer.parseInt(setting));
        }

        setting = settings.getProperty(KEY_COPY_MSG_ON_SEND);
        if (setting != null && setting.length() > 0) {
            factory.setCopyMessageOnSend(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_DISABLE_TIMESTAMP);
        if (setting != null && setting.length() > 0) {
            factory.setDisableTimeStampsByDefault(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_DEFER_OBJ_SERIAL);
        if (setting != null && setting.length() > 0) {
            factory.setObjectMessageSerializationDefered(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_OPTIM_ACK);
        if (setting != null && setting.length() > 0) {
            factory.setOptimizeAcknowledge(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_OPTIM_DISPATCH);
        if (setting != null && setting.length() > 0) {
            factory.setOptimizedMessageDispatch(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_PREFETCH_QUEUE);
        if (setting != null && setting.length() > 0) {
            factory.getPrefetchPolicy().setQueuePrefetch(Integer.parseInt(setting));
        }

        setting = settings.getProperty(KEY_PREFETCH_TOPIC);
        if (setting != null && setting.length() > 0) {
            factory.getPrefetchPolicy().setTopicPrefetch(Integer.parseInt(setting));
        }

        setting = settings.getProperty(KEY_USE_COMPRESSION);
        if (setting != null && setting.length() > 0) {
            factory.setUseCompression(Boolean.getBoolean(setting));
        }

        setting = settings.getProperty(KEY_USE_RETROACTIVE);
        if (setting != null && setting.length() > 0) {
            factory.setUseRetroactiveConsumer(Boolean.getBoolean(setting));
        }
    }
}
