package gob.bcb.core.persist;

import gob.bcb.service.commons.UserSessionHolder;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.orm.hibernate3.SessionFactoryUtils;
import org.springframework.transaction.TransactionStatus;

public class EntityUserTransaction {
	private static final Log log = LogFactory.getLog(EntityUserTransaction.class);
	private static Map<String, SessionFactory> sessionFactoryMap = new HashMap<String, SessionFactory>();
	private String nameSessionFactory;
	private static final ThreadLocal<Map> threadTransaction = new ThreadLocal<Map>();
	private static final ThreadLocal<Map> threadTransactionStatus = new ThreadLocal<Map>();
	private static final ThreadLocal<Integer> contador = new ThreadLocal<Integer>();
	// private static final ThreadLocal threadInterceptor = new ThreadLocal();

	public EntityUserTransaction() {

	}

	// public EntityUserTransaction(SessionFactory sessionFactory) {
	// EntityUserTransaction.sessionFactory = sessionFactory;
	// }

	public void begin() throws Exception {
		beginTransaction(getNameSessionFactory());
		// if (sessionFactory == null) {
		// throw new Exception("No se inicializo la variable sessionFactory");
		// }
		// if (hibernateTransactionManager == null) {
		// hibernateTransactionManager = new
		// HibernateTransactionManager(sessionFactory);
		// }
		// if (transactionStatus != null && !transactionStatus.isCompleted() &&
		// nestedTransaction) {
		// // si se intenta inicializar una nuvba trx error de prog.
		// throw new
		// Exception("Existe una transaccion activa, no se puede iniciar una nueva");
		// }
		// if (transactionStatus == null) {
		// transactionStatus = hibernateTransactionManager.getTransaction(null);
		// }

	}

	public void commit() {
		commitTransaction(getNameSessionFactory());
		// try {
		// if (transactionStatus.isCompleted()) {
		// // no existe ninguna transaccion activa
		// return;
		// }
		// hibernateTransactionManager.commit(transactionStatus);
		// } catch (Exception e) {
		// throw new
		// HibernateException("Error al actualizar en la base de datos " +
		// e.getMessage());
		// } finally {
		// transactionStatus = null;
		// }

	}

	public void rollback() {
		rollbackTransaction(getNameSessionFactory());
		// try {
		// if (!transactionStatus.isCompleted()) {
		// hibernateTransactionManager.rollback(transactionStatus);
		// }
		// } catch (Exception e) {
		// throw new HibernateException("Error al realizar rollback " +
		// e.getMessage());
		// } finally {
		// transactionStatus = null;
		// }

	}

	public boolean isActive() {
		TransactionStatus trxStatus = getTransactionStatus();
		return trxStatus != null && !trxStatus.isCompleted();
	}

	public void flush() {
		TransactionStatus trxStatus = getTransactionStatus();
		try {
			if (isActive()) {
				log.info("Starting flushing transaction in this thread. " + getNameSessionFactory());
				trxStatus.flush();
			}
		} catch (Exception e) {
			log.error("Error al realizar " + getNameSessionFactory() + " flush " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * retorna la session activa si no se desea que se cree el parametro es
	 * false, true se creara una nueva session
	 *
	 * @param crearSession
	 * @return
	 */
	public Session getSession(boolean crearSession) {
		Session session = SessionFactoryUtils.getSession(getSessionFactory(getNameSessionFactory()), crearSession);
		return session;
	}

	/**
	 * recupera el session factory del objeto
	 *
	 * @return
	 */
	public SessionFactory getSessionFactory() {
		return getSessionFactory(getNameSessionFactory());
	}

	// public static void setSessionFactory(SessionFactory sessionFactory) {
	// EntityUserTransaction.sessionFactory = sessionFactory;
	// }
	//
	// public static SessionFactory getSessionFactory() {
	// return sessionFactory;
	// }

	public void setTransactionStatus(TransactionStatus transactionStatus) {
	}

	public TransactionStatus getTransactionStatus() {
		TransactionStatus txStatus = (TransactionStatus) threadTransactionStatus.get().get(getNameSessionFactory());
		return txStatus; // transactionStatus;
	}

	public void setHibernateTransactionManager(HibernateTransactionManager hibernateTransactionManager) {
	}

	public HibernateTransactionManager getHibernateTransactionManager() {
		HibernateTransactionManager tx = (HibernateTransactionManager) threadTransaction.get().get(getNameSessionFactory());
		return tx;
	}

	/**
	 * Start a new database transaction.
	 */
	public static void beginTransaction(String sessionFactoryName) throws RuntimeException {
		initSession();
		HibernateTransactionManager tx = (HibernateTransactionManager) threadTransaction.get().get(sessionFactoryName);
		try {
			if (tx == null) {
				log.info("Inicio de una nueva transaccion: " + sessionFactoryName);
				if (getSessionFactory(sessionFactoryName) == null) {
					throw new RuntimeException("No se inicializo la variable sessionFactory " + sessionFactoryName);
				}

				tx = new HibernateTransactionManager(getSessionFactory(sessionFactoryName));

				TransactionStatus txStatus = tx.getTransaction(null);
				threadTransaction.get().put(sessionFactoryName, tx);
				threadTransactionStatus.get().put(sessionFactoryName, txStatus);
				//if (sessionFactoryName.equals("coin")){
					Integer i = contador.get();
					i++;
					contador.set(i);
					log.info(sessionFactoryName + " ==>sesiones : " + contador.get());
				//}
			}
		} catch (HibernateException e) {
			log.error("Error al realizar  " + sessionFactoryName + " beginTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		} catch (Exception e) {
			log.error("Exception Error al realizar  " + sessionFactoryName + " beginTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		}

	}

	/**
	 * Commit the database transaction.
	 */
	public static void commitTransaction(String sessionFactoryName) throws RuntimeException {
		log.info("intenttando comitear." + sessionFactoryName);
		//initSession();
		HibernateTransactionManager tx = (HibernateTransactionManager) threadTransaction.get().get(sessionFactoryName);
		TransactionStatus txStatus = (TransactionStatus) threadTransactionStatus.get().get(sessionFactoryName);
		try {
			if (tx != null && txStatus != null && !txStatus.isCompleted()) {
				// existe transaccion activa
				log.info("Inicio de commit en: " + sessionFactoryName);
				tx.commit(txStatus);
				log.info("Datos almacenados en BDD " + sessionFactoryName);
			}

			threadTransaction.get().put(sessionFactoryName, null);
			threadTransactionStatus.get().put(sessionFactoryName, null);
		} catch (HibernateException e) {
			log.error("Error al realizar " + sessionFactoryName + " commitTransaction(se realizara rollback) " + e.getMessage(), e);
			rollbackTransaction(sessionFactoryName);
			throw new RuntimeException(e);
		} catch (Exception e) {
			log.error("Exception Error al realizar " + sessionFactoryName + " commitTransaction(se realizara rollback) " + e.getMessage(), e);
			rollbackTransaction(sessionFactoryName);
			throw new RuntimeException(e);
		} finally {
			txStatus = null;
		}
	}

	public static void closeTransaction() throws RuntimeException {
		try {
			Map map = threadTransaction.get();
			if (map != null)
				map.clear();
			EntityUserTransaction.threadTransaction.set(null);
			Map map2 = threadTransactionStatus.get();
			if (map2 != null)
				map2.clear();
			EntityUserTransaction.threadTransactionStatus.set(null);

			EntityUserTransaction.contador.set(null);
			log.info("Transacciones cerradas.");
			// Session s = (Session) threadSession.get();
			// threadSession.set(null);
			// if (s != null && s.isOpen()) {
			// log.debug("Closing Session of this thread.");
			// s.close();
			// }
		} catch (HibernateException e) {
			log.error("Error al realizar closeTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		}

	}

	/**
	 * Commit the database transaction.
	 */
	public static void rollbackTransaction(String sessionFactoryName) throws RuntimeException {
		HibernateTransactionManager tx = (HibernateTransactionManager) threadTransaction.get().get(sessionFactoryName);
		TransactionStatus txStatus = (TransactionStatus) threadTransactionStatus.get().get(sessionFactoryName);
		try {
			threadTransaction.get().put(sessionFactoryName, null);
			threadTransactionStatus.get().put(sessionFactoryName, null);

			if (tx != null && txStatus != null && !txStatus.isCompleted()) {
				log.info("Inicio de revertir datos en BDD: " + sessionFactoryName);
				tx.rollback(txStatus);
				log.info("Datos revertidos en BDD: " + sessionFactoryName);
			}
		} catch (HibernateException e) {
			log.error("Error al realizar " + sessionFactoryName + " rollbackTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		} catch (Exception e) {
			log.error("Exception Error al realizar " + sessionFactoryName + " rollbackTransaction " + e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public static void rollbackTransactions() throws RuntimeException {
		Map mapa = threadTransaction.get();
		if (mapa == null || mapa.isEmpty()) {
			return;
		}
		Set<String> l = mapa.keySet();
		for (String string : l) {
			try {
				rollbackTransaction(string);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		closeTransaction();
	}

	private static void initSession() {
		if (threadTransaction.get() == null) {
			Map prefMap = new HashMap();
			threadTransaction.set(prefMap);
		}
		if (threadTransactionStatus.get() == null) {
			Map prefMap2 = new HashMap();
			threadTransactionStatus.set(prefMap2);
		}
		if (contador.get() == null) {
			contador.set(Integer.valueOf(0));
		}
	}

	public static void setSessionFactoryMap(Map<String, SessionFactory> sessionFactoryMap) {
		EntityUserTransaction.sessionFactoryMap = sessionFactoryMap;
	}

	public static Map<String, SessionFactory> getSessionFactoryMap() {
		return sessionFactoryMap;
	}

	public static void setSessionFactoryMap(String name, SessionFactory sessionFactory) {
		EntityUserTransaction.sessionFactoryMap.put(name, sessionFactory);
	}

	public static SessionFactory getSessionFactory(String name) {
		return sessionFactoryMap.get(name);
	}

	public void setNameSessionFactory(String nameSessionFactory) {
		this.nameSessionFactory = nameSessionFactory;
	}

	public String getNameSessionFactory() {
		return nameSessionFactory;
	}
}
