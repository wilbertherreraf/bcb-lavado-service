/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.core.utils;

/**
 *
 * @author wilherrera
 */
import java.sql.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class CorreoUtils {

    private Properties props;
    private String smtpHost = "10.2.11.27";
    private int smtpPort = 25;

    public CorreoUtils() {
    }

    public CorreoUtils(String smtpHost, int smtpPort) {
        this.smtpHost = smtpHost;
        this.smtpPort = smtpPort;
    }

    public void enviaAlServidorSMTP(String from, String to,
            String subject, String content) {
        try {
            initProperties();
            Session session = Session.getInstance(props);

            // Construct the message
            Message msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
            msg.setSubject(subject);
            msg.setText(content);

            // Send the message
            Transport.send(msg);
        } catch (AddressException add) {
            System.out.println("Error de Direccion IP: " + add.toString());
        } catch (MessagingException mes) {
            System.out.println("Error de Mensaje: " + mes.toString());
        }
    }

    private void initProperties() {
        // Create a mail session
        props = new Properties();
        //System.out.println(" props: " + props.getProperty("mail.smtp.host"));
        props.put("mail.smtp.host", smtpHost);
        props.put("mail.smtp.port", "" + smtpPort);
        //System.out.println(" props: " + props.getProperty("mail.smtp.host"));
    }

    /**
     * @return the smtpHost
     */
    public String getSmtpHost() {
        return smtpHost;
    }

    /**
     * @param smtpHost the smtpHost to set
     */
    public void setSmtpHost(String smtpHost) {
        this.smtpHost = smtpHost;
    }

    /**
     * @return the smtpPort
     */
    public int getSmtpPort() {
        return smtpPort;
    }

    /**
     * @param smtpPort the smtpPort to set
     */
    public void setSmtpPort(int smtpPort) {
        this.smtpPort = smtpPort;
    }
}
