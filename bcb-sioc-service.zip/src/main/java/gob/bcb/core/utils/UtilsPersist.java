package gob.bcb.core.utils;

import java.io.File;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public final class UtilsPersist {
	// ########## INICIO: CONSTANTES DE ACCESO A DATOS DE BASES DE DATOS
	// ########//
	public static final String PROP_DB_JDBC_DRIVER = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcdriver";
	public static final String PROP_DB_JDBC_URL = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcurl";
	public static final String PROP_DB_JDBC_USER = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcuser";
	public static final String PROP_DB_JDBC_PASSWORD = "repositorio/configdb/database[@id='ID-DATABASE']/jdbcpassword";
	public static final String PROP_DB_JNDI = "repositorio/configdb/database[@id='ID-DATABASE']/jndi";
	public static final String PROP_DB_HANDLER_FACTORY = "repositorio/configdb/database[@id='ID-DATABASE']/handlerfactory";

	private static Logger log = Logger.getLogger(UtilsPersist.class);

	/**
	 * The name of the default persistence context. * {@value}
	 */
	// public static final String DEFAULT_PERSISTENCE_CONTEXT =
	// Constants.PERSISTENCE_UNIT_NAME_ALADI;

	private UtilsPersist() {
	}

	/**
	 * Create an entity manager
	 * 
	 * @param manager
	 *            name of the manager to retrieve from the persistence.xml
	 * @param options
	 *            any other options
	 * @return an EntityManagerFactory implementation
	 */
	public static EntityManagerFactory createManagerFactory(String manager, Map options) {
		EntityManagerFactory factory;
		factory = Persistence.createEntityManagerFactory(manager, options);
		return factory;
	}

	/**
	 * extract all properties from source with the given prefix, strip the
	 * prefix and return a new Properties instance with the values bound to the
	 * stripped keys
	 * 
	 * @param source
	 *            source properties
	 * @param prefix
	 *            prefix to match for and strip
	 * @return the set of matching and stripped properties (may be size 0, but
	 *         never null)
	 */
	public static Properties extractOptionsWithPrefix(Properties source, String prefix) {
		Properties result = new Properties();
		Enumeration keys = source.propertyNames();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			if (key.startsWith(prefix)) {
				String tail = key.substring(prefix.length());
				result.setProperty(tail, source.getProperty(key));
			}
		}
		return result;
	}

	public static EntityManagerFactory createEntityManagerFactory2(String path, String idDBSource, final String persistenceUnit) {
		XMLConfiguration config = null;
		try {
			File f = new File(path);
			if (f.isDirectory() || !f.exists()) {
				throw new RuntimeException("Error archivo inexistente " + path);
			}
			config = new XMLConfiguration(f);
		} catch (ConfigurationException e) {
			throw new RuntimeException(e);
		}
		String url = (String) Utils.getValueFromXML(config, PROP_DB_JDBC_URL.replaceFirst("ID-DATABASE", idDBSource), "string");
		String username = (String) Utils.getValueFromXML(config, PROP_DB_JDBC_USER.replaceFirst("ID-DATABASE", idDBSource), "string");
		String password = (String) Utils.getValueFromXML(config, PROP_DB_JDBC_PASSWORD.replaceFirst("ID-DATABASE", idDBSource), "string");
		String driver = (String) Utils.getValueFromXML(config, PROP_DB_JDBC_DRIVER.replaceFirst("ID-DATABASE", idDBSource), "string");

		Map<String, String> options = new HashMap<String, String>();

		// propiedades por defecto
		options.put("hibernate.show_sql", "false");
		options.put("hibernate.format_sql", "true");
		options.put("hibernate.dialect", "org.hibernate.dialect.InformixDialect");
		options.put("hibernate.connection.autocommit", "false");
		options.put("hibernate.connection.driver_class", driver);
		options.put("hibernate.connection.url", url);
		options.put("hibernate.connection.username", username);
		options.put("hibernate.connection.password", password);

		options.put("hibernate.c3p0.min_size", String.valueOf(5));
		options.put("hibernate.c3p0.max_size", String.valueOf(50));
		options.put("hibernate.c3p0.timeout", String.valueOf(300));
		// options.put("hibernate.c3p0.acquire_increment", String.valueOf(1));
		options.put("hibernate.c3p0.max_statements", String.valueOf(50));
		options.put("hibernate.c3p0.idle_test_period", String.valueOf(3000));

		// options.put("hibernate.cache.provider_class","net.sf.ehcache.hibernate.EhCacheProvider");

		EntityManagerFactory factory;
		try {
			factory = Persistence.createEntityManagerFactory(persistenceUnit, options);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		log.info("Unidad de persistencia JPA configurado con " + idDBSource + " en URL " + url + ", username " + username);
		return factory;
	}

}
