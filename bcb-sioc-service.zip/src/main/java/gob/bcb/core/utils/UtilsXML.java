package gob.bcb.core.utils;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.io.IOUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.thoughtworks.xstream.XStream;

public final class UtilsXML {
	private static XStream xstream;

	/**
	 * Making nice XML for output in browser, i.e. converting &lt; to &amp;lt;,
	 * &gt; to &amp;gt; etc.
	 */
	public static String makeXML(String param) {
		String xml = param;
		if (xml != null && !"".equals(xml)) {
			xml = xml.replaceAll("><", ">\n<");
			xml = xml.replaceAll("<", "&lt;");
			xml = xml.replaceAll(">", "&gt;");
			xml = xml.replaceAll("\n", "<br />");
		}
		return xml;
	}

	/**
	 * @return A beautified xml string
	 */
	public static String beautifyAndHtmlXML(String xml, String split) {
		return makeXML(beautifyXML(xml, split));
	}

	/**
	 * @return A beautified xml string
	 */
	public static String beautifyXML(String xml, String split) {
		String s = "";
		if (split != null)
			s = ".:split:.";

		if (xml == null || "".equals(xml))
			return xml;

		StringBuffer result = new StringBuffer();

		String[] results = xml.split("<");
		for (int i = 1; i < results.length; i++) {
			results[i] = "<" + results[i].trim();
			if (results[i].endsWith("/>")) {
				result.append(results[i]).append(s);
			} else if (results[i].startsWith("</")) {
				result.append(results[i]).append(s);
			} else if (results[i].endsWith(">")) {
				result.append(results[i]).append(s);
			} else {
				result.append(results[i]);
			}
		}
		// result = result.trim();

		if (split == null)
			return result.toString().trim();

		StringBuilder newResult = new StringBuilder();
		String ident = "";
		results = result.toString().split(s);
		for (int i = 0; i < results.length; i++) {
			if (results[i].startsWith("</"))
				ident = ident.substring(split.length());

			newResult.append(ident).append(results[i]).append("\n");

			if (!results[i].startsWith("<!") && !results[i].startsWith("<?") && results[i].indexOf("</") == -1 && results[i].indexOf("/>") == -1)
				ident += split;
		}
		return newResult.toString();
	}

	public static String objectToXML(Object object) {
		String xml = null;
		if (xstream == null) {
			xstream = new XStream();
			xstream.setMode(XStream.NO_REFERENCES);
		}
		String packageObject[] = object.getClass().getPackage().toString().split(" ");
		if (packageObject.length == 1) {
			xstream.aliasPackage("", packageObject[0].trim());
		} else if (packageObject.length > 1) {
			xstream.aliasPackage("", packageObject[1].trim());
		}
		xml = xstream.toXML(object);
		return xml;
	}

	/**
	 * Dado un objeto XMLConfiguration busca mediante una consulta xpath una
	 * valor en el mismo
	 * 
	 * @param config
	 *            Archivo XMLConfiguration contenedor de propiedades
	 * @param expXpath
	 *            ruta de consulta escrita en formato xpath
	 * @param typeValRet
	 *            tipo de dato del valor a retornar string, number, node o dom
	 * @return los tipos de valores retornados pueden ser string, number, node o
	 *         dom
	 */
	public static Object getValueFromXML(XMLConfiguration config, String expXpath, String typeValRet) {
		Object propResult = null;

		Document document = config.getDocument();
		try {
			XPathFactory xFactory = XPathFactory.newInstance();
			XPath xpath = xFactory.newXPath();
			XPathExpression exp = null;

			exp = xpath.compile(expXpath);

			if (typeValRet.equalsIgnoreCase("STRING")) {
				propResult = exp.evaluate(document, XPathConstants.STRING);
			} else if (typeValRet.equalsIgnoreCase("NUMBER")) {
				propResult = exp.evaluate(document, XPathConstants.NUMBER);
			} else if (typeValRet.equalsIgnoreCase("NODE")) {
				propResult = exp.evaluate(document, XPathConstants.NODE);
			} else if (typeValRet.equalsIgnoreCase("DOM")) {
				propResult = exp.evaluate(document);
			}

		} catch (XPathExpressionException e) {
			document = null;
			throw new RuntimeException(e);
		} catch (Exception e) {
			document = null;
			throw new RuntimeException(e);
		}
		document = null;
		return propResult;
	}

	public static String node2XML(Node node) throws TransformerException {
		String processedXML = null;

		// Transform the DOM tree into XML String
		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer = transFactory.newTransformer();
		//transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		DOMSource dSource = new DOMSource(node);
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(dSource, sr);

		StringWriter anotherSW = (StringWriter) sr.getWriter();
		StringBuffer sBuffer = anotherSW.getBuffer();
		processedXML = sBuffer.toString();

		return processedXML;
	}

	public static String tagToString(String cadenaXML, String tag) throws ParserConfigurationException, SAXException, IOException, TransformerException {

		Document doc = getDomFromString(cadenaXML);
		NodeList nodeList = doc.getElementsByTagName(tag);
		Node node = nodeList.item(0);

		String s = node2XML(node);
		return s;
	}

	public static Document getDomFromString(String xmlSource) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();

		return builder.parse(new InputSource(new StringReader(xmlSource)));
	}

	public static void main(String[] args) throws TransformerException, ParserConfigurationException, SAXException, IOException {
		String s = cadenapru.toString();
		int i = s.indexOf("<respuesta>");
		int k = s.indexOf("</codigo1>");
		String ss = ( i > 0 && k > 0 ? s.substring((i + "<codigo4>".length()), k): "");
		System.out.println(ss);
		System.out.println(UtilsDate.stringFromDate(new Date(), "yyyyMMddHHmmss"));
		s = tagToString(cadenapru.toString(), "respuesta");

		System.out.println(s + " " + UtilsDate.stringFromDate(new Date(), "yyyyMMddhhmmss"));		
		// StreamSource source = new StreamSource(new StringReader(xml));
		// TransformerFactory transFac = TransformerFactory.newInstance();
		// Transformer xformer = transFac.newTransformer();
		// DOMResult domResult = new DOMResult();
		// xformer.transform(source, domResult);
		//
		// Node n = domResult.getNode();

	}

	static StringBuilder cadenapru = new StringBuilder();
	static {

		cadenapru.append("<respuesta>                                                     ");
		cadenapru.append("	<ID>1</ID>                                                  ");
		cadenapru.append("	<Fecha>20130717</Fecha>                                     ");
		cadenapru.append("	<totalReg>2</totalReg>                                      ");
		cadenapru.append("	<Autorizados>                                               ");
		cadenapru.append("		<Autorizado>                                            ");
		cadenapru.append("			<codigo>00336501óññ↨@┘</codigo>                           ");
		cadenapru.append("			<prestamo>17000</prestamo>                         ");
		cadenapru.append("			<tramo>1</tramo>                                    ");
		cadenapru.append("			<estado>A</estado>                                  ");
		cadenapru.append("			<observacion>NINGUNA</observacion>                  ");
		cadenapru.append("			<cuentaServicio>3987069001</cuentaServicio>         ");
		cadenapru.append("			<libretaServicio>00890508003</libretaServicio>      ");
		cadenapru.append("			<cuentaComisiones>3987069001</cuentaComisiones>     ");
		cadenapru.append("			<libretaComisiones>00660104201</libretaComisiones>  ");
		cadenapru.append("		</Autorizado>                                           ");
		cadenapru.append("		<Autorizado>                                            ");
		cadenapru.append("			<codigo>00336801</codigo>                           ");
		cadenapru.append("			<prestamo>1040005</prestamo>                         ");
		cadenapru.append("			<tramo>1</tramo>                                    ");
		cadenapru.append("			<estado>A</estado>                                  ");
		cadenapru.append("			<observacion>NINGUNA</observacion>                  ");
		cadenapru.append("			<cuentaServicio>3987069001</cuentaServicio>         ");
		cadenapru.append("			<libretaServicio>00410101101</libretaServicio>      ");
		cadenapru.append("			<cuentaComisiones>3987069001</cuentaComisiones     ");
		cadenapru.append("			<libretaComisiones>00810104301</libretaComisiones>  ");
		cadenapru.append("		</Autorizado>                                           ");
		cadenapru.append("	</Autorizados>                                              ");
		cadenapru.append("</respuesta> 													");
	}

}
