package gob.bcb.core.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;


public final class UtilsNet {
    public static String getAddressHost() throws Exception {
        String hostName = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostName = addr.getHostAddress();
        } catch (UnknownHostException e) {
            hostName = "localhost";
        }
        return hostName;
    }
    public static String getNameHost() throws Exception {
        String hostName = "";
        try {
            InetAddress addr = InetAddress.getLocalHost();
            hostName = addr.getCanonicalHostName();
        } catch (UnknownHostException e) {
            hostName = "localhost";
        }
        return hostName;
    }
}
