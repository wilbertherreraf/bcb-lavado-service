package gob.bcb.core.utils;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.security.InvalidParameterException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.CDATASection;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.thoughtworks.xstream.XStream;
import java.lang.annotation.Annotation;

public class UtilsXmlBind {
	private static final Log log = LogFactory.getLog(UtilsXmlBind.class);
	public static SimpleDateFormat FORMATO_FECHA = new SimpleDateFormat("EEE MMM dd HH:mm:ss.SSS zzz yyyy", new Locale("es", "BO"));
	private final static Map<Class<?>, JAXBContext> contexts = new HashMap<Class<?>, JAXBContext>();
	private final static Map<String, JAXBContext> packageContexts = new HashMap<String, JAXBContext>();
	private static final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
	private static DocumentBuilder builder;
	private final static TransformerFactory tf = TransformerFactory.newInstance();
	private UtilsXmlBind() {

	}
 
	// ---------------------------------------------------------------------------
	/**
	 * Convierte el contenido xml de un objeto {@link String} en un objeto
	 * {@link Document}
	 * 
	 * @param xmlSource
	 *            el objeto {@link String} a ser procesado
	 * @return el objeto {@link Document}
	 */
	public static Document stringToDom(String xmlSource) {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			return builder.parse(new InputSource(new StringReader(xmlSource)));
		} catch (ParserConfigurationException e) {
			log.error(e.getMessage());
			return null;
		} catch (SAXException e) {
			log.error(e.getMessage());
			return null;
		} catch (IOException e) {
			log.error(e.getMessage());
			return null;
		}
	}

	// ---------------------------------------------------------------------------
	// ---------------------------------------------------------------------------
	public static String getStringFromDom(Document doc) throws TransformerException {
		if (null == doc) {
			throw new InvalidParameterException("Objeto Document proporcionado es null.");
		}

		DOMSource domSource = new DOMSource(doc);
		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		Transformer transformer = tf.newTransformer();
		//transformer.setOutputProperty(OutputKeys.ENCODING, "ISO-8859-1");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.MEDIA_TYPE,"text/xml");		
		transformer.transform(domSource, result);
		return writer.toString();
	}

	// ---------------------------------------------------------------------------
	public static String getStringFromSoap(SOAPMessage soapMessage) throws SOAPException, TransformerException {
		Source sourceContent = soapMessage.getSOAPPart().getContent();

		DOMResult domResult = new DOMResult();

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.transform(sourceContent, domResult);

		Document node = (Document) domResult.getNode();

		return getStringFromDom(node);
	}

	// ---------------------------------------------------------------------------
	public static Document getDomFromString(String xmlSource) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder = factory.newDocumentBuilder();
		return builder.parse(new InputSource(new StringReader(xmlSource)));
	}

	public static Document getDomFromStringNoSpaceAware(String xmlSource) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		return builder.parse(new InputSource(new StringReader(xmlSource)));
	}

	// ---------------------------
	public static String toString(Object value) throws JAXBException, ParserConfigurationException, TransformerException {
		Document doc = UtilsXmlBind.toDocument(value);
		return UtilsXmlBind.getStringFromDom(doc);
	}

	public static Document toDocument(Object value) throws JAXBException, ParserConfigurationException {
		if (value == null) {
			throw new IllegalArgumentException("Cannot convert from null value to JAXBSource");
		}
		if (value.getClass().getAnnotation(XmlRootElement.class) != null) {
			JAXBContext context = getJaxbContext(value);
			// must create a new instance of marshaller as its not thread safe
			Marshaller marshaller = context.createMarshaller();

			Document doc = createDocument();

			marshaller.marshal(value, doc);
			return doc;
		} else {
			JAXBContext context = getPackageContext(value);
			// must create a new instance of marshaller as its not thread safe
			Marshaller marshaller = context.createMarshaller();

			Document doc = createDocument();

			marshaller.marshal(value, doc);
			return doc;
		}

	}

	private static synchronized JAXBContext getJaxbContext(Object value) throws JAXBException {
		Class<?> type = value.getClass();
		JAXBContext context = contexts.get(type);
		if (context == null) {
			context = JAXBContext.newInstance(type);
			contexts.put(type, context);
		}
		return context;
	}

	public static JAXBContext getPackageContext(Object value) {
		Class<?> type = value.getClass();
		if (type == null || type == JAXBElement.class) {
			return null;
		}
		synchronized (packageContexts) {
			String packageName = PackageUtils.getPackageName(type);
			JAXBContext context = packageContexts.get(packageName);

			if (context == null) {
				try {
					context = JAXBContext.newInstance(packageName, type.getClassLoader());
					packageContexts.put(packageName, context);
				} catch (JAXBException ex) {
					log.error("Error creating a JAXBContext using ObjectFactory : " + ex.getMessage());
					return null;
				}
			}
			return context;
		}
	}

	public static Document createDocument() throws ParserConfigurationException {
		DocumentBuilder builder = createDocumentBuilder();
		return builder.newDocument();
	}

	public static DocumentBuilder createDocumentBuilder() throws ParserConfigurationException {
		if (builder == null) {
			documentBuilderFactory.setNamespaceAware(true);
			//documentBuilderFactory.setIgnoreElementContentWhitespace(true);
			documentBuilderFactory.setIgnoringElementContentWhitespace(true);
			documentBuilderFactory.setIgnoringComments(true);
			builder = documentBuilderFactory.newDocumentBuilder();

		}
		return builder;
	}
}
