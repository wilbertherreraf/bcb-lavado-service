package gob.bcb.core.utils;

import org.apache.log4j.Logger;

import java.lang.reflect.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 */
public class UtilsQNatives {
	private static Logger log = Logger.getLogger(UtilsQNatives.class);

	public static Object convertResultSetToMap(ResultSet rs) throws SQLException {
		Map<String, Object> result = new HashMap<String, Object>();
		// whf evaluar si es posible con entrys
		// Set<Map.Entry<String, Object>> listaRS0 = result.entrySet();

		Set<Map<String, Object>> listaRS = new HashSet<Map<String, Object>>();

		while (rs.next()) {
			result = new HashMap<String, Object>();
			for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
				String key = rs.getMetaData().getColumnName(i);

				if (key != null) {
					result.put(key, rs.getObject(i));
					log.debug(i + " - " + key + " - " + rs.getObject(i));
				}
			}
			listaRS.add(result);
		}
		/*
		 * } catch (SQLException e) { e.printStackTrace(); }
		 */
		return listaRS;
	}
	
	public static List<Map<String, Object>> convertListToMap(List result, String[] namesColumns) {
		Iterator iter = result.iterator();
		List<Map<String, Object>> resultado = new ArrayList<Map<String, Object>>();		
		if (!iter.hasNext()) {
			log.debug("Lista de datos sin registros.");
			return resultado;
		}
		log.debug("convertListToMap " + result.size());
		while (iter.hasNext()) {
			Map<String, Object> fila = new LinkedHashMap<String, Object>();
			Object objeto = iter.next();
			if (objeto != null) {
				Class clazz = objeto.getClass();
				if (clazz.isArray()) {
					// Object[] obj = (Object[]) iter.next();
					int length = Array.getLength(objeto);
					if (length != 0) {
						Object[] obj = (Object[]) objeto;
						// Array.newInstance(wrapperType, length);
						for (int i = 0; i < length; i++) {
							fila.put((i > namesColumns.length ? String.valueOf(i) : namesColumns[i].trim()), obj[i]);
						}
						resultado.add(fila);
					}
				} else {
					fila.put(namesColumns[0], objeto);
					resultado.add(fila);
				}
			} else {
				fila.put(namesColumns[0], objeto);
				resultado.add(fila);
			}

		}
		return resultado;
	}
	
}
