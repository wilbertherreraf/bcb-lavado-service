/**
 * InternaException.java
 *
 * Creado el 28 de mayo de 2003, 08:48 AM
 */

package gob.bcb.core.exception;


/**
 * Crea una nueva instancia de <code>InternaException</code> sin mensaje.
 */
public class InternaException extends UncheckedException {

    /**
     * Crear una nueva instancia de <code>InternaException</code> sin mensaje.
     */
    public InternaException() {
    }
    /**
     * Construir una instancia de <code>InternaException</code> especifiacndo el mensaje.
     * @param msg el mensaje.
     */
    public InternaException(String msg) {
        super(msg);
    }
    public InternaException(String msg, Throwable t) {
		super(msg, t);
	}
    public InternaException(Throwable t) {
		super(t);
	}    
}
