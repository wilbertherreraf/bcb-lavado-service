/**
 * DataBaseException.java
 *
 * Creado el 27 de mayo de 2003, 02:48 PM
 */
package gob.bcb.core.exception;

import org.apache.log4j.Logger;

/**
 * Excepcion de tipo FIRMA
 */
public class DataBaseException extends UncheckedException {

    /**
     * Crear una nueva instancia de <code>DataBaseException</code> sin mensaje.
     */
    public DataBaseException() {
    }
    /**
     * Construir una instancia de <code>DataBaseException</code> especifiacndo el mensaje.
     * @param msg el mensaje.
     */
    public DataBaseException(String msg) {
        super(msg);
    }
    public DataBaseException(String msg, Throwable t) {
		super(msg, t);
	}
    public DataBaseException(Throwable t) {
		super(t);
	}    
}
