/**
 * AlmacenException.java
 *
 * Creado el 28 de mayo de 2003, 03:17 PM
 */
package gob.bcb.core.exception;
/**
 * Clase de captura de excepcion personalizada
 * @author Alfredo Lupe
 */

public class VerificaException extends UncheckedException {

    /**
     * Crear una nueva instancia de <code>VerificaException</code> sin mensaje.
     */
    public VerificaException() {
    }
    /**
     * Construir una instancia de <code>VerificaException</code> especifiacndo el mensaje.
     * @param msg el mensaje.
     */
    public VerificaException(String msg) {
        super(msg);
    }
    public VerificaException(String msg, Throwable t) {
		super(msg, t);
	}
    public VerificaException(Throwable t) {
		super(t);
	}    
}
