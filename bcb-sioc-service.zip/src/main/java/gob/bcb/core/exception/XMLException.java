/**
 * XMLException.java
 *
 * Creado el 26 de mayo de 2003, 12:02 PM
 */
package gob.bcb.core.exception;
/**
 * Clase para capturar las excepciones de tipo XML
 * @author ALupe
 * @version 2.00.0000
 */
public class XMLException extends java.lang.Exception {

    /**
     * Crear una nueva instancia de <code>XMLException</code> sin incluir mensaje.
     */
    public XMLException() {
    }
    /**
     * Construir una instancia de <code>XMLException</code>
     * incluyendo el mensaje.
     * @param msg detalle del mensaje.
     */
    public XMLException(String msg) {
        super(msg);
    }
}
