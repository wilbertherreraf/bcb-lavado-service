package gob.bcb.core.exception;


import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.Serializable;
import java.text.MessageFormat;

/**
 * Para mensajes de error
 * @author wilherrera
 * Wilbert Herrera Flores
 * Banco Central de Bolivia
 * Departamento de Desarrollo
 */
public class MsgManager implements Serializable {
	private static final long serialVersionUID = 3658825171297169508L;
	transient String code;
	transient Object[] parameters;
	transient ResourceBundle bundle;

	/**
	 * Constructor.
	 * 
	 * @param key
	 *            the message catalog (resource bundle) key
	 * @param logger
	 *            a logger with an associated resource bundle
	 * @param params
	 *            the message substitution parameters
	 */
	public MsgManager(String key, Logger logger, Object... params) {
		this(key, logger.getResourceBundle(), params);
	}

	/**
	 * Constructor.
	 * 
	 * @param key
	 *            the message catalog (resource bundle) key
	 * @param catalog
	 *            the resource bundle
	 * @param params
	 *            the message substitution parameters
	 */
	public MsgManager(String key, ResourceBundle catalog, Object... params) {
		code = key;
		bundle = catalog;
		parameters = params;
	}
	public MsgManager(String key) {
		code = key;
		
		
	}
	public String toString() {
		String fmt = null;
		try {
			if (null == bundle) {
				return code;
			}
			fmt = bundle.getString(code);
		} catch (MissingResourceException ex) {
			return code;
		}
		return MessageFormat.format(fmt, parameters);
	}

	public String getCode() {
		return code;
	}

	public Object[] getParameters() {
		return parameters;
	}

	private void writeObject(java.io.ObjectOutputStream out) throws IOException {
		out.writeUTF(toString());
	}

	private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
		code = in.readUTF();
		bundle = null;
		parameters = null;
	}
}
