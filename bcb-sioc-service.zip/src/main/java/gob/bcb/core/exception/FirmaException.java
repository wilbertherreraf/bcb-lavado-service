/**
 * FirmaException.java
 *
 * Creado el 27 de mayo de 2003, 02:48 PM
 */
package gob.bcb.core.exception;

/**
 * Excepcion de tipo FIRMA
 */
public class FirmaException extends java.lang.Exception {

    /**
     * Crear una nueva instancia de <code>FirmaException</code> sin mensaje.
     */
    public FirmaException() {
    }
    /**
     * Construir una instancia de <code>FirmaException</code> especifiacndo el mensaje.
     * @param msg el mensaje.
     */
    public FirmaException(String msg) {
        super(msg);
    }
}
