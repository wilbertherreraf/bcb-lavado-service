package gob.bcb.swift.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the swf_mencampos database table.
 * 
 */
@Embeddable
public class SwfMencamposPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="mtf_codcampo")
	private String mtfCodcampo;

	@Column(name="mtf_codmt")
	private String mtfCodmt;

	@Column(name="mtf_nro")
	private int mtfNro;

	public SwfMencamposPK() {
	}
	public String getMtfCodcampo() {
		return this.mtfCodcampo;
	}
	public void setMtfCodcampo(String mtfCodcampo) {
		this.mtfCodcampo = mtfCodcampo;
	}
	public String getMtfCodmt() {
		return this.mtfCodmt;
	}
	public void setMtfCodmt(String mtfCodmt) {
		this.mtfCodmt = mtfCodmt;
	}
	public int getMtfNro() {
		return this.mtfNro;
	}
	public void setMtfNro(int mtfNro) {
		this.mtfNro = mtfNro;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof SwfMencamposPK)) {
			return false;
		}
		SwfMencamposPK castOther = (SwfMencamposPK)other;
		return 
			this.mtfCodcampo.equals(castOther.mtfCodcampo)
			&& this.mtfCodmt.equals(castOther.mtfCodmt)
			&& (this.mtfNro == castOther.mtfNro);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.mtfCodcampo.hashCode();
		hash = hash * prime + this.mtfCodmt.hashCode();
		hash = hash * prime + this.mtfNro;
		
		return hash;
	}
}