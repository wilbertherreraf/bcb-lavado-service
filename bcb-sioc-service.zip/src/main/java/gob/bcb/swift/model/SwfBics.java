package gob.bcb.swift.model;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The persistent class for the swf_bics database table.
 * 
 */
@Entity
@Table(name = "swf_bics")
public class SwfBics implements Serializable{
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SwfBicsPK id;

	@Column(name = "bic_ciudad")
	private String bicCiudad;

	@Column(name = "bic_descrip")
	private String bicDescrip;

	@Column(name = "bic_direcc1")
	private String bicDirecc1;

	@Column(name = "bic_direcc2")
	private String bicDirecc2;

	@Column(name = "bic_pais")
	private String bicPais;

	public SwfBics() {
	}

	public SwfBics(String bicCodbic, String bicCodbranch, String bicDescrip, String bicDirecc1, String bicCiudad, String bicPais) {
		SwfBicsPK swfBicsPK = new SwfBicsPK();
		swfBicsPK.setBicCodbic(bicCodbic);
		swfBicsPK.setBicCodbranch(bicCodbranch);

		setId(swfBicsPK);
		setBicDescrip(bicDescrip);
		setBicDirecc1(bicDirecc1);
		setBicCiudad(bicCiudad);
		setBicPais(bicPais);
	}

	public SwfBicsPK getId() {
		return this.id;
	}

	public void setId(SwfBicsPK id) {
		this.id = id;
	}

	public String getBicCiudad() {
		return this.bicCiudad;
	}

	public void setBicCiudad(String bicCiudad) {
		this.bicCiudad = bicCiudad;
	}

	public String getBicDescrip() {
		return this.bicDescrip;
	}

	public void setBicDescrip(String bicDescrip) {
		this.bicDescrip = bicDescrip;
	}

	public String getBicDirecc1() {
		return this.bicDirecc1;
	}

	public void setBicDirecc1(String bicDirecc1) {
		this.bicDirecc1 = bicDirecc1;
	}

	public String getBicDirecc2() {
		return this.bicDirecc2;
	}

	public void setBicDirecc2(String bicDirecc2) {
		this.bicDirecc2 = bicDirecc2;
	}

	public String getBicPais() {
		return this.bicPais;
	}

	public void setBicPais(String bicPais) {
		this.bicPais = bicPais;
	}

}