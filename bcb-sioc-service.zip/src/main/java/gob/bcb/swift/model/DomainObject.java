package gob.bcb.swift.model;

import java.io.Serializable;

public interface DomainObject extends Serializable {

}
