package gob.bcb.swift.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "swf_mttransfer")
public class SwfMttransfer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "mtt_codttransfer")
	private String mttCodttransfer;

	@Column(name = "mtt_descrip")
	private String mttDescrip;

	@Column(name = "mtt_codmt")
	private String mttCodmt;

	public SwfMttransfer() {

	}

	public String getMttCodttransfer() {
		return mttCodttransfer;
	}

	public void setMttCodttransfer(String mttCodttransfer) {
		this.mttCodttransfer = mttCodttransfer;
	}

	public String getMttDescrip() {
		return mttDescrip;
	}

	public void setMttDescrip(String mttDescrip) {
		this.mttDescrip = mttDescrip;
	}

	public String getMttCodmt() {
		return mttCodmt;
	}

	public void setMttCodmt(String mttCodmt) {
		this.mttCodmt = mttCodmt;
	}
}
