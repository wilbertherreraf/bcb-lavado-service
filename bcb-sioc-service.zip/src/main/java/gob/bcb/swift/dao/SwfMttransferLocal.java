package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfMttransfer;

import java.util.List;

import org.hibernate.SessionFactory;

//@Local
//public interface SwfMttransferLocal extends DAO<String, SwfMttransfer>{
//public interface SwfMttransferLocal 	extends GenericoDao<SwfMttransfer> {
public interface SwfMttransferLocal {
	SwfMttransfer findByCodigo(String mttCodttransfer);

	List<SwfMttransfer> getMTs();
	void setSessionFactory(SessionFactory sessionFactory);

}
