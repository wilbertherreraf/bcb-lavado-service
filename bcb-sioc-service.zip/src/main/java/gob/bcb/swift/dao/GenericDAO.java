/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gob.bcb.swift.dao;

import gob.bcb.core.utils.AccessorsUtil;
import gob.bcb.service.commons.UserSessionHolder;
import gob.bcb.swift.commons.ConstantsSwift;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;

/**
 * Implementación de la interfaz generica que se utiliza para abstrar el comportamient general de
 * un DAO.Esta clase abstra la funcionalidad de persistir, inactivar, remover, mezclar, actualizar,
 * buscar por primary key, y obtener los registros cuyo cve_estado sea 'V'
 * 
 * @author wherrera
 */
/**
 * @author wilherrera Wilbert Herrera Flores Banco Central de Bolivia
 *         Departamento de Desarrollo
 * @param <K>
 * @param <E>
 */
public abstract class GenericDAO<K, E> implements DAO<K, E> {

	protected static Logger log = Logger.getLogger(GenericDAO.class);
	protected Class<E> entityClass;

	@PersistenceContext(unitName = "ALADI_PU")
	protected EntityManager entityManager;
	
	protected Method methodfho = null;
	protected Method methodwst = null;
	protected Method methodusr = null;
	private boolean auditdo = false;
	private String estacionAudit;
	private String usuarioDBAudit;	
	private Map<String, String> fieldsAudit = new HashMap<String, String>();

	/**
	 * Constructor.- Obtiene por medio de reflection la clase de la entidad
	 * generica E
	 */
	public GenericDAO() {
		ParameterizedType parameterizedType = (ParameterizedType) getClass().getGenericSuperclass();
		this.entityClass = (Class<E>) parameterizedType.getActualTypeArguments()[1];
		fieldsAudit.put("FechaHora", "FechaHora");
		fieldsAudit.put("Estacion", "Estacion");
		fieldsAudit.put("CodUsuario", "CodUsuario");
		log.info("Creando DAO ... " + entityClass.getName());
		
	}

	public void setEntityManager(EntityManager em) {
		this.entityManager = em;
	}

	protected EntityManager getEntityManager() {
		if (entityManager == null)
			throw new IllegalStateException("EntityManager has not been set on DAO before usage");
		return entityManager;
	}

	
	public Class<E> getEntityBeanType() {
		return entityClass;
	}

	/**
	 * Metodo que inserta un registro en base de datos.
	 * 
	 * @param entity
	 *            Entidad asociada que sera ingresada a la Base de Datos
	 * @param entityManager
	 *            EntityManager utilizado para la transaccion
	 */
	/*
	 *  public void insertar(E entity, EntityManager em) {
	 * em.persist(entity); }
	 */
	
	public void persist(E entity) {
		audit(entity);
		entityManager.persist(entity);
	}

	/**
	 * Metodo que actualiza un registro en base de datos
	 * 
	 * @param entity
	 *            Entidad asociada que sera actualizada a la Base de Datos
	 * @param entityManager
	 *            EntityManager utilizado para la transaccion
	 */
	/*
	 *  public void actualizar(E entity, EntityManager em) {
	 * em.merge(entity); }
	 */

	
	public E makePersistent(E entity) {
		audit(entity);
		return getEntityManager().merge(entity);
	}

	/**
	 * Metodo que refresca el cache de una entidad
	 * 
	 * @param entity
	 *            Entidad asociada que sera refrescada a la Base de Datos
	 * @param entityManager
	 *            EntityManager utilizado para la transaccion
	 */
	
	public void refresh(E entity) {
		getEntityManager().refresh(entity);
	}

	/**
	 * Metodo que elimina un registro en base de datos
	 * 
	 * @param entity
	 *            Entidad asociada que sera eliminada de la Base de Datos
	 * @param entityManager
	 *            EntityManager utilizado para la transaccion
	 */
	/*
	 *  public void remover(E entity, EntityManager em) {
	 * em.remove(entity); }
	 */

	
	public void makeTransient(E entity) {
		getEntityManager().remove(entity);
	}

	
	public void flush() {
		// if (em.getTransaction().isActive())
		getEntityManager().flush();
	}

	
	public void clear() {
		getEntityManager().clear();
	}

	/**
	 * Metodo que coloca el cve_estado en 'S' de un registro en base de datos
	 * 
	 * @param entity
	 *            Entidad asociada que sera suspendida (inactivada) en la Base
	 *            de Datos
	 * @param entityManager
	 *            EntityManager utilizado para la transaccion
	 */
	
	public void inactivar(E entity) {
		try {
			Method method = entityClass.getMethod("setCveVigente", String.class);
			method.invoke(entity, "S");
			getEntityManager().merge(entity);
		} catch (IllegalArgumentException ex) {
			throw new RuntimeException("La entidad: " + this.entityClass.getName() + " no tiene el método setCveVigente. " + ex.getMessage(), ex);
		} catch (InvocationTargetException ex) {
			throw new RuntimeException("La entidad no es de la clase: " + this.getClass().getName() + " y lanzo una excepción. " + ex.getMessage(),
					ex);
		} catch (NoSuchMethodException ex) {
			throw new RuntimeException("La entidad: " + this.entityClass.getName() + " no tiene el método setCveVigente. " + ex.getMessage(), ex);
		} catch (SecurityException ex) {
			throw new RuntimeException("La entidad: " + this.entityClass.getName() + " tiese el método setCveVigente, pero no es accesible. "
					+ ex.getMessage(), ex);
		} catch (IllegalAccessException ex) {
			throw new RuntimeException("La entidad: " + this.entityClass.getName() + " tiese el método setCveVigente, pero no es accesible. "
					+ ex.getMessage(), ex);
		}
	}

	public void audit(E entity) {
		initaudit(entity);
		try {
			if (methodfho != null)
				methodfho.invoke(entity, new Date());
		} catch (Exception ex) {
		}

		try {
			if (methodwst != null && getEstacionAudit() != null)
				methodwst.invoke(entity, getEstacionAudit());
		} catch (Exception ex) {
		}

		try {
			if (methodusr != null && getUsuarioDBAudit() != null)
				methodusr.invoke(entity, getUsuarioDBAudit());
		} catch (Exception ex) {
		}
	}


	private void initaudit(E entity) {
		if (auditdo){
			return;
		}
		String fieldAudit = "set" + fieldsAudit.get("FechaHora");
		List<String> fieldsAudit0 = AccessorsUtil.extractFieldsList(entityClass);
		String namefield = fieldsAudit0.get(0);
		
		if (namefield.length() <= 5){
			namefield = fieldsAudit0.get(1);
		}

		if (namefield == null || namefield.length() <= 5){
			namefield = "XXXXX";
		}
		
		String fieldAuditAudit = "";

		try {
			methodfho = entityClass.getMethod(fieldAudit, Date.class);
		} catch (Exception ex) {
		}
		
		try {
			if (methodfho == null) {
				fieldAuditAudit = "set" + Character.toUpperCase(namefield.charAt(0)) + namefield.substring(1, 3) + "Auditfho";
				methodfho = entityClass.getMethod(fieldAuditAudit, Date.class);
			}
		} catch (Exception ex) {
		}
		
		fieldAudit = "set" + fieldsAudit.get("Estacion");
		{

			try {
				methodwst = entityClass.getMethod(fieldAudit, String.class);
			} catch (Exception ex) {
			}
			try {
				if (methodwst == null) {
					fieldAuditAudit = "set" + Character.toUpperCase(namefield.charAt(0)) + namefield.substring(1, 3) + "Auditwst";
					methodwst = entityClass.getMethod(fieldAuditAudit, String.class);
				}
			} catch (Exception ex) {
			}
		}

		// User ID

		fieldAudit = "set" + fieldsAudit.get("CodUsuarioHa");

		{
			try {
				methodusr = entityClass.getMethod(fieldAudit, String.class);
			} catch (Exception ex) {
			}
			try {
				if (methodusr == null) {
					fieldAuditAudit = "set" + fieldsAudit.get("CodUsuario");
					methodusr = entityClass.getMethod(fieldAuditAudit, String.class);
				}
			} catch (Exception ex) {
			}			
			try {
				if (methodusr == null) {
					fieldAuditAudit = "set" + Character.toUpperCase(namefield.charAt(0)) + namefield.substring(1, 3) + "Auditusr";
					methodusr = entityClass.getMethod(fieldAuditAudit, String.class);
				}
			} catch (Exception ex) {
			}
		}
		auditdo = true;
	}

	/**
	 * Método que devuelve una entidad a partir de su llave primaria.
	 * 
	 * @param id
	 *            Llave primaria para buscar la entidad
	 * @param entityManager
	 *            EntityManager utilizado para la transaccion
	 * @return Entidad encontrada o en su defecto null
	 */
	/*
	 *  public E buscarPorPK(K id, EntityManager em) { return
	 * em.find(entityClass, id); }
	 */

	// 
	public E findById(K id, boolean lock) {
		E entity;
		if (lock) {
			entity = getEntityManager().find(getEntityBeanType(), id);
			entityManager.lock(entity, javax.persistence.LockModeType.WRITE);
		} else {
			entity = getEntityManager().find(getEntityBeanType(), id);
		}
		return entity;
	}

	
	
	public List<E> findAll() {
		return getEntityManager().createQuery("from " + getEntityBeanType().getName()).getResultList();
	}

	
	
	public List<E> findByExample(E exampleInstance, String... excludeProperty) {
		// Using Hibernate, more difficult with EntityManager and EJB-QL
		org.hibernate.Criteria crit = ((org.hibernate.ejb.HibernateEntityManager) getEntityManager()).getSession()
				.createCriteria(getEntityBeanType());
		org.hibernate.criterion.Example example = org.hibernate.criterion.Example.create(exampleInstance);
		for (String exclude : excludeProperty) {
			example.excludeProperty(exclude);
		}
		crit.add(example);
		return crit.list();
	}

	/**
	 * Use this inside subclasses as a convenience method.
	 */
	
	protected List<E> findByCriteria(org.hibernate.criterion.Criterion... criterion) {
		// Using Hibernate, more difficult with EntityManager and EJB-QL
		org.hibernate.Session session = ((org.hibernate.ejb.HibernateEntityManager) getEntityManager()).getSession();
		org.hibernate.Criteria crit = session.createCriteria(getEntityBeanType());
		for (org.hibernate.criterion.Criterion c : criterion) {
			crit.add(c);
		}
		return crit.list();
	}

	public void setFieldsAudit(Map<String, String> fieldsAudit) {
		this.fieldsAudit = fieldsAudit;
	}

	public Map<String, String> getFieldsAudit() {
		return fieldsAudit;
	}

	public String getEstacionAudit() {
		estacionAudit = (String) UserSessionHolder.get(ConstantsSwift.AUDIT_USER_ESTACION);			
		return estacionAudit;
	}

	public void setEstacionAudit(String estacionAudit) {
		this.estacionAudit = estacionAudit;
	}

	public String getUsuarioDBAudit() {
		usuarioDBAudit = (String) UserSessionHolder.get(ConstantsSwift.AUDIT_USER_DATABASE_ID);			
	
		return usuarioDBAudit;
	}

	public void setUsuarioDBAudit(String usuarioDBAudit) {
		this.usuarioDBAudit = usuarioDBAudit;
	}
}
