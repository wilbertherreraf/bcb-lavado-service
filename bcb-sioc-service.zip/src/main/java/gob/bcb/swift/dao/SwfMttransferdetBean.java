package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfMttransferdet;


import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("swfMttransferdetLocal")
@Transactional
public class SwfMttransferdetBean extends HibernateDaoSupport implements SwfMttransferdetLocal {
	
	private static Logger log = Logger.getLogger(SwfMttransferdetBean.class);
	
	public SwfMttransferdet findByCodigo(String dttCodttransfer, String dttCodcampo, Integer dttBloque) {
		String jpql = "SELECT t FROM SwfMttransferdet t ";
		jpql = jpql.concat("WHERE t.id.dttCodttransfer = :dttCodttransfer ");
		jpql = jpql.concat("and t.id.dttCodcampo = :dttCodcampo ");
		jpql = jpql.concat("and t.id.dttBloque = :dttBloque ");		

		Query query = getSession().createQuery(jpql);
		query.setParameter("dttCodttransfer", dttCodttransfer);
		query.setParameter("dttCodcampo", dttCodcampo);
		query.setParameter("dttBloque", dttBloque);		

		log.info("findByCodigo dttCodttransfer: " + dttCodttransfer  + " Bloque: " + dttBloque + " dttCodcampo " +  dttCodcampo);
		List lista = query.list();
		if (lista.size() > 0) {
			return (SwfMttransferdet) lista.get(0);
		}

		return null;
	}

	public List<SwfMttransferdet> findByCodTTransfer(String dttCodttransfer, Integer dttBloque) {
		
		String jpql = "SELECT t FROM SwfMttransferdet t WHERE t.id.dttCodttransfer = :dttCodttransfer ";
		
		if (dttBloque != null)
			jpql = jpql.concat("and t.id.dttBloque = :dttBloque ");
		
		log.info("findByCodTTransfer dttCodttransfer: " + dttCodttransfer  + " Bloque: " + dttBloque);
		Query query = getSession().createQuery(jpql);
		query.setParameter("dttCodttransfer", dttCodttransfer);
		
		if (dttBloque != null)
			query.setParameter("dttBloque", dttBloque);
		List lista = query.list();
		return lista;
	}

}
