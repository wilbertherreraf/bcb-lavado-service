package gob.bcb.swift.dao;

import java.io.File;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gob.bcb.bpm.pruebaCU.SocBancosDao;
import gob.bcb.bpm.pruebaCU.SocParametrosDao;
import gob.bcb.core.utils.UtilsFile;
import gob.bcb.service.servicioSioc.pojos.BancoPlaza;
import gob.bcb.swift.commons.ConstantsSwift;
import gob.bcb.swift.exception.SwiftAdminException;
import gob.bcb.swift.model.SwfDetmensaje;
import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.model.SwfMttransfer;
import gob.bcb.swift.pojos.SwiftDatos;
import gob.bcb.swift.pojos.SwiftMessageBcb;

@Repository("swfMensajeLocal")
@Transactional
public class SwfMensajeBean extends HibernateDaoSupport implements SwfMensajeLocal {
	private static Logger log = Logger.getLogger(SwfMensajeBean.class);

	private SwfDetmensajeLocal swfDetmensajeLocal;

	public SwfMensaje findByCodigo(Integer menCodmen) {
		String jpql = "SELECT t FROM SwfMensaje t WHERE t.menCodmen = :menCodmen ";

		log.info("findByCodigo " + menCodmen);
		Query query = getSession().createQuery(jpql);

		query.setParameter("menCodmen", menCodmen);
		List lista = query.list();
		if (lista.size() > 0) {
			return (SwfMensaje) lista.get(0);
		}
		return null;
	}

	public List<SwfMensaje> findByEstMen(String menCveestswift) {
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCveestswift = :menCveestswift ");

		Query query = getSession().createQuery(jpql);
		query.setParameter("menCveestswift", menCveestswift);
		List lista = query.list();
		return lista;
	}

	public List<SwfMensaje> findOperaciones(String menCodoperacion, Integer menDetcodigo, String menCveestswift) {
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCodoperacion = :menCodoperacion ");
		jpql = jpql.concat("and t.menDetcodigo = :menDetcodigo ");

		if (!StringUtils.isBlank(menCveestswift)) {
			jpql = jpql.concat("AND t.menCveestswift = :menCveestswift ");
		} else {
			// si es nulo es el estado (A,P)
			jpql = jpql.concat("AND t.menCveestswift in ('P','1','A') ");
		}

		Query query = getSession().createQuery(jpql);

		query.setParameter("menCodoperacion", menCodoperacion);
		query.setParameter("menDetcodigo", menDetcodigo);

		if (!StringUtils.isBlank(menCveestswift)) {
			query.setParameter("menCveestswift", menCveestswift);
		}

		List lista = query.list();
		return lista;
	}

	public SwfMensaje findByCodoperacion(String menCodoperacion, Integer menDetcodigo) {
		String jpql = "SELECT t FROM SwfMensaje t ";
		jpql = jpql.concat("WHERE t.menCodoperacion = :menCodoperacion ");
		jpql = jpql.concat("and t.menDetcodigo = :menDetcodigo ");
		jpql = jpql.concat("and t.menCveestswift != 'R' ");

		Query query = getSession().createQuery(jpql);

		query.setParameter("menCodoperacion", menCodoperacion);
		query.setParameter("menDetcodigo", menDetcodigo);

		List<SwfMensaje> lista = query.list();
		if (lista.size() == 1) {
			return (SwfMensaje) lista.get(0);
		}

		if (lista.size() > 1) {
			// si el estado es rechazado o eliminacion logica
			throw new SwiftAdminException("Swift: mensaje con cod solicitud " + menCodoperacion + ":" + menDetcodigo + " con mas de un registro creado");

		}
		return null;
	}

	public SwfMensaje saveorupdate(SwfMensaje swfMensaje) {
		log.info("En  saveorupdate SwfMensaje " + swfMensaje.toString());
		SwfMensaje swfMensajeOld = null;

		validarDatos(swfMensaje);

		swfMensajeOld = findByCodoperacion(swfMensaje.getMenCodoperacion(), swfMensaje.getMenDetcodigo());

		if (swfMensajeOld == null) {
			Integer perCodigo = getCodigo();

			swfMensaje.setMenAuditfho(new Date());
			swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PEND);
			swfMensaje.setMenCodmen(perCodigo);
			swfMensaje.setMenFecreg(new Date());

			this.getHibernateTemplate().merge(swfMensaje);

			SwfMensaje swfMensajeNew = findByCodigo(perCodigo);
			log.info("XXX:nuevo " + swfMensajeNew.getMenCodmen());

		} else {
			validarEstado(swfMensajeOld);
			swfMensaje.setMenAuditfho(new Date());
			this.getHibernateTemplate().merge(swfMensaje);
		}
		log.info("Actualizado " + swfMensaje.getMenCodmen());
		return swfMensaje;
	}

	public SwfMensaje actualizarSwift(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList) {
		log.info("En actualizarSwift SwfMensaje " + swfMensaje.getMenCodoperacion() + " " + swfMensaje.toString() + " " + swfDetmensajeList.size());
		SwfMensaje swfMensajeNew = saveorupdate(swfMensaje);

		log.info("XXX:En actualizarSwift SwfMensaje " + swfMensajeNew.getMenCodoperacion() + " " + swfMensajeNew.getMenCodmen());

		swfDetmensajeLocal = new SwfDetmensajeBean();
		swfDetmensajeLocal.setSessionFactory(getSessionFactory());

		swfDetmensajeLocal.actualizarDetalles(swfMensajeNew, swfDetmensajeList);

		log.info("XXX:222En actualizarSwift SwfMensaje " + swfMensajeNew.getMenCodoperacion() + " " + swfMensajeNew.getMenCodmen());
		return swfMensajeNew;
	}

	public SwiftDatos swiftDatosFromSwfMensaje(SwfMensaje swfMensajePar) {
		log.info("En swiftDatosFromSwfMensaje " + swfMensajePar.getMenCodmen());

		SwfMensaje swfMensaje = findByCodigo(swfMensajePar.getMenCodmen());
		if (swfMensaje == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensajePar.getMenCodmen() + " inexistente");
		}
		SwiftDatos swiftDatos = new SwiftDatos();
		swiftDatos.setSwfMensaje(swfMensaje);

		SocBancosDao socBancosDao = new SocBancosDao();
		socBancosDao.setSessionFactory(getSessionFactory());

		SwfMttransferLocal swfMttransferLocal = new SwfMttransferBean();
		swfMttransferLocal.setSessionFactory(getSessionFactory());

		SwfMttransfer swfMttransfer = swfMttransferLocal.findByCodigo(swfMensaje.getMenCodmt());

		swiftDatos.setSwfMttransfer(swfMttransfer);

		BancoPlaza institucionSender = socBancosDao.bancoPlazaByBic(swfMensaje.getMenBicemisor());

		if (institucionSender == null) {
			throw new SwiftAdminException("Swift: Error de parametrización institucion emisora BIC " + swfMensaje.getMenBicemisor() + " inexistente");
		}

		swiftDatos.newSwfBicsSender(institucionSender.getPlaBic(), "", institucionSender.getBcoNombre(), null, institucionSender.getPlaNombre(), null);

		BancoPlaza institucionReceiver = socBancosDao.bancoPlazaByBic(swfMensaje.getMenBic());

		if (institucionReceiver == null) {
			throw new SwiftAdminException("Swift: Error de parametrización institucion receptora BIC " + swfMensaje.getMenBic() + " inexistente");
		}

		swiftDatos.newSwfBicsReceiver(institucionReceiver.getPlaBic(), "", institucionReceiver.getBcoNombre(), null, institucionReceiver.getPlaNombre(), null);

		return swiftDatos;
	}

	public SwfMensaje preAutorizarSwift(SwfMensaje swfMensajePar, String pathSwift) {
		// valida y guarda en el directorio temporal
		log.info("En preAutorizarSwift " + swfMensajePar.getMenCodmen());

		if (StringUtils.isBlank(pathSwift)) {
			throw new SwiftAdminException("Parametro de ruta de mensajes swift nulo, avise a sistemas");
		}

		SwfMensaje swfMensaje = findByCodigo(swfMensajePar.getMenCodmen());
		if (swfMensaje == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensajePar.getMenCodmen() + " inexistente");
		}

		validarDatos(swfMensaje);

		if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PEND)) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensajePar.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}
		validarEstado(swfMensaje);

		if (swfMensaje.getMenNrocorr() == null || swfMensaje.getMenNrocorr().compareTo(0) <= 0) {
			throw new SwiftAdminException("Error al autorizar mensaje " + swfMensaje.getMenCodmen() + " sin nro swift asignado ");
		}

		if (StringUtils.isBlank(swfMensaje.getMenPlano())) {
			throw new SwiftAdminException("Error al autorizar mensaje " + swfMensaje.getMenCodmen() + " texto del mensaje swift nulo, actualice o verifique la operación");
		}

		log.info("PRE Autorizando swift Codmen:" + swfMensaje.getMenCodmen() + " Codoperacion:" + swfMensaje.getMenCodoperacion() + " Codmt:" + swfMensaje.getMenCodmt()
				+ " Nrocorr:" + swfMensaje.getMenNrocorr());
		log.info(swfMensaje.getMenPlano());

		SwiftMessageBcb swiftMessageBcbEval = new SwiftMessageBcb();
		swiftMessageBcbEval.verificarPlano(swfMensaje.getMenPlano());

		swfMensaje.setMenCveestswift(ConstantsSwift.PAR_ESTSWIFT_PREAUT);
		swfMensaje.setMenFecauto(new Date());

		swfMensaje.setMenAuditusr(swfMensajePar.getMenAuditusr());
		swfMensaje.setMenAuditwst(swfMensajePar.getMenAuditwst());

		this.getHibernateTemplate().merge(swfMensaje);

		this.getHibernateTemplate().flush();

		swfMensaje = findByCodigo(swfMensaje.getMenCodmen());
		log.info("actualizado mensaje " + swfMensaje.toString());

		String nameFile = nombreArchivo(swfMensaje);
		// creamos el directorio si no existe

		String pathFileBck = pathSwift + "Backup/" + nameFile;
		String ptmp = UtilsFile.grabaEnArchivo(swfMensaje.getMenPlano(), pathFileBck);

		log.info("Swift pre autorizado [" + swfMensaje.getMenCodmen() + "] generado!!! en " + ptmp);

		return swfMensaje;
	}

	public SwfMensaje autorizarSwift(SwfMensaje swfMensaje, String pathSwift) {
		log.info("En autorizarSwift " + swfMensaje.getMenCodmen());
		SocParametrosDao socParametrosDao = new SocParametrosDao();
		socParametrosDao.setSessionFactory(getSessionFactory());

		String nameFile = nombreArchivo(swfMensaje);
		String pathFileBck = pathSwift + "Backup/" + nameFile;

		String pathFile = pathSwift + "/" + nameFile;
		String pathFileServSwift = pathSwift + "Autorizados/" + nameFile;
		try {
			File h = new File(pathFileServSwift);
			if (h.exists() && !h.isDirectory()) {
				log.info("=====%%% ATENCION!!! %%%=======");
				log.info("SWIFT [" + swfMensaje.getMenCodmen() + "] autorizado en archivo " + pathFileServSwift);
				log.info("SE RE - INTENTO AUTORIZAR EL MENSAJE, REVISAR MENSAJES ANTERIORES, POSIBLES ERROR EN AUTORIZACION ANTERIOR");
				log.info("=====%%% ATENCION!!! %%%=======");
				// ojooo correo aca??
			} else {
				String p = UtilsFile.copiarArchivo(pathFileBck, pathFile, true);
				log.info("SWIFT AUTORIZADO!! [" + swfMensaje.getMenCodmen() + "] generado!!! en " + p);

				UtilsFile.copiarArchivo(pathFileBck, pathFileServSwift, false);
				log.info("Mensaje [" + swfMensaje.getMenCodmen() + "] de respaldo de autorizacion en " + pathFileServSwift);
			}
		} catch (Exception e) {
			log.error("Swift[" + swfMensaje.getMenCodmen() + "]: error al AUTORIZAR swift " + pathFile + ": " + e.getMessage(), e);
			throw new SwiftAdminException("Swift[" + swfMensaje.getMenCodmen() + "]: error al AUTORIZAR swift " + pathFile + ": " + e.getMessage(), e);
		}
		return swfMensaje;
	}

	public void rechazarSwift(String menCodoperacion, Integer menDetcodigo, String menAuditusr, String menAuditwst) {
		log.info("En rechazar Swift " + menCodoperacion);

		if (StringUtils.isBlank(menCodoperacion)) {
			return;
			// throw new SwiftAdminException("Parametro de codOperacion nulo");
		}

		SwfMensaje swfMensaje = findByCodoperacion(menCodoperacion, menDetcodigo);
		if (swfMensaje != null) {
			if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)) {
				throw new SwiftAdminException(
						"Swift: mensaje " + swfMensaje.getMenCodmen() + " con operacion[" + menCodoperacion + "] en estado " + swfMensaje.getMenCveestswift() + " invalido");
			}
		}

		String jsql = "UPDATE SwfMensaje t ";
		jsql = jsql.concat("set t.menCveestswift = :menCveestswift, ");
		jsql = jsql.concat("t.menAuditfho = :menAuditfho, ");
		jsql = jsql.concat("t.menAuditusr = :menAuditusr, ");
		jsql = jsql.concat("t.menAuditwst = :menAuditwst ");
		jsql = jsql.concat("WHERE t.menCodoperacion = :menCodoperacion ");
		jsql = jsql.concat("and t.menDetcodigo = :menDetcodigo ");
		jsql = jsql.concat("and t.menCveestswift in ('P','1') ");

		Query query = getSession().createQuery(jsql);
		query.setParameter("menCveestswift", ConstantsSwift.PAR_ESTSWIFT_RECH);
		query.setDate("menAuditfho", new Date());
		query.setParameter("menAuditusr", menAuditusr);
		query.setParameter("menAuditwst", menAuditwst);
		query.setParameter("menCodoperacion", menCodoperacion);
		query.setParameter("menDetcodigo", menDetcodigo);

		int result = query.executeUpdate();
		log.info("Modificados: " + result + " para " + menCodoperacion);

	}

	private String nombreArchivo(SwfMensaje swfMensaje) {
		String nameFile = "sioc" + swfMensaje.getMenCodoperacion() + "_" + String.format("%03d", swfMensaje.getMenDetcodigo()) + "_"
				+ String.format("%06d", swfMensaje.getMenNrocorr()) + swfMensaje.getMenCodusrswf() + ".dos";
		return nameFile;
	}

	private void validarDatos(SwfMensaje swfMensaje) {
		log.info("validando mensaje");
		if (swfMensaje == null) {
			throw new SwiftAdminException("Swift: mensaje  parametro nulo");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCodoperacion())) {
			throw new SwiftAdminException("Swift: mensaje con nro operacion nulo");
		}
		if (swfMensaje.getMenDetcodigo() == null) {
			throw new SwiftAdminException("Swift: mensaje con cod detalle nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenCveestswift())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " con estado nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenBic())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " Bic receptor nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenBicemisor())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " Bic emisor nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenCodmt())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " con tipo mensaje nulo");
		}
		if (swfMensaje.getMenFecvalor() == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " con fecha valor nulo");
		}
		if (swfMensaje.getMenGestion() == null) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " con gestion nulo");
		}
		if (StringUtils.isBlank(swfMensaje.getMenCodusrswf())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " con usuario nulo");
		}
		if (swfMensaje.getMenMonto() == null || swfMensaje.getMenMonto().compareTo(BigDecimal.ZERO) <= 0) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodoperacion() + ":" + swfMensaje.getMenDetcodigo() + " con monto invalido");
		}
	}

	private void validarEstado(SwfMensaje swfMensajePar) {
		log.info("validando Estado mensaje");
		if (swfMensajePar == null) {
			throw new SwiftAdminException("Swift: parametro mensaje nulo");
		}
		if (swfMensajePar.getMenCodmen() == null) {
			List<SwfMensaje> swfMensajeLista = findOperaciones(swfMensajePar.getMenCodoperacion(), swfMensajePar.getMenDetcodigo(), null);

			if (swfMensajeLista.size() > 0) {
				throw new SwiftAdminException(
						"Swift: mensaje con operación " + swfMensajePar.getMenCodoperacion() + " ya tiene registrados otros mensajes con estado valido, verifique los mismos ");
			}
			return;
		}

		List<SwfMensaje> swfMensajeLista = findOperaciones(swfMensajePar.getMenCodoperacion(), swfMensajePar.getMenDetcodigo(), null);

		if (swfMensajeLista.size() > 1) {
			// si es mayor a uno quiere decir que existe duplicacion de
			// operacion
			throw new SwiftAdminException(
					"Swift: mensaje con operación " + swfMensajePar.getMenCodoperacion() + " ya tiene registrados otros mensajes con estado valido, verifique los mismos ");
		}

		SwfMensaje swfMensaje = findByCodigo(swfMensajePar.getMenCodmen());

		if (swfMensaje == null) {
			throw new SwiftAdminException("Mensaje  " + swfMensajePar.getMenCodmen() + " inexistente");
		}

		if (StringUtils.isBlank(swfMensaje.getMenCveestswift())) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con estado nulo");
		}

		if (!swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PEND) && !swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)
				&& !swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_PREAUT)) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " con estado " + swfMensaje.getMenCveestswift() + " invalido");
		}

		if (swfMensaje.getMenCveestswift().equals(ConstantsSwift.PAR_ESTSWIFT_AUTO)) {
			throw new SwiftAdminException("Swift: mensaje  " + swfMensaje.getMenCodmen() + " autorizado");
		}

	}

	private Integer getCodigo() {
		Integer codigo = null;
		StringBuilder query = new StringBuilder();
		query.append("select max(m.menCodmen) from SwfMensaje m ");

		List result = getSession().createQuery(query.toString()).list();
		if (result.size() > 0)
			codigo = (Integer) result.get(0);

		if (codigo == null) {
			codigo = 0;
		}
		codigo++;
		log.info("Nuevo codigo : " + codigo);
		return codigo;

	}

}
