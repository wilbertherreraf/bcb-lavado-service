package gob.bcb.swift.dao;

import gob.bcb.swift.model.SwfDetmensaje;

import gob.bcb.swift.model.SwfMensaje;
import gob.bcb.swift.pojos.SwiftDatos;

import java.util.List;

import org.hibernate.SessionFactory;

public interface SwfMensajeLocal{

	SwfMensaje findByCodigo(Integer menCodmen);

	List<SwfMensaje> findByEstMen(String menCveestswift);

	SwfMensaje saveorupdate(SwfMensaje swfMensaje);

	SwfMensaje actualizarSwift(SwfMensaje swfMensaje, List<SwfDetmensaje> swfDetmensajeList);

	SwiftDatos swiftDatosFromSwfMensaje(SwfMensaje swfMensajePar);

	SwfMensaje autorizarSwift(SwfMensaje swfMensajePar, String pathSwift);

	void setSessionFactory(SessionFactory sessionFactory);

	SwfMensaje findByCodoperacion(String menCodoperacion, Integer menDetcodigo);

	void rechazarSwift(String menCodoperacion, Integer menDetcodigo, String menAuditusr, String menAuditwst);

	List<SwfMensaje> findOperaciones(String menCodoperacion, Integer menDetcodigo, String menCveestswift);

	SwfMensaje preAutorizarSwift(SwfMensaje swfMensajePar, String pathSwift);
}
