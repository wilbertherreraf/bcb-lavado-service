package gob.bcb.swift.pojos;

import java.io.Serializable;

public class PersonaCta implements Serializable {
	private String pecCodpersona;
	private String pecDescrip;
	private String pecNrocta;
	private String pecCtadescrip;
	private String pecCodmonCta;
	private String pecBic;
	private String pecBcodescrip;
	private String pecBcodirecc;
	private String pecBcopais;
	private String pecBcoplaza;

	public String getPecCodpersona() {
		return pecCodpersona;
	}

	public void setPecCodpersona(String pecCodpersona) {
		this.pecCodpersona = pecCodpersona;
	}

	public String getPecDescrip() {
		return pecDescrip;
	}

	public void setPecDescrip(String pecDescrip) {
		this.pecDescrip = pecDescrip;
	}

	public String getPecNrocta() {
		return pecNrocta;
	}

	public void setPecNrocta(String pecNrocta) {
		this.pecNrocta = pecNrocta;
	}

	public String getPecCtadescrip() {
		return pecCtadescrip;
	}

	public void setPecCtadescrip(String pecCtadescrip) {
		this.pecCtadescrip = pecCtadescrip;
	}

	public String getPecCodmonCta() {
		return pecCodmonCta;
	}

	public void setPecCodmonCta(String pecCodmonCta) {
		this.pecCodmonCta = pecCodmonCta;
	}

	public String getPecBic() {
		return pecBic;
	}

	public void setPecBic(String pecBic) {
		this.pecBic = pecBic;
	}

	public String getPecBcodescrip() {
		return pecBcodescrip;
	}

	public void setPecBcodescrip(String pecBcodescrip) {
		this.pecBcodescrip = pecBcodescrip;
	}

	public String getPecBcodirecc() {
		return pecBcodirecc;
	}

	public void setPecBcodirecc(String pecBcodirecc) {
		this.pecBcodirecc = pecBcodirecc;
	}

	public String getPecBcopais() {
		return pecBcopais;
	}

	public void setPecBcopais(String pecBcopais) {
		this.pecBcopais = pecBcopais;
	}

	public String getPecBcoplaza() {
		return pecBcoplaza;
	}

	public void setPecBcoplaza(String pecBcoplaza) {
		this.pecBcoplaza = pecBcoplaza;
	}

}
