package gob.bcb.swift.pojos;

import java.io.Serializable;

public class HeaderMsg implements Serializable {
	private String mencodmen;
	private String operator;	
	private String priority;
	private String nroreference;
	private String reference;
	private String nroinreference;
	private String inreference;
	private String mt;
	private String mtdescrip;
	private String sender;
	private String senderdescrip;
	private String receiver;
	private String receiverdescrip;
	private String mur;
	private String nrocorr;	
	private String footer;	
	private String fechora;
	private String codusuario;
	
	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getNroreference() {
		return nroreference;
	}

	public void setNroreference(String nroreference) {
		this.nroreference = nroreference;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getNroinreference() {
		return nroinreference;
	}

	public void setNroinreference(String nroinreference) {
		this.nroinreference = nroinreference;
	}

	public String getInreference() {
		return inreference;
	}

	public void setInreference(String inreference) {
		this.inreference = inreference;
	}

	public String getMt() {
		return mt;
	}

	public void setMt(String mt) {
		this.mt = mt;
	}

	public String getMtdescrip() {
		return mtdescrip;
	}

	public void setMtdescrip(String mtdescrip) {
		this.mtdescrip = mtdescrip;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getSenderdescrip() {
		return senderdescrip;
	}

	public void setSenderdescrip(String senderdescrip) {
		this.senderdescrip = senderdescrip;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getReceiverdescrip() {
		return receiverdescrip;
	}

	public void setReceiverdescrip(String receiverdescrip) {
		this.receiverdescrip = receiverdescrip;
	}

	public String getMur() {
		return mur;
	}

	public void setMur(String mur) {
		this.mur = mur;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public String getFechora() {
		return fechora;
	}

	public void setFechora(String fechora) {
		this.fechora = fechora;
	}

	public String getCodusuario() {
		return codusuario;
	}

	public void setCodusuario(String codusuario) {
		this.codusuario = codusuario;
	}

	public String getNrocorr() {
		return nrocorr;
	}

	public void setNrocorr(String nrocorr) {
		this.nrocorr = nrocorr;
	}

	public String getMencodmen() {
		return mencodmen;
	}

	public void setMencodmen(String mencodmen) {
		this.mencodmen = mencodmen;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

}