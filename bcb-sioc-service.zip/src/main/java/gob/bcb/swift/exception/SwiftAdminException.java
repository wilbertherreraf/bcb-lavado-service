package gob.bcb.swift.exception;

public class SwiftAdminException extends RuntimeException {

    /**
     * Crear una nueva instancia de <code>DataBaseException</code> sin mensaje.
     */
    public SwiftAdminException() {
    }
    /**
     * Construir una instancia de <code>DataBaseException</code> especifiacndo el mensaje.
     * @param msg el mensaje.
     */
    public SwiftAdminException(String msg) {
        super(msg);
    }
    public SwiftAdminException(String msg, Throwable t) {
		super(msg, t);
	}
    public SwiftAdminException(Throwable t) {
		super(t);
	}    
}

