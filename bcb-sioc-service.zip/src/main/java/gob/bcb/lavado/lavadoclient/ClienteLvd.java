package gob.bcb.lavado.lavadoclient;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gob.bcb.lavado.rest.dto.SearchResponse;
import gob.bcb.service.servicioSioc.common.Constants;
import gob.bcb.swift.exception.SwiftAdminException;

public class ClienteLvd {
	private final Logger log = LoggerFactory.getLogger(ClienteLvd.class);

	public final static String SCAN_SWIFT_GET_SESSION = Constants.PATH_RESOURCE_API_SEARCH + "/lvd-inicia?codapp={codapp}&coduser={coduser}";
	public final static String SCAN_SWIFT_SOLICITARCORR_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-correlativo?codapp={codapp}&idop={idop}&coduser={coduser}&idsession={idsession}";
	public final static String SCAN_SWIFT_SCANREGISTRO_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-registro?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}";
	public final static String SCAN_SWIFT_PREAUT_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH
			+ "/scan-preaut?codapp={codapp}&coduser={coduser}&codlvd={codlvd}&nroswf={nroswf}&idop={idop}&idsession={idsession}&swfp={swfp}";
	public final static String SCAN_SWIFT_END_SESSION = Constants.PATH_RESOURCE_API_SEARCH + "/lvd-fin?codapp={codapp}&coduser={coduser}&idsession={idsession}";

	public final static String SCAN_SWIFT_SINGLE_RESOURCE = Constants.PATH_RESOURCE_API_SEARCH + "/scan-single?query={query}";
	public final static String SCAN_SWIFT_BY_CODSTRATEGY = Constants.PATH_RESOURCE_API_SEARCH + "/scan-field?query={query}&field={field}";

	private String urlBase;
	private String protocol;
	private String host;
	private String nameContextSite;
	private int port;
	protected static ObjectMapper mapper = new ObjectMapper();

	private RestTemplate template;

	public ClienteLvd(String url) {
		this.urlBase = url;
		try {
			URI uri = new URI(url);
			this.protocol = uri.getScheme();
			this.host = uri.getHost();
			this.port = uri.getPort();
			this.nameContextSite = uri.getPath();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			template = new RestTemplate();
		} catch (URISyntaxException e) {
			log.error("Error al desparcear URL " + e.getMessage(), e);
		}
	}

	public ClienteLvd getInstance(String url) {
		ClienteLvd clienteLvd = new ClienteLvd(url);
		return clienteLvd;
	}

	public SearchResponse getSessionLavado(String codapp, String coduser) throws Exception {
		log.info("======@ getSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_GET_SESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public SearchResponse solicitarCorrelativo(String codapp, String codoperacion, String coduser, String idsession) throws Exception {
		log.info("======@ solicitarCorrelativo @======");
		String url = getUrlResouce(SCAN_SWIFT_SOLICITARCORR_RESOURCE);
		log.info("Consultando... " + url);
		try {
			Map<String, String> params = new HashMap<String, String>();
			params.put("codapp", codapp);
			params.put("idop", codoperacion);
			params.put("coduser", coduser);
			params.put("idsession", idsession);

			String searchResponses = template.getForEntity(url, String.class, params).getBody();
			SearchResponse searchResponse = deserialize(searchResponses);

			return searchResponse;
		} catch (NullPointerException e) {
			throw new Exception("Respuesta NULO en servicio REST " + url + " : " + e.getMessage());
		}
	}

	public SearchResponse scanSwiftRegistro(String codapp, String coduser, Integer codlvd, Integer nroswf, String idoperacion, String idsession, String menPlano)
			throws Exception {
		log.info("======@ scanSwiftRegistro @======");
		menPlano = convertToUtf8(menPlano, "ISO-8859-1");
		log.info(menPlano);
		menPlano = URLEncoder.encode(menPlano, "UTF-8");

		String url = getUrlResouce(SCAN_SWIFT_SCANREGISTRO_RESOURCE);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("codlvd", String.valueOf(codlvd));
		params.put("nroswf", String.valueOf(nroswf));
		params.put("idop", idoperacion);
		params.put("idsession", idsession);
		params.put("swfp", menPlano);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public SearchResponse preautorizarSwift(String codapp, String coduser, Integer codlvd, Integer nroswf, String idoperacion, String idsession, String menPlano)
			throws Exception {
		log.info("======@ preautorizarSwift @======");
		menPlano = convertToUtf8(menPlano, "ISO-8859-1");
		log.info(menPlano);
		menPlano = URLEncoder.encode(menPlano, "UTF-8");

		String url = getUrlResouce(SCAN_SWIFT_PREAUT_RESOURCE);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("codlvd", String.valueOf(codlvd));
		params.put("nroswf", String.valueOf(nroswf));
		params.put("idop", idoperacion);
		params.put("idsession", idsession);
		params.put("swfp", menPlano);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public SearchResponse postSessionLavado(String codapp, String coduser, String idsession) throws Exception {
		log.info("======@ postSessionLavado @====== ");

		String url = getUrlResouce(SCAN_SWIFT_END_SESSION);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("codapp", codapp);
		params.put("coduser", coduser);
		params.put("idsession", idsession);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	/**
	 * Consulta rest para un mensaje plano retornando cadena url:
	 * /api/_search/scan-single?query={query}
	 * 
	 * @param menPlano
	 *            mensaje swift en formato plano
	 * @return
	 * @throws Exception
	 */
	public SearchResponse scanMsgPlanoSingleFromString(String menPlano) throws Exception {
		log.info("======@ Scan Single Msg Plano @======");
		log.info(menPlano);
		menPlano = URLEncoder.encode(menPlano, "UTF-8");
		String url = getUrlResouce(SCAN_SWIFT_SINGLE_RESOURCE);
		log.info("Consultando... " + url);

		Map<String, String> params = new HashMap<String, String>();
		params.put("query", menPlano);
		template = new RestTemplate();
		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	/**
	 * Consulta rest para una consulta y
	 * /api/_search/scan-field?query={query}&field={field}
	 * 
	 * @param query
	 *            texto a buscar
	 * @param field
	 *            id de la estrategia
	 * @return
	 * @throws Exception
	 */
	public SearchResponse searchQueryByFieldFromString(String query, String field) throws Exception {
		log.info("======@ Scan Field @======");
		log.info("Field: " + field + " " + query);
		String url = getUrlResouce(SCAN_SWIFT_BY_CODSTRATEGY);
		log.info("Consultando... " + url);

		template = new RestTemplate();

		Map<String, String> params = new HashMap<String, String>();
		params.put("query", query);
		params.put("field", field);

		String searchResponses = template.getForEntity(url, String.class, params).getBody();
		SearchResponse searchResponse = deserialize(searchResponses);

		return searchResponse;
	}

	public static String convertToUtf8(String input, String encoding) {
		CharsetDecoder decoder = Charset.forName("UTF-8").newDecoder();
		CharsetEncoder encoder = Charset.forName(encoding).newEncoder();
		ByteBuffer tmp;
		try {
			tmp = encoder.encode(CharBuffer.wrap(input));
		} catch (CharacterCodingException e) {
			return input;
		}

		try {
			return decoder.decode(tmp).toString();
		} catch (CharacterCodingException e) {
			return input;
		}

	}

	public String getUrlResouce(String endpoint) throws MalformedURLException {
		log.debug("endpoint " + endpoint);
		String nContextSite = "";
		if (nameContextSite.startsWith("/")) {
			nContextSite = nameContextSite;
		} else {
			nContextSite = "/" + nameContextSite;
		}

		URL base = new URL(protocol, host, port, nContextSite);
		String url = fullUrl(base.toString(), endpoint);

		return url;
	}

	private String fullUrl(String baseUrl, String end) {
		String base = !baseUrl.endsWith("/") ? baseUrl + "/" : baseUrl;
		String newEnd = end.startsWith("/") ? end.substring(1) : end;
		return base + newEnd;
	}

	public static SearchResponse deserialize(String object) {
		try {
			return mapper.readValue(object, SearchResponse.class);
		} catch (IOException e) {
			throw new IllegalArgumentException("Unserializable " + object.getClass().getName() + " -> " + object.toString());
		}
	}
}
