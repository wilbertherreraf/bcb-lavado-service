package gob.bcb.lavado.rest.dto;

/**
 * Objeto de respuesta a una búsqueda en listas OFAC 
 * @author wherrera
 *
 */
public class SearchResponse {
	private String codResp;
	private String descripResp;
	private Integer countRegs = 0;
	private String qry;	
	private String codoperacion;	
	private String idresponse;	
	private Integer nrocorr;	
	private float score = 0f;
	private ItemsInfo[] itemsInfo;

	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public String getCodResp() {
		return codResp;
	}
	public void setCodResp(String codResp) {
		this.codResp = codResp;
	}
	public String getDescripResp() {
		return descripResp;
	}
	public void setDescripResp(String descripResp) {
		this.descripResp = descripResp;
	}
	
	public ItemsInfo[] getItemsInfo() {
		return itemsInfo;
	}
	public void setItemsInfo(ItemsInfo[] itemsInfo) {
		this.itemsInfo = itemsInfo;
	}

	public Integer getCountRegs() {
		return countRegs;
	}
	public void setCountRegs(Integer countRegs) {
		this.countRegs = countRegs;
	}

	public String getQry() {
		return qry;
	}
	public void setQry(String qry) {
		this.qry = qry;
	}

	public String getCodoperacion() {
		return codoperacion;
	}
	public void setCodoperacion(String codoperacion) {
		this.codoperacion = codoperacion;
	}

	public String getIdresponse() {
		return idresponse;
	}
	public void setIdresponse(String idresponse) {
		this.idresponse = idresponse;
	}

	public Integer getNrocorr() {
		return nrocorr;
	}
	public void setNrocorr(Integer nrocorr) {
		this.nrocorr = nrocorr;
	}

	public static class ItemsInfo{
		private String id;		
		private String idDoc;
		private String clazz;
		private String field;
		private String content;
		private String contentHighlight;		
		private Float score = 0f;
		public ItemsInfo() {

		}
		public String getIdDoc() {
			return idDoc;
		}
		public void setIdDoc(String idDoc) {
			this.idDoc = idDoc;
		}
		public String getClazz() {
			return clazz;
		}
		public void setClazz(String clazz) {
			this.clazz = clazz;
		}
		public String getField() {
			return field;
		}
		public void setField(String field) {
			this.field = field;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public Float getScore() {
			return score;
		}
		public void setScore(Float score) {
			this.score = score;
		}
		public String getContentHighlight() {
			return contentHighlight;
		}
		public void setContentHighlight(String contentHighlight) {
			this.contentHighlight = contentHighlight;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
	}
}
