select ncent, nocrd, count(*)
from crt025
group by 1, 2
having count(*) > 1;

select *
from mig_pre_prestamos
where pre_codmod = 40
and not exists (
        select 1
        from (
            select trim(nocrd) || '/' || substr(dgocr,3) codcred, crt025.*
            from crt025
            where ncent = '023'
            and nocrd not matches '*[A-Z]*'
        )
        where codcred = pre_codcredcirc
    )


and ciobl in ('1000006BCB','186860LP','2300209LP','2213210LP','2205787LP',
'304770LP','235714LP','376994LP','2834769SC','1745236BE',
'1675550BE','2335567LP','169489LP','2320357LP','197928LP',
'1679165TDD','306876LP','476515LP','154752LP','2394436LP',
'2239406LP','308651LP','335752LP','11695LP','1642505TJ',
'2003236LP','32044LP','3213EX','1227620LP','375414LP',
'2202927LP','1020247','293349SC','2293645LP','471898LP',
'2349016LP','498865LP','787171CB')


select *
from (
select decode(pre_codmod, 38, '022', 39, '004', 40, '023', '004') ncentcar, year(pre_fecemi) anioemi, 
pre_codcredcirc,
nvl(decode(f_getposcad(trim(pre_codcredcirc), '/'), 0, year(pre_fecemi), to_number(substr(trim(pre_codcredcirc), f_getposcad(trim(pre_codcredcirc), '/') +1)) + 1900), 0) codcred0,
decode(f_getposcad(pre_codcredcirc, '/'), 0, pre_codcredcirc, substr(pre_codcredcirc, 1, f_getposcad(pre_codcredcirc, '/') - 1)) codcred
--mig_pre_prestamos.*
from mig_pre_prestamos
)
where not exists (
        select 1
            from crt025
            where ncent = ncentcar
            and nocrd = codcred
            and dgocr = codcred0
    )

