
DROP PROCEDURE d_cartera.pi_pre_prestamos;

--/
CREATE PROCEDURE d_cartera.pi_pre_prestamos(n_pre_codcred      INTEGER      ,          n_pre_codmod       INTEGER      ,          n_pre_codprod      INTEGER      ,          
n_pre_codmon       INTEGER      ,          n_pre_tcuota       INTEGER      ,          n_pre_codcli       INTEGER      ,          n_pre_numcontra    INTEGER      ,          
n_pre_fecreg       DATE         ,          n_pre_fecemi       DATE         ,          n_pre_viadesem     INTEGER      ,          n_pre_viacob       INTEGER      ,          
n_pre_plazo        INTEGER      ,          n_pre_unidplaz     INTEGER      ,          n_pre_tabttasaex integer,n_pre_ttasaex     INTEGER      ,          n_pre_tipotasa integer,
n_pre_tasapac      FLOAT        ,          n_pre_fecven       DATE         ,          n_pre_fecvenact    DATE         ,          n_pre_fecvenori    DATE         ,          
n_pre_monto        DECIMAL(12,4),          n_pre_monliqent    DECIMAL(14,2),          n_pre_saldo        DECIMAL(14,2),          n_pre_fecdev       DATE         ,          
n_pre_montsusp     DECIMAL(14,2),          n_pre_capven       DECIMAL(14,2),          n_pre_tiprubro     INTEGER      ,          n_pre_destcred     INTEGER      ,          
n_pre_descrdcr     VARCHAR(30)  ,          n_pre_cuentat      VARCHAR(15)  ,          n_pre_ctacorr      VARCHAR(15)  ,    n_pre_tabstatus       INTEGER      ,      n_pre_status       INTEGER      ,          
n_pre_fecstatus    DATE         ,          n_pre_statant      INTEGER      ,          n_pre_fecstatant   DATE         ,          n_pre_numlinea     INTEGER      ,          
n_pre_diasfijo     INTEGER      ,          n_pre_codcclf      VARCHAR(5)   ,          n_pre_fecastigo    DATE         ,          n_pre_fecplzven    DATE         ,          
n_pre_numper       INTEGER      ,          n_pre_tabtcredauto integer, n_pre_tcredauto    INTEGER      ,          n_pre_numpergracia INTEGER      ,          n_pre_diaspercap   INTEGER      ,          
n_pre_origfondos   INTEGER      ,          n_pre_codeje       INTEGER      ,          n_pre_codusuauto   VARCHAR(15)  ,          n_pre_uniplapp     INTEGER      ,          
n_pre_fecprimpag   DATE         ,          n_pre_tasimputil   FLOAT        ,          n_pre_feculttrx    DATE         ,          n_pre_tabformcalif integer, n_pre_formcalif    INTEGER      ,          
n_pre_numconv      INTEGER      ,          n_pre_numresol     VARCHAR(15)  ,          n_pre_usrcob       INTEGER      ,          n_pre_usrsuper     INTEGER      ,          
n_pre_mondev       DECIMAL(18,4),          n_pre_cargos       DECIMAL(18,4),          n_pre_segdesgra    DECIMAL(18,4),          n_pre_monaseg      DECIMAL(18,4),          
n_pre_codmonaseg   INTEGER      ,          n_pre_cuodoble     VARCHAR(1)   ,          n_pre_credauto     VARCHAR(1)   ,          n_pre_statcast     VARCHAR(1)   ,          
n_pre_tabcatcal integer,n_pre_catcal       INTEGER      ,          n_pre_statreg      INTEGER      ,          n_pre_numrepros    INTEGER      ,
n_pre_modresol integer,n_pre_fecrepro date,n_pre_monsegtries decimal(18,2),
n_pre_tabtrxstaau integer,n_pre_trxstaau      INTEGER ,n_pre_audittrx    VARCHAR(10),
n_pre_auditusr VARCHAR(15),n_pre_auditwst VARCHAR(20)
) returning integer,date,date,integer,integer,integer,
    integer,integer,integer,date,varchar(1),
    integer,float,integer,integer,
    varchar(1),integer,integer,integer,integer,
    integer,decimal(18,2),decimal(18,2),decimal(18,2),date,
    integer,date,date,date,varchar(5),varchar(15),
    decimal(18,2),decimal(18,2),date,varchar(1),date,
    integer,integer,integer,decimal(18,2),decimal(18,2),decimal(18,2),
    date,date,varchar(15),integer,decimal(18,2),
    integer,integer

    define errno integer;
    define errmsg char(255);

    define v_tas_tbas,v_mtp_tspread,v_pta_tasa float;
    define  v_nat_fecnacim date;
    define v_cli_tipper integer;
    define v_ret integer;

    define v_pge_feccierre date;
    define v_cont integer;

    define v_lcr_codcli integer ;
    define v_lcr_fechasta  date ;
    define v_aux integer;
	define v_fechadia date;
    define v_cuotacap integer;
    define v_cuotaint integer;
    define v_per_cap integer;
    define v_cuotagrac integer;

    define v_ttm_porc like pre_tastipmon.ttm_porc;
    define v_ttm_tasa like pre_tastipmon.ttm_tasa;

    DEFINE	l_flag,l_edad,g_anios integer;
    DEFINE	v_crg_basaplic,v_crg_codmon,v_crg_codprod,v_crg_tcargo,v_crg_codcarg,v_crg_factaplic integer;
    DEFINE	v_crg_valor like gen_cargos.crg_valor;
    DEFINE	g_vasg  decimal(18,2);
    DEFINE	l_msdg,l_vasg,l_mgas,g_mgas  decimal(18,2);
    DEFINE	g_msdg  decimal(18,2);
    DEFINE	v_crg_codtrx like gen_cargos.crg_codtrx;
    DEFINE	v_pre_codmon,v_pre_codmonaseg integer;
    DEFINE	v_ctr_marcfin like pre_cargospre.ctr_marcfin;

	let v_fechadia = f_getfechadia();

    if v_fechadia is null then
        let errno  = -1003;
        let errmsg = "NO EXISTE UNA FECHA ABIERTA";
        raise exception -746, 0, errmsg;    
    end if;

        if n_pre_codmod = 4 then
    return n_pre_codcred,n_pre_fecvenact,n_pre_fecvenori,n_pre_tabttasaex,n_pre_ttasaex,n_pre_viacob,
    n_pre_tabstatus,n_pre_status,n_pre_numrepros,n_pre_fecrepro,n_pre_credauto,
    n_pre_numpergracia,n_pre_tasimputil,n_pre_diaspercap,n_pre_numper,
    n_pre_cuodoble,n_pre_viadesem,n_pre_tabcatcal,n_pre_tabtcredauto,n_pre_tabformcalif,
    n_pre_tcuota,n_pre_saldo,n_pre_capven,n_pre_monliqent,n_pre_fecven,
    n_pre_statant,n_pre_fecstatus,n_pre_fecstatant,n_pre_feculttrx,n_pre_codcclf,n_pre_ctacorr,
    n_pre_mondev,n_pre_montsusp,n_pre_fecdev,n_pre_statcast,n_pre_fecplzven,
    n_pre_tcredauto,n_pre_catcal,n_pre_formcalif,n_pre_cargos,n_pre_segdesgra,n_pre_monto,
    n_pre_fecprimpag,n_pre_fecemi,n_pre_cuentat,n_pre_codmonaseg,n_pre_monsegtries,
    n_pre_tabtrxstaau,n_pre_trxstaau;
        end if

         if n_pre_plazo < 0 then
            let errno  = -1003;
            let errmsg = "Plazo invÃ¡lido";
            raise exception -746, 0, errmsg;
        end if;

        if n_pre_unidplaz is null then
            let errno  = -1003;
            let errmsg = "ingrese unidad de plazo";
            raise exception -746, 0, errmsg;        
        end if

        if n_pre_unidplaz = 1 then
            let n_pre_plazo = n_pre_plazo * 360;
        elif n_pre_unidplaz = 2 then
            let n_pre_plazo = n_pre_plazo * 30;
        end if

        IF n_pre_fecvenact IS NULL THEN
            LET n_pre_fecvenact = n_pre_fecreg + n_pre_plazo;
            LET n_pre_fecvenori = n_pre_fecvenact;
        END IF

                    if n_pre_numlinea is not null  then
                SELECT lcr_codcli, lcr_fechasta
                INTO v_lcr_codcli, v_lcr_fechasta                       FROM cli_lineacred
                WHERE lcr_numlinea = n_pre_numlinea
                AND   lcr_statlincr = 1;

                if dbinfo ("sqlca.sqlerrd2") = 0 then
                  let errno  = -1005;
                  let errmsg = "No existe la linea de credito";
                  raise exception -746, 0, errmsg;                
                end if

                IF v_lcr_fechasta < n_pre_fecvenact THEN				                           let errno  = -1005;
                    let errmsg = "Fecha plazo linea " || n_pre_numlinea ||" menor a la de la operacion";
                    raise exception -746, 0, errmsg;
                END IF;             end if

        if n_pre_monliqent <0 then
            let errno  = -1003;
            let errmsg = "Monto Liq. entregado debe ser igual o mayor a cero";
            raise exception -746, 0, errmsg;        
        end if

        IF n_pre_fecreg > v_fechadia THEN
              let errno  = -1005;
              let errmsg = "FECHA MAYOR A FECHA DE PROCESO";
              raise exception -746, 0, errmsg;
        END IF;



        if n_pre_uniplapp is null  then
          let errno  = -1005;
          let errmsg = "Plazo fijo - no existe unidad de plan de pagos";
          raise exception -746, 0, errmsg;                
        end if

        let n_pre_cuodoble = upper(nvl(n_pre_cuodoble,"N"));
        let n_pre_viadesem = 1;
        let n_pre_tabformcalif = 181;
        let n_pre_formcalif = 4;
        let n_pre_tabcatcal = 180;
        let n_pre_catcal = 1;
        let n_pre_tabtcredauto = 180;
        let n_pre_tcredauto = 1;
        let n_pre_tabtrxstaau = 30;
        let n_pre_trxstaau = 1;
        let n_pre_tabstatus = 1704;
        let n_pre_fecstatus = n_pre_fecreg;
        let n_pre_saldo = 0;
        let n_pre_capven = 0;
        let n_pre_fecven = null;
        let n_pre_feculttrx = null;
        --let n_pre_codcclf = 1;
        let n_pre_ctacorr = null;
        let n_pre_mondev = 0;
        let n_pre_fecdev = null;
        let n_pre_montsusp = 0;
        let n_pre_statcast = "N";
        let n_pre_fecplzven = null;
        let n_pre_cargos = 0;
        let n_pre_segdesgra = 0;
        let n_pre_fecprimpag = null;
        let n_pre_fecemi = null;
        let n_pre_monsegtries = 0;

        --let n_pre_codcred = f_getnroprestamo(n_pre_codmod);

        if n_pre_codcred is null or n_pre_codcred = 0 then
              let errno  = -1005;
              let errmsg = "No se pudo generar nro de prest.";
              raise exception -746, 0, errmsg;    
        end if

        if n_pre_codmod in (17) or f_exists_mod(n_pre_codmod) then
            let n_pre_monliqent = 0;
            let n_pre_status = 1;

             if n_pre_monto < 0 then
                let errno  = -1003;
                let errmsg = "El monto del prestamo debe ser mayor  a cero";
                raise exception -746, 0, errmsg;
            end if;

                if n_pre_tipotasa is null then
                    let errno  = -1003;
                    let errmsg = "ingrese tipo de tasa";
                    raise exception -746, 0, errmsg;
                end if

                if n_pre_tipotasa != 1 then
                    if n_pre_ttasaex is null then
                        let errno  = -1003;
                        let errmsg = "Ingrese tipo de tasa externa";
                        raise exception -746, 0, errmsg;
                    end if
                end if            

                if nvl(n_pre_tasapac,0) !=0 then
                    let errno  = -1003;
                    let errmsg = "Mod. " || n_pre_codmod || " NO PERMITE Tasa de interes pactada" ;
                    --raise exception -746, 0, errmsg;
                end if

                if nvl(n_pre_monaseg,0) !=0 then
                    let errno  = -1003;
                    let errmsg = "Mod. " || n_pre_codmod || " NO PERMITE Monto/valor Asegurado" ;
                    raise exception -746, 0, errmsg;
                end if
                let n_pre_codmonaseg = null;

                if n_pre_numresol is not null or n_pre_modresol is not null then

                    let n_pre_modresol = nvl(n_pre_modresol,0);
                    let n_pre_numresol = nvl(n_pre_numresol,0);

                    select count(*)
                    into v_cont
                    from pla_otrasopr
                    where cte_numoper = n_pre_numresol
                    and cte_codmod = n_pre_modresol;

                    select count(*) + v_cont
                    into v_cont 
                    from pre_prestamos
                    where pre_codcred = n_pre_numresol
                    and pre_codmod = n_pre_modresol;

                    if v_cont = 0 then
                      let errno  = -1005;
                      let errmsg = "Numero de prest. "|| n_pre_numresol || " mod." || n_pre_modresol || " inexistente";
                      raise exception -746, 0, errmsg;
                    else
                        SELECT pre_codcli
                        INTO v_cont
                        FROM pre_prestamos
                        WHERE pre_codcred = n_pre_numresol
                        and pre_codmod = n_pre_modresol
                        AND pre_status BETWEEN 2 AND 7
                        AND pre_statreg = 0;

                        if n_pre_codcli != v_cont then
                          let errno  = -1005;
                          let errmsg = "Cliente prest." || n_pre_codcli || " difiere con cliente resol. " || v_cont;
                          raise exception -746, 0, errmsg;
                        end if
                    end if

                        SELECT nvl(pre_numrepros,0),pre_fecrepro 
                        INTO n_pre_numrepros,n_pre_fecrepro
                        FROM pre_prestamos
                        WHERE pre_codcred = n_pre_numresol
                        AND   pre_codmod = n_pre_modresol
                        AND   pre_codcli = n_pre_codcli
                        AND   pre_statreg  = 0;

                        LET n_pre_fecrepro = v_fechadia;
                        LET n_pre_numrepros = n_pre_numrepros + 1;
                end if

                        if n_pre_tcuota = 1 then
                            if n_pre_numper is null or n_pre_numper = 0 then
                              let errno  = -1005;
                              let errmsg = "Plazo fijo, ingrese periodo interes";
                              raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_uniplapp = 1 then 
                                let n_pre_numper = n_pre_numper * 360;
                            elif n_pre_uniplapp = 2 then 
                                let n_pre_numper = n_pre_numper * 30;
                            end if

                            let v_aux = n_pre_plazo / n_pre_numper;

                            if n_pre_plazo / n_pre_numper != v_aux then
                              let errno  = -1005;
                              let errmsg = "Plazo fijo - Periodo pago interes no es multiplo de plazo";
                              raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_diasfijo is not null then
                                    if n_pre_numper < 30 then
                                          let errno  = -1005;
                                          let errmsg = "No puede elegir dia de Periodo pago interes";
                                          raise exception -746, 0, errmsg;                
                                    end if
                                    if n_pre_diasfijo < 1 or n_pre_diasfijo > 31 then
                                          let errno  = -1005;
                                          let errmsg = "Dia Periodo pago interes no permitido";
                                          raise exception -746, 0, errmsg;                
                                    end if
                            end if

                            let n_pre_numpergracia = 0;
                            let n_pre_tasimputil = 0;
                            let n_pre_diaspercap = n_pre_plazo;
                        elif n_pre_tcuota = 2 then
                                        if n_pre_diaspercap is null or n_pre_diaspercap < 0 then
                                  let errno  = -1005;
                                  let errmsg = "Amortizable - Periodo no permitido";
                                  raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_uniplapp = 1 then 
                                let n_pre_diaspercap = n_pre_diaspercap * 360;
                            elif n_pre_uniplapp = 2 then 
                                let n_pre_diaspercap = n_pre_diaspercap * 30;
                            end if

                            let v_aux = n_pre_plazo / n_pre_diaspercap;

                            if n_pre_plazo / n_pre_diaspercap != v_aux then
                                  let errno  = -1005;
                                  let errmsg = "Amortizable - Periodo de Capital no es multiplo de plazo";
                                  raise exception -746, 0, errmsg;                
                            end if

                            let v_cuotacap = v_aux;

                                                        if n_pre_numper is null or n_pre_numper = 0 then
                              let errno  = -1005;
                              let errmsg = "Amortizable, ingrese periodo interes";
                              raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_uniplapp = 1 then 
                                let n_pre_numper = n_pre_numper * 360;
                            elif n_pre_uniplapp = 2 then 
                                let n_pre_numper = n_pre_numper * 30;
                            end if
                                                        let v_aux = n_pre_plazo / n_pre_numper;

                            if n_pre_plazo / n_pre_numper != v_aux then
                              let errno  = -1005;
                              let errmsg = "Amortizable - Periodo pago interes no es multiplo de plazo";
                              raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_diasfijo is not null then
                                    if n_pre_numper < 30 then
                                          let errno  = -1005;
                                          let errmsg = "No puede elegir dia de Periodo pago interes";
                                          raise exception -746, 0, errmsg;                
                                    end if
                                    if n_pre_diasfijo < 1 or n_pre_diasfijo > 31 then
                                          let errno  = -1005;
                                          let errmsg = "Dia Periodo pago interes no permitido";
                                          raise exception -746, 0, errmsg;                
                                    end if
                            end if

                            let v_cuotaint = v_aux;

                            let v_aux = n_pre_diaspercap / n_pre_numper;

                            IF  (n_pre_diaspercap / n_pre_numper) != v_aux THEN
                                  let errno  = -1005;
                                  let errmsg = "Amortizable - Periodo de capital no es multiplo de periodo interes";
                                  raise exception -746, 0, errmsg;                
                            end if

                            let v_per_cap = v_aux;

                            if n_pre_numpergracia is null  then
                                  let errno  = -1005;
                                  let errmsg = "Amortizable - Gracia no permitida";
                                  raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_uniplapp = 1 then 
                                let n_pre_numpergracia = n_pre_numpergracia * 360;
                            elif n_pre_uniplapp = 2 then 
                                let n_pre_numpergracia = n_pre_numpergracia * 30;
                            end if

                            if n_pre_numpergracia > 0 then
                                    let v_aux = n_pre_numpergracia / n_pre_numper;

                                    if n_pre_numpergracia / n_pre_numper != v_aux then
                                          let errno  = -1005;
                                          let errmsg = "Amortizable - Periodo de Gracia no es multiplo de periodo de interes";
                                          raise exception -746, 0, errmsg;                
                                    end if

                                    let v_cuotagrac = v_aux;

                                    let v_aux = (v_cuotaint - v_cuotagrac) / v_per_cap;

                                    IF (v_cuotaint - v_cuotagrac) / v_per_cap != v_aux THEN
                                          let errno  = -1005;
                                          let errmsg = "Amortizable - Cuotas de capital no es multiplo periodos de gracia";
                                          raise exception -746, 0, errmsg;                
                                    end if 			
                            end if

                            let n_pre_tasimputil = nvl(n_pre_tasimputil,0);

                            if n_pre_tasimputil < 0 then
                                          let errno  = -1005;
                                          let errmsg = "Amortizable - IMPORTE NO PERMITIDO";
                                          raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_diasfijo is not null then
                                    if n_pre_numper < 30 then
                                          let errno  = -1005;
                                          let errmsg = "No puede elegir dia de Periodo pago interes";
                                          raise exception -746, 0, errmsg;                
                                    end if
                                    if n_pre_diasfijo < 1 or n_pre_diasfijo > 31 then
                                          let errno  = -1005;
                                          let errmsg = "Dia Periodo pago interes no permitido";
                                          raise exception -746, 0, errmsg;                
                                    end if
                            end if
                        elif n_pre_tcuota = 3 then
                            if n_pre_diaspercap is null or n_pre_diaspercap < 0 then
                                  let errno  = -1005;
                                  let errmsg = "Cuota fija - Periodo no permitido";
                                  raise exception -746, 0, errmsg;                
                            end if

                            if n_pre_uniplapp = 1 then 
                                --anios
                                let n_pre_diaspercap = n_pre_diaspercap * 360;
                            elif n_pre_uniplapp = 2 then 
                                -- meses
                                let n_pre_diaspercap = n_pre_diaspercap * 30;
                            end if

                            let v_aux = n_pre_plazo / n_pre_diaspercap;

                            if n_pre_plazo / n_pre_diaspercap != v_aux then
                                  let errno  = -1005;
                                  let errmsg = "Cuota fija - Periodo de Capital no es multiplo de plazo";
                                  raise exception -746, 0, errmsg;                
                            end if

                            let v_cuotacap = v_aux;

                                                        let n_pre_numper = n_pre_diaspercap;

                            
                            if n_pre_uniplapp = 1 then 
                                let n_pre_numpergracia = n_pre_numpergracia * 360;
                            elif n_pre_uniplapp = 2 then 
                                let n_pre_numpergracia = n_pre_numpergracia * 30;
                            end if

                            if n_pre_numpergracia > 0 then
                                    let v_aux = n_pre_numpergracia / n_pre_diaspercap;

                                    if n_pre_numpergracia / n_pre_diaspercap != v_aux then
                                          let errno  = -1005;
                                          let errmsg = "Cuota fija - Periodo de Gracia no es multiplo de periodo de pago";
                                          raise exception -746, 0, errmsg;                
                                    end if

                                    let v_cuotagrac = v_aux;
                            end if

                            let n_pre_tasimputil = nvl(n_pre_tasimputil,0);

                            if n_pre_tasimputil < 0 then
                                          let errno  = -1005;
                                          let errmsg = "Cuota fija - IMPORTE NO PERMITIDO";
                                          raise exception -746, 0, errmsg;                
                            end if		

                            if n_pre_numper <= 0 then
                                  let errno  = -1005;
                                  let errmsg = "Cuota fija - Periodo pago interess no permitido";
                                  raise exception -746, 0, errmsg;                
                            end if		

                            if n_pre_diasfijo is not null then
                                    if n_pre_numper < 30 then
                                          let errno  = -1005;
                                          let errmsg = "No puede elegir dia de Periodo pago interes";
                                          raise exception -746, 0, errmsg;                
                                    end if
                                    if n_pre_diasfijo < 1 or n_pre_diasfijo > 31 then
                                          let errno  = -1005;
                                          let errmsg = "Dia Periodo pago interes no permitido";
                                          raise exception -746, 0, errmsg;                
                                    end if
                            end if

                            end if

                let n_pre_viacob = nvl(n_pre_viacob,1);

                let n_pre_credauto = upper(nvl(n_pre_credauto, "N"));
                                if n_pre_credauto = "S" then
                    if n_pre_viacob is null then
                          let errno  = -1005;
                          let errmsg = "NO PUEDE HACER DEBITO SIN CUENTA";
                          raise exception -746, 0, errmsg;
                    else
                        if n_pre_viacob !=2 and n_pre_viacob !=3  then
                          let errno  = -1005;
                          let errmsg = "VIA PARA DEBITO NO PERMITIDA";
                          raise exception -746, 0, errmsg;                
                        end if
                    end if
                end if

                let v_tas_tbas = 0;
                let v_mtp_tspread = 0;
                let v_pta_tasa = 0;

                SELECT tas_tbas
                INTO v_tas_tbas
                FROM gen_parmtasa
                WHERE tas_codmod = n_pre_codmod
                        AND tas_codmon = n_pre_codmon
                         and tas_codprod = n_pre_codprod;


                    if v_tas_tbas is null or v_tas_tbas < 0 then
                          let errno  = -1005;
                          let errmsg = "Tasa base nula ni o menor a 0";
                          raise exception -746, 0, errmsg;
                    end if

                if n_pre_tipotasa = 1 then
                    let n_pre_ttasaex = null;
                    let n_pre_tabttasaex = null;

                elif  n_pre_tipotasa = 2 then
                    SELECT pta_tasa
                    into v_pta_tasa
                    FROM pre_parmtasas
                    WHERE pta_codmon = n_pre_codmon
                    and pta_fecvig = nvl(( SELECT MAX(pta_fecvig)
                                                            FROM pre_parmtasas
                                                             WHERE   pta_fecvig <= n_pre_fecreg
                                                            and pta_codmon = n_pre_codmon),
                                                            ( SELECT MIN(pta_fecvig)
                                                            FROM pre_parmtasas
                                                             WHERE   pta_fecvig > n_pre_fecreg
                                                            and pta_codmon = n_pre_codmon));

                        let v_mtp_tspread = nvl(v_tas_tbas,0) - nvl(v_pta_tasa,0);
                end if;

                IF n_pre_tipotasa = 1  AND v_mtp_tspread > 0 THEN
                    let errno  = -1005;
                    let errmsg = "Tasa spread invalida, spread debe ser 0 para tip tasa " || n_pre_tipotasa;
                    raise exception -746, 0, errmsg;
                END IF

                if n_pre_tipotasa = 1 then
                    insert into pre_tasaspre(mtp_codmod,mtp_codcred,mtp_fechavig,mtp_tbase,mtp_tspread,
                    mtp_auditusr,mtp_auditfho,mtp_auditwst,mtp_audittrx,mtp_trxstaau)
                    values(n_pre_codmod, n_pre_codcred,n_pre_fecreg,v_tas_tbas,v_mtp_tspread,
                    n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);
                elif n_pre_tipotasa = 2 then
                    insert into pre_tasaspre(mtp_codmod,mtp_codcred,mtp_fechavig,mtp_tbase,mtp_tspread,
                    mtp_auditusr,mtp_auditfho,mtp_auditwst,mtp_audittrx,mtp_trxstaau)
                    values(n_pre_codmod, n_pre_codcred,n_pre_fecreg,v_tas_tbas,v_mtp_tspread,
                    n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);
                end if;
                
        elif n_pre_codmod = 18 then
            let n_pre_monto = 0;
            let n_pre_numpergracia = 0;
            let n_pre_cuentat = null;
            let n_pre_credauto = "N";
            let n_pre_status = 0;

                if nvl(n_pre_tipotasa,0) !=0 then
                    let errno  = -1003;
                    let errmsg = "Mod. " || n_pre_codmod || " NO PERMITE Tipos de Tasa " ;
                    raise exception -746, 0, errmsg;
                end if

                if n_pre_tasapac <= 0  then
                    let errno  = -1003;
                    let errmsg = "Tasa pactada invalida";
                    raise exception -746, 0, errmsg;
                end if

                let n_pre_tcuota = nvl(n_pre_tcuota,3);

                IF n_pre_tcuota != 3 then
                    let errno  = -1003;
                    let errmsg = "Tipo de cuota invalida, ingrese cuota fija";
                    raise exception -746, 0, errmsg;
                end if

                SELECT ttm_porc,ttm_tasa
                INTO v_ttm_porc,v_ttm_tasa
  		FROM  pre_tastipmon
	  	WHERE  ttm_codmod = n_pre_codmod
                and ttm_codprod = n_pre_codprod
	    	AND  ttm_codmon = n_pre_codmon
	    	AND  ttm_plazo1 <= n_pre_plazo 
	    	AND  ttm_plazo2 >= n_pre_plazo;

                IF n_pre_tasapac < (v_ttm_tasa - v_ttm_porc) OR n_pre_tasapac > (v_ttm_tasa + v_ttm_porc)THEN
                    let errno  = -1003;
                    let errmsg = "Tasa de intereses no permitida";
                    raise exception -746, 0, errmsg;
                END IF

                let n_pre_monaseg = nvl(n_pre_monaseg,0) ;
                if nvl(n_pre_monaseg,0) < 0 then
                    let errno  = -1003;
                    let errmsg = "Monto asegurado invalido" ;
                    raise exception -746, 0, errmsg;
                end if

                IF n_pre_monaseg = 0 THEN
                    LET n_pre_codmonaseg = n_pre_codmon;
		END IF

                if n_pre_codmonaseg is null  AND n_pre_monaseg > 0 then
                    let errno  = -1003;
                    let errmsg = "Ingrese moneda de valor asegurado" ;
                    raise exception -746, 0, errmsg;
                end if

                    if n_pre_diaspercap is null or n_pre_diaspercap < 0 then
                          let errno  = -1005;
                          let errmsg = "Amortizable - Periodo no permitido";
                          raise exception -746, 0, errmsg;                
                    end if

                    if n_pre_uniplapp = 1 then 
                        let n_pre_diaspercap = n_pre_diaspercap * 360;
                    elif n_pre_uniplapp = 2 then 
                        let n_pre_diaspercap = n_pre_diaspercap * 30;
                    end if

                    let v_aux = n_pre_plazo / n_pre_diaspercap;

                    if n_pre_plazo / n_pre_diaspercap != v_aux then
                          let errno  = -1005;
                          let errmsg = "PERIODO DE PAGO NO ES MULTIPLO DEL PLAZO";
                          raise exception -746, 0, errmsg;                
                    end if
                    
                    if n_pre_diasfijo is not null then
                            if n_pre_diasfijo < 1 or n_pre_diasfijo > 31 then
                                  let errno  = -1005;
                                  let errmsg = "Dia Periodo no permitido";
                                  raise exception -746, 0, errmsg;                
                            end if
                    end if
                    
                    let n_pre_viacob = 1;
                else
                    let errno  = -1003;
                    let errmsg = "Modulo invalido";
                    raise exception -746, 0, errmsg;
        end if
                insert into cli_clicta(clc_codmod,clc_codcred,clc_codcli,clc_tiporel,
        clc_auditusr,clc_auditfho,clc_auditwst,clc_audittrx,clc_trxstaau)
        values (n_pre_codmod,n_pre_codcred,n_pre_codcli, 1,
        n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);

        select nat_fecnacim,cli_tipper
        into v_nat_fecnacim,v_cli_tipper
        from cli_persona,cli_natural
        where cli_codigo = nat_codcli
        and cli_codigo = n_pre_codcli;

	LET g_anios = nvl((((v_fechadia + n_pre_plazo ) - v_nat_fecnacim)/360),0);
	LET l_edad = 65;

	FOREACH 
                SELECT crg_tcargo,crg_codcarg,crg_valor,crg_factaplic,crg_codtrx
                into v_crg_tcargo,v_crg_codcarg,v_crg_valor,v_crg_factaplic,v_crg_codtrx
                FROM gen_cargos
                WHERE crg_tcargo in (1,5)
                AND crg_codprod = n_pre_codprod
                AND crg_codmon = n_pre_codmon
                and crg_codmod = n_pre_codmod

				IF v_crg_factaplic  = 7 THEN 		                                            let v_crg_valor = 0;
		END IF;
		IF v_crg_factaplic  = 9 THEN 		                                            let v_crg_valor = 0;
		END IF;
		    if v_crg_tcargo = 5 and (n_pre_codmod = 17 or f_exists_mod(n_pre_codmod)) then
                    if v_cli_tipper = 1 AND (g_anios <= l_edad)  then
                        INSERT 	INTO pre_cargospre(ctr_codmod,ctr_codcred,ctr_codcarg,ctr_codtrx,ctr_valor,ctr_statreg,
                            ctr_auditusr,ctr_auditfho,ctr_auditwst,ctr_audittrx,ctr_trxstaau)
                            VALUES (n_pre_codmod,n_pre_codcred,v_crg_codcarg,v_crg_codtrx,v_crg_valor,0,
                            n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);
                    end if;
                                elif v_crg_tcargo = 1 then
                    INSERT 	INTO pre_cargospre(ctr_codmod,ctr_codcred,ctr_codcarg,ctr_codtrx,ctr_valor,ctr_statreg,
                        ctr_auditusr,ctr_auditfho,ctr_auditwst,ctr_audittrx,ctr_trxstaau)
			VALUES (n_pre_codmod,n_pre_codcred,v_crg_codcarg,v_crg_codtrx,v_crg_valor,0,
                        n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);
                end if;
	END FOREACH;

        if n_pre_codmod = 18 then
                        LET g_vasg = 0;
                LET g_mgas = 0;
                LET g_msdg = 0;
                LET l_flag = 0;

                IF n_pre_codmon = 3 THEN
                        LET v_pre_codmon = 2;
                END IF
                IF n_pre_codmonaseg = 3 THEN
                        LET v_pre_codmonaseg = 2;
                END IF

                LET v_cont = 0;

                SELECT COUNT(*) 
                INTO v_cont 
                FROM gen_cargos
                WHERE crg_codprod = n_pre_codprod
                AND   crg_tcargo = 3
                AND   crg_codmon = n_pre_codmon
                and crg_codtrx = 1;

                FOREACH 
                    SELECT crg_codcarg,crg_valor,crg_factaplic,crg_tcargo,ctr_marcfin,crg_codprod
                    INTO v_crg_codcarg,v_crg_valor,v_crg_factaplic,v_crg_tcargo,v_ctr_marcfin,v_crg_codprod
                    FROM gen_cargos
                            WHERE crg_codprod = n_pre_codprod
                              AND crg_codmon = n_pre_codmon
                              and crg_codmod = n_pre_codmod
                              and crg_codtrx = 1                             ORDER BY crg_tcargo

                        IF v_crg_tcargo = 1 THEN
                                IF v_crg_factaplic = 1 THEN
                                        LET l_mgas = v_crg_valor;
                                ELSE
                                        LET l_mgas = f_redondeo(((v_crg_valor * n_pre_monliqent) / 100),2);
                                END IF

                                IF v_pre_codmon = 1 AND v_crg_codmon = 2 THEN
                                        LET l_mgas = f_redondeo(f_conversion(v_fechadia,l_mgas,v_crg_codmon,v_pre_codmon, 3),2);                                 elif v_pre_codmon = 2 AND v_crg_codmon = 1 THEN
                                        LET l_mgas = f_redondeo(f_conversion(v_fechadia,l_mgas,v_crg_codmon,v_pre_codmon, 2),2);                                 END IF

                                INSERT 	INTO pre_cargospre(ctr_codmod,ctr_codcred,ctr_codcarg,ctr_codtrx,ctr_valor,ctr_statreg,ctr_monfin,ctr_marcfin,
                                    ctr_auditusr,ctr_auditfho,ctr_auditwst,ctr_audittrx,ctr_trxstaau)
                                    VALUES (n_pre_codmod,n_pre_codcred,v_crg_codcarg,v_crg_codtrx,v_crg_valor,0,l_mgas,v_ctr_marcfin,
                                    n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);

                                IF upper(v_ctr_marcfin) = "S" THEN
                                        LET g_mgas = g_mgas + l_mgas;
                                END IF

                        elif v_crg_tcargo = 2 THEN
                                LET l_vasg = n_pre_monaseg;

                                LET l_vasg = f_redondeo(f_conversion(v_fechadia,n_pre_monaseg,v_pre_codmonaseg,v_pre_codmon, 1),2); 
                                IF v_crg_factaplic = 1 THEN
                                        LET l_vasg = v_crg_valor;
                                ELSE
                                        LET l_vasg = (v_crg_valor * l_vasg)/100;
                                        LET l_vasg = f_redondeo(l_vasg,2);
                                END IF

                                IF v_pre_codmon = 1 AND v_crg_codmon = 2 THEN
                                        LET l_vasg = f_redondeo(f_conversion(v_fechadia,l_vasg,v_crg_codmon,v_pre_codmon, 3),2);                                 END IF

                                IF v_pre_codmon = 2 AND v_crg_codmon = 1 THEN
                                        LET l_vasg = f_redondeo(f_conversion(v_fechadia,l_vasg,v_crg_codmon,v_pre_codmon, 2),2);                                 END IF

                                IF l_vasg <> 0 THEN
                                    INSERT 	INTO pre_cargospre(ctr_codmod,ctr_codcred,ctr_codcarg,ctr_codtrx,ctr_valor,ctr_statreg,ctr_monfin,ctr_marcfin,
                                    ctr_auditusr,ctr_auditfho,ctr_auditwst,ctr_audittrx,ctr_trxstaau)
                                    VALUES (n_pre_codmod,n_pre_codcred,v_crg_codcarg,v_crg_codtrx,v_crg_valor,0,l_vasg,v_ctr_marcfin,
                                    n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);
                                END IF

                                LET g_vasg = g_vasg + l_vasg;
                        END IF

                        IF v_crg_tcargo = 3 AND l_flag = 0 THEN
                           IF v_crg_factaplic = 1 THEN
                                LET l_msdg = v_crg_valor;
                           ELSE	
                                if v_crg_basaplic = 1 then
                                        LET l_msdg = n_pre_monliqent;
                                elif v_crg_basaplic = 2 then
                                        LET l_msdg = n_pre_monaseg;
                                elif v_crg_basaplic = 3 then
                                        LET l_msdg = n_pre_monliqent + g_mgas + g_vasg;
                                elif v_crg_basaplic = 4 then
                                        LET l_msdg = n_pre_monliqent + g_mgas + g_vasg;
                                END if

                                LET l_msdg = (v_crg_valor * l_msdg)/100;
                                LET l_msdg = f_redondeo(l_msdg,2);
                           END IF

                           IF v_pre_codmon = 1 AND v_crg_codmon = 2 THEN
                                LET l_msdg = f_redondeo(f_conversion(v_fechadia,l_msdg,v_crg_codmon,v_pre_codmon, 3),2);                            END IF
                           IF v_pre_codmon = 2 AND v_crg_codmon = 1 THEN
                                LET l_msdg = f_redondeo(f_conversion(v_fechadia,l_msdg,v_crg_codmon,v_pre_codmon, 2),2);                            END IF

                           IF v_cont > 0 THEN 
                                  CONTINUE FOREACH;
                           END IF

                            INSERT 	INTO pre_cargospre(ctr_codmod,ctr_codcred,ctr_codcarg,ctr_codtrx,ctr_valor,ctr_statreg,ctr_monfin,ctr_marcfin,
                            ctr_auditusr,ctr_auditfho,ctr_auditwst,ctr_audittrx,ctr_trxstaau)
                            VALUES (n_pre_codmod,n_pre_codcred,v_crg_codcarg,v_crg_codtrx,v_crg_valor,0,l_msdg,v_ctr_marcfin,
                            n_pre_auditusr,current,n_pre_auditwst,n_pre_audittrx,5);

                           LET l_flag = 1;
                           LET g_msdg = g_msdg + l_msdg;
                        END IF
                END FOREACH
            let n_pre_segdesgra = g_msdg;
            let n_pre_cargos = g_mgas;
            let n_pre_monsegtries = g_vasg;
        end if
        
        let n_pre_fecvenact = null;
        let n_pre_fecvenori = null;
        let n_pre_statant = n_pre_status;
        let n_pre_fecstatant = n_pre_fecstatus;

    return n_pre_codcred,n_pre_fecvenact,n_pre_fecvenori,n_pre_tabttasaex,n_pre_ttasaex,n_pre_viacob,
    n_pre_tabstatus,n_pre_status,n_pre_numrepros,n_pre_fecrepro,n_pre_credauto,
    n_pre_numpergracia,n_pre_tasimputil,n_pre_diaspercap,n_pre_numper,
    n_pre_cuodoble,n_pre_viadesem,n_pre_tabcatcal,n_pre_tabtcredauto,n_pre_tabformcalif,
    n_pre_tcuota,n_pre_saldo,n_pre_capven,n_pre_monliqent,n_pre_fecven,
    n_pre_statant,n_pre_fecstatus,n_pre_fecstatant,n_pre_feculttrx,n_pre_codcclf,n_pre_ctacorr,
    n_pre_mondev,n_pre_montsusp,n_pre_fecdev,n_pre_statcast,n_pre_fecplzven,
    n_pre_tcredauto,n_pre_catcal,n_pre_formcalif,n_pre_cargos,n_pre_segdesgra,n_pre_monto,
    n_pre_fecprimpag,n_pre_fecemi,n_pre_cuentat,n_pre_codmonaseg,n_pre_monsegtries,
    n_pre_tabtrxstaau,n_pre_trxstaau;

end procedure;                                                                                                                                                         
/--

