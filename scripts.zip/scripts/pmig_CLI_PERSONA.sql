
drop procedure pmig_CLI_PERSONA;
--/
create procedure pmig_CLI_PERSONA()

define v_cli_codcred			like mig_cli_persona.cli_codcred			;
define v_cli_codmod             like mig_cli_persona.cli_codmod             ;
define v_cli_codigo             like mig_cli_persona.cli_codigo             ;
define v_cli_nombre             like mig_cli_persona.cli_nombre             ;
define v_cli_tabtipiden         like mig_cli_persona.cli_tabtipiden         ;
define v_cli_tipiden            like mig_cli_persona.cli_tipiden            ;
define v_cli_identifica         like mig_cli_persona.cli_identifica         ;
define v_cli_identificaant      like mig_cli_persona.cli_identificaant      ;
define v_cli_fveniden           like mig_cli_persona.cli_fveniden           ;
define v_cli_numruc             like mig_cli_persona.cli_numruc             ;
define v_cli_fvennumruc         like mig_cli_persona.cli_fvennumruc         ;
define v_cli_tabtipper          like mig_cli_persona.cli_tabtipper          ;
define v_cli_tipper             like mig_cli_persona.cli_tipper             ;
define v_cli_direccion1         like mig_cli_persona.cli_direccion1         ;
define v_cli_direccion2         like mig_cli_persona.cli_direccion2         ;
define v_cli_telcel             like mig_cli_persona.cli_telcel             ;
define v_cli_telfdir            like mig_cli_persona.cli_telfdir            ;
define v_cli_telfofi            like mig_cli_persona.cli_telfofi            ;
define v_cli_casilla            like mig_cli_persona.cli_casilla            ;
define v_cli_fax                like mig_cli_persona.cli_fax                ;
define v_cli_telex              like mig_cli_persona.cli_telex              ;
define v_cli_codciiu            like mig_cli_persona.cli_codciiu            ;
define v_cli_descact            like mig_cli_persona.cli_descact            ;
define v_cli_calif              like mig_cli_persona.cli_calif              ;
define v_cli_feching            like mig_cli_persona.cli_feching            ;
define v_cli_codsucact          like mig_cli_persona.cli_codsucact          ;
define v_cli_codofiact          like mig_cli_persona.cli_codofiact          ;
define v_cli_clase              like mig_cli_persona.cli_clase              ;
define v_cli_tabstatus          like mig_cli_persona.cli_tabstatus          ;
define v_cli_status             like mig_cli_persona.cli_status             ;
define v_cli_fstatus            like mig_cli_persona.cli_fstatus            ;
define v_cli_refper             like mig_cli_persona.cli_refper             ;
define v_cli_email              like mig_cli_persona.cli_email              ;
define v_cli_tabcodciud         like mig_cli_persona.cli_tabcodciud         ;
define v_cli_codciud            like mig_cli_persona.cli_codciud            ;
define v_cli_tiempores          like mig_cli_persona.cli_tiempores          ;
define v_cli_direccion          like mig_cli_persona.cli_direccion          ;
define v_cli_codeje             like mig_cli_persona.cli_codeje             ;
define v_cli_eval               like mig_cli_persona.cli_eval               ;
define v_cli_fecheva            like mig_cli_persona.cli_fecheva            ;
define v_cli_calfant            like mig_cli_persona.cli_calfant            ;
define v_cli_fcalfant           like mig_cli_persona.cli_fcalfant           ;
define v_cli_fechcalif          like mig_cli_persona.cli_fechcalif          ;
define v_cli_tabtrxstaau        like mig_cli_persona.cli_tabtrxstaau        ;
define v_cli_trxstaau           like mig_cli_persona.cli_trxstaau           ;
define v_nat_tabsexo            like mig_cli_persona.nat_tabsexo            ;
define v_nat_sexo               like mig_cli_persona.nat_sexo               ;
define v_nat_apematerno         like mig_cli_persona.nat_apematerno         ;
define v_nat_apepaterno         like mig_cli_persona.nat_apepaterno         ;
define v_nat_nombre             like mig_cli_persona.nat_nombre             ;
define v_cli_tiporeg            like mig_cli_persona.cli_tiporeg            ;

define  v_ciobl		like crt023.ciobl;
define  v_ctidn     like crt023.ctidn;
define  v_ctprs     like crt023.ctprs;
define  v_dains     like crt023.dains;
define  v_dmins     like crt023.dmins;
define  v_ddins     like crt023.ddins;
define  v_tnrso     like crt023.tnrso;
define  v_tsobl     like crt023.tsobl;
define  v_caecn     like crt023.caecn;
define  v_mpobl     like crt023.mpobl;
define  v_csexo     like crt023.csexo;
define  v_danac     like crt023.danac;
define  v_dmnac     like crt023.dmnac;
define  v_ddnac     like crt023.ddnac;
define  v_nraiz     like crt023.nraiz;
define  v_ccomp     like crt023.ccomp;
define  v_cext      like crt023.cext ;
define  v_ciant     like crt023.ciant;
define  v_tappo     like crt023.tappo;
define  v_tapmo     like crt023.tapmo;
define  v_tapco     like crt023.tapco;
define  v_tnoco     like crt023.tnoco;
define  v_mactv     like crt023.mactv;
define  v_mpart     like crt023.mpart;
define  v_minvs     like crt023.minvs;
define  v_nproc     like crt023.nproc;
define  v_ncent     like crt023.ncent;


    foreach 
        select ciobl,ctidn,ctprs,dains,dmins,ddins,tnrso,tsobl,
caecn,mpobl,csexo,danac,dmnac,ddnac,nraiz,ccomp,
cext ,ciant,tappo,tapmo,tapco,tnoco,mactv,mpart,
minvs,nproc,ncent      
{        into v_ciobl,v_ctidn,v_ctprs,v_dains,v_dmins,v_ddins,v_tnrso,v_tsobl,
v_caecn,v_mpobl,v_csexo,v_danac,v_dmnac,v_ddnac,v_nraiz,v_ccomp,
v_cext ,v_ciant,v_tappo,v_tapmo,v_tapco,v_tnoco,v_mactv,v_mpart,
v_minvs,v_nproc,v_ncent}
        from crt023

            let v_cli_codigo = decode(v_ncent, '022', 38, '023', 40, '041', 41, '004', 55);
let v_cli_codigo			=;
let v_cli_nombre            =;
let v_cli_tabtipiden        =;
let v_cli_tipiden           =;
let v_cli_identifica        =;
let v_cli_identificaant     =;
let v_cli_fveniden          =;
let v_cli_numruc            =;
let v_cli_fvennumruc        =;
let v_cli_tabtipper         =;
let v_cli_tipper            =;
let v_cli_direccion1        =;
let v_cli_direccion2        =;
let v_cli_telcel            =;
let v_cli_telfdir           =;
let v_cli_telfofi           =;
let v_cli_casilla           =;
let v_cli_fax               =;
let v_cli_telex             =;
let v_cli_codciiu           =;
let v_cli_descact           =;
let v_cli_calif             =;
let v_cli_feching           =;
let v_cli_codsucact         =;
let v_cli_codofiact         =;
let v_cli_clase             =;
let v_cli_tabstatus         =;
let v_cli_status            =;
let v_cli_fstatus           =;
let v_cli_refper            =;
let v_cli_email             =;
let v_cli_tabcodciud        =;
let v_cli_codciud           =;
let v_cli_tiempores         =;
let v_cli_direccion         =;
let v_cli_codeje            =;
let v_cli_eval              =;
let v_cli_fecheva           =;
let v_cli_calfant           =;
let v_cli_fcalfant          =;
let v_cli_fechcalif         =;
let v_cli_tabtrxstaau       =;
            
        insert into cli_persona (cli_codigo        ,   cli_nombre        ,   cli_tabtipiden    ,   
cli_tipiden       ,   cli_identifica    ,   cli_identificaant ,   cli_fveniden      ,   cli_numruc        ,   
cli_fvennumruc    ,   cli_tabtipper     ,   cli_tipper        ,   cli_direccion1    ,   cli_direccion2    ,   
cli_telcel        ,   cli_telfdir       ,   cli_telfofi       ,   cli_casilla       ,   cli_fax           ,   
cli_telex         ,   cli_codciiu       ,   cli_descact       ,   cli_calif         ,   cli_feching       ,   
cli_codsucact     ,   cli_codofiact     ,   cli_clase         ,   cli_tabstatus     ,   cli_status        ,   
cli_fstatus       ,   cli_refper        ,   cli_email         ,   cli_tabcodciud    ,   cli_codciud       ,   
cli_tiempores     ,   cli_direccion     ,   cli_codeje        ,   cli_eval          ,   cli_fecheva       ,   
cli_calfant       ,   cli_fcalfant      ,   cli_fechcalif     ,   cli_tabtrxstaau   ,   cli_trxstaau      )
        values (v_cli_codigo        ,   v_cli_nombre        ,   v_cli_tabtipiden    ,   
v_cli_tipiden       ,   v_cli_identifica    ,   v_cli_identificaant ,   v_cli_fveniden      ,   v_cli_numruc        ,   
v_cli_fvennumruc    ,   v_cli_tabtipper     ,   v_cli_tipper        ,   v_cli_direccion1    ,   v_cli_direccion2    ,   
v_cli_telcel        ,   v_cli_telfdir       ,   v_cli_telfofi       ,   v_cli_casilla       ,   v_cli_fax           ,   
v_cli_telex         ,   v_cli_codciiu       ,   v_cli_descact       ,   v_cli_calif         ,   v_cli_feching       ,   
v_cli_codsucact     ,   v_cli_codofiact     ,   v_cli_clase         ,   v_cli_tabstatus     ,   v_cli_status        ,   
v_cli_fstatus       ,   v_cli_refper        ,   v_cli_email         ,   v_cli_tabcodciud    ,   v_cli_codciud       ,   
v_cli_tiempores     ,   v_cli_direccion     ,   v_cli_codeje        ,   v_cli_eval          ,   v_cli_fecheva       ,   
v_cli_calfant       ,   v_cli_fcalfant      ,   v_cli_fechcalif     ,   v_cli_tabtrxstaau   ,   v_cli_trxstaau      );

        
    end foreach;

end procedure;
/--

