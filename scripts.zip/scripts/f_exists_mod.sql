

drop function "d_cartera".f_exists_mod;

--/
create function "d_cartera".f_exists_mod(buscado like gen_modulo.mod_codmod)
returning boolean
    if buscado in(31,32,33,34,35,36,37,38,39,40,41) then
        return 't';
    end if;
    return 'f';

end function;
/--

