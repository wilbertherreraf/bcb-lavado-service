--- para pre_tipprest
insert into gen_desctabla (des_codtab, des_codigo, des_descrip, des_codeiso, des_status, des_audittrx, des_auditusr, des_auditfho, des_auditwst) 
values (185, 38, 'BANCO POTOSI', null, 'A', '000000', 'MIGRA-CAM', current, 'MIGRA');
insert into gen_desctabla (des_codtab, des_codigo, des_descrip, des_codeiso, des_status, des_audittrx, des_auditusr, des_auditfho, des_auditwst) 
values (185, 39, 'BANCO DE CREDITO ORURO', null, 'A', '000000', 'MIGRA-CAM', current, 'MIGRA');
insert into gen_desctabla (des_codtab, des_codigo, des_descrip, des_codeiso, des_status, des_audittrx, des_auditusr, des_auditfho, des_auditwst) 
values (185, 40, 'BANCO PROGRESO', null, 'A', '000000', 'MIGRA-CAM', current, 'MIGRA');
insert into gen_desctabla (des_codtab, des_codigo, des_descrip, des_codeiso, des_status, des_audittrx, des_auditusr, des_auditfho, des_auditwst) 
values (185, 41, 'EX INALPRE', null, 'A', '000000', 'MIGRA-CAM', current, 'MIGRA');
