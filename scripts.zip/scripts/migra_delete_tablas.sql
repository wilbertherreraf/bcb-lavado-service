delete from pre_tasaspre where mtp_codmod in (38,39,40,41);
delete from pre_tramon where tmo_codmod in (38,39,40,41);
delete from cli_opergaran where ogr_codmod in (38,39,40,41);
delete from cli_clicta where clc_codmod in (38,39,40,41);
delete from pre_prestamos where pre_codmod in (38,39,40,41);
--delete from pre_categoria where cat_codmod in (38,39,40,41);
--delete from cli_lineacred where lin_codmod in (38,39,40,41);
delete from gen_cargos where crg_codmod in (38,39,40,41);
--delete from gen_parmtasa where tas_codmod in (38,39,40,41);
--delete from gen_tipproducto where tpd_codmod in (38,39,40,41);
--delete from cli_natural where mtp_codmod in (38,39,40,41);
--delete from cli_persona where mtp_codmod in (38,39,40,41);
--delete from gen_oficina where mtp_codmod in (38,39,40,41);
--delete from gen_sucursal where mtp_codmod in (38,39,40,41);
--delete from gen_desctabla where mtp_codmod in (38,39,40,41);
--delete from gen_parmgrales where mtp_codmod in (38,39,40,41);

