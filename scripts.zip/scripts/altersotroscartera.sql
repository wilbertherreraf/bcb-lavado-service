--OJO ANTES DE APLICAR VER LAS IMPLICANCIAS EN POWER BUILDER Y SCRIPTS
alter table pre_prestamos modify (pre_monto decimal(18,2))

